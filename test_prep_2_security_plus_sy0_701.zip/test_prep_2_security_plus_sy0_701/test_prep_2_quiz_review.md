# Security+ study questions — v1.1.0

Unofficial study material; verify uncertain points against trusted sources.

## SEC2-Q001

An email security gateway is advertised as providing data loss prevention. During an approved test, a restricted attachment reaches an external mailbox and the gateway immediately alerts an analyst. The requirement is to stop the attachment before delivery. Which assessment is supported by this evidence?

- A. The immediate alert meets the requirement because the gateway identified the restricted content
- B. The tested configuration provides detection but does not meet the required preventive function
- C. The configuration is corrective because an analyst can contact the recipient after delivery
- D. The product meets the requirement because its advertised control type takes precedence over test results

Answer: B

Control effectiveness depends on configured behavior and evidence. The gateway recognized restricted content, which demonstrates detection, but allowed the attachment to arrive. Meeting the stated preventive requirement would require an effective blocking or quarantine path, followed by a test confirming that delivery is stopped.

Study tip: Classify the observed behavior, then compare it with the required outcome.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Identification and prevention are different outcomes. An immediate alert can support response, but the attachment has already reached the external recipient.

B: The completed delivery demonstrates that this configuration did not prevent disclosure, even though its alert successfully detected the event.

C: The observed control only alerts. A possible later response does not demonstrate that this configuration corrected the disclosure or recovered the attachment.

D: A product can support several functions through different settings. Assessment must establish the behavior actually delivered by the deployed configuration.

## SEC2-Q002

A server agent compares a protected configuration with an approved baseline every minute. If it finds an unauthorized change, it generates an alert and restores the approved values. The unauthorized values may operate until the next comparison. Which TWO control functions are directly demonstrated? (Select TWO.)

- A. Detective
- B. Directive
- C. Compensating
- D. Preventive
- E. Corrective

Answer: A|E

One implementation can perform more than one function. Baseline comparison detects a deviation, while restoring the baseline corrects it. Because the unwanted values can operate before the next check, this evidence does not establish prevention of the initial change. Compensating describes an approved substitute, which the scenario does not identify.

Study tip: Separate what identifies an event from what repairs its effects.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Comparing the active configuration with an approved baseline identifies changes that have already occurred and generates evidence of the deviation.

B: A directive control communicates required behavior, such as an instruction or policy. This sequence detects and repairs actual configuration changes.

C: No unavailable primary control or approved substitution is described. Automation alone does not establish that a control has a compensating role.

D: The described sequence allows unauthorized values to take effect before detection. It does not block the initial configuration change.

E: Restoring approved values repairs the identified deviation after it occurs. That restoration is distinct from detecting the changed configuration.

## SEC2-Q003

A legacy payment application cannot require a second person to approve a bank-account change before it takes effect. The approved exception requires an alternative that preserves that exact objective. All changes can be forced through an external broker. Which proposal BEST satisfies the compensating-control requirement?

- A. Require clerks to record their business justification and acknowledge a warning before saving each change
- B. Let clerks make changes, then require a different employee to reconcile the changes each evening
- C. Require two authentication factors from the initiating clerk before the application accepts the change
- D. Have the broker hold each change until a separately authenticated approver releases it, and block direct changes

Answer: D

A compensating control must address the objective left unmet by the primary control. Here, timing and independence matter: a second person must approve before a change becomes effective. A broker can enforce both requirements only if the application cannot also accept an unbrokered change.

Study tip: Compare a substitute with the original security objective, including timing and bypass paths.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Justification and acknowledgment add accountability and direction, but the person initiating the change still approves their own action without independent review.

B: Reconciliation can detect inappropriate changes later, but the new bank account could take effect before independent approval, violating the stated objective.

C: Two factors provide stronger assurance about one person. They do not introduce a second person who independently approves the transaction.

D: Holding the change before execution preserves independent approval. Blocking direct access prevents a clerk from bypassing the compensating workflow.

## SEC2-Q004

A control review finds automated access enforcement and documented daily administrator checks. However, no role has authority to approve security exceptions, and unresolved exceptions accumulate without an accountable decision maker. Which addition MOST directly fills the missing managerial control?

- A. Increase the frequency of the administrators' daily access checks
- B. Require administrators to capture additional screenshots of each unresolved exception
- C. Establish exception decision authority, named accountability, and a management review process
- D. Add an automated alert whenever an exception record remains open

Answer: C

The gap concerns governance of decisions, rather than a shortage of enforcement or daily checking. Managerial controls establish responsibilities, authority, and oversight. Naming an accountable decision maker and a review process gives exceptions an authorized disposition instead of leaving administrators to infer risk acceptance.

Study tip: Authority and oversight point to managerial controls; execution and monitoring serve different roles.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: More frequent operational checks can discover issues sooner, but they do not assign authority or accountability for accepting an exception.

B: Additional evidence may help an eventual reviewer, but collecting it does not create the missing authority to evaluate and resolve exceptions.

C: Defining accountable decision makers and oversight addresses the missing management function while allowing technical and operational controls to support it.

D: An alert can expose overdue work, but another technical detection mechanism does not establish who may make the required management decision.

## SEC2-Q005

A shared training room contains laptops that are routinely powered off and disconnected from the network. The immediate requirement is to delay someone physically carrying a laptop out of the room without authorization. Which control MOST directly addresses that requirement?

- A. Attach each laptop to a fixed desk anchor using an appropriate locking cable
- B. Encrypt each laptop's internal storage using a protected recovery key
- C. Add each laptop's serial number to the asset inventory and checkout register
- D. Configure the endpoint agent to alert when a laptop connects from an unfamiliar network

Answer: A

The stated objective is a physical delay while devices are offline. A cable attached to a suitable fixed anchor supplies that delay. Encryption, tracking, and records can complement the restraint, but their benefits concern data protection, later detection, or accountability rather than physically resisting removal.

Study tip: Match the control to the asset and the specific unwanted action.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A physical restraint directly increases the effort required to remove the device and continues functioning while the laptop is powered off.

B: Encryption helps protect stored information if a laptop is stolen, but it does not physically delay removal of the device.

C: Inventory and checkout records improve tracking and accountability, but they provide no physical resistance when someone attempts to remove a laptop.

D: That alert depends on a later network connection. It supports detection after removal instead of delaying the physical act of taking the laptop.

## SEC2-Q006

A facility replaces highly visible observation patrols with concealed cameras and remote observers. Access barriers remain unchanged, and testing confirms the same detection and response times. Visitors are not informed about the new monitoring. Which control function is MOST likely reduced by removing the visible patrols?

- A. Preventive
- B. Deterrent
- C. Corrective
- D. Detective

Answer: B

Deterrence depends partly on a potential offender perceiving a security measure and deciding against an attempt. Concealed monitoring can still detect an intrusion effectively. By holding access barriers, detection time, and response time constant, the scenario isolates the likely loss of visible discouragement.

Study tip: A control can remain effective at detection while becoming less visible as a deterrent.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The physical access barriers remain unchanged. The removed patrols performed observation, so the evidence points to reduced discouragement rather than changed blocking.

B: Visible security can discourage an attempt before it occurs. Removing that visible presence can reduce deterrence even when hidden monitoring remains effective.

C: Corrective activity addresses effects after an event. The scenario preserves response timing and provides no evidence that restoration capabilities changed.

D: The scenario specifically states that testing found unchanged detection times. The meaningful difference is what potential intruders can see before acting.

## SEC2-Q007

Equipment cabinets use electronic locks that release when their shared power supply fails. Cameras depend on that same supply. The team wants a preventive layer that continues to resist opening a cabinet during this failure, without relying on staff arriving. Which change BEST meets the requirement?

- A. Add a second network connection to each electronic lock while retaining its current power arrangement
- B. Add a suitable mechanical cabinet lock with controlled keys as a separate physical barrier
- C. Require an administrator to review cabinet access logs after every power interruption
- D. Connect a second camera to the existing power supply and retain its recordings longer

Answer: B

Multiple controls are not independent merely because they are separate products. The electronic locks and cameras share a failure that defeats both. An appropriately managed mechanical cabinet lock adds prevention under the exact outage condition, while additional cameras, logs, or network paths do not address that dependency.

Study tip: Look for a common failure that can defeat several controls at once.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Network redundancy does not correct the specified power failure behavior. Both connections are irrelevant if the lock releases when power disappears.

B: A mechanical lock supplies an independent preventive barrier. Its operation does not depend on the power source shared by the existing controls.

C: A later review supports detection and accountability. It neither provides a barrier during the interruption nor removes dependence on staff action.

D: Another camera remains dependent on the same failed supply and records activity rather than physically preventing the cabinet from opening.

## SEC2-Q008

A report containing employee medical-leave details is accidentally sent to an external recipient who has no authorization to view it. The report remains accurate, and employees can still access the reporting service. Which security objective has been directly violated?

- A. Availability
- B. Confidentiality
- C. Integrity
- D. Non-repudiation

Answer: B

Confidentiality restricts disclosure to authorized recipients. Sending an accurate report to an unauthorized person violates that objective without requiring data alteration or a service outage. The scenario deliberately preserves integrity and availability so the disclosure can be assessed on its own.

Study tip: Ask whether information was exposed, changed, or made inaccessible.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The service remains accessible to its authorized users. Nothing in the scenario demonstrates an interruption or inability to obtain needed information.

B: Sensitive information reached someone without authorization to receive it. Confidentiality can fail even while the information remains accurate and available.

C: The report has not been altered. Although unauthorized disclosure is serious, the stated evidence does not identify inaccurate or modified information.

D: The scenario concerns unauthorized disclosure rather than a dispute about whether a particular party performed or approved an action.

## SEC2-Q009

Two business partners use the same secret key to generate and verify HMACs on purchase messages. A disputed message has a valid HMAC. Both partners possessed the key at the time, and there is no independent evidence identifying who submitted the message. What can the HMAC alone establish?

- A. A holder of the shared key authenticated the message, but the HMAC does not distinguish the two holders
- B. The partner whose company name appears in the message must have generated its HMAC
- C. A trusted auditor can uniquely identify the sender by independently verifying the HMAC with a copy of the same secret
- D. A valid HMAC provides non-repudiation because its output is different for different message contents

Answer: A

A valid HMAC provides message authentication and integrity relative to knowledge of the shared secret. It does not identify which of several key holders generated the message. Non-repudiation requires an attribution basis that excludes the verifier from freely creating equivalent evidence, such as appropriately controlled digital signing keys.

Study tip: Ask who can generate the same cryptographic evidence, not only who can verify it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Both partners can generate a valid HMAC with the same key. Verification therefore does not uniquely attribute the disputed message to one partner.

B: A company name inside the message is a claim protected by the shared key. Either key holder could create that claim and its HMAC.

C: Independent verification can confirm that the authenticator is valid. It cannot distinguish which of the original shared-key holders computed that authenticator.

D: Binding authentication to message contents helps detect alteration, but it does not remove the fact that both partners can compute valid authenticators.

## SEC2-Q010

A backup server must establish that an incoming connection is from an enrolled backup agent before accepting data. No employee is signing in during the connection. Which mechanism MOST directly authenticates the system making the request?

- A. Permit the connection whenever the source uses an address from the backup subnet
- B. Record the remote address and transferred byte count after the backup session ends
- C. Validate the agent's issued certificate and its proof of possession of the corresponding private key
- D. Accept an agent name in the request whenever that name appears in the inventory

Answer: C

Authentication applies to systems as well as people. The server needs evidence that the requester controls an enrolled credential, not simply a familiar label or network address. Certificate validation combined with proof of private-key possession can supply that evidence; permission to perform particular backup operations remains an authorization decision.

Study tip: An identifier states a name; an authenticator provides evidence supporting that claim.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: A network location can support an access decision, but it does not itself prove that the requester controls a particular enrolled agent identity.

B: Recording session activity provides accounting information. It does not authenticate the requesting agent before the server accepts its connection and data.

C: The validated certificate binds an enrolled identity to a public key, while private-key possession demonstrates that the requester can use its associated credential.

D: A listed name identifies an expected asset, but a requester can claim that name without proving control of an enrolled credential.

## SEC2-Q011

A Zero Trust trace shows that the policy engine granted a user access to one application. The policy enforcement point is healthy but never receives the command or connection information needed to establish that access path. Which logical component should be investigated for failing to carry out the grant decision?

- A. Policy engine
- B. Threat intelligence feed
- C. Policy administrator
- D. Subject

Answer: C

The policy engine makes the access decision, and the policy administrator carries it out by managing the path through enforcement components. A completed grant followed by missing setup instructions points to the administrator or its communication path. These are logical roles and may share a physical implementation.

Study tip: Distinguish deciding access, arranging the path, and enforcing the connection.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final

A: The trace already shows a completed grant decision. The identified failure occurs when that decision should be translated into establishment of an access path.

B: Threat intelligence can inform the policy engine's evaluation, but it is not the component responsible for executing a completed grant decision.

C: The policy administrator executes the policy decision by establishing or shutting down the communication path through instructions to enforcement components.

D: The subject requests access to a resource. It does not administer the policy-controlled connection path on behalf of the enterprise decision components.

## SEC2-Q012

Application traffic is encrypted between users and a resource gateway. However, the gateway accepts unauthenticated policy-update messages from a shared management network. A tester sends a forged update that enables an unauthorized session. Which change addresses the mechanism demonstrated by the test?

- A. Require revocation checks for certificates presented by users when establishing their application connections
- B. Authenticate authorized policy components and protect the integrity of their control-plane messages
- C. Increase the encryption key length used for the users' application traffic
- D. Add intrusion-detection signatures for unusual application requests while retaining the current policy-update message handling

Answer: B

The attack targets the control plane, which communicates decisions and instructions that govern access. Encrypting application data does not authenticate those instructions. Protecting policy-message origin and integrity, with access limited to authorized components, addresses the forged command that caused the gateway to permit the session.

Study tip: Secure the instructions controlling a connection as well as the data carried by it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final

A: Checking user certificates can strengthen user authentication. It does not authenticate the separate management messages that the gateway accepts as policy instructions.

B: The gateway must reject policy instructions from unauthorized senders and detect altered instructions. This directly protects the path used in the test.

C: Stronger application encryption does not authenticate policy commands. The attacker changed an enforcement decision through a separate management communication path.

D: Application monitoring may detect other attacks, but retaining unauthenticated policy-update acceptance leaves the demonstrated control-plane manipulation available to the tester.

## SEC2-Q013

A research team wants to observe how an intruder discovers and moves among an imitation directory service, file server, and administrative workstation. These connected decoy systems contain no production data and have controlled isolation from production. Which deception approach is being implemented?

- A. Honeytoken
- B. Honeyfile
- C. Production sandbox for application testing
- D. Honeynet

Answer: D

The defining feature is the connected set of decoy systems that supports observation of movement between hosts and services. That makes the environment a honeynet. Individual honeyfiles or honeytokens could be placed within it, but neither describes the overall network of deceptive resources.

Study tip: Use the scope of the deception: one artifact, one host, or a connected network.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A honeytoken is a planted indicator such as a credential or identifier. A collection of connected decoy services has a broader network scope.

B: A honeyfile is a decoy document or file intended to attract access. It does not describe the interconnected directory, server, and workstation environment.

C: A testing sandbox evaluates application behavior in isolation. The stated purpose is to attract and study intruder behavior across intentionally deceptive systems.

D: A honeynet combines multiple decoy systems into a network environment, allowing observation of interactions and movement among those systems.

## SEC2-Q014

A newly deployed honeyfile generates an alert every night. Each recorded read comes from the documented enterprise backup identity during its scheduled full-file backup, with no interactive session or other unexpected access. Which conclusion is BEST supported before treating these alerts as intrusions?

- A. The documented backup process explains these events; refine the detection while preserving alerts for unexpected access
- B. Suppress honeyfile alerts from any identity during the backup window because that period contains expected activity
- C. The honeyfile should be removed because a useful deception control cannot receive legitimate reads
- D. The repeated honeyfile alerts establish that an attacker has compromised the backup service

Answer: A

Honeyfile access is an investigative signal, not automatic proof of intrusion. These records match an authorized process that legitimately reads every file. The team should confirm that explanation and narrowly account for it, while retaining visibility into unusual timing, sources, operations, or other identities accessing the decoy.

Study tip: Interpret deception alerts against legitimate automated access before concluding that a human intruder is present.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The evidence supports a known operational cause. Carefully accounting for that behavior can reduce noise without abandoning detection of other readers.

B: The evidence explains reads by one documented identity. Suppressing other readers during that time would also conceal unexpected access that the backup does not explain.

C: Legitimate automated tools may access decoy files. The control can remain useful if expected activity is distinguished carefully from unexpected access.

D: The observed identity, schedule, and operation match a documented legitimate process. A deception alert warrants investigation but does not independently prove compromise.

## SEC2-Q015

A records-room entrance needs a concealed detector that triggers when a person's weight is applied to a floor mat. It does not rely on emitted radio waves, reflected sound, or body heat. Which sensor type meets this operating requirement?

- A. Microwave
- B. Pressure
- C. Ultrasonic
- D. Infrared

Answer: B

The required input is mechanical force from a person stepping on a surface. A pressure sensor converts that applied force into a detectable signal. The other choices use different physical phenomena, so they do not match the mat's specified operating mechanism.

Study tip: Match the sensor to the physical phenomenon described in the evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Microwave motion detection uses radio-frequency energy and changes in reflected signals. It does not directly measure the load applied to a floor mat.

B: A pressure sensor responds to force applied to a surface, making it suitable for detecting someone stepping on the specified floor mat.

C: Ultrasonic detection uses high-frequency sound and its reflections. The requirement instead specifies a physical load applied at a particular floor location.

D: Infrared sensing relies on infrared energy, such as changes associated with body heat. That is different from detecting pressure on a mat.

## SEC2-Q016

A security baseline requires every privileged action to be attributable to an individual. A business unit uses a different administration product from headquarters, but testing confirms named identities and complete individual action records. An analyst marks the requirement as a gap solely because the product name differs. What should the reviewer do?

- A. Close the gap because the business unit purchased an administration product from an established vendor
- B. Replace the baseline with the unit's current settings so that no deviations remain to evaluate
- C. Compare the demonstrated capability with the baseline outcome before deciding whether a gap exists
- D. Retain the gap because a baseline outcome can only be achieved with identical products

Answer: C

A gap analysis compares the actual state with a defined desired state. Here, the desired state is individual attribution, and the supplied testing supports that capability. Product differences alone do not demonstrate a security gap unless standardizing that product is itself a stated requirement.

Study tip: Identify the required outcome before treating an implementation difference as a gap.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Vendor reputation does not demonstrate individual attribution. Closure should depend on evidence that the required capability works in this environment.

B: Changing the required state merely to match existing settings removes the comparison. It does not establish whether the intended security outcome is achieved.

C: The baseline requires individual attribution rather than a particular product. Evidence that another implementation meets that outcome must inform the gap assessment.

D: Different implementations can satisfy the same security outcome. An identical-product requirement would have to be explicitly included in the baseline.

## SEC2-Q017

A contractor authenticates to one project portal and then receives network reachability to unrelated internal applications, which trust traffic from the portal subnet without another access decision. The redesign must limit a compromised portal session to its approved resource. Which TWO changes directly support that goal? (Select TWO.)

- A. Require a longer password at the portal while retaining unrestricted access from its subnet
- B. Enforce resource-specific access paths that prevent the portal session from directly reaching unrelated applications
- C. Extend the portal session lifetime so the contractor performs fewer authentication exchanges
- D. Require an explicit authorization decision for each unrelated application instead of inheriting trust from the subnet
- E. Encrypt traffic to every application while continuing to accept the portal subnet as sufficient authorization

Answer: B|D

The problem is the scope of trust after initial access. Resource-specific decisions and enforced paths reduce the ability to reuse a portal session for unrelated services. Stronger initial authentication or encrypted traffic can be useful, but neither removes the broad authorization inherited from the subnet.

Study tip: Limit what an accepted session can reach; successful authentication should not grant an entire trust zone.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final

A: A stronger initial password does not constrain the resources available to an already compromised session. The inherited network trust remains unchanged.

B: Constrained paths reduce the session's reachable scope and provide enforcement for the requirement that only approved resources be accessible.

C: A longer session increases the period in which the granted session can be used. It does not narrow access to unrelated applications.

D: Separate decisions remove the assumption that access to one network zone grants permission to every resource reachable from that zone.

E: Transport encryption protects traffic but does not decide whether the session should reach an application. The implicit authorization assumption would remain.

## SEC2-Q018

A service detects that its write queue may contain corrupted updates. Its approved protection mechanism temporarily refuses new writes while continuing to serve previously verified records. Which description BEST explains the security tradeoff made by this mechanism?

- A. It preserves integrity by accepting a temporary reduction in write availability
- B. It restores full availability because users can still read some records
- C. It gives up confidentiality to increase the number of successful write requests
- D. It preserves non-repudiation by deleting the identities associated with queued updates

Answer: A

Security objectives can require tradeoffs. The service restricts a legitimate function so uncertain updates cannot damage trusted state, prioritizing integrity over immediate write availability. Continued access to verified records preserves some availability, but users who need to write still experience a real service limitation.

Study tip: Evaluate availability for each required function, rather than treating a service as simply up or down.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Refusing uncertain updates helps prevent corrupted state, while legitimate users temporarily lose the ability to perform write operations on the service.

B: Read access remains available, but the service's legitimate write function is unavailable. Partial functionality does not demonstrate full service availability.

C: The mechanism neither discloses records to new recipients nor increases successful writes. Its behavior concerns possible corruption and restricted service functionality.

D: The scenario does not describe removing identities or strengthening attribution. It describes blocking writes whose correctness cannot currently be trusted.

## SEC2-Q019

An approved configuration change is copied successfully to a running service. The documented service behavior is to read this file only at startup, and a runtime query still shows the old values. What should the implementation plan include to make the intended configuration effective?

- A. Perform the planned service restart within the approved window, then verify the active values
- B. Refresh the management interface and accept the new configuration file timestamp as proof of activation
- C. Copy the same configuration file again and use the successful copy result as acceptance evidence
- D. Close the change because the stored configuration now matches the approved version

Answer: A

Successful deployment of a file is not the same as activation of its settings. The service explicitly reads the file only at startup, so a scoped restart is a required change step. Verification should inspect the running service after activation, with its interruption included in the approved maintenance plan.

Study tip: Check when a service loads its configuration and verify the active state after that event.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The service must start again to load the new file. A runtime check after the restart confirms that the intended values actually took effect.

B: A fresh timestamp proves that the file changed, not that the service reread it. The documented startup-only loading behavior still requires activation.

C: The file is already present. Repeating the copy does not make the running process reread settings that it loads only at startup.

D: The intended operational behavior is not yet active. Matching a file on disk does not demonstrate that the running service uses it.

## SEC2-Q020

Two firewall changes were approved independently from configuration version 40. Change A was deployed as version 41. Change B is ready as a complete replacement file based on version 40 and would remove A's required rule. What is the appropriate next step before deploying B?

- A. Reconcile B with version 41, assess the combined effects, and obtain any required review before deployment
- B. Restore version 40 first so B can be deployed against the exact configuration used during its approval
- C. Deploy B, then add A's rule back only if a user reports that the missing rule caused a failure
- D. Deploy B unchanged because its approval makes the older configuration a valid replacement

Answer: A

Version control reveals that B was prepared against a state that is no longer current. A full-file deployment could reverse an unrelated approved change. The team should reconcile the changes, evaluate their interactions, and follow the applicable review and testing process for the resulting candidate configuration.

Study tip: Compare a change with the current approved baseline, not only the version on which it was drafted.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The candidate must incorporate the current approved state. Reviewing the combined changes prevents an older replacement file from unintentionally reversing valid work.

B: That sequence intentionally removes A even though its rule remains required. Reproducing an old baseline does not justify undoing a needed change.

C: The conflict is already known. Waiting for a user-visible problem introduces avoidable risk instead of evaluating and testing the intended combined configuration.

D: Approval of B's intended change does not authorize removing A's required rule. The deployed baseline has changed since B was prepared.

## SEC2-Q021

A maintenance window ends at 23:00, when the service must be operating normally. If validation fails, the tested backout procedure needs 20 minutes, including its final checks. No extension is authorized. What is the latest time at which the team can decide to begin backout and still satisfy the window?

- A. 22:40
- B. 22:20
- C. 22:50
- D. 23:00

Answer: A

The window must contain backout execution and its verification, not only forward deployment. With a complete tested backout duration of twenty minutes, the latest mathematical decision point is 22:40. An operational plan may choose an earlier threshold for additional margin, but that is separate from the latest time requested.

Study tip: Work backward from the required restoration time and include backout verification.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Subtracting the complete twenty-minute backout duration from the 23:00 deadline gives 22:40, assuming the tested duration is met.

B: Starting at 22:20 leaves forty minutes until the deadline. It would fit, but it is earlier than the latest permissible start.

C: Only ten minutes remain at 22:50. A twenty-minute backout would finish at 23:10 and exceed the authorized maintenance window.

D: The requirement is for normal operation by 23:00, not merely a decision then. Starting at the deadline leaves no time for recovery.

## SEC2-Q022

A new appliance version passes functional tests on a single laboratory node. Production uses two nodes, and the change proposal promises uninterrupted service during a rolling upgrade. No test has exercised mixed versions or a transfer between nodes. Which missing evidence matters most to that promise?

- A. A successful failover test completed while both production nodes were still running the existing software version
- B. A representative test of mixed-version operation, state transfer, and service continuity during the upgrade sequence
- C. A screenshot showing that the production pair currently reports both nodes as healthy
- D. A longer test of the new version on the same isolated laboratory node using identical inputs

Answer: B

Test evidence must represent the mechanism supporting the promised outcome. The claim of uninterrupted service depends on clustered behavior during a mixed-version transition. Testing that sequence, including state transfer and client continuity, addresses the uncertainty that ordinary functional tests on one node cannot resolve.

Study tip: Match the test environment and sequence to the production behavior being promised.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Same-version failover establishes useful baseline behavior. It does not establish compatibility or continuity while the upgrade temporarily places different versions on the two nodes.

B: Uninterrupted rolling upgrades depend on interactions between nodes. A single-node test cannot establish compatibility or continuity during the proposed transfer sequence.

C: Current health is useful baseline information. It does not demonstrate how nodes running different versions will behave during the proposed upgrade.

D: Longer single-node testing may reveal other faults, but it still does not exercise the cluster behaviors on which the continuity promise depends.

## SEC2-Q023

An update closes a remotely exploitable flaw. The proposed backout plan restores the vulnerable version if a critical business function fails. Before approval, testing confirms that a temporary gateway restriction can block the vulnerable feature while preserving that function. What should be added to the backout plan?

- A. The tested restriction, an accountable risk decision, and a time-bound plan to regain the corrected software state
- B. A second verified backup of the vulnerable release as the sole additional protection for the restored operating period
- C. A statement that restored software is automatically acceptable because it was used successfully before the update
- D. A requirement to omit the backout plan because returning to an earlier version can create security exposure

Answer: A

A backout plan can reintroduce a vulnerability even when it restores business functionality. The validated gateway restriction provides a temporary way to limit that exposure. Approval should consider its residual risk, assign accountability, and define follow-up so the emergency operating state does not become an unexamined permanent exception.

Study tip: Assess the security of the restored state as well as whether backout makes the service work.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: This records how security exposure will be constrained during backout, who accepts the remaining risk, and how the temporary state will end.

B: Another restorable copy supports recovery from operational failure. It does not limit exploitation of the known vulnerability while that release is running.

C: Earlier operational success does not eliminate the now-known vulnerability. Backout can restore availability while also restoring an exploitable security weakness.

D: Removing recovery planning does not resolve either the operational failure risk or the security risk. Both need an explicit, reviewed treatment.

## SEC2-Q024

A tested authentication change will invalidate every active session when deployed. The application will be technically available afterward, but agents may lose unsaved customer forms and must sign in again. The change request currently lists "no downtime" and has no business coordination. What review action is MOST appropriate?

- A. Retain the current impact assessment and let the help desk document session losses after deployment
- B. Keep the no-impact assessment because a responding application endpoint demonstrates uninterrupted business operations
- C. Record the session and unsaved-work impact, then coordinate timing and user instructions with the affected business owner
- D. Choose the hour with the lowest server CPU usage and treat that metric alone as evidence of negligible business impact

Answer: C

Change impact includes business processes and people, not just whether a port continues responding. The known session invalidation threatens in-progress work and requires reauthentication. Recording that effect allows the business owner to coordinate an appropriate window, user instructions, and any measures needed to preserve work.

Study tip: Consider the user's workflow when a technically available service changes state.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A later help-desk record may describe the disruption, but it does not prepare affected users or correct the inaccurate impact assessment before the change.

B: A responding endpoint can coexist with lost sessions and unsaved work. Technical uptime does not demonstrate continuity of the users' current tasks.

C: Service availability alone does not capture user disruption. The owner and affected staff need a plan for reauthentication and preservation of in-progress work.

D: Low CPU usage does not establish that users have no active sessions or unsaved work. The known business effect still requires coordination.

## SEC2-Q025

A support-agent upgrade has passed its acceptance tests. The change record says a temporary diagnostic account is permitted only during implementation and that the support procedure must reflect the new log location before closure. The account remains enabled, and the procedure still names the old location. Which TWO actions complete the stated closeout requirements? (Select TWO.)

- A. Retain the diagnostic account until the next upgrade so that the same credentials remain available
- B. Update and verify the support procedure using the log location that the deployed agent now uses
- C. Disable the temporary diagnostic account after confirming its implementation work is complete
- D. Close the record based on acceptance tests and let the routine annual document review handle the procedure
- E. Attach the vendor's release notes to the record and retain the existing local support procedure unchanged

Answer: B|C

Closeout must address the approved temporary activities and operating documentation as well as functional success. The diagnostic account has reached the end of its authorized purpose, and the support procedure no longer matches production. Removing the temporary access and validating the revised procedure complete the two outstanding requirements.

Study tip: Track temporary access and operational instructions through change closure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Possible future convenience does not extend an account's implementation-only authorization. Any future need should receive its own appropriate access approval.

B: The stated closure condition requires an accurate operating procedure. Verifying the actual location prevents support staff from following instructions for the old version.

C: The account's authorization is limited to implementation. Retaining it after that work ends extends access beyond the approved scope of the change.

D: Passing functional tests satisfies only one part of the change. The record explicitly requires the procedure update before closure.

E: Generic release notes do not correct a local procedure that still points to the old log location. The explicit documentation requirement remains incomplete.

## SEC2-Q026

A tool embeds the bytes of a short message within an ordinary-looking image without encrypting those bytes. Someone who knows the embedding method can extract the message directly. Which description correctly identifies the technique and its protection?

- A. Steganography; the image hides the message's presence but does not itself encrypt its content
- B. Tokenization; the original message can only be retrieved from a separate token vault
- C. Asymmetric encryption; only a designated recipient can recover the message using a private key
- D. Hashing; the image contains a one-way digest that can verify but cannot recover the message

Answer: A

Steganography conceals information within an apparently ordinary carrier. The scenario explicitly says the embedded bytes are not encrypted, so discovery and extraction expose the message. Steganography can be combined with encryption, but the concealment technique alone does not provide the confidentiality property of encryption.

Study tip: Hiding that a message exists is different from cryptographically protecting its readable contents.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Embedding information inside another medium conceals its existence. Without separate encryption, successful extraction exposes the readable message to the person extracting it.

B: The message is carried inside the image, not replaced by a surrogate whose meaning depends on a separate mapping service.

C: The scenario describes direct extraction using an embedding method, with no public-private key operation. It does not establish recipient-specific cryptographic confidentiality.

D: The tool allows the original message to be extracted. A cryptographic digest does not store a reversible representation of the complete original message.

## SEC2-Q027

A purchaser ranks cryptographic products only by their advertised key bit count, placing an RSA key above an elliptic-curve key because the RSA key has more bits. Which principle should guide a valid comparison?

- A. Compare supported security strength for each algorithm and key size, because raw key lengths across algorithm families are not equivalent
- B. Prefer the shorter key because reduced storage and transmission overhead directly demonstrates greater resistance to cryptanalysis
- C. Use raw key length as the security ranking because each added bit has the same effect in every cryptographic algorithm
- D. Rank the keys by measured signature-generation time because slower signing directly measures an attacker's cryptanalytic workload

Answer: A

Key length is meaningful in the context of an algorithm. RSA and elliptic-curve systems achieve security using different mathematical structures, so their key bit counts are not directly interchangeable. A sound comparison uses recognized security-strength guidance and appropriate supported parameters rather than selecting the largest printed number.

Study tip: Do not compare key sizes across algorithm families as though they were the same unit of security.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Different algorithms rely on different mathematical problems. The same number of key bits does not imply the same resistance to the best known attacks.

B: Compact keys can provide efficiency benefits, but their size alone does not demonstrate greater attack resistance. Security strength still depends on the construction and parameters.

C: Key-length relationships depend on the algorithm family and attack methods. A universal bit-for-bit ranking would incorrectly compare different mathematical constructions.

D: Legitimate operation speed depends on algorithms, implementations, and hardware. It does not directly measure the cost of the best attack against those keys.

## SEC2-Q028

A records service starts encrypting new files with key version 8. Existing files remain encrypted with version 7 and must stay readable for their retention period. There is no evidence that version 7 was compromised. Which lifecycle treatment meets both requirements without re-encrypting the existing files now?

- A. Stop new encryption with version 7 but retain protected, authorized decryption access to it for the retained files
- B. Continue using version 7 for new files until every retained file has reached the end of its retention period
- C. Destroy version 7 as soon as version 8 is activated and let file metadata identify the missing key
- D. Change each old file's key-version label to 8 while leaving its ciphertext unchanged

Answer: A

Rotation does not automatically transform old ciphertext. The service must retain the appropriate protected decryption capability while those files remain in their required retention period. Separating new-encryption use from historical-decryption use allows version 8 to protect new records without making version 7 records inaccessible.

Study tip: A key can stop encrypting new data before it stops being needed to decrypt retained data.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: An older encryption key can have a decryption-only retention phase. New writes use version 8 while authorized reads can still process older ciphertext.

B: That would postpone the stated rotation for new encryption. Read compatibility can be maintained without continuing to encrypt new files with the older key.

C: Metadata can identify the required version but cannot replace its secret key material. Destroying version 7 would prevent decryption of the remaining files.

D: Changing a label does not change the cryptographic key that produced the ciphertext. Selecting version 8 would not correctly decrypt version 7 data.

## SEC2-Q029

An isolated appliance uses a self-signed certificate. Its approved client supports trusting one exact appliance certificate, and administrators can deliver that certificate through an authenticated management channel. All certificate validity and service-name checks will remain enabled. Which approach establishes the intended trust most narrowly?

- A. Accept the first certificate presented over an unverified connection and use its fingerprint as the approved reference
- B. Configure the client to accept any self-signed certificate whose service name matches the appliance name
- C. Distribute and verify the exact approved appliance certificate through the management channel, then configure the client to trust it specifically
- D. Disable certificate authentication but retain encryption because a self-signature cannot be used in any trusted configuration

Answer: C

A self-signature does not establish identity by itself, but a certificate can be explicitly trusted through a separate authenticated process. The approved management channel supplies that process here. Narrow trust in the verified certificate, combined with the remaining checks, is different from accepting arbitrary certificates that claim the expected name.

Study tip: Ask how trust is established, not only whether the certificate signs itself.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html|https://www.rfc-editor.org/rfc/rfc5280.html

A: An intercepted first connection could supply the attacker's certificate. The scenario provides an authenticated distribution method that avoids this initial trust uncertainty.

B: An attacker can create another self-signed certificate containing the same claimed name. Name matching alone does not establish that the issuer is trusted.

C: An authenticated distribution path establishes which certificate is intended. Trusting that exact certificate avoids accepting unrelated self-signed certificates encountered on the network.

D: A self-signed certificate can be trusted through an appropriate independent mechanism. Disabling authentication unnecessarily removes protection against an impersonated endpoint.

## SEC2-Q030

A server sends a valid leaf certificate and its issuing intermediate certificate. The chain leads to a new internal root that managed clients do not yet trust. The enterprise has independently verified and approved this root. Which action addresses the clients' trust failure?

- A. Increase the leaf certificate's expiration period while retaining the clients' current trust stores
- B. Send the root certificate from the server and assume clients will trust it because its self-signature verifies
- C. Deploy the approved root as a trust anchor through the clients' authorized configuration-management process
- D. Obtain a newly generated leaf certificate from the same intermediate while retaining the clients' existing trust configuration

Answer: C

A complete, correctly signed chain still needs an independently trusted starting authority. Receiving a root from the server cannot establish that trust by itself. Since the enterprise has verified and approved this root, controlled deployment to the intended clients addresses the missing trust anchor while preserving normal chain validation.

Study tip: A supplied certificate chain and a locally trusted root solve different parts of validation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html|https://www.rfc-editor.org/rfc/rfc5280.html

A: The failure concerns an untrusted issuer path, not the leaf validity period. Extending expiration does not add the root to client trust policy.

B: A server can send a root certificate, but that does not make it a trusted anchor. An attacker can also create a valid self-signature.

C: Trust anchors are established by client trust policy. Controlled deployment of the approved root allows the already supplied chain to terminate at a trusted authority.

D: A newly issued leaf would still chain to the untrusted root. Replacing the server certificate does not address the missing client trust anchor.

## SEC2-Q031

At 14:00 UTC, a client evaluates a certificate that passes identity, chain, and validity-period checks. Its cached CRL has a valid issuer signature, thisUpdate 12:00 UTC, and nextUpdate 13:00 UTC today. The serial number is absent. Policy requires current revocation information and denies access if it cannot be obtained. What should the client do?

- A. Accept the certificate because a valid CRL signature makes its revocation information current
- B. Treat the certificate as definitely revoked because the cached CRL has passed nextUpdate
- C. Obtain current revocation information and deny access if that attempt cannot satisfy the stated policy
- D. Accept the certificate until its own expiration because its serial number is absent from the cached CRL

Answer: C

At 14:00, the cached CRL is beyond its 13:00 nextUpdate value. Its valid signature proves origin and integrity, not freshness. The certificate might still be valid, but this evidence cannot satisfy the stated policy. The client must obtain current status information or deny access as that policy requires.

Study tip: Keep authenticity, freshness, and the certificate's actual revocation status separate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html|https://www.rfc-editor.org/rfc/rfc5280.html

A: The signature authenticates the CRL contents but does not extend their freshness. The specified nextUpdate time has already passed.

B: A stale CRL does not establish that a particular certificate was revoked. It means the client lacks the current status evidence required by policy.

C: The cached list is stale at 14:00. The client must refresh status evidence, with denial required if current information remains unavailable.

D: The certificate's validity period does not override revocation checks. Absence from an outdated list cannot satisfy the explicit current-information requirement.

## SEC2-Q032

A supplier writes an incorrect laboratory measurement to a shared blockchain ledger using its authorized account. The network accepts the transaction normally, and no ledger history is altered afterward. Which conclusion about this record is justified?

- A. Consensus makes the laboratory value accurate because multiple nodes accepted the same transaction
- B. An additional valid digital signature on the transaction would independently verify the physical measurement
- C. The supplier's authorized account guarantees that the record matches the physical sample tested
- D. The ledger can preserve evidence of what was recorded without proving that the original measurement was true

Answer: D

A ledger can provide strong evidence about the sequence and contents of accepted records while faithfully preserving a false input. The scenario involves an authorized but inaccurate submission, not tampering with history. Reliable measurement, validation, and source controls remain necessary for claims about the physical world.

Study tip: Integrity of a recorded history does not automatically establish truth of the original input.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/ir/8202/final

A: Consensus on an accepted transaction does not independently repeat or verify the physical measurement. Participants can agree to preserve an incorrect submitted value.

B: A signature can bind a signer to the submitted data, but cryptographic verification does not independently test whether that data accurately describes a sample.

C: Authorization identifies who may submit data; it does not ensure that each submitted value accurately describes a real-world event or measurement.

D: Tamper resistance concerns the recorded history. Accuracy of external input still depends on the measuring process and trustworthy submission of its result.

## SEC2-Q033

An application stores salted password hashes with each record's algorithm and work factor. The approved work factor increases after performance testing. The team wants active users migrated during successful sign-in without collecting a separate plaintext-password database. Which implementation is appropriate?

- A. Encrypt the existing hash database under a new storage key and mark every account as migrated to the increased work factor
- B. Verify using the record's current parameters, then rehash the successfully supplied password with the new settings and a fresh salt
- C. Replace each record's old work-factor label with the new value while leaving the stored hash unchanged
- D. Hash the supplied password with the new work factor first and compare that output directly with every old hash

Answer: B

Each stored verifier must be checked using its own parameters. After a successful authentication, the application can use the supplied password to create a replacement with the approved settings and salt, without retaining plaintext. Accounts that do not sign in will need a separate lifecycle policy if old verifiers must be retired.

Study tip: Changing hashing parameters requires computing a new verifier, not editing its metadata.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html|https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html

A: Storage encryption protects a separate boundary. It does not recompute the password verifiers or increase the work factor used to evaluate password guesses.

B: A successful login supplies the password transiently and proves it matches the old verifier. The application can then replace that verifier with a stronger one.

C: The stored hash was computed with its original parameters. Relabeling those parameters does not recompute the verifier and can cause valid password checks to fail.

D: Changing the work factor changes the computed verifier. The application must first check an old record using the parameters that originally produced it.

## SEC2-Q034

A passive adversary records a completed TLS session that used authenticated ephemeral Diffie-Hellman key exchange. Both endpoints later erase the ephemeral private values and session secrets. Months afterward, the adversary steals only the server's long-term certificate signing key. Assuming sound cryptography and no earlier compromise, what protects the recorded session?

- A. TLS record sequence numbers prevent recorded ciphertext from being processed for offline decryption outside its original connection
- B. The session key depended on ephemeral secrets, so the later signing-key compromise alone does not recover it
- C. Revoking the stolen certificate retroactively changes the ciphertext captured by the passive adversary
- D. The public certificate becomes sufficient to decrypt the recording once its private signing key is known

Answer: B

Forward secrecy limits the effect of later long-term key compromise on earlier sessions. In the specified exchange, the certificate key authenticates fresh ephemeral key agreement, while separate ephemeral values establish session secrets. With those secrets erased and no earlier compromise, possession of the signing key alone does not reveal the old traffic keys.

Study tip: Check which secret established the traffic key and whether that secret survived the session.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final|https://www.rfc-editor.org/rfc/rfc8446.html

A: Sequence numbers support record ordering and protection against replay within TLS. They do not independently prevent an adversary from attempting offline decryption of captured traffic.

B: Fresh ephemeral key exchange separates session-secret derivation from the long-term authentication key. Erasure prevents later recovery of those ephemeral secrets from the endpoints.

C: Revocation can help reject future use of the compromised credential, but it does not modify previously captured packets or their encryption keys.

D: The signing key authenticated this exchange; it was not used to transport the session secret through decryptable RSA key transport.

## SEC2-Q035

A shared database must protect each customer record with a different encryption key so that one record can be re-encrypted under a replacement key without re-encrypting the other records. The application and key service support this design. Which encryption granularity MOST directly meets the requirement?

- A. Transport encryption using one session key for each connection to the database
- B. Record-level encryption using a separately managed key for each customer record
- C. Full-disk encryption using one key for the database server's system disk
- D. Volume encryption using one key for the database storage volume

Answer: B

The required unit of independent cryptographic change is one customer record. Record-level encryption with separately managed keys aligns that unit with the key lifecycle. Broader disk or volume encryption can still complement the design, and transport encryption remains useful, but none of those alone provides the stated per-record behavior.

Study tip: Choose an encryption boundary that matches the unit requiring an independent key lifecycle.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Transport encryption protects data while it travels over a connection. Its session keys do not supply persistent, independently managed encryption for stored records.

B: Encrypting at the record boundary with distinct keys permits one record's cryptographic protection to change without re-encrypting all other records.

C: Full-disk encryption protects the storage device as a unit. A single disk key does not provide the required independent key for each customer record.

D: A shared volume key operates at a broader storage boundary. It does not create the specified independent encryption lifecycle for individual records.

## SEC2-Q036

A workstation's disk-key release policy is bound to TPM measurements of its approved boot state. After an authorized firmware update, automatic release fails because the measured state no longer matches that policy. The TPM passes its hardware checks, and protected recovery material is available. Which TWO conclusions are supported? (Select TWO.)

- A. The recovery process should validate the new boot state and use the authorized recovery material before establishing an appropriate updated release policy
- B. Moving the encrypted drive to another healthy TPM should preserve automatic release under the original workstation's measurement-bound policy
- C. A legitimate firmware change can alter measured boot values and trigger recovery without implying that the TPM hardware failed
- D. The failed automatic release establishes that the disk ciphertext was damaged by the firmware update and must be restored from backup
- E. Passing the TPM hardware checks proves that every newly measured boot component should be trusted automatically

Answer: A|C

A TPM can condition key use on measured platform state. An authorized firmware update can change those measurements, causing the existing release condition to fail even when hardware and ciphertext remain intact. The appropriate recovery path validates the intended state and uses authorized recovery material before updating how future automatic release is permitted.

Study tip: A boot-measurement mismatch is evidence of a changed state, not by itself proof of hardware failure or malicious code.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final|https://learn.microsoft.com/en-us/windows/security/hardware-security/tpm/trusted-platform-module-overview

A: Validation distinguishes the intended update from unexpected changes. Authorized recovery restores access while preserving a reasoned policy for future automatic release.

B: Another TPM and platform do not automatically satisfy the original key protection and release conditions. Moving the drive does not resolve the stated policy mismatch.

C: The release policy compares measured state with an expected state. A legitimate software change can produce a mismatch even when the hardware functions correctly.

D: The identified failure is a measurement-policy mismatch. That does not demonstrate corrupted encrypted data or a need to replace the disk contents.

E: Hardware health does not establish that measured software is authorized. The changed values still need to be evaluated against the intended approved update.

## SEC2-Q037

A warehouse employee intentionally gives a criminal group a valid loading-dock badge and shipment schedules in return for payment. The group uses that assistance to steal inventory. Which assessment BEST describes the relationship between the actors?

- A. An authorized contractor is using delegated physical access for assigned duties
- B. A malicious insider is enabling an external criminal operation
- C. An unintentional insider disclosure enabled opportunistic theft
- D. External social engineering succeeded without participation by a trusted insider

Answer: B

Threats can involve cooperation between different actor types. The employee contributes trusted physical access and business knowledge, while the outside group performs the theft. Classify each participant by their relationship and conduct rather than assuming that everyone using a valid credential is an authorized insider.

Study tip: Classify the person separately from the credential the person presents.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: The access was supplied to facilitate theft, with no authorized contractor role or assigned logistics duty supporting the criminal group's actions.

B: The employee deliberately abuses trusted access, while the separate criminal group benefits from that insider assistance to carry out theft.

C: The employee knowingly trades access for payment, which distinguishes deliberate collusion from an accidental release that outsiders later discover.

D: The employee deliberately supplies access and schedules for payment, so the incident includes active insider participation rather than only outside deception.

## SEC2-Q038

An intruder deploys unauthorized cryptocurrency-mining workloads on a company's cloud account. Billing rises sharply, and mining proceeds go to a wallet controlled by the intruder. No ransom demand or stolen business records are found. Which motivation is directly supported?

- A. Blackmail based on threatened disclosure of customer records
- B. Financial gain by using the victim's computing resources
- C. Espionage focused on confidential business intelligence
- D. Political advocacy through public disruption

Answer: B

Financially motivated attacks do not require a payment demand to the victim. Here, the attacker monetizes cloud capacity directly and transfers the operating expense to the company. Increased cost is an impact on the victim, while receipt of mining proceeds establishes the attacker's demonstrated financial objective.

Study tip: Follow the benefit to the attacker; financial gain can come from resources rather than extortion.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: No disclosure threat or payment demand is present; the demonstrated income comes from mining with the victim's resources.

B: The intruder receives mining proceeds while the company pays for computation, directly connecting unauthorized resource use to a financial benefit.

C: The observed workload generates mining revenue rather than collecting strategic information, so espionage is not the motivation established by this evidence.

D: The evidence includes a revenue destination but no public cause or political demand that would support advocacy as the primary motivation.

## SEC2-Q039

A benefits employee accidentally attaches the full employee census instead of an approved summary to an external email. Investigation confirms a mistaken attachment selection and finds no deliberate disclosure. Which assessment BEST fits the established facts?

- A. The release was authorized because the employee had legitimate access to the source file
- B. The sensitivity of the attachment establishes deliberate insider data theft
- C. An unintentional insider action caused a confidentiality incident
- D. An external account compromise is the established cause of the message

Answer: C

Insider risk includes mistakes as well as intentional abuse. The employee's legitimate access created the opportunity for an accidental disclosure, but it does not establish malicious intent. Response and prevention should address the actual event while keeping conclusions about the person's motivation consistent with the evidence.

Study tip: A harmful outcome and malicious intent are different findings.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: Permission to read sensitive information does not authorize sending it to an unintended external recipient, even when the disclosure is accidental.

B: The data's sensitivity explains the impact of disclosure but does not establish malicious intent beyond the mistaken selection confirmed by the investigation.

C: An employee with legitimate access can cause an incident through error, and the investigation establishes accidental rather than deliberate disclosure.

D: The investigation attributes the message to the employee's attachment mistake and provides no evidence that another person controlled the account.

## SEC2-Q040

A group locks a public organization's files, demands a policy reversal rather than money, and publishes statements supporting its political cause. Analysts initially label the campaign ordinary financial ransomware because files were encrypted. Which evidence MOST directly challenges that motivation assessment?

- A. The campaign encrypted files rather than immediately deleting them
- B. The group's demands and public statements identify an ideological objective
- C. The malware used components also observed in financially motivated incidents
- D. The campaign affected several departments during the same time window

Answer: B

The same technical method can serve financial, political, retaliatory, or destructive goals. The demands explain what the group wants to achieve, while encryption explains how it pressures the victim. Assess motivation using that distinction rather than assigning intent automatically from a familiar attack tool or payload.

Study tip: A technique describes the method; demands and objectives provide stronger evidence of motivation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: The technical choice may support several coercive objectives; encryption by itself does not distinguish a political demand from an intended financial payoff.

B: The requested policy reversal and stated cause directly describe the desired outcome, unlike the encryption mechanism used to apply pressure.

C: Tool reuse can connect techniques without establishing identical motivations, so shared components are weaker evidence of intent than the group's explicit demands.

D: The operational scope describes how widely the attack reached, but does not explain the outcome the group wanted from its victim.

## SEC2-Q041

A criminal organizer cannot develop exploits but pays a specialist for access and rents the infrastructure needed to operate a campaign. The resulting attacks are technically capable. Which planning assumption is MOST appropriate for defenders?

- A. Base future planning only on the currently observed tool version, excluding further purchases
- B. Assess the capabilities the actor can obtain as well as the actor's personal skills
- C. Rate the campaign using only the organizer's demonstrated programming skills
- D. Treat infrastructure funding as unrelated business information rather than a threat attribute

Answer: B

Threat capability is not limited to tools an actor can build personally. An actor can acquire access, specialist services, and infrastructure, making resources and relationships operationally important. Defenders should evaluate the resulting capability without assuming either personal technical expertise or harmlessness from the organizer's programming skills.

Study tip: Purchased capability still counts when assessing what a threat actor can accomplish.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: The established ability to acquire components makes adaptation relevant, so planning that excludes further purchases understates the actor's available options.

B: Funding and access to specialists can supply effective capabilities even when the organizer lacks the expertise to create those capabilities personally.

C: A skill-only rating omits purchased access and specialist services that can give the operation capabilities beyond the organizer's own technical knowledge.

D: The scenario connects funding directly to access and operational infrastructure, making it relevant evidence about the capability the organization may face.

## SEC2-Q042

During an armed conflict, an attributed military cyber unit deliberately overwrites a logistics provider's scheduling data and disables dispatch services. No recovery offer or collection of documents is observed. Which immediate objective is BEST supported?

- A. Covert collection of business records for later intelligence analysis
- B. Disruption of the opponent's operational capability
- C. Financial extortion through sale of a working decryption service
- D. Ethical validation of the provider's disaster-recovery process

Answer: B

Actor identity and observed actions can support a particular objective without proving every strategic intent. Here, destruction and disabled dispatch establish an effort to impair operations. The lack of a demonstrated recovery offer also makes ordinary payment-for-restoration extortion a weaker explanation than the observed disruption.

Study tip: Destruction that removes a business capability can be the objective, rather than leverage for payment.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: Document collection is not observed, while the confirmed destructive actions directly establish operational disruption as the immediate effect sought.

B: Destroying scheduling data and disabling dispatch directly impair logistics operations, consistent with a destructive objective in the stated conflict context.

C: The evidence describes destructive overwriting and no recovery offer, rather than a demonstrated business model based on selling restoration to the victim.

D: The operation is an attributed hostile action during conflict, with no assessment authorization or agreed testing conditions supporting an ethical exercise.

## SEC2-Q043

Analysts are comparing competitive market research with possible espionage against a manufacturer. Which observation provides the STRONGEST evidence of unauthorized intelligence collection rather than ordinary research from public sources?

- A. Repeated failed sign-ins appear at the private bidding portal without a successful session
- B. A compromised account selectively exports unpublished bids to a competitor-controlled destination
- C. A market analyst accesses the company's approved subscription to industry pricing data
- D. A competitor's address downloads many public product manuals late at night

Answer: B

The strongest observation combines an unauthorized access method with selection of nonpublic information valuable to a competitor. Public information gathering can also support adversaries, but it does not by itself demonstrate espionage. The scenario asks which evidence crosses that evidentiary threshold, not whether market research is always benign.

Study tip: Look for unauthorized access and nonpublic intelligence value before labeling ordinary research as espionage.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://attack.mitre.org/tactics/enterprise/

A: Failed sign-ins may indicate attempted access, but without successful retrieval they do not demonstrate completed intelligence collection as strongly as the confirmed export.

B: The unauthorized account use, nonpublic bid selection, and competitor-controlled destination jointly support covert collection of commercially valuable information.

C: Authorized use of a business information subscription is compatible with legitimate research and lacks the unauthorized private-data access shown by the stronger evidence.

D: Unusual volume or timing can justify review, but the material is public and the observation does not establish unauthorized collection of confidential intelligence.

## SEC2-Q044

A researcher follows a published authorization scope, demonstrates a defect without accessing other users' data, and reports it through the program's required channel. The program pays the advertised reward. Which statement about motivation is MOST accurate?

- A. Treat stated good intentions as stronger evidence of authorization than the published scope
- B. Ethical security improvement and financial reward can motivate the same authorized work
- C. Classify the reward as coercive leverage because the report describes a defect
- D. Payment proves the researcher may test any system owned by the organization

Answer: B

Motivations need not be exclusive. A researcher can seek both a reward and improved security while operating within an authorized program. The permission and behavior distinguish the described work from coercive activity. Neither receiving payment nor claiming good intentions expands the testing scope or waives the program's conditions.

Study tip: Evaluate authorization and conduct separately from the existence of an advertised research reward.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/115/final

A: Good intentions do not replace the agreed rules; compliance with the authorized scope and reporting conditions remains part of legitimate research.

B: Compensation under an authorized research program can coexist with ethical security improvement; receiving a reward does not itself turn the work into extortion.

C: An agreed reward differs from a coercive payment demand, and the researcher followed the program's authorization and reporting conditions.

D: Compensation does not broaden authorization beyond the published scope, which continues to define the systems and activities permitted for the research.

## SEC2-Q045

In Case A, an employee mistakenly publishes an internal planning file. In Case B, an unrelated criminal steals that employee's session and downloads another file. Which TWO classifications are supported by the identified people and actions? (Select TWO.)

- A. Case B should be classified as ordinary employee activity because its session was accepted
- B. Case A is external activity because the file became visible outside the company
- C. Case B involves an external actor using an internal account's session
- D. Case A demonstrates an unintentional insider action
- E. Case A establishes malicious insider intent because the file was internal

Answer: C|D

Account identifiers, actor relationships, and intent describe different aspects of an event. A legitimate employee can make an unintentional disclosure, while an outsider can later impersonate that employee using a stolen session. Accurate classification follows the identified person and evidence, not merely the username recorded by the application.

Study tip: A log's account name is not automatically the identity of the person controlling the session.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: Technical acceptance of a stolen session does not authorize its criminal holder or establish that the legitimate user initiated the action.

B: The destination of the exposure does not change who performed the action; the identified employee is still the internal actor.

C: The criminal remains external to the organization despite presenting a session associated with an employee's identity to the application.

D: The actual employee performs the mistaken publication using organizational access, so the event involves an insider even without malicious intent.

E: The file's internal status describes its intended audience, while the scenario identifies a mistake rather than evidence of deliberate employee misconduct.

## SEC2-Q046

An email contains a picture of a QR code and asks the employee to scan it with a personal phone to renew work access. The email has no clickable link. The code opens a counterfeit sign-in page; no image-parser defect is involved. Which mechanism BEST explains the risk?

- A. The image exploits the email viewer's parser to execute code on the original workstation
- B. The attack replays employee credentials already stolen in an unrelated breach
- C. The code poisons the legitimate portal's DNS record before the user visits it
- D. The image carries a destination that moves the phishing interaction to another device

Answer: D

An image can deliver a social-engineering instruction without exploiting image-processing software. The QR code sends the user to a counterfeit page and can shift the interaction away from the original device's controls. Evaluate the decoded destination and the requested account action rather than treating the image format as a safety signal.

Study tip: An image-based vector can carry instructions or a URL without exploiting an image parser.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: The scenario excludes a parser exploit; the harmful step is following the encoded destination and interacting with the counterfeit login page.

B: The observed entry mechanism directs the user to a counterfeit login page, rather than submitting previously stolen credentials to the real service.

C: The QR code supplies a different destination directly, and there is no evidence that the legitimate portal's DNS information was changed.

D: Scanning translates the visual code into a destination, allowing a phishing workflow even though the email contains no ordinary clickable hyperlink.

## SEC2-Q047

A collaboration message appears under the display name of the IT director and requests that an employee install a remote-access tool. The profile is actually an external guest with a similar name. Which check MOST directly addresses the trust mistake?

- A. Ask the same profile to repeat the director's publicly listed job title
- B. Approve installation if the message uses the organization's normal logo
- C. Verify the actual account identity and request through an established internal contact path
- D. Accept the request because it arrived inside the corporate collaboration application

Answer: C

Message-based social engineering also occurs in collaboration tools. Display names and logos are presentation details, while the account's actual identity and guest status reveal the trust relationship. An independent established contact path can verify the request without continuing to rely on the same potentially fraudulent profile.

Study tip: A trusted messaging platform does not make every profile or request inside it trustworthy.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Public role information is available to impersonators and does not independently establish that the profile belongs to the director.

B: Branding can be copied into messages or profiles and does not validate the external account's authority to request remote-access installation.

C: Checking the account's external status and using a trusted contact path tests the claimed identity instead of relying on an easily copied display name.

D: A trusted platform can carry messages from external or compromised accounts, so the application's presence does not authenticate the claimed sender's role.

## SEC2-Q048

A mail gateway delivers a password-protected archive. Its report says outer_message_checks=pass, archive_contents=not_inspected, reason=decryption_key_unavailable. A user-readable note includes the archive password. Which interpretation BEST describes the file-based threat exposure established by the report?

- A. Passing the outer-message checks leaves the encrypted archive's payload unassessed by the stated scan
- B. Passing the outer-message checks establishes that the inner files were scanned and cleared for execution
- C. Failure to decrypt the archive establishes a confirmed malware detection that requires incident containment
- D. The user-readable password establishes that the gateway inspected the payload during a later stage

Answer: A

Encrypted containers can limit content inspection when a control lacks the decryption material. Successful checks on the outer message do not establish the safety of its uninspected inner files. Apply the organization's handling procedure for uninspectable attachments while preserving the distinction between an unknown payload and a confirmed malicious or clean verdict.

Study tip: Distinguish uninspected content from both a clean verdict and a positive malware finding.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The report explicitly separates successful outer-message checks from uninspected inner content, so it provides no payload-safety verdict for the encrypted archive.

B: The passing result applies to outer-message checks, while the archive-content field explicitly says inspection did not occur because the key was unavailable.

C: Lack of inspection creates uncertainty rather than a positive malware finding; additional analysis is needed before classifying the archive as confirmed malicious content.

D: Providing a password to the recipient does not demonstrate that the gateway used it, and no later inspection result is supplied.

## SEC2-Q049

A phishing message directs an employee to a real cloud-provider consent page for an attacker-controlled application. The employee approves permission to read mailbox contents. No password is entered into an imitation site. Which boundary has the deception targeted?

- A. The user's decision to delegate access to an untrusted application
- B. The user's decision to install a new certificate authority into the browser trust store
- C. The user's membership in the cloud platform's administrator role
- D. The mailbox password's resistance to offline guessing

Answer: A

Social engineering can target delegated authorization rather than credential entry. A genuine provider can present the consent interface while the application requesting access belongs to an attacker. The security decision therefore includes whether that application is trusted and whether its requested permissions match an approved business need.

Study tip: A genuine login or consent page does not establish that the requesting application deserves access.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: The attacker obtains an authorization grant through deceptive consent, allowing the malicious application to use delegated access without capturing the user's password.

B: No certificate installation occurs; the user grants application permissions through a genuine consent page without changing the browser's certificate trust configuration.

C: The action delegates mailbox access to an application, rather than granting the employee a new platform-wide administrator role.

D: The described access comes from an approved application grant, not recovered password material or attempts to guess the mailbox secret.

## SEC2-Q050

An unexpected document claims its invoice is unreadable until the recipient disables protected viewing and enables embedded macros. The invoice should require only viewing. Which feature of the request is the STRONGEST warning sign?

- A. The sender chose an attachment instead of putting the invoice total in the message
- B. It asks the user to enable executable content that the viewing task does not require
- C. The document uses a common office-file format rather than a custom extension
- D. The invoice contains a page explaining its required viewing steps

Answer: B

The lure tries to make a security restriction appear to be a formatting problem. Enabling embedded macros changes the task from reading a document to running its active content. The stated viewing requirement provides a concrete reason to reject that unnecessary privilege or capability change and follow the reporting process.

Study tip: Compare the requested capability with what the claimed business task actually needs.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Attachments are normal in many workflows; the specific risk is the unnecessary request to disable protection and run embedded active content.

B: The instruction attempts to cross an execution boundary by persuading the user to enable active content unrelated to simply reading the invoice.

C: Common document formats are used for both legitimate and malicious content, so format familiarity is less informative than the unnecessary execution request.

D: Instructions alone can be legitimate; the security concern comes from instructions that demand executable behavior and weakened protection for a passive viewing task.

## SEC2-Q051

A workstation blocks USB mass-storage devices. During an approved test, a different USB device identifies itself as a keyboard and generates input that the workstation accepts. Which limitation does the test demonstrate?

- A. A storage-only policy does not cover every USB device class
- B. The storage block failed to recognize the test device's filesystem
- C. The user's account password was bypassed through repeated authentication guesses
- D. A file-content filter on mounted storage volumes is the control that failed in this test

Answer: A

USB is a connection system supporting multiple device functions. Blocking storage does not necessarily block devices presenting as keyboards or other classes. The approved test demonstrates the scope of the existing control, supporting a broader device-admission policy where the business environment requires stronger restrictions.

Study tip: Distinguish the USB connection from the specific device classes a policy actually controls.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The control blocks mass storage, while the test device uses the human-interface class, exposing a separate capability outside that policy's coverage.

B: The device presents as a keyboard rather than a storage volume, so filesystem recognition is not the security boundary exercised by the test.

C: The evidence describes accepted device input, with no password-guessing sequence or authentication result establishing an account-password attack.

D: The device supplies keyboard input rather than mounting a storage volume, so a file-content inspection policy is not the boundary the test exercised.

## SEC2-Q052

An unattended meeting-room Ethernet jack gives any connected laptop direct access to internal services. The wireless network already requires individual authentication. Which exposure remains despite the wireless controls?

- A. A switch-console attack requiring privileged access to the equipment cabinet
- B. A wireless authentication-server certificate validation failure
- C. An unauthorized guest SSID that bridges visitors onto the corporate wireless network
- D. An unauthenticated wired attachment point that provides a separate network entry path

Answer: D

Security coverage must include every available attachment path. Strong wireless admission does not secure a wired jack whose switch port grants internal access without verification. The exposed path exists because network reachability is provided before the organization establishes whether the attached device should receive it.

Study tip: Check alternate connection paths instead of assuming one secured access method protects every interface.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The meeting-room jack already grants access without a console session, so the exposure does not require the additional privileged equipment access described here.

B: The described access does not use wireless authentication, so no certificate-validation failure in that separate system is needed to explain the wired entry path.

C: The observed connection comes from a physical Ethernet jack, with no guest wireless network or SSID configuration involved in the demonstrated access.

D: The Ethernet connection bypasses the wireless admission controls, giving an unverified device a distinct route to the internal services described.

## SEC2-Q053

A build expects an internal library named inventory-utils. Its package resolver also searches a public registry and chooses an unrelated higher-version package with that name. The public package enters the application without approval. Which trust mistake MOST directly enabled this supply chain exposure?

- A. The resolver treated a matching name from an untrusted source as the intended internal dependency
- B. The package download lacks confidentiality even though the correct publisher was selected
- C. The application lacks a runtime firewall rule restricting its public web listener
- D. The private package's lower version number alone makes it an untrusted dependency

Answer: A

Dependency identity includes its trusted source, not merely a familiar name and a preferred version number. The build crossed a supply chain boundary by allowing a public artifact to satisfy an internal dependency. Controlled registry selection and authenticated dependency records help prevent unintended source substitution in this workflow.

Study tip: A matching package name and a larger version number do not establish the intended publisher or source.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: The package name did not establish source identity, and resolution rules allowed an unrelated public artifact to replace the approved internal component.

B: The scenario identifies selection of an unrelated package, not interception of a correctly selected artifact, so source identity is the demonstrated failure.

C: The substitution happens during dependency resolution before runtime, so an application listener rule does not explain the build's acceptance of the wrong package.

D: A version number does not establish provenance; the problem is substituting an unrelated public source for the intended trusted internal component.

## SEC2-Q054

A sponsored search result uses a payroll provider's logo and directs employees to secure-helpdesk.example, a domain the provider does not own. The domain is not a misspelling of the real one. Which deception is MOST directly demonstrated?

- A. Typosquatting that relies on a user mistyping the real domain
- B. Brand impersonation using familiar visual identity
- C. DNS poisoning of the payroll provider's authoritative zone
- D. A legitimate authorization created by the site's valid HTTPS certificate

Answer: B

Brand impersonation uses recognizable names, logos, or presentation to borrow trust. It can operate on an unrelated domain and therefore need not be typosquatting. A paid advertisement or valid HTTPS certificate also does not establish that the payroll provider owns or endorses the destination.

Study tip: Separate domain ownership from visual branding and connection encryption.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: The scenario explicitly gives an unrelated domain rather than a mistyped variant, so copied branding is the demonstrated mechanism.

B: The site borrows a trusted provider's branding to make an unrelated destination appear legitimate, without depending on a spelling mistake.

C: No legitimate DNS record is shown as modified; the sponsored result directs users to a separate domain using misleading presentation.

D: A certificate can authenticate the unrelated domain's connection but does not grant permission to represent another company's brand or collect its users' credentials.

## SEC2-Q055

A traveling employee connects a laptop to an open conference network. HTTPS protects the employee's web sessions, but the laptop's file-sharing service accepts connections from other attendees on the same network. Which exposure is unaffected by the web-session encryption?

- A. Local peers can directly reach the laptop's separately exposed sharing service
- B. A false VPN gateway has intercepted the employee's corporate tunnel
- C. An office-gateway rule permits unauthorized database requests from the conference network
- D. Failed certificate validation lets the conference network modify the employee's protected web pages

Answer: A

A protected application connection is not a blanket shield around the endpoint. Other listeners may remain accessible to devices on the same network. Assess the local network as untrusted and control host-service reachability separately from the encryption protecting the employee's web traffic.

Study tip: Connection-level protection does not automatically close unrelated listening services on the same host.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: HTTPS protects particular web sessions, while the file-sharing service is another listener reachable by untrusted peers through the local network.

B: No VPN session or gateway impersonation is described, while direct peer access to the file-sharing listener is explicitly established.

C: The described connection is between local conference peers and the laptop, with no evidence that office-gateway routing or database access creates this exposure.

D: The scenario states that HTTPS protects the web sessions and provides no certificate-validation failure; the demonstrated exposure is a separate inbound sharing service.

## SEC2-Q056

A clinician uses an approved Bluetooth headset, so Bluetooth must remain enabled. A new pairing prompt appears while the clinician is in a public waiting area, but no device is being intentionally added. Which response BEST addresses the immediate risk?

- A. Accept the request because Bluetooth devices must be physically nearby
- B. Approve any device whose displayed name includes the organization's name
- C. Reject the unsolicited pairing and verify approved pairing requests through the established procedure
- D. Accept the new pairing temporarily and remove it at the end of the shift

Answer: C

When a wireless capability has a real business purpose, the appropriate decision may be to reject a new unauthorized relationship rather than disable the capability entirely. The unsolicited prompt supplies no approved pairing intent. Device proximity and a familiar name are weak substitutes for an established enrollment procedure.

Study tip: Required wireless service does not mean accepting every nearby device's request to establish trust.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Nearby presence does not establish authorization or ownership, especially in a public area where unrelated devices are within radio range.

B: A device name can be chosen to imitate trusted equipment and does not independently verify that the pairing request is approved.

C: Rejecting an unrequested trust relationship preserves the required headset function while preventing an unidentified nearby device from being paired through a reflexive approval.

D: A later removal does not justify establishing the unapproved relationship now, and the unfamiliar device has no verified business need for temporary access.

## SEC2-Q057

An employee shares an old outage notice, sincerely believing it describes a current incident. Investigation finds the employee did not create the notice or know it was outdated. Which term BEST describes that employee's sharing behavior?

- A. Deliberate disinformation by an employee who knows the claim is false
- B. Credential phishing intended to collect account passwords
- C. Misinformation shared without an established intent to deceive
- D. A confirmed attempt to impersonate the original notice's author

Answer: C

Incorrect information can spread through people who believe they are helping. That differs from knowingly creating or distributing false information to manipulate others. Correcting the date and using an authoritative current incident channel addresses the described problem without attributing intent that the investigation does not support.

Study tip: Assess the sharer's knowledge and intent, not only whether the information is incorrect.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: The scenario expressly establishes that the employee believed the notice was current, so knowledge of falsity and deliberate deception are unsupported.

B: No credential request or collection destination is described; the error concerns the accuracy and timing of shared outage information.

C: The employee distributes an inaccurate claim about the current situation but believes it is true, matching unintentional misinformation.

D: Sharing an existing notice does not by itself claim authorship or establish impersonation, and the investigation identifies a mistaken belief about its age.

## SEC2-Q058

A recruiter receives an external instant message containing an archive labeled as a resume. After extraction, the recruiter launches a disguised shortcut that starts unauthorized software. Which TWO entry vectors are evidenced in this chain? (Select TWO.)

- A. A removable-device vector introduced through physical media
- B. A file-based vector through the delivered archive and shortcut
- C. A vendor-update supply chain compromise
- D. A voice-call vector through a fraudulent telephone conversation
- E. A message-based vector through instant messaging

Answer: B|E

An attack chain can use more than one vector. The instant message delivers the social lure, while the archive and shortcut provide executable file content. Classify the mechanisms the evidence actually shows rather than forcing the whole chain into one label or adding unobserved delivery stages.

Study tip: Delivery channel and payload format can both describe parts of the same entry chain.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The archive arrives through messaging rather than attached physical media, so a removable-device entry mechanism is not established by these observations.

B: The attached archive and launched shortcut carry the next stage of the attack, providing a file-based entry mechanism within the message-delivered chain.

C: The file is delivered as a resume by an external contact, with no compromised software supplier or update distribution process established.

D: No telephone interaction occurs, so a voice-based social-engineering classification would add a delivery mechanism absent from the evidence.

E: The external instant message delivers the lure and attachment to the recruiter, making the messaging channel part of the demonstrated entry chain.

## SEC2-Q059

A parser copies a UTF-8 field into a 128-byte buffer after checking only that it contains at most 40 characters. A test supplies 40 characters requiring four bytes each. Ignore terminators and metadata for this exercise. Which correction addresses the demonstrated overflow condition?

- A. Require valid UTF-8 input while retaining only the existing character-count limit
- B. Repeat the 40-character check at both input validation and the copy function
- C. Validate the encoded byte length against the destination capacity before copying
- D. Copy the field first, then check its encoded size and reject oversized results

Answer: C

Input limits must use units appropriate to the operation they protect. Forty four-byte characters require 160 bytes, exceeding the stated 128-byte buffer. A character-count check therefore does not establish memory safety. The correction must validate the actual encoded size, with any additional storage overhead included in a real implementation.

Study tip: Match validation units to storage units; characters and bytes are not interchangeable.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: Valid UTF-8 can still require multiple bytes per character, so encoding validity does not establish that the field fits the destination buffer.

B: Repeating the same measurement does not repair the units mismatch; both checks can accept a 40-character field that occupies 160 encoded bytes.

C: The test field occupies 160 bytes despite containing only 40 characters, so checking the actual encoded length prevents exceeding the 128-byte capacity.

D: A size check performed after the unsafe copy occurs too late to prevent writing beyond the destination's capacity during that operation.

## SEC2-Q060

A one-use voucher endpoint first checks unused=true, grants the credit, and then marks the voucher used. Two simultaneous requests both pass the check and each receive credit. Which design BEST removes this race condition?

- A. Require a longer voucher identifier without changing transaction handling
- B. Log duplicate credits after allowing every successful check to complete
- C. Make checking and consuming the voucher one atomic operation tied to granting credit
- D. Add a browser button delay while leaving the server workflow unchanged

Answer: C

Each request observes a valid state, but the combined concurrent outcome violates the one-use rule. The check, state change, and credit effect must be coordinated so only one transaction can succeed. Client timing and stronger identifiers do not enforce consistency at the server's shared state boundary.

Study tip: When concurrent requests each pass a valid check, examine whether the shared state change is atomic.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: Identifier complexity can reduce guessing but does not prevent simultaneous legitimate references to the same voucher from passing separate state checks.

B: Logging may detect the resulting abuse but does not prevent the concurrent state transition or remove the application's double-credit condition.

C: Atomic state transition and credit handling prevent two concurrent requests from independently consuming the same unused voucher and both committing the benefit.

D: A client-side delay cannot serialize requests from other clients or direct API calls, so concurrent server processing can still pass both checks.

## SEC2-Q061

A report API safely binds search values but concatenates a user-supplied sort-column name into SQL. Its database interface cannot bind a column identifier as a value parameter. Only three sort columns are required. What is the BEST correction?

- A. Remove database errors from the response while retaining unrestricted concatenation
- B. Map three permitted client choices to fixed server-defined column identifiers
- C. Allow any identifier as long as the request travels over HTTPS
- D. Pass any supplied column name through the existing value-binding operation

Answer: B

Parameter binding is appropriate for values, but structural elements such as column identifiers often require a different design. Here, only three choices are needed, so a fixed server-side mapping avoids accepting arbitrary SQL structure. Continue binding actual search values separately; the two protections address different input roles.

Study tip: Separate data values from structural identifiers; use a strict mapping when the user selects query structure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html

A: Suppressing errors can reduce information disclosure but leaves the client able to influence the query's structure through the unvalidated identifier.

B: A strict mapping limits query structure to identifiers chosen by the application, preventing arbitrary client text from becoming SQL syntax.

C: HTTPS protects transport but does not make user-selected SQL structure safe after the server receives the sort-column input.

D: The stated interface cannot bind an identifier as a value, so this does not provide a working safe selection of query structure.

## SEC2-Q062

A browser page reads text from its URL fragment and assigns it to a div's innerHTML. The text is never sent to the server and should be displayed literally. A controlled test confirms script execution through that browser-side path. Which change BEST removes the dangerous interpretation?

- A. Percent-encode the fragment, then decode it before assigning the result to innerHTML
- B. Validate the fragment's character count while retaining the same innerHTML assignment
- C. Hide server error messages while preserving the same browser code
- D. Assign the untrusted display value using the element's textContent property

Answer: D

The flaw occurs when client-side code sends untrusted text into an HTML interpretation context. Because the intended output is literal text, a text-only property directly addresses that behavior. Server-side controls for data that never reaches the server do not correct this specific DOM-based XSS path.

Study tip: Find where data becomes executable content; client-only input needs a safe client-side output operation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/DOM_based_XSS_Prevention_Cheat_Sheet.html

A: Decoding recreates the original untrusted text before HTML interpretation, so this reversible transformation leaves the demonstrated input-to-DOM vulnerability in place.

B: A length restriction does not make accepted text safe to interpret as HTML, leaving the dangerous output context intact for inputs within that limit.

C: Server errors are unrelated to this client-only execution path, so suppressing them leaves the unsafe input-to-DOM assignment unchanged.

D: For literal display text, textContent avoids interpreting the input as HTML, removing the unsafe DOM insertion behavior in the described path.

## SEC2-Q063

A workstation has current operating-system updates. An old third-party hardware driver is still loaded in the kernel, and a vendor advisory confirms a flaw in that driver. Which assessment is MOST accurate?

- A. The assessment can be limited to applications that expose Internet-facing listeners
- B. Driver review can be deferred because ordinary tests show the hardware still functions
- C. The loaded driver remains a privileged vulnerable component requiring its own remediation
- D. The host can be treated as remediated based solely on its operating-system patch dashboard

Answer: C

Security maintenance must cover the components actually loaded into the system, including third-party drivers. Updating the operating system does not necessarily update those dependencies. Confirm the driver version and applicable vendor fix, then plan a supported update or removal that accounts for the hardware function it supplies.

Study tip: An updated operating system can still load an outdated, separately maintained privileged component.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Privileged local components can matter even without their own public network listeners, so this scope would exclude the confirmed vulnerable driver.

B: Functional tests do not establish the absence of the security defect identified by the vendor, so continued hardware operation does not resolve the finding.

C: Current operating-system patches do not establish that a separately supplied driver is fixed, and its kernel execution makes the confirmed flaw significant.

D: A dashboard for the operating system does not establish the state of a separately maintained driver confirmed to contain an applicable defect.

## SEC2-Q064

An organization clones virtual machines from a template that accidentally contains an active service credential. Each clone starts with the same credential, although the services should have separate identities. Which template correction BEST addresses the resulting cross-instance exposure?

- A. Remove live credentials from the template and provision separate scoped identities for new instances
- B. Encrypt the template archive but distribute the same active secret to every running clone
- C. Regenerate each clone's network MAC address while retaining the copied service credential
- D. Rename each clone while preserving the copied service credential

Answer: A

Reusable machine images can reproduce sensitive identity state as well as useful configuration. Protecting the image archive does not separate the credentials inside the running clones. Templates should exclude active secrets, and provisioning should establish the appropriate independent identities, with any exposed existing credential rotated through a controlled process.

Study tip: A reusable system image should not silently reproduce a live identity across independent workloads.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Removing the shared secret and assigning individual scoped identities prevents every clone from inheriting the same reusable access to other services.

B: Archive encryption may protect storage or transfer, but every deployed instance still receives the shared credential and the associated cross-instance risk.

C: Unique network identifiers can prevent address conflicts, but they do not separate the reusable application credential inherited by every clone.

D: Distinct hostnames do not separate the actual credential, so compromise of one clone can still expose the shared secret used by the others.

## SEC2-Q065

A cloud rule should allow an administrative service only from 192.0.2.0/24. The deployed source is 0.0.0.0/0, and a test from outside the approved network reaches the service. Which weakness is MOST directly demonstrated?

- A. A misconfigured rule grants a broader source range than intended
- B. A spoofed routing advertisement redirected the approved subnet through the outside tester
- C. An outdated service listener was exploited to bypass the intended source restriction
- D. A stolen administrative credential explains why the outside source can reach the listener

Answer: A

The intended and deployed source ranges differ materially. The all-sources IPv4 prefix exposes the administrative listener to sources outside the required network, and the external test confirms that behavior. This is a configuration weakness even if the service's software and transport encryption work correctly.

Study tip: Compare the effective address range with the intended boundary, not just the rule's description.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The deployed prefix covers all IPv4 sources rather than the approved subnet, directly explaining why an outside source can reach the service.

B: No routing manipulation is evidenced, and the all-sources rule already grants connectivity to the tester without any redirection of the approved subnet.

C: The deployed rule already permits the outside source, so no service-software exploit is required or demonstrated to explain the confirmed connection.

D: The test establishes network reachability rather than a successful administrative login, and the broad source rule explains that reachability without credential theft.

## SEC2-Q066

A replacement network board arrives through an unauthorized distributor. Before installation, inspection discovers additional firmware not present in the manufacturer's reference image. Chain-of-custody records show the modification occurred before the organization received it. Which exposure should the investigation prioritize?

- A. An ordinary approved firmware update verified against the manufacturer's reference
- B. A browser-based attack launched by an employee after installation
- C. A DNS resolver error introduced by the organization's current network configuration
- D. Possible hardware supply chain compromise before delivery

Answer: D

Supply chain exposure can occur in hardware and its embedded firmware before the customer deploys a product. The receipt timeline and reference comparison distinguish this case from compromise during local operation. Investigators should preserve the component and trace provenance while verifying the manufacturer's authorized configuration and distribution history.

Study tip: Use the modification timeline to distinguish pre-delivery tampering from compromise after deployment.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The inspection finds firmware absent from the reference and an unauthorized delivery route, so the evidence does not establish a normal approved update.

B: The board has not yet been installed, and the documented modification occurred earlier, so a later employee browsing event cannot explain this evidence.

C: DNS behavior does not account for additional firmware physically present on an uninstalled board before it enters the organization's network.

D: The board's unauthorized modification predates receipt and follows an unapproved distribution path, focusing attention on the hardware procurement and delivery chain.

## SEC2-Q067

An employee sideloads a signed mobile application from an unapproved website. The signature verifies under the application's publisher key, but the organization has not assessed that publisher or application. Which conclusion is justified?

- A. The valid signature proves the device was not jailbroken or rooted
- B. Any signed sideloaded application has passed the organization's security review
- C. The signature does not replace the organization's application-source and permission review
- D. A verified publisher identity establishes that this application needs every requested permission

Answer: C

Sideloading raises questions about source trust, review, updates, and permissions. A valid publisher signature is one fact about the package, not a substitute for evaluating those concerns. The organization still needs to decide whether that publisher and application are approved for the intended data and device environment.

Study tip: Signed, permitted by the operating system, and approved by the organization are separate states.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Application signature verification does not independently attest to the entire device's platform integrity or establish its privileged modification state.

B: The publisher's signing process is separate from the organization's approval process, and the scenario explicitly states that no such assessment occurred.

C: Signature verification can support integrity and publisher identity, but it does not establish business approval, safe behavior, or appropriate requested permissions.

D: The publisher's identity does not demonstrate a business requirement for each requested capability, which the organization still needs to evaluate.

## SEC2-Q068

A mobile administrator discovers that a phone's platform restrictions were bypassed so an application can obtain privileges beyond the normal application sandbox. Which security assumption is MOST directly weakened?

- A. The platform can reliably enforce its normal application-isolation boundaries
- B. The confidentiality of records in an independently protected backup service
- C. The integrity of the corporate identity provider's user database
- D. The availability of the wireless access point's network uplink

Answer: A

Mobile operating systems normally restrict applications through platform controls and sandbox boundaries. Removing those restrictions can undermine assumptions used to protect other applications and sensitive device functions. A rooted or jailbroken state therefore needs separate evaluation even when ordinary network connectivity and visible application features continue working.

Study tip: Platform integrity determines whether the expected application boundaries remain dependable.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Bypassing platform restrictions can let software exceed the usual sandbox, weakening assumptions about separation between applications and protected device functions.

B: A changed mobile sandbox does not itself demonstrate access to the separate backup service or establish failure of that service's data protections.

C: The observed platform modification affects the phone's local application boundaries, without evidence that it changed records in the separate identity service.

D: The phone's privilege restrictions are the affected control, while no uplink outage or change to access-point availability is described.

## SEC2-Q069

A password-reset service creates long hexadecimal tokens by feeding the current timestamp into a predictable generator. A tester who estimates issuance time can reproduce valid tokens. Which change BEST addresses the demonstrated cryptographic weakness?

- A. Generate tokens with an appropriate cryptographically secure random source and sufficient entropy
- B. Display the same predictable generator output using more hexadecimal characters
- C. Base64-encode the timestamp before passing it to the same predictable generator
- D. Hide the reset form while leaving its token-generation endpoint callable

Answer: A

A token's printed length is not the same as its unpredictability. If a small set of estimated timestamps determines the output, an attacker can reproduce candidates without searching the full displayed space. Use a suitable cryptographically secure random source and protect the token's lifecycle, including binding, expiry, and single-use handling.

Study tip: Measure uncertainty in the secret's generation, not merely the number of characters used to display it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Unpredictable random generation addresses the attacker's ability to reproduce tokens from public timing information, rather than merely changing their visible representation.

B: A longer representation does not add unpredictability when the underlying token is still determined by an easily estimated seed.

C: Reversible encoding of a predictable value does not create entropy or stop an attacker from reproducing the generator's token output.

D: Removing a visible link does not correct token predictability or prevent direct use of an endpoint that still issues reproducible security values.

## SEC2-Q070

An application encrypts repeated fixed-size records using AES in ECB mode under one key. Identical plaintext blocks produce identical ciphertext blocks, exposing repetitions even though the key remains secret. Which assessment BEST explains the weakness?

- A. The observation proves that the encryption key has been recovered
- B. Adding an unkeyed checksum makes the repeated ciphertext values confidential
- C. Changing only the AES key length eliminates ECB's repeated-block behavior
- D. The selected mode reveals equality patterns that stronger key length alone does not remove

Answer: D

A sound cipher can be used in a mode that is unsuitable for the application's data patterns. ECB gives the same ciphertext block for the same plaintext block under one key, allowing equality patterns to remain visible. Select an appropriate modern encryption construction rather than treating key length as the only security parameter.

Study tip: Evaluate the encryption construction and mode as well as the underlying cipher and key length.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/38/a/final

A: Recognizing repeated ciphertext blocks does not require recovering the key or decrypting every block; the mode's deterministic relationship explains the observation.

B: A checksum does not hide ciphertext patterns or change ECB's block mapping, so it does not address the demonstrated confidentiality leakage.

C: A longer key can change key-search difficulty but leaves ECB's independent deterministic mapping of identical blocks under one key unchanged.

D: ECB encrypts each block independently under the same key, so repeated input blocks retain an observable equality relationship in the ciphertext.

## SEC2-Q071

A web preview feature fetches a URL supplied by a user. Testing shows that the application server can be directed to request an internal administration endpoint that the user cannot reach directly. Which vulnerability BEST describes this trust-boundary crossing?

- A. Server-side request forgery through the application's URL-fetching function
- B. DNS cache poisoning that replaces a trusted internal name's address
- C. Cross-site scripting that runs injected code in the user's browser
- D. A client-side open redirect that changes only the user's browser destination

Answer: A

A server-side fetch feature can bridge a network boundary when untrusted callers control its destination. The server's own connectivity becomes the mechanism for reaching internal services. The evidence establishes a request capability; additional results would be needed to claim sensitive response disclosure or administrative state changes.

Study tip: Identify who sends the request: a user-controlled destination fetched by the server points to SSRF.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/

A: The user controls the destination of a request made by the server, abusing the server's access to reach an otherwise inaccessible internal endpoint.

B: The scenario does not require corrupt DNS data; accepting an unsafe destination for the server's fetch already explains the internal request.

C: The confirmed action is an outbound request from the application server, not execution of injected script within the user's browser.

D: The application server sends the internal request, whereas a client-side redirect would instruct the browser itself to navigate to another destination.

## SEC2-Q072

A deployment review finds that a publicly downloadable container image includes a production API secret in an earlier image layer. It also finds an unauthenticated diagnostic endpoint returning the current database password. Which TWO corrections directly address these secret exposures? (Select TWO.)

- A. Delete the secret only in the final image layer and keep the same API credential
- B. Require HTTPS for the public diagnostic endpoint while continuing to return its passwords
- C. Move the image into an authenticated registry while retaining the previously published credentials
- D. Remove secrets from image history, rebuild the image, and rotate the exposed API credential
- E. Stop exposing secret values through the diagnostic endpoint and rotate the disclosed database credential

Answer: D|E

Removing a disclosure path and replacing an exposed credential address different parts of the problem. Image layers can preserve data beyond a final-file deletion, and diagnostic output can reveal live secrets directly. Correct both publication mechanisms and rotate the affected credentials rather than relying on renamed fields or encrypted transport.

Study tip: Once a credential has been exposed, fixing the disclosure path does not make that existing value secret again.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/190/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A final-layer deletion does not reliably remove data from earlier distributed layers, and retaining the exposed credential preserves its potential unauthorized use.

B: HTTPS protects delivery to the requester but does not prevent an unauthenticated requester from receiving secrets that the endpoint intentionally returns.

C: Restricting future artifact access can reduce further exposure, but it does not invalidate secret values already published or address the diagnostic endpoint's disclosure.

D: Earlier image layers can retain included data, so cleanup must remove the published secret from the artifact and invalidate the credential already exposed.

E: Removing the unsafe disclosure path prevents further retrieval, while rotation addresses the possibility that the previously returned password is already known.

## SEC2-Q073

A vendor confirms a newly discovered flaw and provides an affected-version list, but a public CVE identifier has not yet been assigned. The organization runs an affected version and has found no evidence of exploitation locally. Which TWO conclusions are justified? (Select TWO.)

- A. Classify the organization's host as compromised based solely on its affected version
- B. The confirmed applicable flaw can require mitigation before a CVE identifier is published
- C. The available facts establish vulnerability exposure but do not prove a local compromise
- D. Use identifier-publication status instead of impact and exploit conditions to assign priority
- E. Wait for a public identifier before opening a remediation record for the confirmed flaw

Answer: B|C

A tracking identifier helps coordination but does not create the underlying defect. The vendor's confirmation and version match justify evaluating mitigation while publication is pending. Keep that exposure assessment separate from incident findings: an applicable vulnerability does not, by itself, prove an attacker used it in this environment.

Study tip: Keep vulnerability existence, identifier assignment, severity, and evidence of compromise separate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://www.cve.org/Resources/Media/Archives/OldWebsite/about/faqs.html|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: A version match establishes applicability, while a confirmed incident requires additional evidence that the flaw or another entry path was actually used.

B: A vulnerability's existence and applicability do not depend on identifier publication, so the confirmed affected system can need action while coordination continues.

C: Running an affected version establishes an applicable weakness, whereas a claim of local exploitation requires evidence beyond the vulnerability's existence.

D: Identifier timing is not a substitute for evaluating consequences, exposure, and exploitation conditions when deciding how urgently to address the confirmed flaw.

E: A publication delay does not remove the established applicable weakness, so deferring tracking solely for identifier assignment leaves a known exposure unmanaged.

## SEC2-Q074

An unauthorized process records each key pressed while a user types in several unrelated applications. During an isolated examination, harmless test phrases appear in its captured input file in typing order. Which malicious function is directly demonstrated?

- A. A hash-collision search against password verifiers
- B. Self-propagation through remote service exploitation
- C. Keystroke logging
- D. File encryption for a ransom demand

Answer: C

The harmless test phrases demonstrate the input-capture function without requiring exposure of actual secrets. A keylogger can capture information across applications before transport encryption is applied. The observation establishes keystroke logging, while any claim about external transmission or additional malware capabilities would need separate evidence.

Study tip: Capture before encryption can expose typed input even when the application's network connection is protected.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The process observes what the user types rather than deriving values through cryptographic computation against stored password hashes.

B: No transmission of an infection to other hosts is described; the verified behavior is local capture of keyboard activity.

C: Recording keys across applications and preserving test phrases in typing order directly demonstrates capture of keyboard input rather than merely application inventory.

D: The evidence concerns recorded input, with no inaccessible encrypted files or payment demand establishing ransomware behavior in this observation.

## SEC2-Q075

A browser extension secretly collects browsing history and periodic screenshots unrelated to its advertised calculator function. It transmits those records without user or organizational authorization. Which malware category BEST fits the demonstrated purpose?

- A. A file virus defined by attaching itself to executable hosts
- B. A worm defined by automatic replication to other systems
- C. Ransomware withholding access until a payment is made
- D. Spyware performing unauthorized surveillance

Answer: D

Spyware focuses on collecting information about users or systems without appropriate authorization. The mismatch between the calculator's purpose and the covert history and screenshot collection is important evidence. Classify the demonstrated surveillance function without assuming the extension also replicates, encrypts files, or performs other unobserved activities.

Study tip: Classify malware by the behavior demonstrated, especially collection that exceeds the application's legitimate purpose.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: No infection of other executable files is described; the observed extension behavior is covert collection of browsing and screen information.

B: The scenario shows information collection and transmission but no autonomous replication that would establish worm behavior as the defining category.

C: The user is being monitored rather than denied access for payment, and the scenario includes no ransom demand or recovery condition.

D: The extension covertly gathers user activity and screen information, making surveillance and unauthorized information collection the demonstrated malicious purpose.

## SEC2-Q076

In an isolated lab, malicious code inserts a copy of itself into previously clean executable files. A copied file spreads the code further only after that infected executable runs. Which propagation model BEST matches the observation?

- A. A worm that automatically exploits remote network services without a host file
- B. A logic bomb defined only by waiting for a calendar date
- C. A file virus that depends on execution of an infected host file
- D. A standalone keylogger whose only behavior is recording input

Answer: C

A file virus incorporates itself into another executable and spreads when an infected host runs. That dependency distinguishes the described mechanism from a worm's autonomous network propagation. Malware can combine capabilities, but the question asks which replication model the controlled observations actually demonstrate.

Study tip: Ask what must run for replication to continue; an infected host-file dependency is a virus clue.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The observed spread depends on infected executable files being run, rather than autonomous remote-service exploitation independent of that host-file mechanism.

B: A time trigger does not explain infection of executable hosts, and no calendar-dependent trigger appears in the described propagation test.

C: The code reproduces by infecting executable hosts, with subsequent host execution driving further spread, matching the defining file-virus propagation pattern.

D: The evidence specifically demonstrates replication into other executables, which is not explained by a nonreplicating input-recording function.

## SEC2-Q077

New laptops contain several unnecessary trial utilities that consume memory and start background services. Review finds no unauthorized collection, hostile commands, or exploitation, but the organization has no business need for the utilities. Which assessment is BEST supported?

- A. Unneeded bloatware adds resource use and avoidable software exposure without proving a hostile campaign
- B. The laptops are confirmed malware infections based only on the utilities' memory use
- C. A clean behavioral review means the utilities require no inventory or patch management
- D. Manufacturer inclusion is sufficient business approval to retain every installed utility

Answer: A

Bloatware can be a security-management concern without being proven malware. Unneeded utilities use resources, require maintenance, and may introduce unnecessary listeners or dependencies. The organization can remove unneeded software through an approved process while avoiding an unsupported conclusion that the installation itself proves an active attacker campaign.

Study tip: Unnecessary software and confirmed malicious software are related management concerns, but not identical findings.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Unnecessary applications can consume resources and expand maintenance needs, while the supplied evidence does not establish malicious control or deliberate data theft.

B: High resource consumption by unnecessary software can justify removal or investigation, but the supplied observation does not establish a malicious infection.

C: Software still has support and vulnerability-management implications even when current observation does not show malicious activity or unauthorized information collection.

D: Manufacturer packaging does not establish an organizational business requirement for each utility or eliminate the need to assess its support and security exposure.

## SEC2-Q078

A locked communications cabinet has a bent latch and tool marks. Video shows a person prying the door open; there is no use of an access badge or electronic unlock command. Which attack method is directly evidenced?

- A. Tailgating through a door opened by an authorized employee
- B. RFID cloning of a legitimate employee's badge
- C. Physical brute force against the enclosure
- D. Password guessing against the cabinet's management service

Answer: C

Brute force can describe a physical attack as well as password guessing. Tool marks and direct video of prying demonstrate the mechanical method here. The damaged barrier and recorded action provide stronger evidence than inferring an electronic bypass merely because the enclosure protects network equipment.

Study tip: Use the evidence to distinguish physical force from credential misuse or following someone through a barrier.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: The person independently forces the cabinet open, rather than following an authorized individual through an already opened access barrier.

B: A copied RFID credential is not shown, and video instead establishes that the attacker physically forced the latch open.

C: The observed mechanical force defeats the cabinet's physical barrier directly, without relying on a copied credential or electronic access-control command.

D: The evidence shows a mechanical entry method rather than authentication attempts against an electronic management interface or account.

## SEC2-Q079

Servers begin shutting down from excessive heat. Video and access records show an unauthorized visitor deliberately disabling the cooling controller shortly before temperatures rise. Which attack category MOST directly explains the method used to affect computing availability?

- A. An application-layer injection attack against the ordering website
- B. A natural equipment failure with no evidence of intentional action
- C. A reflected denial-of-service flood through public network servers
- D. An environmental attack against supporting facility conditions

Answer: D

Computing services depend on environmental support such as cooling and power. An attacker can affect availability by targeting those conditions without exploiting an application. The temperature sequence alone might have multiple explanations, but the direct evidence of deliberate cooling disruption supports an environmental attack in this case.

Study tip: Distinguish an environmental symptom from an intentional attack using corroborating physical and timing evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The confirmed action targets physical cooling infrastructure, with no application input or interpreter behavior connecting the event to a website injection flaw.

B: The video and access evidence explicitly show deliberate unauthorized manipulation, so the event cannot be characterized solely as an unexplained natural failure.

C: No reflected network traffic is established; the shutdowns follow deliberate disruption of cooling and the resulting rise in temperature.

D: The attacker manipulates cooling rather than the servers' application code, using environmental conditions to cause the observed loss of computing availability.

## SEC2-Q080

A web service's network link remains below 10% utilization, but its database CPU reaches 100% under thousands of confirmed malicious requests for an expensive report operation. Legitimate users time out. Which denial-of-service mechanism BEST fits?

- A. Storage-bandwidth exhaustion caused by large file uploads
- B. A bandwidth flood that has filled the external network link
- C. Application-layer resource exhaustion through costly requests
- D. Authentication-service exhaustion caused by repeated password verification

Answer: C

Denial of service can exhaust application workers, database capacity, or other limited resources without filling the network link. The CPU and request evidence identify the expensive operation as the relevant bottleneck. Controls should account for request cost and service capacity rather than measuring attack volume only in network bytes.

Study tip: A low-bandwidth attack can still cause denial of service when each request consumes expensive resources.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The measured saturation involves database CPU under report requests, with no upload or storage-bandwidth evidence identifying the alternative bottleneck.

B: The measured link remains lightly utilized, while the database is saturated, so the observed bottleneck is processing rather than external network capacity.

C: The requests consume disproportionate application and database resources, causing timeouts without needing to saturate the available network bandwidth.

D: The malicious requests target expensive report generation, not password verification, so authentication processing is not the bottleneck supported by the scenario.

## SEC2-Q081

A host generates many long, changing subdomains under sync-channel.example. An authorized reconstruction confirms that query labels encode fragments of a local test file and that the external authoritative server receives them. Which mechanism is demonstrated?

- A. Ordinary name resolution established solely by the use of a permitted DNS port
- B. A reflected amplification flood caused by oversized server replies
- C. DNS cache poisoning that returns the wrong address for a trusted service
- D. DNS tunneling used as a data-transfer channel

Answer: D

DNS fields can carry information beyond ordinary service-name lookups. Long or unusual names alone would be suspicious indicators, but the reconstruction adds evidence of an actual data channel in this exercise. The permitted protocol and destination role do not establish that the traffic serves an authorized business purpose.

Study tip: Unusual DNS names are a lead; confirmed encoded content makes the data-channel conclusion stronger.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/techniques/T1071/004/

A: A permitted protocol can carry unauthorized data, and the reconstruction confirms that these labels contain file fragments rather than only ordinary service names.

B: No spoofed victim address or large response amplification is described; the important behavior is the transfer of encoded data in requests.

C: The evidence concerns data placed into outgoing query names, not corruption of a resolver's cached address mapping for a legitimate service.

D: The confirmed embedding of file fragments in DNS queries demonstrates data being carried through the protocol to an externally controlled destination.

## SEC2-Q082

Wireless clients repeatedly disconnect while signal strength stays normal. Capture shows forged deauthentication frames from an unauthorized transmitter impersonating the access point. Protected management frames are not enforced. Which mechanism BEST explains the disconnects?

- A. Weak signal attenuation alone explains every observed disconnect
- B. An evil-twin access point has captured the users' login credentials
- C. The access point's DHCP address pool must be exhausted
- D. Spoofed wireless management messages are forcing session termination

Answer: D

Wireless availability can be attacked through management traffic rather than radio interference or password compromise. The forged deauthentication frames provide the specific cause in this scenario. Their success does not establish decryption of application traffic; it shows that the network lacks effective protection against the demonstrated session-disruption messages.

Study tip: Normal radio strength does not rule out a protocol-level wireless denial-of-service attack.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: Signal measurements remain normal and the packet evidence supplies a deliberate protocol-level cause, making pure coverage loss an insufficient explanation.

B: Forged disconnection messages can be part of a broader attack, but the capture does not establish association with another access point or credential collection.

C: DHCP exhaustion affects address assignment, while the capture directly identifies forged management messages terminating existing wireless associations.

D: The forged deauthentication messages instruct clients to end their association, explaining disruptions despite normal signal strength and available radio coverage.

## SEC2-Q083

An attacker captures a valid signed request that authorizes a one-time inventory adjustment. Replaying the identical request causes a second adjustment because the server does not track whether it was already used. The signature remains valid. Which attack is demonstrated?

- A. A hash collision that replaces the request contents
- B. Forgery of a new signed request using a compromised signing key
- C. A successful defense because the signature was verified both times
- D. Replay of an authentic request without an effective single-use check

Answer: D

An authentic message can still be unsafe to process more than once. The server needs a replay-resistant design appropriate to the operation, such as a unique request identifier with atomic single-use tracking. Signature verification alone does not enforce the business requirement that the adjustment occur only once.

Study tip: Authenticity is not freshness, and freshness alone may not enforce one-time processing.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: The request contents are identical to the original, and no different message with the same digest is necessary to explain the repeated action.

B: The attacker reuses the original signed request unchanged, so neither a newly forged message nor possession of the signing key is demonstrated.

C: Signature validity establishes authenticity and integrity properties, but it does not independently show that this one-time action has not already been performed.

D: The attacker reuses an unchanged valid message, exploiting missing replay handling rather than needing to forge or alter its signature.

## SEC2-Q084

While an employee is signed in, an unrelated website causes the browser to submit a settings-change request to the work portal. The browser includes the session cookie under the portal's configured cookie policy. The portal checks the session but has no request-forgery protection, and the setting changes. Which attack is demonstrated?

- A. Stored cross-site scripting inside the work portal's page content
- B. Server-side request forgery initiated by the work portal's URL-fetching service
- C. Cross-site request forgery using the victim browser's authenticated context
- D. Password brute force against the employee account

Answer: C

The portal confuses a browser's existing authentication with evidence that its user intended a particular change. Under the stated cookie behavior, another site can induce the request. Effective anti-forgery controls must validate the request's authorized context, while authentication remains necessary but insufficient for this particular boundary.

Study tip: Identify the request sender and the reused trust: browser-attached credentials can support CSRF without password theft.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html

A: No attacker script is stored or rendered inside the portal; the action is triggered from another site using the browser's existing authentication.

B: The employee's browser sends the request here, rather than the portal server fetching an attacker-selected destination through a server-side function.

C: The attacker causes the browser to send a state-changing request with automatically attached authentication, without establishing that the user intended that operation.

D: The request uses a current authenticated session rather than guessing the employee's password, so password-search behavior is not the mechanism shown.

## SEC2-Q085

A service policy allows technicians to edit only tickets assigned to them. A technician changes a ticket identifier and successfully edits another technician's ticket. The account remains in the same role and receives no administrator rights. Which access violation is BEST demonstrated?

- A. Vertical privilege escalation into an administrator role
- B. Session hijacking through theft of the other technician's authentication token
- C. Horizontal privilege escalation across peer-owned resources
- D. Authorized delegation implied by knowing a valid ticket number

Answer: C

The distinction is the direction of the authorization failure. The technician accesses a peer's object without changing role, making the escalation horizontal. The server must enforce the assignment relationship for each requested ticket instead of assuming that a valid role and object identifier establish permission.

Study tip: Crossing into a peer's resources can violate authorization without adding a more privileged role.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/

A: The scenario explicitly states that the role and administrative privileges do not change, so the violation concerns peer-level object access.

B: The user changes an object identifier while keeping the original account and role, with no evidence that another technician's session token was stolen.

C: The account reaches another user's resource at the same privilege tier, crossing an ownership boundary without obtaining a higher administrative role.

D: A resource identifier locates an object but does not grant permission to edit it under the stated assignment-based access policy.

## SEC2-Q086

A classroom exercise uses an idealized 32-bit hash output. Ignoring constant factors, what order of work does the birthday effect suggest for finding any pair of colliding inputs, rather than matching a specified target digest?

- A. About 2^16 candidate hashes
- B. About 32 candidate hashes
- C. About 2^32 candidate hashes
- D. About 2^64 candidate hashes

Answer: A

With many generated outputs, every pair offers a chance of matching. This produces a square-root relationship for generic collisions: roughly 2^(n/2) work for an n-bit ideal hash, ignoring constants. The result is an order estimate rather than a guaranteed sample count or a claim that such a small hash is suitable for security.

Study tip: Any-pair collision search and matching one specified digest have different generic work factors.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Generic collision searching scales with the square root of the output space, so a 32-bit output has a birthday-bound scale near 2^16 samples.

B: The bit count is not the number of candidate samples needed; collision probability depends on the much larger space of possible output values.

C: That scale corresponds to searching an ideal 32-bit space for a specified output, rather than comparing many generated outputs for any matching pair.

D: Squaring the output-space size reverses the birthday relationship; generic any-pair collision search benefits from pairwise comparisons instead of requiring this expanded work.

## SEC2-Q087

Immediately after a service-account password rotation, failures recur every 60 seconds from one backup server and trigger lockouts. Other clients authenticate successfully. The backup job's credential configuration was not updated. Which explanation is BEST supported before attributing an attack?

- A. A network path failure is preventing the backup server from reaching the directory
- B. The service account has reached its configured expiration date
- C. An authentication ticket is failing because the backup server's clock is outside its permitted tolerance
- D. A scheduled job is retrying with the previous credential

Answer: D

Account lockouts are indicators that need context, not automatic proof of hostile guessing. The known job, rotation event, and repeated schedule provide a coherent operational explanation. Update and verify the affected service configuration through the approved process, while reviewing any evidence that does not fit the expected retry pattern.

Study tip: Correlate lockouts with recent credential changes and scheduled services before assuming a password attack.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The directory is receiving and recording authentication failures that cause lockout, so total inability to reach it does not fit the evidence.

B: Account expiration can deny access, but other clients still authenticate and the stated unchanged credential configuration supports stale-password retries instead.

C: Clock problems can cause authentication failures, but no time evidence supports that explanation, while the unchanged job secret directly follows the password rotation.

D: The rotation timing, fixed retry interval, single known source, and unchanged job configuration jointly support stale stored credentials causing repeated failures.

## SEC2-Q088

An impossible-travel alert links logins minutes apart from two countries. Device telemetry identifies the same managed laptop at one office, and both apparent source addresses are approved secure-proxy exits used by that session. Which interpretation is MOST appropriate?

- A. The geolocation difference conclusively proves simultaneous control by two attackers
- B. The proxy routing supplies a plausible explanation for the apparent travel and should inform validation
- C. Every future alert for the employee should be suppressed regardless of source
- D. The event establishes token replay between two unmanaged devices

Answer: B

IP geolocation often describes an egress point rather than a person's actual location. In this case, verified proxy routing and device telemetry provide a plausible explanation that should be documented and validated. Tune with specific trusted context instead of treating either the initial alert or the explanation as permission for blanket suppression.

Study tip: Establish what an IP address represents before converting a location difference into a physical-travel conclusion.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Approved proxy exits explain the address difference, and the supplied evidence does not establish two physical users or malicious controllers.

B: The observed source addresses represent approved egress points rather than the laptop's physical movement, so the location-based alert needs that verified network context.

C: Explaining this event does not justify removing coverage for unrelated devices, destinations, or future conditions that may indicate a genuine compromise.

D: The supplied device evidence identifies one managed laptop and verified proxy routing, so two unmanaged devices and replay are not established by the location tags.

## SEC2-Q089

An endpoint record for a confirmed malicious file states action=blocked, stage=before_execution, result=success. Correlated telemetry contains no process execution for that file. What is the STRONGEST conclusion supported by these records?

- A. The malicious file ran before the prevention engine generated its alert
- B. This file's execution attempt was blocked; the records alone do not prove the whole endpoint is clean
- C. This block result is sufficient evidence to clear other suspicious host activity from the investigation
- D. The detection is a false positive because no malicious process was created

Answer: B

Interpret security events according to the action, stage, and result they record. A successful pre-execution block is evidence of a prevented attempt, not proof that the file ran. It also has a limited scope: preventing one artifact does not establish that no other artifact or access path affected the endpoint.

Study tip: Detection, attempted execution, successful execution, and successful blocking are different event states.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The recorded stage explicitly precedes execution, and the correlated telemetry contains no matching process, so post-execution detection is not the supported interpretation.

B: The event and correlation support prevention of this specific execution, while excluding every other compromise path would require additional evidence.

C: A specific prevented artifact does not account for other events or entry paths, so its successful block cannot resolve unrelated evidence by itself.

D: Successful prevention can explain the absence of a process, and the file has independently been confirmed malicious, so nonexecution does not make the detection false.

## SEC2-Q090

Forensic analysis identifies two file hashes as malicious. Analysts need evidence that those artifacts actually ran, rather than merely arriving or being stored. Which TWO records provide the strongest direct execution evidence? (Select TWO.)

- A. The mail gateway records delivery of an attachment containing one of the malicious hashes
- B. Endpoint process telemetry records a started process whose image hash matches a confirmed malicious artifact
- C. A threat-intelligence report contains both hashes as plain text in its indicators section
- D. The download filter records successful quarantine of the other artifact before execution
- E. Service telemetry shows a running service process mapped to the other confirmed malicious image hash

Answer: B|E

Malicious reputation and local execution answer different questions. Matching the known malicious content to an actual started or running process directly supports execution. Delivery, download, quarantine, and documentation records remain useful, but they describe other stages and should not be promoted into execution evidence without corroboration.

Study tip: Connect a confirmed artifact identity to a runtime event before claiming that the artifact executed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Attachment delivery establishes arrival at the mailbox, but additional endpoint or application evidence is needed to show that the recipient executed it.

B: A recorded process start tied to the verified malicious image demonstrates execution more directly than a file delivery or presence event.

C: A report mentioning identifiers is documentation, not a process or execution record for the files represented by those identifiers.

D: A successful pre-execution quarantine supports a prevented attempt rather than direct evidence that the malicious artifact ran on the endpoint.

E: The active service process and matching malicious image establish that this artifact is running, not simply registered or stored for possible later use.

## SEC2-Q091

Monitoring shows a report service using all allocated CPU, while tested report requests repeatedly time out. The cause has not been established, and no data-content or account-activity evidence is available. Which TWO conditions are directly supported? (Select TWO.)

- A. Users are experiencing resource or service inaccessibility
- B. An undersized capacity plan is the confirmed root cause
- C. A deliberate application-layer denial-of-service attack caused the timeouts
- D. An expired application account credential caused the request failures
- E. The service is experiencing high resource consumption

Answer: A|E

Indicators describe observations before an investigation establishes cause. CPU saturation supports resource consumption, and failed requests support service inaccessibility. Either might arise from an attack or an operational fault. Preserve that distinction while gathering evidence that separates malicious requests, capacity problems, and authentication or application failures.

Study tip: First separate what was measured from the unproven explanation for why it happened.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: Repeatedly unsuccessful tested report requests demonstrate an availability problem for the requested service, regardless of the eventual root-cause classification.

B: Insufficient capacity is one possible explanation for saturation, but the measurements alone do not distinguish it from other operational or malicious causes.

C: Resource saturation and failed requests can occur during an attack or an operational fault; the scenario provides no evidence establishing deliberate hostile causation.

D: The scenario contains no authentication records or account-state evidence, so a credential-expiration explanation is not established by CPU use and request timeouts.

E: The measured use of all allocated CPU directly establishes resource saturation without requiring an assumption about the actor or process responsible.

## SEC2-Q092

A support laptop must accept a management service on the organization's authenticated office network but must reject that inbound service on public networks. The laptop frequently travels outside the office. Which control BEST enforces this location-specific exposure requirement?

- A. Require a longer management password while allowing the service on every network
- B. Remove the service from every network profile, including the approved office network
- C. Block the service at the office perimeter but leave the laptop's public-profile rules unchanged
- D. Apply host firewall rules that allow the service on the verified office profile and block it on public profiles

Answer: D

A mobile endpoint needs enforcement where it operates, not only at the office perimeter. Host firewall profiles can restrict the listener on untrusted networks while preserving its approved office use. The trusted profile must be established appropriately; a convenient network name alone should not automatically grant office-level reachability.

Study tip: For a traveling endpoint, enforce inbound service restrictions on the host and validate the trusted-network condition.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Stronger authentication can reduce guessing risk but does not meet the explicit requirement to reject public-network connections to the management service.

B: A universal block removes the required office-management capability, while the requirement calls for different exposure under verified office and public conditions.

C: The office firewall cannot enforce connections between the laptop and local peers on an unrelated public network, where the laptop needs its own restriction.

D: Profile-aware host rules can enforce different inbound exposure on the laptop itself, including when it is away from the office's network firewall.

## SEC2-Q093

An application allowlist trusts every executable inside a tools directory. Standard users can write to that directory, and a test shows an unapproved program runs after being copied there. Which correction BEST repairs the trust mistake?

- A. Restrict the program's Internet destinations while leaving it free to execute locally
- B. Block only the test program's current hash while preserving the writable-path allowance
- C. Remove broad trust in the user-writable path and authorize software through appropriately protected, narrow rules
- D. Increase malware scanning frequency while keeping the existing path-based allow rule

Answer: C

An allowlist is only as strong as the conditions that grant execution. A directory whose contents ordinary users control cannot establish that every file inside it is approved. Correct both the policy's trust scope and the permissions or identities governing approved software, then test the intended approved and unapproved execution paths.

Study tip: A trusted execution rule must rely on something the untrusted user cannot freely replace.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Egress restrictions can limit communication but do not meet the requirement to prevent unapproved executable content from using the writable trusted path.

B: A single hash block addresses that sample but leaves the same trusted location available for other unapproved programs with different content.

C: The writable location lets users supply content to a trusted execution rule; protecting the source of allowed code repairs that underlying trust boundary.

D: More frequent scanning may detect additional malicious files but does not enforce approval for arbitrary unapproved code placed in the trusted directory.

## SEC2-Q094

A file system combines allowed group permissions, with no deny rules in this example. An employee belongs to Auditors, which grants read, and an obsolete ProjectWriters group, which grants write. The employee should retain audit access only. Which change BEST removes the excess permission?

- A. Restrict ProjectWriters access to business hours but retain the employee's membership
- B. Remove the obsolete ProjectWriters membership while retaining Auditors membership
- C. Add another explicit read grant while leaving both group memberships unchanged
- D. Remove Auditors membership while leaving ProjectWriters membership unchanged

Answer: B

Effective permissions can come from more than one grant. In the model explicitly supplied, adding a narrower permission does not subtract a broader one. Remove the obsolete source of write access while preserving the group that serves the employee's current audit duties, then verify the resulting effective permissions.

Study tip: Trace the source of each effective grant; adding read access does not necessarily remove existing write access.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A schedule narrows when the excess permission applies but still grants write access during those hours, contrary to the required audit-only role.

B: Removing the source of the unnecessary write grant leaves the required read access supplied by the employee's valid audit-group membership.

C: Under the stated cumulative model, an additional read permission does not cancel the existing write permission granted by ProjectWriters.

D: This removes the current role's group instead of the obsolete grant, leaving the permission source responsible for the excessive write access.

## SEC2-Q095

A quarantine network blocks access to production subnets but permits unrestricted Internet access. A contained host continues contacting an external command server. Quarantined hosts need only approved update and response services. Which change BEST completes the intended containment?

- A. Encrypt update downloads while preserving unrestricted outbound access
- B. Restrict outbound access to the approved remediation and response destinations
- C. Add another production-subnet deny rule without changing Internet egress
- D. Block only the currently observed command-server address and permit every other Internet destination

Answer: B

Containment must address the communication paths relevant to the incident. Blocking production access limits lateral movement, but unrestricted Internet egress can preserve external control. A policy limited to required remediation and response services closes the stated gap while keeping the host supportable during the investigation.

Study tip: Review quarantine traffic in every relevant direction, including command channels that remain outside production networks.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Transport protection for updates does not remove the host's separate ability to communicate with unauthorized external destinations from the quarantine network.

B: A narrow outbound policy removes unnecessary external communication while preserving the specified services needed for updates and incident response.

C: Additional internal restrictions do not address the demonstrated external command channel, which remains reachable through the unrestricted outbound policy.

D: A single address block may interrupt one destination but does not implement the stated requirement to allow only approved remediation and response services.

## SEC2-Q096

A container's application dependency has a security fix. Editing the package inside one running container works temporarily, but the next deployment recreates the vulnerable version from the approved image. Which action BEST makes remediation persist across replacements?

- A. Update the host kernel while leaving the application's packaged dependency unchanged
- B. Patch only the current container again without changing the deployment image
- C. Rebuild using the same vulnerable dependency version and apply a new image tag
- D. Update the image's dependency, rebuild and validate it, then deploy the corrected image to affected instances

Answer: D

Remediation must reach the artifact that recreates the workload. A temporary change inside one container can disappear at the next deployment, so the image and dependency definition must be corrected. Validate the new artifact and ensure affected instances actually run it instead of relying on a tag name or a one-time local edit.

Study tip: Patch the source of replacement workloads as well as the currently running instance.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/190/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Host maintenance may address other risks but does not replace the specifically affected application dependency embedded in the container image.

B: A runtime-only change is discarded when the container is replaced from the unchanged vulnerable image, recreating the same defect on deployment.

C: A new label or build does not establish remediation when the affected component version is deliberately retained inside the produced image.

D: Changing the deployable source artifact ensures replacement containers receive the fixed dependency, while rollout and validation address the currently running instances.

## SEC2-Q097

An employee sends an encrypted archive and its password in the same mailbox conversation. The stated threat is an attacker who can read that mailbox. Which change BEST improves confidentiality against that specific threat?

- A. Send the password in a second message to the same compromised mailbox
- B. Use a stronger archive-encryption algorithm but keep sending its password in the same mailbox
- C. Deliver the decryption secret through a separately protected, verified channel inaccessible to the mailbox reader
- D. Make the password longer but continue including it in the same conversation

Answer: C

Encryption depends on keeping the decryption material outside the attacker's reach. In this scenario, mailbox access supplies both required pieces, regardless of password complexity. A separately protected verified channel addresses the stated threat, provided that it does not ultimately rely on the same compromised mailbox for access or recovery.

Study tip: Check whether one compromised channel reveals both the ciphertext and the secret needed to decrypt it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Separate messages within the same readable mailbox remain exposed through the same access path and do not separate the decryption material from the attacker.

B: A stronger algorithm does not prevent decryption by an attacker who can read the actual password through the same compromised delivery channel.

C: Separating the secret from the compromised mailbox prevents that access alone from supplying both the encrypted archive and the material needed to open it.

D: A longer password resists guessing but does not help when the attacker can simply read its full value beside the archive.

## SEC2-Q098

An approved repair requires a baseline-enforced setting to differ on one workstation for 20 minutes. The fleet must remain protected, and the normal setting must resume afterward. Which TWO measures BEST support that limited exception? (Select TWO.)

- A. Accept the technician's completion email as sufficient proof that the required setting was restored
- B. Pause the workstation's enforcement agent without recording which setting changed or when enforcement must resume
- C. Create a centrally recorded exception limited to the identified workstation, setting, and repair window
- D. Automatically expire the exception and verify that baseline enforcement restores the required setting
- E. Record the repair ticket but leave enforcement continuously reversing the required temporary setting

Answer: C|D

Configuration enforcement needs a controlled way to support legitimate short-term work without losing the normal protection. Scope the exception precisely, retain accountability, and give it an enforced end. Verification after expiry matters because a recorded end time alone does not prove the workstation actually returned to the required state.

Study tip: A temporary exception needs a limited scope and a verified return to the normal protected state.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A completion message does not verify the endpoint's actual state, so an ineffective restoration could leave the approved temporary deviation in place unnoticed.

B: A local pause can enable the repair but lacks the tracked scope and restoration commitment needed to keep the temporary deviation accountable.

C: A narrowly scoped exception permits the approved deviation without removing enforcement from unrelated systems or leaving its purpose and duration untracked.

D: Expiry and resulting-state verification ensure the temporary allowance does not silently become permanent after the approved maintenance need ends.

E: Documentation alone does not make the approved repair possible if enforcement immediately undoes the setting needed to perform the work.

## SEC2-Q099

A company retires a hosted service and releases its provider resource name. The company's public DNS alias still points to that name, which another provider customer can now claim. Which omitted decommissioning action MOST directly addresses the continuing trust exposure?

- A. Sanitize the retired server's local storage without reviewing DNS dependencies
- B. Remove or update dependent DNS references before relinquishing the hosted resource
- C. Retain the obsolete alias for convenience because the previous application account was disabled
- D. Mark the server as powered off while leaving its service references published

Answer: B

Decommissioning must remove dependencies that still convey trust to an endpoint. A stale DNS alias can outlive the application and point into a naming system where ownership is reassigned. Updating those references before release closes the described route, whereas storage cleanup and account disablement address different retirement risks.

Study tip: Retirement includes references to the service, especially names whose underlying resources can be reassigned.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Storage sanitization protects residual data on that asset but does not remove the public alias pointing to a resource whose ownership has changed.

B: Removing the stale alias prevents the company's trusted name from continuing to direct visitors toward a provider resource that another customer may control.

C: Disabling the old application account does not reserve the released hosting resource or make the stale DNS destination remain under company control.

D: Power state does not establish continued ownership of the released provider name or prevent the remaining DNS reference from pointing to another tenant.

## SEC2-Q100

A service records unauthorized configuration changes, but no one receives alerts or regularly reviews the records. Changes are discovered months later. The organization wants monitoring to reduce how long such activity remains unaddressed. Which improvement BEST meets that goal?

- A. Increase raw log retention without changing who reviews the events
- B. Compress archived logs more efficiently while keeping the same review process
- C. Collect the same event in an additional archive without configuring notification
- D. Create actionable alerts with an assigned review and escalation path

Answer: D

Recording an event and acting on it are separate capabilities. To reduce the time an unauthorized change remains unaddressed, monitoring needs useful notification, ownership, and escalation. Retention and resilient archives remain valuable, but they do not themselves create timely awareness when the review process is missing.

Study tip: Ask who receives the signal and what happens next; collection alone does not create timely response.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Longer retention may preserve historical evidence but does not shorten the delay when no person or workflow reviews relevant events promptly.

B: Storage efficiency reduces capacity costs but does not create timely awareness or an accountable response to the unauthorized changes being recorded.

C: An extra copy can improve availability of records, but duplicate unreviewed data does not address the absence of timely detection and action.

D: Timely notification linked to accountable handling turns collected events into an opportunity to investigate and respond before the activity remains unnoticed for months.

## SEC2-Q101

Testing confirms that a specific approved installer is falsely blocked by host intrusion prevention during a required update. The team has verified its hash and needed operations. Which exception BEST preserves protection while allowing the approved update window?

- A. Trust every executable launched from the user's downloads folder during future maintenance
- B. Temporarily disable the entire prevention engine on affected hosts for the update window
- C. Permanently allow every program from the installer publisher to perform every blocked behavior
- D. Allow the verified installer and required operations under a scoped, expiring exception, then validate normal protection

Answer: D

A verified false positive justifies a targeted exception, not removal of unrelated enforcement. Tie the allowance to the specific trusted artifact, necessary actions, and approved period, then check that the intended update succeeds and ordinary protections resume. This preserves the distinction between a known compatibility issue and blanket trust.

Study tip: Scope a prevention exception to the evidence: artifact, required behavior, affected systems, and duration.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A user-writable location can contain unrelated code, so this rule grants more execution freedom than the verified installer and specific update require.

B: A temporary shutdown is narrower than permanent disablement but still removes unrelated prevention, although a verified artifact-specific allowance can meet the same update need.

C: Publisher-wide unrestricted behavior covers more programs and operations than were assessed and retains that excess permission after the update is complete.

D: The narrow identity, behavior, and time conditions address the known false positive without removing prevention from unrelated processes or future activity.

## SEC2-Q102

A gateway correctly denies ordinary traffic between a test zone and a production zone. A management host has interfaces in both zones and has accidentally enabled packet forwarding, creating a second path. It needs to administer each zone but must not route other devices' traffic. Which correction BEST closes the bypass?

- A. Restrict unsolicited Internet traffic at the external perimeter without changing the internal host
- B. Encrypt administrator sessions while leaving the host's inter-zone forwarding enabled
- C. Add another deny rule only to the gateway that the bypass traffic does not traverse
- D. Disable forwarding and bridging on the management host while preserving its authorized management connections

Answer: D

Segmentation depends on controlling every path between the zones. A correct gateway policy cannot enforce traffic that bypasses it through a forwarding host. Disabling the unintended transit function preserves the host's direct administrative role while removing the extra route available to other devices.

Study tip: Trace the actual packet path; a correct firewall rule cannot protect a boundary that traffic goes around.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The bypass exists between two internal interfaces, so an external perimeter rule does not address traffic routed locally through the management host.

B: Session encryption protects management content but does not remove the transit path that lets other devices cross the intended zone boundary.

C: Rules cannot block packets that take another path, so strengthening the correct gateway policy does not remove forwarding through the dual-homed host.

D: Removing the host's transit capability closes the unintended inter-zone path while retaining its stated need to initiate approved administration in each zone.

## SEC2-Q103

Two cloud designs meet the same security, availability, and data-location requirements. In this synthetic comparison, A costs $700 per month including the required transfers. B costs $200 per month plus $0.04 per GB transferred out; its workload transfers 20,000 GB out every month. Ignore all other charges. Which monthly cost assessment is correct?

- A. A costs $700 and B costs $1,800, because each transfer must be charged for departure and arrival
- B. A costs $700 and B costs $800, because the usage charge replaces B's fixed monthly charge
- C. A costs $700 and B costs $200, making B preferable based on its lower fixed charge
- D. A costs $700 and B costs $1,000, making A the lower-cost qualifying architecture

Answer: D

Architecture cost depends on the workload and its data movement, not just the lowest fixed fee. Here, B's recurring transfer cost is 20,000 multiplied by $0.04, or $800, plus $200 fixed. Because both designs satisfy the stated security and service requirements, A's $700 total is the lower qualifying monthly cost.

Study tip: Compare total workload cost, including recurring data movement, after checking the required security properties.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The scenario charges B's outbound traffic once and excludes other charges. Adding a second charge for arrival invents a cost absent from the supplied model.

B: The quoted pricing makes the transfer charge additional to the fixed charge. Counting only usage omits the separate $200 monthly amount.

C: The fixed charge omits the workload's recurring outbound transfers. Ignoring that usage understates B's monthly cost by $800 in the supplied comparison.

D: B's recurring transfers cost $800, which must be added to its $200 fixed charge. A therefore costs less under the stated equivalent requirements.

## SEC2-Q104

A Terraform deployment marks a database password as sensitive, so normal console output hides it. Reviewers find that the password is still present in the deployment state file, which a broad support group can download. Which design change BEST addresses this exposure?

- A. Use an encrypted, access-controlled state backend limited to authorized deployment identities
- B. Encrypt the database's data volume while leaving deployment state permissions unchanged
- C. Keep state broadly readable and hide the password more thoroughly in the deployment summary
- D. Rotate the database password more often while retaining the current state-access permissions

Answer: A

In this explicitly named Terraform case, the sensitive flag hides ordinary presentation but does not by itself omit the value from state. The state therefore needs appropriate confidentiality and access controls. Designs can also avoid persistence where supported, but existing secret-bearing state cannot be treated as a harmless status report.

Study tip: Trace a secret through saved plans and state, not only visible deployment output.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://developer.hashicorp.com/terraform/language/manage-sensitive-data

A: Hiding sensitive console output does not remove secrets from state. Restricting and protecting the state backend addresses the actual location and readers of the exposed value.

B: Database-volume encryption protects a different resource. It does not prevent broad readers from obtaining credentials that the provisioning process retained in its state.

C: Additional display masking changes the summary rather than the stored state. Support users could still retrieve the password from the downloadable artifact.

D: Rotation can reduce a credential's useful lifetime, but broad readers can still obtain the latest secret-bearing state. The exposed storage and access boundary remains.

## SEC2-Q105

An AWS Lambda function serves different customers. It stores a customer's private report in a module-level variable and returns that variable when a later request omits a field. A reused execution environment returns the previous customer's report. Which change MOST directly addresses the defect?

- A. Add provisioned concurrency while retaining the shared customer variable and existing fallback
- B. Keep customer data in request-scoped state and enforce the current customer's authorization before returning a report
- C. Encrypt the network response while leaving the previous-customer fallback unchanged
- D. Redeploy the function periodically while retaining the shared variable between invocations

Answer: B

Serverless execution environments may be reused, so a function must not treat retained process state as private to the next caller. Customer-specific data should be scoped and selected deliberately for each request. The repair addresses state separation and authorization rather than assuming provider-managed execution provides automatic application-level isolation.

Study tip: Reusable execution environments require deliberate separation of each request's private state.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html

A: Provisioned capacity changes startup and scaling behavior. It does not make retained customer data private to the next invocation or correct the report selection.

B: Request-scoped state prevents unintended reuse of another request's private data. Current-customer authorization also binds the returned report to the caller who is entitled to receive it.

C: Transport encryption protects delivery to the requesting client, but it would still securely deliver the wrong customer's private report to that client.

D: Redeployment may replace an environment, but requests can still share state during its lifetime. Periodic replacement does not repair the cross-customer fallback.

## SEC2-Q106

An order passes through six microservices. Each service records local events, but investigators cannot determine which events belong to the same order because calls cross several queues and retries. Which architecture improvement BEST supports reconstruction without logging complete customer payloads?

- A. Propagate a nonsecret correlation identifier and record it with relevant service events
- B. Collect more precise timestamps but leave every event unrelated to its originating request
- C. Retain only the public API gateway's final response status
- D. Give each service its own independent request identifiers without recording how they relate

Answer: A

Distributed services create an observability challenge because one business action can cross multiple processes and asynchronous boundaries. Correlation identifiers link related events without requiring sensitive payloads in every log. They support tracing and investigation; they are not credentials and should not be used as authorization decisions.

Study tip: Use a request correlation value to connect events that timestamps alone cannot reliably associate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A shared correlation value connects events across asynchronous boundaries and retries. Logging it with service context supports reconstruction without duplicating complete sensitive message contents.

B: Accurate time helps sequencing, but concurrent requests and retries can still overlap. Timestamps alone do not reliably identify which events belong to the same order.

C: The gateway outcome omits the internal queue and service events needed to reconstruct processing. A final status alone does not explain the distributed execution path.

D: Local identifiers organize each service's records, but unrelated identifiers do not connect the same order across service boundaries, queues, and retries.

## SEC2-Q107

A batch container needs to read an input directory and write to its own temporary workspace. It currently runs privileged and mounts the host's root filesystem read-write. Which change BEST restores a useful isolation boundary for this workload?

- A. Disable privileged mode, allow only required capabilities, and replace the host-root mount with narrowly scoped storage
- B. Keep privileged mode and the host-root mount but publish no network ports
- C. Make the container image's root filesystem read-only while retaining its privileged writable host-root mount
- D. Retain the configuration and move the container image to a private registry

Answer: A

Container isolation depends on runtime configuration as well as packaging. A privileged workload with broad writable host mounts can undermine the intended separation even if the image came from a trusted registry. This job should receive only the capabilities and storage paths its stated processing requires.

Study tip: Inspect runtime privileges and host mounts before treating a container as a strong boundary.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/190/final

A: The workload has no stated need to control the host. Removing excessive privileges and broad writable host access reduces ways container code can affect host resources.

B: Closing inbound ports reduces one entry path but leaves container code able to use excessive local host access. Network exposure and host privilege are separate boundaries.

C: A read-only container root does not make a separately mounted host path read-only. The broad writable host mount and excessive runtime authority remain.

D: Registry access controls protect image distribution but do not change the privileges or writable host paths granted when the image runs.

## SEC2-Q108

A virtualized test workload consumes nearly all host CPU and storage I/O, slowing a critical application in another virtual machine. No guest-to-host escape or unauthorized data access occurred. Which control MOST directly addresses the demonstrated problem?

- A. Put the two guests into separate network VLANs without changing host resource allocation
- B. Increase both guests' virtual CPU counts while leaving host capacity and consumption limits unchanged
- C. Raise the critical application's process priority only inside its guest operating system
- D. Reserve required capacity for the critical workload and enforce suitable limits on the test workload

Answer: D

Shared infrastructure can suffer availability problems without any security boundary escape. A workload may legitimately consume resources that other workloads also need. Capacity reservations and carefully chosen limits address this failure mode, while network isolation and encryption address different risks.

Study tip: A noisy neighbor can harm availability while remaining inside its authorized virtual machine.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Network segmentation can restrict communication between guests but does not allocate the CPU or storage I/O they consume on the same host.

B: More virtual CPUs do not create physical processing or storage capacity. Without suitable allocation controls, the test workload can still compete for the shared bottleneck.

C: Guest-local priority affects that guest's processes. It does not reserve the host CPU and storage resources contested by the separate test virtual machine.

D: Reservations and resource limits address competition for shared host capacity. They can preserve critical service performance without requiring an isolation escape to have occurred.

## SEC2-Q109

A laboratory labels a network air-gapped. A dual-connected maintenance computer now forwards approved update traffic between that network and the corporate network, using a restrictive firewall. Which assessment is correct?

- A. The physical air gap remains intact because only approved update destinations are permitted
- B. The network no longer has a physical air gap because a forwarding connection now crosses the boundary
- C. The physical air gap remains intact if the maintenance computer uses encrypted connections
- D. The network becomes physically isolated whenever users cannot browse arbitrary websites

Answer: B

An air gap is a physical separation from other networks. Once a connected intermediary forwards traffic across the boundary, the architecture relies on that intermediary and its policy for protection. It may still provide useful controlled connectivity, but its security description must reflect the actual path.

Study tip: Verify actual forwarding paths when assessing a claim of physical isolation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: An allowlist limits which traffic crosses a connection; it does not remove the connection itself. Physical isolation and filtered connectivity are different architecture properties.

B: A functioning network path through the maintenance computer connects the environments. Restrictive filtering may provide logical control, but it does not restore physical disconnection.

C: Encryption protects communication across an existing path. The presence of that path still contradicts the claimed physical disconnection.

D: Blocking general browsing narrows permitted use but leaves the approved forwarding path present. Application restrictions are not evidence of an air gap.

## SEC2-Q110

An SDN deployment must continue accepting authorized policy updates after one controller fails. During a complete management-network outage, switches must continue applying their existing restrictive policy rather than permitting all traffic. Which TWO design provisions address these separate requirements? (Select TWO.)

- A. Provide supported redundant controllers with tested failover and independent management reachability
- B. Configure and test local forwarding behavior that retains the approved restrictive rules when controllers are unreachable
- C. Make every switch permit all traffic whenever controller communication is lost
- D. Add a second switch power supply while leaving the sole controller and its network path unchanged
- E. Increase the only controller's memory without adding an alternate controller

Answer: A|B

SDN separates policy management from forwarding, so resilience needs to address both planes. Supported redundant controllers can preserve administration after a controller failure, while defined local behavior controls what switches do when no controller is reachable. Neither behavior should be assumed from the SDN label alone.

Study tip: Plan separately for losing a controller and losing every control-plane connection.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Controller redundancy and reachable alternate paths support continued policy administration after a single controller failure. The failover behavior must be tested for the chosen implementation.

B: Defined local behavior prevents loss of the management connection from turning into an unrestricted forwarding condition. Its operation must match the switch platform's supported behavior.

C: An unrestricted fallback may preserve reachability, but it directly violates the requirement to maintain restrictive policy during a complete management outage.

D: Power redundancy can protect a switch from a power-supply failure. It does not provide controller failover or define forwarding policy during a management-network outage.

E: More memory may improve capacity but does not allow management to continue when that single controller fails or becomes unreachable.

## SEC2-Q111

A battery-powered environmental sensor must operate unattended for a year. A proposed security package was designed for desktop computers and substantially increases radio traffic and processor use. Which evaluation is MOST important before selecting the package?

- A. Check only whether the package's peak memory use fits the sensor's available RAM
- B. Measure battery life with logging and radio communication disabled, then enable them for deployment
- C. Use the desktop vendor's processor benchmark as the acceptance test for the sensor fleet
- D. Measure the package's resource and power demands under representative secure operating conditions

Answer: D

Embedded and IoT systems can have tight power, processor, and communication budgets. A control suitable for a workstation may be impractical on a long-lived sensor. The architecture should validate compatible protections with representative workloads and retain required security properties rather than silently weakening them to meet an energy target.

Study tip: Evaluate security controls within the device's power and compute budget.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: Memory compatibility is useful, but it does not establish the year-long power budget. Added processor activity and radio transmissions also affect unattended operating life.

B: This test omits important parts of the deployed workload. Its result would not establish operating life when security logging and communication consume energy.

C: A desktop benchmark does not reproduce the sensor's hardware, communication pattern, or battery constraints. The architecture needs measurements under representative secure operating conditions.

D: The sensor's architecture has constrained energy and compute resources. Representative testing determines whether the proposed controls can operate while preserving the required unattended service life.

## SEC2-Q112

An industrial network must export process telemetry to a business reporting system. No business-network command or acknowledgement needs to enter the industrial network, and the approved design requires hardware-enforced one-way transfer. Which architecture BEST fits?

- A. A site-to-site VPN carrying telemetry over a conventional bidirectional encrypted tunnel
- B. A dual-homed reporting proxy whose software policy rejects incoming business-network commands
- C. A unidirectional gateway designed for the required telemetry transfer
- D. Separate VLANs with an inter-VLAN firewall permitting only outbound telemetry sessions

Answer: C

A unidirectional gateway is suited to a one-way export requirement when the protocol and application can operate through it. This provides a different property from encrypting a normal bidirectional link. The scenario explicitly removes the need for inbound commands or acknowledgements, which is essential when evaluating feasibility.

Study tip: One-way transfer is a direction constraint, not a property supplied by ordinary VPN encryption.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: A VPN can protect traffic crossing the boundary, but its encrypted tunnel remains bidirectional. Encryption does not supply the specified hardware-enforced one-way property.

B: A software-controlled proxy can restrict operations, but it retains a conventional connected path. The required one-way property must be enforced by the transfer hardware.

C: A suitable one-way gateway supports the approved outward data flow while preventing reverse network transmission through that boundary. Application compatibility must support the one-way design.

D: This provides logical filtering of a two-way networking path. It does not meet the explicit requirement for hardware-enforced unidirectional transfer across the boundary.

## SEC2-Q113

An on-premises network and a cloud network both use 192.0.2.0/24 in this documentation example. Each contains a different server at 192.0.2.40. A new private connection must let applications reach both servers distinctly, and no address translation exists. What should the architect resolve?

- A. The routing metrics, making the cloud route preferred for both identical destination addresses
- B. The static routes, installing two equal routes to the same overlapping subnet
- C. The overlapping address spaces, using a supported nonoverlapping plan or deliberately designed translation
- D. The DNS names, assigning a unique name to each server but preserving identical returned addresses

Answer: C

Hybrid integration involves more than creating an encrypted or private connection. Existing address plans may conflict when previously separate networks are joined. The solution must provide distinct reachable destinations through supported readdressing or carefully designed translation, while preserving the intended security zones and application behavior.

Study tip: Private connectivity does not automatically resolve incompatible address plans.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Choosing one preferred route selects one destination for that address. It does not provide distinct reachability to both different servers that share the address.

B: Two routes to an identical prefix do not identify which different server a client intended. The addressing or translation design must distinguish the destinations.

C: Identical destination addresses do not uniquely identify the two intended servers across the joined networks. Address planning or supported translation must remove that ambiguity.

D: Different names help users distinguish services, but the resulting identical destination addresses still conflict on the joined network without another supported distinction.

## SEC2-Q114

An AWS Lambda API scales to thousands of concurrent executions, but its required database supports only a bounded number of simultaneous connections. A traffic surge exhausts the database and interrupts legitimate requests. Which architecture change BEST addresses this mismatch?

- A. Remove function concurrency limits so the provider can create more executions
- B. Bound function concurrency and control request admission according to the database's tested capacity
- C. Increase client retry frequency while retaining unlimited function concurrency against the database
- D. Increase the permitted query duration while leaving admission and connection concurrency unrestricted

Answer: B

Elastic compute can overwhelm a dependency that does not scale at the same rate. In this explicitly named Lambda case, controlling concurrency and admission aligns demand with the database's supported capacity. Throttling behavior and legitimate traffic needs should be tested; autoscaling alone is not an end-to-end availability guarantee.

Study tip: Check the capacity of dependencies before allowing an upstream service to scale freely.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html

A: More simultaneous executions can create additional database connections and worsen the bottleneck. Function scalability does not expand the capacity of its dependency.

B: Scaling must account for downstream limits. Concurrency and admission controls can keep the function from overwhelming the database while providing a deliberate response to excess demand.

C: More frequent retries can increase demand on an already exhausted dependency. They do not align simultaneous function work with the database's connection capacity.

D: Longer execution allowances may keep connections occupied for longer. They do not correct the mismatch between elastic request processing and bounded database connections.

## SEC2-Q115

A research contract requires its processing hardware not to be shared with workloads belonging to other organizations. Logical separation alone is explicitly insufficient. Which hosting arrangement MOST directly meets this requirement?

- A. Separate VLANs for tenants whose virtual machines share physical servers
- B. Different virtual machines on a shared multi-organization hypervisor
- C. Different container namespaces on a shared multi-organization host
- D. Dedicated physical hosts reserved for the organization's workloads under a verified hosting agreement

Answer: D

The required security property is physical allocation of compute, so the design must provide dedicated hardware rather than only separate names, networks, or virtual execution contexts. Dedicated hosting does not eliminate other security responsibilities; it addresses the particular sharing restriction stated in the contract.

Study tip: Translate a physical-separation requirement into evidence about the underlying hardware allocation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://aws.amazon.com/compliance/shared-responsibility-model/

A: VLANs separate network traffic rather than reserving compute hardware. They do not prevent another organization's workload from executing on the same physical server.

B: Separate virtual machines provide logical isolation but still share physical processing hardware. That does not meet the contract's explicit physical allocation requirement.

C: Namespaces can separate workloads logically, but the containers still use the same physical host. The requirement explicitly rejects logical separation as sufficient.

D: Dedicated physical hosts address the stated prohibition on sharing processing hardware. The organization still needs evidence that the hosting arrangement actually enforces that allocation.

## SEC2-Q116

Two independent stateful firewalls have identical policies but do not synchronize connection state. A client's initial TCP packet passes through FW-A. The server's reply returns through FW-B, which logs 'no matching established session' and drops it. How should connectivity be restored without weakening the established-session requirement?

- A. Duplicate the same new-connection policy on FW-B without synchronizing state
- B. Extend FW-B's idle-session timeout without changing routing or sharing connection state
- C. Restore a symmetric traffic path or implement supported connection-state synchronization between the firewalls
- D. Accept inbound packets carrying a TCP ACK flag even when no matching session exists

Answer: C

Stateful enforcement depends on the firewall seeing or learning the relevant session, not merely having the same static rules as another device. The logs identify asymmetric routing through independent state tables. Correcting the path or using supported state synchronization preserves the intended protection instead of broadly allowing unsolicited packets.

Study tip: Identical firewall rules do not imply identical live connection tables.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The policies are already identical. Matching configuration does not automatically give FW-B the runtime session information created when the connection traversed FW-A.

B: A longer timeout preserves state that already exists. FW-B never learned this connection, so retaining entries longer does not create the missing session.

C: The reply reaches a firewall that never learned the connection. Symmetric routing or supported state synchronization addresses that missing state while preserving the intended connection policy.

D: An ACK flag can be set without an authorized session. Accepting it alone would bypass the established-session requirement rather than give FW-B the missing state.

## SEC2-Q117

A test request passes through an inline security appliance and reaches the application. The appliance successfully decodes the request and records a matching exploit signature with action=ALERT. The rule's blocking action is disabled. What BEST explains why the request was delivered?

- A. The matching rule detects the request but is configured not to enforce a blocking action
- B. A parallel route carried this request around the inline appliance's inspection path
- C. The appliance entered an overload bypass after exhausting its TCP session capacity
- D. The application payload remained encrypted and unavailable to the inspection engine

Answer: A

Detection capability, placement, and enforcement configuration are separate properties. This appliance sees and recognizes the request, but its selected rule only alerts. Prevention requires an appropriate blocking action, deployed and validated under the organization's change process; inline placement alone does not establish that enforcement is active.

Study tip: Read the rule action as well as whether an appliance is inline.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The log confirms detection, and the rule explicitly uses alert-only behavior. Being physically inline does not make a disabled blocking action take effect.

B: The described request passes through the appliance and produces a matching decoded event. The evidence supports a nonblocking action rather than this routing explanation.

C: Capacity bypass is a possible failure mechanism, but no overload is reported here. The explicit alert-only rule already explains delivery of the recognized request.

D: The appliance successfully decoded the request and matched its exploit content. Those observations show that missing payload visibility is not the demonstrated cause.

## SEC2-Q118

A web application firewall blocks an approved test attack sent to portal.example. The same test reaches the application when sent directly to its public origin address with the expected hostname. Policy requires all public requests to pass through the WAF. Which change MOST directly closes the demonstrated gap?

- A. Move the public hostname to another DNS record while keeping the same unprotected origin path
- B. Restrict origin access to the approved WAF path and validate that direct public requests are rejected
- C. Add another copy of the existing WAF signature while leaving the origin directly reachable
- D. Enable more detailed WAF request logging without changing the origin's allowed connection sources

Answer: B

A protective gateway only controls traffic that actually traverses it. The successful direct-origin test demonstrates an alternate path around the WAF, rather than a failure of its existing signature. The origin should accept the approved gateway path while rejecting direct public access, with normal application behavior also verified.

Study tip: Test the origin's reachable paths when a gateway is meant to protect every request.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Changing the public name or record does not prevent clients that know the origin address from connecting directly with the expected hostname.

B: The origin remains a route around the required control. Restricting its reachable sources or authenticated proxy path makes traversal of the WAF enforceable.

C: The WAF already blocks the test when traffic reaches it. Additional identical rules do not affect requests that bypass the WAF entirely.

D: Additional logs improve visibility only for requests the WAF receives. They do not force direct-origin traffic through the protected path.

## SEC2-Q119

A legacy printer cannot run an 802.1X supplicant. An approved exception lets the switch admit it by matching its MAC address, with access restricted to print services. Which limitation should remain in the architecture assessment?

- A. A match against the inventory's stored address is sufficient proof that the original physical printer returned
- B. Successful use of an allowed print service authenticates the connecting printer's hardware identity
- C. Address-only admission logs can distinguish the original printer from another device presenting its permitted address
- D. The MAC address can be copied, so the exception does not provide cryptographic proof of the printer's identity

Answer: D

MAC-based exceptions can accommodate devices that cannot perform the preferred authentication method, but their assurance differs from certificate-based identity. The restricted policy is a compensating measure that limits access. It does not make the address uncopyable or prove that the original physical printer is connected.

Study tip: An address-based exception is a weaker identity signal even when its network access is narrow.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An inventory match establishes that the presented address is recognized, not that its presenter is the original device. Another device can present that address.

B: Permission to reach a service describes authorized communication. Completing that communication does not turn a copyable network address into cryptographic device authentication.

C: Those logs record the same accepted identifier in either case. Additional independent evidence would be needed to distinguish which physical device presented it.

D: A MAC match identifies a presented address rather than proving possession of a protected credential. Restricting the exception's access limits exposure but does not strengthen that identity proof.

## SEC2-Q120

An application uses a reverse proxy's client-address header in access decisions. The proxy currently preserves a header supplied by the client, and the origin also accepts direct internet connections. Which design BEST prevents a client from choosing the address the application treats as trusted?

- A. Require HTTPS and the expected hostname while trusting the first address supplied in each request
- B. Have the proxy set the correct header while leaving the directly reachable origin equally trusting
- C. Replace untrusted headers at the proxy, restrict the origin to that proxy, and trust only its verified metadata
- D. Restrict origin connections to the proxy but forward the client's original address header unchanged

Answer: C

A proxy header is not inherently trustworthy merely because its name resembles an infrastructure field. The origin needs a controlled path from a proxy that replaces untrusted values with verified connection metadata. Otherwise, encrypted requests or familiar header names can still carry client-chosen assertions into security decisions.

Study tip: Establish who created security-relevant metadata and which path delivered it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: TLS and hostname checks do not make a client-supplied address truthful. The application would continue basing its decision on an unverified assertion.

B: Proxy replacement protects requests that traverse it. A direct client could still supply a trusted-looking header to the origin through the remaining bypass path.

C: Trusted metadata must be created at a controlled boundary and accepted only through that boundary. Sanitizing headers and restricting the origin closes both described spoofing paths.

D: The network restriction establishes the request's immediate sender, but the forwarded address remains client-controlled. Trusted transport does not validate that header's original content.

## SEC2-Q121

A TCP load balancer currently passes TLS through unchanged to a server pool. A new requirement routes /billing and /catalog requests to different pools based on the HTTP path. An approved design permits TLS termination at the load balancer and protects the backend connections. What capability is needed?

- A. More Layer 4 listeners using the same destination port without inspecting HTTP
- B. DNS-based distribution that sends the same service hostname to both server pools
- C. TCP source-address affinity that keeps each client on one backend pool
- D. Layer 7 proxying that can inspect the decrypted HTTP path and apply the routing policy

Answer: D

The required decision depends on application content, so a Layer 4 connection distributor is insufficient while TLS remains opaque. A properly configured Layer 7 proxy at the approved termination point can evaluate paths. Backend transport protection remains part of the supplied design, distinct from the routing capability.

Study tip: Choose the inspection layer that can see the field used in the routing rule.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: The requests share the same transport endpoint. Additional port-based listeners do not reveal which encrypted HTTP path an individual request contains.

B: DNS resolution does not examine the HTTP path of each request. It cannot implement the specified billing-versus-catalog routing decision for that shared hostname.

C: Client affinity makes a connection-routing choice using a different property. It does not send that client's different HTTP paths to their required application pools.

D: Path-based routing requires access to HTTP application content. The approved TLS termination boundary supplies that visibility, allowing an application-layer proxy to select the correct pool.

## SEC2-Q122

A remote-access VPN routes only company private subnets through its tunnel. Internet browsing and DNS use the employee's home connection directly. Policy now requires that all work-device internet traffic and DNS follow the company's monitored path whenever the VPN is connected. Which configuration BEST meets that requirement?

- A. A profile that adds selected SaaS routes but leaves the default internet route outside the tunnel
- B. An enforced full-tunnel profile with the required DNS routing and tested coverage of the work device's traffic
- C. The existing split-tunnel routes with a stronger VPN cipher
- D. A profile that tunnels DNS but leaves internet application traffic on the home connection

Answer: B

Routing scope determines which traffic traverses a VPN. The existing profile is intentionally split, so strengthening its authentication or encryption does not meet the new monitoring requirement. An enforced full-tunnel design must include DNS and actual device traffic behavior, with testing for the environment's supported network configurations.

Study tip: A stronger tunnel does not protect or monitor traffic that routes around it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Selected routes can capture those destinations, but the policy covers all work-device internet traffic. Unlisted destinations would continue using the home connection.

B: A full-tunnel design directs the required traffic through the monitored path. DNS and supported address-family behavior must be included in verification to avoid unintended bypasses.

C: A stronger cipher protects traffic already using the VPN, but internet browsing and DNS would still follow their existing direct routes.

D: Tunneling DNS addresses name-resolution visibility, but browsing and other application traffic would still avoid the company's monitored path under the remaining split routes.

## SEC2-Q123

A contractor needs one browser-based scheduling application and no network-level access to internal servers. The existing VPN profile grants broad internal subnet reachability. Which redesign BEST matches the contractor's stated requirement?

- A. The current broad VPN profile with a shorter idle timeout
- B. An identity-controlled application access broker that exposes only the scheduling application
- C. The existing broad VPN profile with stronger multifactor authentication for the contractor
- D. A dedicated contractor VLAN with unrestricted routing to the same internal server subnets

Answer: B

The business requirement is an application workflow, not membership in the internal network. A suitably enforced application access broker can grant that workflow with a narrower exposed surface. Its policies must still authorize the contractor correctly, while any unnecessary direct VPN paths are removed.

Study tip: Grant the required application function without automatically granting internal network reachability.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final

A: A shorter timeout reduces session duration but leaves unnecessarily broad reachability while the session is active. It does not narrow access to the scheduling application.

B: Application-specific access provides the required workflow without granting general network adjacency. Authorization can be scoped to the contractor and the single permitted application.

C: Stronger authentication improves assurance about the connecting user, but the resulting network reachability remains excessive. The requirement also calls for a narrower access scope.

D: A different network segment does not by itself narrow reachable applications. Unrestricted routing would preserve the broad access that exceeds the contractor's task.

## SEC2-Q124

Two gateways must protect traffic crossing an untrusted network. The design requires confidentiality for each complete original IP packet, including its inner source and destination addresses, while new outer addresses route between the gateways. Which IPsec configuration fits?

- A. ESP in transport mode with encryption enabled
- B. AH in tunnel mode without ESP encryption
- C. AH in transport mode without ESP encryption
- D. ESP in tunnel mode with encryption enabled

Answer: D

The question requires both encapsulation of the original packet and confidentiality. ESP tunnel mode with encryption provides those properties while leaving a new outer header available for gateway routing. AH supplies a different protection goal, and transport mode does not hide the original IP header as an inner encrypted packet.

Study tip: Separate tunnel encapsulation from the choice of encryption or authentication service.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://www.rfc-editor.org/rfc/rfc4301.html

A: Transport mode protects the upper-layer content while retaining the original IP header for routing. It does not provide the required encrypted inner-packet encapsulation.

B: AH can provide authentication and integrity protection but does not provide confidentiality. Tunnel encapsulation alone does not encrypt the original packet.

C: AH transport mode does not encrypt the payload or provide the requested protected inner IP packet. It cannot meet the stated confidentiality requirement.

D: Encrypted ESP tunnel mode encapsulates and protects the original IP packet, including its inner header. A separate outer IP header supports routing between the gateways.

## SEC2-Q125

A desk's switch port serves an approved IP phone and a workstation connected through that phone. Port security permits only one source MAC address, so the second approved device triggers a violation. The requirement is to permit exactly these two device addresses and reject others. What is the narrowest suitable change?

- A. Change the workstation's IP address while retaining the one-MAC limit
- B. Permit only the phone's MAC address and exempt all additional sources behind that phone
- C. Raise the dynamic limit to two while allowing whichever two MAC addresses are learned first
- D. Configure the port to permit the two approved MAC addresses with a limit consistent with those two devices

Answer: D

Security configuration must reflect the legitimate topology. This port sees two devices even though only one cable connects to the wall switch. Permitting the known pair and an appropriate count solves the specific violation while retaining a restriction; MAC-based controls still do not provide cryptographic proof of device identity.

Study tip: Count the source devices visible to a port, including devices behind an approved phone.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The violation concerns source MAC addresses, not IP addressing. Renumbering the workstation does not reduce the number of Layer 2 device addresses seen.

B: The exemption would admit additional devices beyond the known workstation. The requirement is an explicit two-address restriction, not trust in everything behind the phone.

C: A count of two fits the topology but does not identify the approved pair. Arbitrary learned addresses could occupy those permitted slots.

D: The requirement identifies two legitimate source addresses. A matching limit and explicit approved addresses accommodate the phone and workstation without removing the port restriction.

## SEC2-Q126

A laptop sends EAP messages through a switch. The switch relays the authentication exchange to a RADIUS server and controls production-network admission based on the result. Which THREE role assignments match this 802.1X deployment? (Select THREE.)

- A. The laptop is the authentication server for other clients
- B. The RADIUS server is the physical access-port authenticator
- C. The laptop is the supplicant
- D. The switch is the supplicant for the laptop's access request
- E. The switch is the authenticator
- F. The RADIUS server is the authentication server

Answer: C|E|F

802.1X separates the requesting client, the device controlling network admission, and the service evaluating authentication. Here, those roles map to the laptop, switch, and RADIUS server respectively. The chosen EAP method changes the authentication details without changing these supplied component responsibilities.

Study tip: Map roles by who requests access, who controls the port, and who evaluates authentication.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/106x/configuration/security/cisco-nexus-9000-series-nx-os-security-configuration-guide-release-106x/m-configuring-8021x.html

A: The laptop is being evaluated for access. Nothing in the described exchange assigns it authority to validate other clients or return RADIUS decisions.

B: The RADIUS server supplies the authentication decision, but the switch owns and controls the access port. These are separate roles in the stated deployment.

C: The laptop requests network access and participates in authentication. In this deployment, that client-side role is the supplicant.

D: The switch enforces access and relays the laptop's exchange here. The laptop, rather than the switch, is requesting this network admission.

E: The switch controls the access port and relays the authentication exchange. Those enforcement and relay functions identify the authenticator role.

F: The server evaluates the authentication exchange and returns a result to the access device. It performs the authentication-server role in this design.

## SEC2-Q127

Two virtual machines communicate through a virtual switch on the same host. Testing confirms their traffic stays inside the host and never reaches its physical uplink. A sensor on the upstream physical switch sees no packets from their exchange. Where should visibility be added?

- A. At the relevant virtual-switch or host-networking path using a supported monitoring mechanism
- B. Only at the organization's internet perimeter firewall
- C. On another physical switch farther upstream from the same unused uplink
- D. By increasing mirror sampling on the physical uplink that the exchange never traverses

Answer: A

Sensor coverage follows the actual traffic path. Communication switched locally between virtual machines may not traverse a physical uplink, so a physical mirror outside the host can miss it entirely. Add supported visibility within the virtual networking environment while controlling access to the captured traffic.

Study tip: Trace where packets are forwarded before choosing a sensor location.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/190/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The monitored exchange remains within the host, so observation must occur along that actual forwarding path. A supported virtual tap or equivalent host visibility can expose it.

B: The exchange does not leave the virtualization host, much less cross the internet perimeter. Perimeter observation cannot supply the missing internal traffic.

C: Moving the sensor farther along a path the traffic never takes does not add visibility. The packets are switched internally on the host.

D: More complete sampling cannot capture packets absent from the monitored link. Visibility must be placed where this host-local forwarding actually occurs.

## SEC2-Q128

A branch needs at least 600 Mbps of throughput with its required security inspection enabled. Synthetic test results are: appliance A, 1,000 Mbps raw / 400 Mbps inspected / $900; B, 2,000 raw / 650 inspected / $1,200; C, 4,000 raw / 500 inspected / $1,100; D, 2,000 raw / 800 inspected / $1,600. Which is the lowest-cost qualifying choice?

- A. Appliance B at $1,200
- B. Appliance D at $1,600
- C. Appliance A at $900
- D. Appliance C at $1,100

Answer: A

Security functions can materially change appliance throughput. Selection must use the performance measured with the required inspection enabled, not a larger raw forwarding figure. Only B and D meet the stated 600 Mbps threshold; B is the less expensive of those two under the supplied synthetic comparison.

Study tip: Compare capacity with the required controls enabled before comparing purchase prices.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Its tested inspected throughput is 650 Mbps, meeting the 600 Mbps requirement. It costs less than the only other qualifying option, appliance D.

B: Its 800 Mbps inspected performance qualifies, but it is not the lowest-cost qualifying option. Appliance B meets the requirement at a lower price.

C: Its low price is attractive, but inspected throughput is only 400 Mbps. The 1,000 Mbps raw figure does not satisfy the required enabled-security condition.

D: The highest raw throughput does not make this appliance suitable. With the required inspection active, its 500 Mbps result falls below the requirement.

## SEC2-Q129

A firewall creates temporary state for an approved UDP exchange and permits replies only while matching state exists. It expires that service's state after 10 seconds of inactivity. The application legitimately responds after 18 seconds, and logs show state expiry before each dropped reply. Service-specific timeouts are supported. Which change BEST preserves functionality and stateful enforcement?

- A. Increase the TCP established-session timeout while retaining the existing UDP timeout for this service
- B. Increase the client's response-wait interval while leaving the firewall's ten-second state lifetime unchanged
- C. Permit reply packets from the approved server even when no matching request state exists
- D. Set a justified service-specific UDP timeout above the validated reply interval, then verify permitted replies and expired-state drops

Answer: D

This firewall tracks the UDP exchange using temporary state, whose lifetime must accommodate the approved application's response behavior. The logs identify premature expiry rather than an incorrect server address or TCP setting. A scoped, tested timeout change addresses that mismatch while preserving the policy that replies must match a tracked request.

Study tip: Match the protocol's state lifetime to validated application timing without bypassing the required state check.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The dropped replies belong to a UDP exchange. A longer TCP timer does not change the lifetime of the UDP state entry involved.

B: The client can wait longer, but the firewall will still discard the matching state before the response arrives. The blocking condition remains.

C: That exception may permit delivery, but it removes the stated request-state requirement. The supported timeout adjustment can retain the required enforcement model.

D: The valid response arrives after this entry expires. A suitable scoped timeout preserves the needed request-to-reply association without abandoning matching-state enforcement.

## SEC2-Q130

During an authorized failure test, an inline inspection appliance loses its policy engine. A hardware bypass keeps the link forwarding, and a previously blocked test request reaches the destination without inspection. Which behavior has the test demonstrated?

- A. Fail-closed behavior that prevents forwarding when enforcement is unavailable
- B. A loss of physical link connectivity that prevents packets from crossing
- C. Fail-open behavior that preserves connectivity while leaving an inspection gap
- D. Successful enforcement failover to an equivalent healthy inspection engine

Answer: C

Failure testing reveals the actual behavior of the forwarding path when enforcement stops. In this case, connectivity survives through a bypass while a known prohibited request passes uninspected, demonstrating fail-open operation. Whether that tradeoff is acceptable depends on documented requirements; the observed behavior should not be mistaken for security-preserving failover.

Study tip: Distinguish a surviving data path from surviving security enforcement.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A fail-closed path would block traffic during the failure. The captured delivery through the hardware bypass contradicts that behavior.

B: The hardware bypass preserves forwarding, and the destination receives the test request. Those observations rule out complete loss of the data path.

C: The bypass continues forwarding despite the unavailable enforcement function. Successful delivery of the previously blocked request demonstrates the resulting loss of inspection on that path.

D: The previously blocked request now passes without inspection. That does not demonstrate equivalent enforcement by a healthy alternate engine.

## SEC2-Q131

Database operators need to maintain indexes and backups but must not read a sensitive record field through direct SQL. Full-volume encryption is already enabled, and the running database transparently decrypts all fields. Which design BEST addresses this specific separation requirement?

- A. Add transparent database encryption while keeping direct SQL results readable by the same operators
- B. Mask the field in the normal application interface while leaving direct SQL results unchanged
- C. Encrypt the sensitive field in the application and restrict its decryption keys to an authorized application identity outside the operators' access
- D. Use TLS for operator SQL connections while returning the field as plaintext

Answer: C

The required protection is against a particular authorized administrative access path. Transparent storage encryption does not provide that separation once the database serves plaintext queries. Application-level field encryption can address it when operators cannot obtain the keys or control the decrypting application; those assumptions must be enforced and validated.

Study tip: Choose an encryption boundary that excludes the actor described in the threat model.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Another transparent storage layer can protect database files, but it still returns plaintext through authorized queries. The specified administrative read path remains exposed.

B: Interface masking limits what that interface displays, but these operators can query the database directly. Their separate plaintext access path would remain available.

C: Application-controlled field encryption can leave the database storing ciphertext while a separate authorized identity controls decryption. The key-access boundary is essential to the stated separation.

D: TLS protects the connection from network observers. It does not conceal query results from the operator who is the intended endpoint.

## SEC2-Q132

A diagnostic tool captures a process's memory, including private records, and writes the capture to a support archive on disk. After the process exits, the archive remains available for analysis. Which protection assessment is correct for the retained archive?

- A. It is a new copy of data at rest that needs protection appropriate to the captured records
- B. The original process's data-in-use protections continue to protect the archive without separate storage controls
- C. Restricting who can initiate a memory capture is sufficient, even if the resulting archive is broadly readable
- D. Protection of the connection used to write the archive is sufficient for its retained contents

Answer: A

Data can move between states during normal support work. A memory capture begins with information in use, but the resulting archive is a new stored copy requiring protection. Diagnostic labels do not make private records less sensitive, and the artifact's lifetime may extend well beyond the original process.

Study tip: Reassess protection whenever a workflow creates a new retained copy of sensitive information.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The private information was captured from active memory but now exists in a retained file. Its storage, permissions, retention, and any encryption require appropriate protection.

B: The archive persists outside the original process's memory boundary. Protections applied to the running process do not establish confidentiality for the separate retained file.

C: Capture authorization controls creation of the artifact, not every later reader. A broadly readable archive can disclose the private records it contains.

D: Transport protection addresses movement across a connection. The resulting stored artifact has its own access and confidentiality requirements after that transfer finishes.

## SEC2-Q133

An analytics system stores customer tokens instead of account numbers. Authorized finance staff recover original numbers through a separate token vault. A restore test recovers the latest analytics data but an older vault backup lacks mappings for recently created tokens. What should the data-protection design address?

- A. Recovery coordination between tokenized records and the corresponding protected mapping data
- B. Use the analytics backup's encryption key to decrypt the tokens directly into account numbers
- C. Increase analytics-only backup frequency while continuing to restore the older mapping vault
- D. Strengthen encryption of the analytics backups without changing the vault's recovery coverage

Answer: A

Tokenization introduces a dependency on the mechanism that maps tokens to original values when authorized reversal is required. Protecting the vault's confidentiality is only part of the design; recoverability also requires the matching data to survive. A successful restore of one component does not prove the protected workflow is complete.

Study tip: Recover tokenized records and their required mappings to compatible states.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The recovered tokens are useful only with their required mappings when authorized reversal is needed. Coordinated recovery must preserve compatible records and mapping versions.

B: The backup key protects the backup representation; it is not the missing token mapping. These separate protection mechanisms do not substitute for each other.

C: The latest analytics records already restore successfully. More frequent protection of that component does not recover the vault mappings required to resolve recent tokens.

D: Backup encryption protects confidentiality of the saved analytics data. It does not supply mappings absent from the restored vault or complete the finance workflow.

## SEC2-Q134

A support page shows only the last four digits of an account number. Browser inspection reveals that the server sends the complete number in JSON, and JavaScript merely hides its other digits. Support staff are not authorized to receive the complete number. Which repair BEST enforces the intended restriction?

- A. Delete the complete number from the browser's JavaScript variables immediately after rendering the masked value
- B. Require HTTPS while continuing to send the full number to the support browser
- C. Apply the authorized field reduction on the server before sending the support response
- D. Move the JavaScript masking function into a less readable minified bundle

Answer: C

Masking must occur at the boundary that prevents unauthorized disclosure. Here, the full value crosses that boundary before the interface conceals it, so the browser's user has already received it. Server-side authorization and field reduction make the support response match the user's permitted information.

Study tip: Hidden on a page is different from withheld from the client.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Client-side deletion occurs after the browser has received the complete number. It does not enforce a restriction against a user who can inspect that response.

B: HTTPS protects transmission to the browser but does not conceal delivered data from the browser's user. The unauthorized recipient still receives the complete value.

C: The browser should receive only data the support user is permitted to access. Server-side reduction prevents the complete number from reaching the unauthorized client.

D: Minification may complicate casual inspection but does not restrict the data in the network response. Client-side presentation remains an ineffective release boundary.

## SEC2-Q135

A document repository encrypts file contents, but its broadly visible object names include customer names and medical conditions. Users cannot open the documents yet can list every object name. Which change BEST addresses the remaining disclosure?

- A. Remove unnecessary sensitive details from object names and restrict metadata listing to appropriate users
- B. Shorten signed document-download link lifetimes while retaining the same object-list access
- C. Require stronger authentication to open documents while leaving broad metadata listing available
- D. Increase the file-content encryption key length without changing object names or listing permissions

Answer: A

Sensitive information may appear outside a protected document's body. Object names, tags, paths, and related metadata can reveal meaningful facts even when content encryption works correctly. A protection review should examine what each interface exposes and limit both metadata content and its audience where required.

Study tip: Include names, tags, and listings when tracing where sensitive information is exposed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The names themselves disclose sensitive information independently of file contents. Reducing sensitive naming data and limiting listing access address that separate metadata exposure.

B: Expiring download links can restrict document retrieval over time. It does not remove the sensitive names already exposed through the separate listing interface.

C: Stronger authentication for document access protects that workflow, but unauthorized readers can still learn the sensitive facts present in the visible object names.

D: Stronger content encryption does not conceal metadata the system intentionally exposes. Customer names and conditions remain readable in the object listing.

## SEC2-Q136

A published dataset replaces each five-digit postal code with its unsalted SHA-256 hash. A reviewer can generate every possible five-digit string and hash each candidate. What limitation is MOST relevant to the claimed concealment of postal codes?

- A. The small predictable input space allows candidate hashes to be matched to the published values
- B. Encrypting the download connection prevents authorized dataset recipients from performing the comparisons
- C. Recovering a postal code would require finding a collision between two unrelated documents
- D. Adding a fixed public prefix before hashing would remove the small-input-space exposure

Answer: A

Hashing a predictable identifier is not equivalent to giving it high-entropy secrecy or reliably anonymizing it. The reviewer can compute candidate hashes and compare outputs because the input space is small. This demonstrates a limitation of the representation and data-release design, not a cryptanalytic break of SHA-256.

Study tip: Consider the number of plausible inputs before treating a hash as concealment.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/ir/8053/final

A: A one-way hash does not prevent testing a manageable set of possible inputs. Matching candidate outputs can reveal which postal code produced a published hash.

B: Transport encryption protects delivery from network observers. Recipients who receive the published hashes can still calculate and compare candidate values locally.

C: The reviewer tests likely original inputs against an existing value. No pair of unrelated colliding documents is required for this lookup-style attack.

D: A known fixed prefix changes the candidates' representation, not their limited number. The reviewer can include that prefix when computing the same candidate comparisons.

## SEC2-Q137

An emergency information service publishes evacuation notices for everyone to read. Its classification policy allows separate confidentiality and operational-criticality labels. Incorrect notices or unavailable service could cause serious harm. Which TWO conclusions are appropriate? (Select TWO.)

- A. A public confidentiality label can be appropriate for the approved notice text
- B. Assign a secret confidentiality label solely because the notice is operationally critical
- C. Exclude published notices from integrity checking because their contents are intentionally disclosed
- D. Strong integrity and availability protections remain necessary despite the public release
- E. Treat the notice's anonymous read permission as sufficient authorization for anonymous content updates

Answer: A|D

Data classification can capture different protection needs rather than imposing one universal ranking. Here, the policy explicitly separates public readability from operational importance. Accurate, available emergency information can be public and critical at the same time, so public release does not reduce the need for controlled updates and resilient delivery.

Study tip: Public readability does not imply low integrity or availability requirements.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The notices are intentionally available to everyone. Under the stated independent labeling scheme, their approved public release can justify a public confidentiality classification.

B: The stated policy separates confidentiality from criticality. Operational importance alone does not require hiding information specifically intended for public emergency use.

C: Intentional disclosure establishes the permitted audience, not the acceptability of unauthorized changes. Published emergency instructions still need protection against alteration.

D: Public readability does not authorize modification or make outages harmless. The stated consequences require protection of accurate updates and continued delivery.

E: Reading a public notice and changing its authoritative content are different permissions. Anonymous updates would undermine the accuracy required for this critical service.

## SEC2-Q138

An approved legal assessment states that a provider's records remain subject to Country B's disclosure laws even when physically stored in Country A. Which data concern does this finding MOST directly illustrate beyond storage location?

- A. Data retention: the period for which the organization keeps the provider's records
- B. Data classification: the organization's assigned sensitivity level for the provider's records
- C. Data residency: the geographic location where the provider physically stores each copy
- D. Data sovereignty: the jurisdictional authority and rules applicable to the information

Answer: D

Data residency concerns where information is located, while sovereignty analysis also considers the authority and rules that apply to it. This fictional scenario supplies the legal conclusion, so no real country's law needs to be inferred. The architecture must account for that conclusion rather than treating physical location as the only factor.

Study tip: Use the applicable jurisdictional assessment as well as the storage-region setting.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Retention governs how long information is preserved. The assessment instead concerns applicable legal authority, without establishing a required storage duration.

B: Classification communicates protection requirements based on information characteristics. The stated legal finding concerns jurisdictional authority, not an assigned sensitivity label.

C: Residency identifies physical location, which this scenario already supplies. The additional finding concerns which jurisdiction can exercise authority despite that location.

D: The supplied legal assessment identifies an obligation that follows the provider despite the storage location. Data-sovereignty review must account for that established jurisdictional exposure.

## SEC2-Q139

A repository combines all applicable allow grants and has no deny rules. An employee's direct access to a restricted folder is removed, but its parent still grants Read to AllStaff, which includes the employee. A fresh permission evaluation allows reading. What explains the result?

- A. The AllStaff grant permits directory listing only, so a separate direct grant must still exist
- B. The folder is still using a cached copy of the former direct grant
- C. Removing the direct grant creates an implicit deny that should override the inherited group permission
- D. The inherited AllStaff grant still supplies effective read permission

Answer: D

Effective access must include direct, group, and inherited grants according to the actual permission model. This repository explicitly adds applicable allows, so an inherited group grant remains sufficient after the direct grant is removed. The repair should address the unintended grant while preserving legitimately required access.

Study tip: Check every path that grants access before concluding that removing one grant revokes it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The inherited grant explicitly supplies Read in this scenario. It can authorize reading through group membership without a separate direct entry for the employee.

B: A fresh evaluation and the still-applicable inherited grant explain the access without stale state. The scenario does not require a cached-permission failure.

C: The supplied model combines remaining allows and has no deny rules. Removing one grant does not create an overriding negative permission.

D: Under the explicitly stated additive permission model, the remaining group grant still authorizes reading. Removing one direct grant does not cancel a separate inherited allow.

## SEC2-Q140

A company intentionally publishes a technical manual for unrestricted reading while retaining its stated intellectual-property interests. The data owner labels the released manual Public. Which description is consistent with these facts?

- A. The manual cannot be intellectual property because anyone can read it
- B. Every earlier working draft must become Public when the finished manual is released
- C. The manual can be intellectual property and have a Public confidentiality classification
- D. The Public label automatically authorizes changes to the company's authoritative copy

Answer: C

Data types and confidentiality classifications need not be mutually exclusive. The released manual can be intellectual property while being approved for public reading. That approval does not automatically grant modification rights or publish earlier drafts; access and classification decisions must apply to the actual information involved.

Study tip: Distinguish what information is from who is allowed to receive or modify it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The scenario explicitly retains intellectual-property interests. Its approved public distribution does not mean the data type must stop describing the work.

B: Approval of the finished content does not automatically approve all source drafts or accompanying material. Their information and handling requirements still need evaluation.

C: The information's type and its approved handling classification describe different properties. Public reading access does not make the intellectual-property description logically incompatible.

D: A confidentiality label about reading does not grant write authority. Modification rights remain a separate access-control decision.

## SEC2-Q141

A software publisher transforms control flow and replaces descriptive symbol names before distributing a program. The program still runs normally on the customer's device. What is the MOST defensible security benefit of this obfuscation?

- A. It encrypts the application's network exchanges with the publisher's servers
- B. It verifies that the distributed program was signed by the expected software publisher
- C. It can increase the effort needed to understand the program through casual inspection or reverse engineering
- D. It establishes the program's permissions to access files through the operating system

Answer: C

Obfuscation is useful when the intended goal is to make analysis harder, within realistic limits. It does not create cryptographic proof of origin or prevent all observation on a device controlled by the recipient. The architecture should treat it as an additional obstacle rather than its primary confidentiality or authorization boundary.

Study tip: Evaluate obfuscation as an increase in analysis effort, not an absolute secrecy guarantee.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: Obfuscation changes how program logic is represented. It does not establish transport encryption or protect network traffic merely because the distributed code is harder to read.

B: Publisher verification requires an appropriate authenticity mechanism such as validated code signing. Renaming symbols and changing control flow do not establish that identity.

C: Obfuscation can make code less straightforward to analyze while preserving execution. Its benefit is increased analysis effort, not a guarantee that recipients cannot understand the program.

D: File access remains governed by the relevant identity and authorization controls. Transforming program structure does not assign operating-system permissions to that program.

## SEC2-Q142

A financial-record service must show authorized corrections to issued statements. Its approved policy also requires each originally issued version to remain identifiable and unchanged throughout retention. Reviewers must not gain overwrite or delete rights over issued versions. Which data-protection workflow BEST satisfies these combined requirements?

- A. Leave the repository unchanged and save the corrected value in the reviewer's private worksheet for future reference
- B. Replace the original value after reviewer approval and log only the change time and reviewer identity
- C. Encrypt the corrected record with a new key and remove the earlier encrypted version from the authoritative repository
- D. Store a linked corrected version, preserve issued versions under enforced read-only retention, and direct normal views to the current version

Answer: D

A corrected value and evidence of what originally existed serve different purposes. Retaining protected issued versions alongside a linked correction satisfies both supplied requirements, while the application identifies the current authoritative version. Recording only who changed a value does not preserve the previous content, and encryption alone does not create that history.

Study tip: Separate permission to issue a correction from permission to alter the historical record.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The private worksheet may preserve a note, but it does not make the correction authoritative in the service that users consult.

B: Approval and actor metadata can establish who made a change, but they do not preserve the originally issued content after an in-place overwrite.

C: Encryption can protect the corrected content but does not satisfy retention of the earlier issued version. Removing that version loses the required historical record.

D: Linked versions support an authoritative correction while retaining the original evidence. Restricting changes to issued versions enforces the required separation between correction and historical alteration.

## SEC2-Q143

A hosted document service must let two named external reviewers view a report until Friday at 18:00 in the service's configured time zone. Anonymous access is prohibited, and their access must expire automatically. The service supports authenticated recipient grants and grant expiration. Which TWO settings directly meet these requirements? (Select TWO.)

- A. Use a long random public link that opens without authentication
- B. Set the reviewers' grants to expire at the specified deadline
- C. Require the two named reviewer identities to authenticate before viewing the report
- D. Email a reminder asking reviewers to stop opening the report after Friday
- E. Require HTTPS while leaving the document readable to every authenticated service user

Answer: B|C

The requirements concern recipient identity and duration, so both must be represented in the service's authorization settings. Authenticated named grants limit the audience, and expiration ends the grants automatically. These controls govern subsequent service access; they should not be described as retroactively erasing any copies a recipient already obtained.

Study tip: Configure who may access the document and when that authorization ends.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A hard-to-guess link can still be used by anyone who obtains it. It does not meet the explicit prohibition on anonymous access.

B: Grant expiration implements the required automatic end of access. The deadline should apply to the actual authorization, not merely to a reminder or document label.

C: Identity-bound access prevents possession of a link alone from authorizing an anonymous reader. The service can apply the grant to the intended reviewers.

D: A reminder requests behavior but does not enforce automatic expiration. The service's supported grant-expiration capability directly implements the requirement.

E: HTTPS protects transport but does not restrict the audience to the two named reviewers or impose the required expiration time.

## SEC2-Q144

A backup system created full backup F on Sunday and differential backups D1, D2, and D3 on Monday, Tuesday, and Wednesday. Each differential contains the changes since F, and no later data is needed. What is the MINIMUM backup set needed to restore Wednesday's state?

- A. Full backup F and differential backup D2
- B. Differential backup D3 by itself
- C. Full backup F and differential backup D3
- D. Full backup F plus D1, D2, and D3

Answer: C

A differential backup contains changes since its associated full backup, so the latest differential can be applied to that baseline without replaying every earlier differential. This differs from an incremental chain that may depend on each preceding step. The question explicitly asks for the minimum sufficient set.

Study tip: Identify whether each backup is cumulative from the full backup or dependent on an incremental chain.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: This combination restores the baseline with changes through Tuesday. It omits the Wednesday changes available in the latest differential.

B: D3 contains changes since the full backup, not all unchanged baseline data. It requires F to produce a complete restored state.

C: The full backup supplies the baseline, and D3 contains the cumulative changes since that baseline through Wednesday. Earlier differentials are unnecessary for the stated restore.

D: Including all differentials adds unnecessary recovery inputs under the stated cumulative design. F and D3 already form the minimum sufficient set.

## SEC2-Q145

A Microsoft VSS backup captures a database's data and log volumes. The storage snapshot reports completion, but the database writer reports failure and a restore fails application-consistency checks. Which change BEST addresses the demonstrated problem?

- A. Encrypt the existing inconsistent snapshots with a stronger key
- B. Increase snapshot frequency while retaining the same uncorrected application-writer failure
- C. Copy the completed snapshot files to a second site without testing the application
- D. Correct the writer failure and create a coordinated application-consistent backup that passes a restore test

Answer: D

Snapshot completion and application consistency are separate acceptance criteria. In this explicitly named VSS workflow, writers coordinate application state with the snapshot process. A failed writer must be addressed, and recovery should demonstrate a usable database rather than relying only on successful storage copying.

Study tip: A completed snapshot job does not override a failed application-consistency check.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://learn.microsoft.com/en-us/windows-server/storage/file-server/volume-shadow-copy-service

A: Encryption protects snapshot confidentiality but does not repair logical relationships between database data and logs or complete the failed writer's coordination.

B: Frequency affects how often copies are taken, not whether the application state is coordinated. Repeating the failed workflow does not establish usable backups.

C: An offsite copy improves geographic independence but can preserve the same inconsistency. Location alone does not make the captured application state restorable.

D: The failed writer indicates that application coordination did not complete correctly. Correcting it and validating restoration addresses consistency rather than treating storage-level snapshot completion as sufficient.

## SEC2-Q146

A two-node database cluster loses communication between its nodes. Both promote themselves and write to shared storage, causing conflicting updates. The platform supports a quorum witness and fencing. Which design BEST prevents this concurrent-writer failure?

- A. Distribute more client connections between the two nodes using round-robin routing
- B. Mirror the shared-storage volume without changing how partitioned nodes obtain write ownership
- C. Shorten heartbeat intervals while allowing either disconnected node to promote itself independently
- D. Configure supported quorum decisions and tested fencing so only the authorized surviving side can write

Answer: D

High availability must preserve consistent ownership during partial failures. A communication partition can leave both sides alive, making simple failure detection insufficient. The supported quorum and fencing design must prevent competing writers, with its behavior tested against realistic communication and node-failure conditions.

Study tip: Failure detection needs an ownership decision and a way to enforce it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/configuring_and_managing_high_availability_clusters/assembly_overview-of-high-availability-configuring-and-managing-high-availability-clusters

A: Client distribution does not resolve cluster ownership or exclude a disconnected writer. It can send additional work to both conflicting active nodes.

B: Storage mirroring can provide another copy, but conflicting writers can affect the replicated data too. The design still needs an enforced ownership decision.

C: Faster failure detection does not establish a single authorized writer. Both sides may still promote independently and reach the shared data.

D: Quorum establishes which partition may continue, while fencing prevents an excluded node from retaining dangerous access. Together they address conflicting ownership during a communication failure.

## SEC2-Q147

A service has run at its recovery site for two days and accepted new transactions. The original site is repaired but still contains the older pre-failure data. Which action should precede returning production traffic to the original site?

- A. Verify that the original site's servers boot successfully, then restore their production routing
- B. Confirm that the original site's older backup restores successfully, then make it authoritative
- C. Let both sites accept independent writes until administrators manually compare differences later
- D. Reconcile the current authoritative data to the original site, validate it, and coordinate a controlled single-writer transition

Answer: D

Failback is a recovery operation with its own consistency risks. The alternate site may have become the authoritative source by processing new work. Before returning service, restore or synchronize that current state, validate dependencies, and coordinate the cutover so the application does not revert or create competing writers.

Study tip: After recovery-site operation, identify which copy contains the current authoritative transactions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Boot success establishes limited infrastructure readiness. It does not bring the original site's older data forward to include the transactions accepted during recovery operation.

B: A usable older restore can still omit two days of accepted transactions. Failback must preserve the current authoritative state, not merely produce a bootable historical copy.

C: Uncoordinated simultaneous writes can create additional conflicts. A controlled transition should preserve the application's supported ownership and consistency model.

D: The recovery site now holds newer business state. Synchronizing and validating that state before a controlled transition prevents reverting service to an outdated copy.

## SEC2-Q148

A company selects a cold recovery site to reduce recurring cost. The contract provides space, power, cooling, and connectivity, but no installed application servers. What must the recovery plan account for before business processing can resume there?

- A. Obtaining and installing equipment, configuring services, restoring data, and validating the complete application
- B. Arranging equipment delivery and network addressing, then resuming processing without application restoration
- C. Confirming that backup media is available, then treating the facility as ready for application traffic
- D. Testing routing to the facility and relying on its contract for installed application capacity

Answer: A

A cold site reduces readiness and recurring cost by leaving substantial work for activation. Its facility services are useful, but they do not constitute a running application. Procurement, installation, configuration, restoration, staffing, and validation all affect whether the recovery arrangement can meet the organization's needs.

Study tip: Evaluate the work remaining after a recovery facility is declared available.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: The contracted facility lacks the computing environment. Recovery therefore includes provisioning and restoration work before the site can perform its business function.

B: Receiving equipment and network service does not produce a working application with current data. Installation, configuration, restoration, and validation remain activation dependencies.

C: Backups are an input to recovery, not a running service. The cold site still needs equipment and a validated restored application before processing can resume.

D: The supplied contract provides facility services but explicitly excludes installed application servers. Network readiness does not fill that compute and application gap.

## SEC2-Q149

Two redundant application instances use the same operating-system family. A platform-specific flaw affects both. A supported alternative platform could run one instance, but it would require a second patching and administration skill set. Which assessment BEST captures the tradeoff?

- A. Identical platforms simplify administration and provide equivalent independence from an operating-system-specific flaw
- B. Operating-system diversity mainly reduces shared electrical-feed failures while increasing patching complexity
- C. Diversity reduces shared platform exposure while allowing both nodes to retain one unchanged maintenance baseline
- D. Diversity may reduce a shared platform-specific failure while increasing maintenance and validation complexity

Answer: D

Platform diversity can reduce exposure to a common operating-system or implementation failure, but it adds operational work. The architecture should balance that benefit against the ability to maintain, secure, and validate both environments. Shared application code, data, and external services can remain common dependencies.

Study tip: Diversity helps only where it creates a meaningful difference in the failure dependencies.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Uniformity can simplify maintenance, but it preserves the shared exposure demonstrated by the flaw. Operational simplicity and independence from that failure are different properties.

B: Separate operating systems do add maintenance work, but they do not separate electrical feeds. The demonstrated benefit concerns platform-specific failures rather than facility power.

C: A second supported platform can reduce common exposure, but its distinct patching and administration requirements contradict the assumption of an unchanged uniform maintenance baseline.

D: Using a genuinely different supported platform can reduce one common dependency, but operating two platforms creates additional skills, patching, compatibility, and testing requirements.

## SEC2-Q150

A recovery review must identify coordination gaps among responders and prove that protected backups can restore a working application. This exercise must not reroute production users or connect restored duplicates to the production network. Which TWO activities together meet those goals? (Select TWO.)

- A. A facilitated tabletop exercise that tests decisions, responsibilities, and communications
- B. A review of successful backup-job notifications without restoring any application data
- C. An isolated restoration exercise with application-level validation of the recovered backup
- D. Starting restored duplicates with production addresses on the active production network
- E. A full production failover that redirects all current users to the recovery environment

Answer: A|C

Recovery assurance requires evidence about both people and technology. A tabletop tests coordination, while an isolated restore validates whether backups produce a usable application. These complementary exercises meet the stated constraints, although they do not replace a separately authorized test of actual production cutover.

Study tip: Select exercises that prove the needed capabilities while respecting the exercise's operational boundaries.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: A tabletop can expose coordination and decision gaps without changing production systems. It supplies the procedural evidence needed alongside a separate technical restoration exercise.

B: Job notifications show what the backup system reported, but they do not prove that the backup can produce a working application.

C: Restoring and checking the application in an isolated environment demonstrates technical recoverability while honoring the prohibition on production rerouting or duplicate production connections.

D: Connecting duplicate restored systems to production violates the stated boundary and can affect live services. The technical restoration must remain isolated.

E: A live cutover would test additional capabilities but violates this exercise's explicit restriction against rerouting production users.

## SEC2-Q151

A database acknowledges a write only after both local storage and its remote replica confirm persistence. After the replica moves farther away, measured network round-trip time increases and write latency rises by a similar amount. CPU and storage measurements are unchanged. What BEST explains the new delay?

- A. The write acknowledgement waits for a remote persistence confirmation that now takes longer to return
- B. The asynchronous replication backlog now postpones writes until its next scheduled batch transfer
- C. The local storage subsystem has developed a new queueing bottleneck independent of the remote confirmation
- D. The local database processor has become the limiting factor for encrypting each write

Answer: A

Synchronous replication places remote confirmation on the write-completion path. Greater geographic separation can improve failure independence while increasing that path's latency. Changing to asynchronous acknowledgement would alter the protection against losing recently acknowledged writes, so that would require a separate review of business requirements rather than an automatic performance fix.

Study tip: Check which remote acknowledgements are required before a user receives write success.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: The stated synchronous acknowledgement includes the remote round trip. Increased network latency can therefore increase commit latency even when local processing and storage remain unchanged.

B: The described service acknowledges only after both copies persist, making this a synchronous completion path. An asynchronous batch schedule is not the supplied mechanism.

C: Storage measurements are unchanged, while write delay tracks the increased network round trip. The supplied evidence supports remote confirmation rather than new local disk saturation.

D: Unchanged CPU measurements do not support a new processing bottleneck. The changed remote round-trip time directly affects the explicitly stated acknowledgement dependency.

## SEC2-Q152

A restore test recovers a case-management database successfully, but all uploaded evidence links return missing-file errors. The application stores uploads in a separate object repository that was not included in the backup design. Which correction BEST addresses the failure?

- A. Include the required object repository and coordinate recovery so database references and stored objects form a usable application state
- B. Add database-only integrity checks before declaring the restoration successful
- C. Maintain an additional database replica while leaving uploads outside the recovery plan
- D. Increase database backup frequency without protecting the upload repository

Answer: A

A technically successful database restore does not necessarily restore the complete service. Applications may depend on separate object stores, configuration, keys, and other authoritative components. Recovery design should map those dependencies and validate actual business functions, including access to referenced files.

Study tip: Back up and restore the data dependencies needed to complete the application workflow.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: The database is only one authoritative data component. Recovering referenced objects in a compatible state is necessary for the restored application to deliver its complete function.

B: Database checks can validate that component but cannot recreate objects never included in recovery protection. Application-level file retrieval remains a necessary acceptance test.

C: Another database copy repeats the same incomplete recovery scope. The referenced files reside in a separate repository that must also be recoverable.

D: More frequent database copies still omit the files referenced by its records. The missing component is outside the current backup scope.

## SEC2-Q153

A server has two power supplies, but both connect to the same UPS. A second independent UPS and electrical feed are available. The design must keep the server running if either single UPS fails. Which connection change BEST meets that goal?

- A. Connect both supplies to different outlets on the original UPS
- B. Connect one power supply to each independent UPS and verify single-feed operation under the expected load
- C. Increase the original UPS battery capacity while leaving both supplies connected to it
- D. Attach both supplies to a larger power strip powered by the original UPS

Answer: B

Redundancy must extend through the relevant failure path. Two server power supplies do not protect against a single UPS failure when both depend on that UPS. Independent supported feeds, correctly sized and tested, allow the surviving supply to maintain service after one feed is lost.

Study tip: Trace redundant components back to their shared upstream dependencies.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Different outlets still depend on the same UPS electronics and output. Failure of that UPS can remove power from both server supplies.

B: Separate supplies fed by independent UPS units remove the shared UPS as a single power dependency. Testing verifies that either remaining feed can support operation.

C: More battery capacity can extend runtime but does not make the server independent of a failure in the UPS supplying both inputs.

D: A larger strip changes distribution but preserves the common upstream UPS. It does not satisfy survival of that UPS's failure.

## SEC2-Q154

A recovery-site test shows normal CPU, storage, and network performance, but the application rejects the 51st concurrent user with a license-limit message. The continuity plan requires 120 concurrent users. Which capacity issue must be corrected?

- A. The bandwidth available between the recovery site and its remote users
- B. The number of processor cores assigned to the recovery application server
- C. The recovery environment's authorized application concurrency entitlement
- D. The number of database connections available to the recovered application

Answer: C

Capacity planning includes constraints enforced by software licensing and service entitlements, not only processor, memory, disk, or network resources. The recovered application can appear healthy under light load while failing to support the required number of users. A representative concurrency test exposes that gap.

Study tip: Test the licensed and contracted limits as well as the physical capacity of a recovery environment.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Network capacity is important during recovery, but the reported network performance is normal. The 51st-user license message identifies a different enforced concurrency ceiling.

B: More processors may increase compute capacity, but the measurements are normal and the explicit rejection identifies a licensing limit. Additional cores do not change that entitlement.

C: The explicit license-limit response identifies a software capacity constraint. Recovery planning must provide an entitlement that supports the required concurrent business workload.

D: A connection pool can limit service, but the supplied failure is an application license limit. Expanding an unrelated pool would not authorize the required concurrent users.

## SEC2-Q155

A planned failover changes a service's authoritative DNS address. Some clients continue using the previous address because they cached its earlier long TTL; fresh resolvers obtain the new address. For the next planned cutover, which preparation BEST reduces this predictable delay?

- A. Increase authoritative DNS server capacity without changing the clients' earlier cache lifetimes
- B. Flush the administrators' local resolver caches while leaving other clients' earlier cache lifetimes unchanged
- C. Lower the TTL in advance, allow the earlier cache lifetime to expire, and test expected client resolution behavior
- D. Lower the authoritative TTL only after cutover and assume every existing cache immediately adopts it

Answer: C

DNS changes are observed through caches, not delivered instantly to every client. A planned transition can reduce cache-related delay by lowering TTLs sufficiently early and validating actual resolution behavior. This does not automatically move established sessions, so the wider cutover plan should also account for application connection behavior.

Study tip: Previously cached records retain their own lifetime; a new TTL is not an immediate global cache flush.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://www.rfc-editor.org/rfc/rfc1034.html

A: More authoritative capacity can help answer new queries, but a client using a valid cached answer may not query it during the existing lifetime.

B: A local flush affects those controlled caches, not unrelated remote clients. The preparation must account for the earlier TTL retained by the wider audience.

C: Resolvers may retain previously cached records for their original lifetime. Reducing the TTL early enough and testing clients improves the predictability of a later planned cutover.

D: A changed authoritative TTL does not retroactively replace records already cached with a longer remaining lifetime. Existing clients may continue using the earlier address.

## SEC2-Q156

A repository must retain four verified full backups. Each occupies exactly 2 TB. Policy prohibits deleting the oldest until the next 2 TB full backup has finished and passed verification in the same repository. Ignore metadata overhead, compression, and deduplication. What is the MINIMUM capacity needed during that transition?

- A. 12 TB
- B. 10 TB
- C. 6 TB
- D. 8 TB

Answer: B

Retention policy can make peak storage demand exceed the size of the normally retained set. Here, deletion must wait for the new backup to complete and verify, so five copies coexist temporarily. Capacity planning must include that staging interval rather than assuming the oldest backup disappears before its replacement starts.

Study tip: Count the copies that must coexist at the busiest point in the backup lifecycle.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Twelve terabytes would provide enough room, but it is not the minimum under the supplied assumptions. Five simultaneous 2 TB copies require 10 TB.

B: The four retained backups consume 8 TB, and the incoming backup needs another 2 TB before deletion is allowed. Peak required capacity is therefore 10 TB.

C: Six terabytes cannot hold even the required four existing 2 TB backups. It is insufficient before the next backup begins.

D: Eight terabytes holds the four verified copies but leaves no space to finish the next copy while all four remain protected under policy.

## SEC2-Q157

A company applied its kiosk baseline to engineering workstations. The baseline blocks approved development tools that kiosks never need. Security requirements shared by both groups remain valid. Which design BEST preserves security while supporting both roles?

- A. Use one engineering-compatible application profile on both engineering workstations and kiosks
- B. Keep the kiosk profile and maintain unrelated local exceptions on each engineering workstation
- C. Maintain common mandatory settings with reviewed role-specific baseline profiles
- D. Exempt engineering machines from central baselines and document their development purpose

Answer: C

A secure baseline must fit the system's intended role. The appropriate response is to preserve common requirements and define reviewed variations for engineering and kiosks. This supports necessary functionality without turning every user inconvenience into an untracked exception or broadening software permissions throughout the entire fleet.

Study tip: A baseline should minimize unnecessary capability for the system's actual role.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A common permissive profile can restore engineering functionality but also exposes kiosks to development capabilities they do not need for their approved role.

B: Individual local exceptions create fragmented configuration management instead of a reviewed reusable profile that consistently supports the approved engineering role.

C: A shared core preserves common protection, while controlled profiles account for legitimate differences in software and permissions required by each workstation role.

D: A documented purpose explains the exception but does not preserve the mandatory shared protections through a managed role-specific configuration.

## SEC2-Q158

A firm purchases smartphones, retains ownership, manages their configuration, and permits employees to install personal applications within defined limits. Which deployment model BEST describes this arrangement?

- A. Bring your own device
- B. An unmanaged personal-device arrangement
- C. Corporate-owned, personally enabled
- D. Corporate-owned, business-only

Answer: C

Device ownership and permitted use are separate dimensions. The company owns these phones but authorizes limited personal use, which identifies the COPE model. That model does not prescribe every technical restriction; the organization still needs appropriate management, application, privacy, and data-handling controls for its chosen use policy.

Study tip: Read both who owns the device and whether personal use is allowed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: BYOD uses devices owned by the individuals bringing them to work, whereas this firm purchases and retains ownership of the smartphones.

B: The stated phones remain under company configuration management and ownership, so neither unmanaged operation nor personal ownership describes this deployment.

C: COPE describes organization-owned devices that permit personal use under organizational rules, matching both the stated ownership and allowed employee activity.

D: A business-only model prohibits the personal use expressly allowed here, even though the organization owns and manages devices in both models.

## SEC2-Q159

Retail handhelds use approved Bluetooth barcode scanners. An audit finds that the handhelds stay discoverable and accept new pairing requests after deployment. Policy requires the existing scanner connections to continue but prohibits unauthorized accessories. Which change BEST meets the policy?

- A. Restrict new pairing through managed controls and exit discoverable mode after approved enrollment
- B. Maintain approved scanner addresses in inventory without enforcing pairing restrictions
- C. Require encrypted Bluetooth links while allowing users to pair any new accessory
- D. Reduce Bluetooth transmit power while retaining unrestricted new pairing

Answer: A

The requirement is to limit the establishment of new Bluetooth trust relationships, not eliminate an approved radio function. Managed pairing restrictions and leaving discoverable mode after enrollment target that boundary. Existing authorized scanners can continue operating, subject to the platform's supported settings and the organization's replacement procedure.

Study tip: Protect the pairing boundary: inventory and encryption do not authorize a new accessory.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Controlled pairing limits authorization of additional accessories while allowing established approved scanner relationships to remain available for the required business function.

B: An inventory documents approved devices but does not stop the handheld from accepting an unauthorized accessory while pairing remains unrestricted.

C: Link encryption protects the communication after pairing but does not establish that the organization authorized the accessory being added.

D: Reduced range can limit physical reach but does not authorize accessories or prevent an unapproved nearby device from obtaining a pairing relationship.

## SEC2-Q160

Managed laptops support the company's required WPA3 mode. Four temporary inventory devices support only an older approved encrypted mode and need one isolated inventory service. Which deployment BEST contains the compatibility exception?

- A. Downgrade the existing employee network so every device uses the older mode
- B. Reserve fixed addresses for the temporary devices on employee Wi-Fi without restricting their service access
- C. Use a separate restricted wireless network for the temporary devices and retain WPA3 for managed laptops
- D. Use an internet-only guest network that has no permitted path to the inventory service

Answer: C

A compatibility exception should be narrowly scoped by device population, network reachability, and duration. A separate restricted wireless network meets the temporary inventory need without weakening the managed laptop network. The organization should still track removal of the exception when the temporary devices are replaced or returned.

Study tip: Confine a compatibility exception instead of spreading it to capable systems.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A company-wide downgrade broadens a four-device exception to managed laptops that can satisfy the required security mode without compatibility changes.

B: Address reservations improve identification but do not confine the compatibility exception's network reachability to the required inventory service.

C: A restricted compatibility network confines the exception to the devices and service that need it, preserving the stronger laptop requirement.

D: Guest isolation may reduce exposure but, as specified, it blocks the internal service these devices must reach to perform their authorized function.

## SEC2-Q161

Analysts open untrusted documents in disposable virtual sandboxes. The sandbox currently has a read-write mount of the analyst's real Documents folder and a shared clipboard. The workflow needs only a one-way import of a test document. Which change BEST strengthens isolation?

- A. Discard the guest at logout while leaving the shared host folder available during testing
- B. Take a guest snapshot before each test while retaining the writable host mount
- C. Remove unnecessary host sharing and use a controlled import mechanism
- D. Scan imported documents with antivirus while preserving all existing host-sharing features

Answer: C

A sandbox's protection depends on its boundaries, including convenience features that connect it to the host. Writable mounts and clipboard sharing can expose real data even when the guest itself is disposable. Removing integrations not needed for the task supports the stated one-way input workflow without claiming the sandbox eliminates every analysis risk.

Study tip: Inspect a sandbox's host integrations, not just whether it is called isolated.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Destroying the guest afterward does not prevent untrusted code from reading or modifying real host files through an active sharing path.

B: A guest snapshot helps restore guest state but does not reliably undo changes to real host files exposed through the writable mount.

C: Removing writable host mounts and clipboard integration closes unnecessary paths between untrusted processing and the analyst's real environment while preserving the required input.

D: Scanning can reduce known-file risk but does not enforce the requested isolation boundary if a document bypasses detection and accesses the shared host resources.

## SEC2-Q162

An organization wants laptops to refuse an unauthorized bootloader before the operating system starts. It has an approved firmware trust configuration for its operating-system images. Which capability MOST directly enforces this requirement?

- A. A user-level application allowlist that runs after sign-in
- B. Secure Boot configured with the approved boot-signing trust
- C. Record TPM boot measurements without configuring any boot-component enforcement decision
- D. An encrypted user profile without any boot-component validation

Answer: B

The required decision occurs before the operating system loads, so it needs a firmware-level boot trust mechanism. Correctly configured Secure Boot checks whether boot components satisfy the approved trust policy. It complements storage encryption and later execution controls; each acts at a different point in the system's startup and operation.

Study tip: Match the enforcement point to when the untrusted code would run.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://learn.microsoft.com/en-us/windows/security/hardware-security/tpm/trusted-platform-module-overview

A: A post-sign-in allowlist governs later application execution, not the earlier firmware decision about which bootloader may start the operating system.

B: Secure Boot can validate boot components against the configured trust and refuse unauthorized components before the normal operating system takes control.

C: Measurement records can support later integrity assessment, but recording them alone does not refuse an unauthorized bootloader before it executes.

D: Profile encryption addresses stored user data but does not by itself enforce the stated trusted-bootloader selection before operating-system execution.

## SEC2-Q163

A network audit finds readable management credentials and telemetry in captures of switch monitoring traffic. The switches and monitoring platform support SNMPv3. Policy requires both authenticated messages and protection against reading their contents. Which configuration BEST meets that requirement?

- A. SNMPv3 with authentication and privacy enabled
- B. SNMPv2c with a longer shared community string
- C. SNMPv3 with neither authentication nor privacy enabled
- D. SNMPv3 with authentication enabled but privacy disabled

Answer: A

Selecting SNMPv3 is not sufficient unless its security settings meet the requirement. Authentication and privacy must both be enabled for authenticated, confidential management exchanges. Configuration compatibility and key handling also matter, and leaving an older insecure monitoring path active could preserve the original exposure.

Study tip: Check the selected security mode, not only the protocol's version number.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final|https://www.rfc-editor.org/rfc/rfc3414.html

A: The authentication-and-privacy configuration protects message authenticity and confidentiality, directly addressing both the management identity and readable-telemetry requirements.

B: A stronger community value does not add encrypted transport to SNMPv2c, so captured management credentials and telemetry remain exposed.

C: The protocol version alone does not supply the requested security services when its authentication and privacy options are disabled.

D: Authentication helps verify and protect the message against modification, but without privacy the telemetry does not receive the requested confidentiality protection.

## SEC2-Q164

Company tablets use a managed cellular connection for a restricted sales application. Their hotspot feature lets personal laptops share that connection and reach internal services through the tablet's network path. Personal laptop access is prohibited; tablet application access must continue. What is the BEST correction?

- A. Limit the tablet's own browser to sales application URLs while leaving tethering enabled
- B. Rotate the hotspot password frequently while still permitting personal laptops to connect
- C. Disable unauthorized tethering through device management while preserving approved tablet connectivity
- D. Require encrypted Wi-Fi for hotspot clients without changing the tablet's forwarding permissions

Answer: C

Hardening should account for forwarding and connection-sharing features as well as the device's own applications. Here, the tablet becomes an unauthorized access path for other devices. Restricting tethering targets that path while preserving approved connectivity; improving the hotspot password would secure a use the policy does not permit.

Study tip: A managed device can expose resources by forwarding another device's traffic.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A browser restriction governs that application but does not necessarily govern forwarded traffic from personal laptops using the tablet's hotspot path.

B: Password rotation changes who knows a shared connection secret but does not enforce the policy prohibiting personal laptops from using that connection.

C: A managed tethering restriction closes the unintended bridging path without removing the cellular connection needed by the authorized sales application.

D: Wireless encryption protects the hotspot link but does not remove the unauthorized internal-service access obtained through the tablet's forwarding capability.

## SEC2-Q165

A site survey compares three supported, nonoverlapping channel choices for a new access point. All provide adequate signal coverage. Measured channel utilization is A=81%, B=17%, and C=74%. Which choice BEST minimizes competition for airtime under these observations?

- A. Channel B
- B. Channel A
- C. Channel C
- D. Any channel, because equal signal coverage implies equal channel congestion

Answer: A

Coverage confirms that clients can receive a usable signal, while utilization describes how busy the channel is. Since the scenario holds coverage and nonoverlap suitability equal, the least utilized choice is preferable for the stated goal. Conditions can change, so the decision should be verified after deployment rather than treated as permanent.

Study tip: Strong signal and available airtime are separate wireless design measurements.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Channel B has the lowest measured utilization while meeting the same coverage requirement, leaving more observed airtime available for the new access point.

B: Channel A is the most heavily utilized option in the measured environment, so it provides the least favorable observed airtime competition.

C: Channel C is less busy than A but substantially busier than B, without any stated coverage advantage to justify the added competition.

D: Signal coverage and airtime utilization describe different properties; adequate coverage does not make the measured competition identical across the channel choices.

## SEC2-Q166

An application accepts customer PDF uploads for later staff review. Uploaded content must not execute as server code, and a caller must not bypass the PDF restriction by renaming another file. Which TWO controls MOST directly meet these requirements? (Select TWO.)

- A. Trust the filename extension supplied by the uploading browser
- B. Store uploads in a nonexecutable location with controlled retrieval
- C. Rely only on HTTPS between the browser and the upload endpoint
- D. Validate the upload's actual content using an appropriate server-side file validation process
- E. Store uploads beside executable application scripts and rely on the original filename to control execution

Answer: B|D

The two requirements involve different boundaries: accepting the file and using it after storage. Server-side content validation addresses disguised file types, while nonexecutable storage and controlled retrieval address server execution. Additional controls such as size limits and malware analysis can help, but they do not replace these specific checks.

Study tip: Validate what arrives and control what the server can do with it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/|https://csrc.nist.gov/pubs/sp/800/218/final

A: The caller can rename a file before submission, so its extension alone cannot enforce the requirement to identify the actual permitted file type.

B: A nonexecutable storage and retrieval design prevents accepted uploads from becoming directly executable server content simply because the application stored them.

C: HTTPS protects transport but does not validate file content or determine whether the server executes the stored upload.

D: Content-aware server-side validation checks more than the caller-controlled filename, reducing acceptance of unsupported files disguised with a PDF extension.

E: An execution-enabled application location adds an unnecessary server-code path, and a caller-controlled filename does not establish that stored content cannot be interpreted as code.

## SEC2-Q167

Laptop inventory records use only IP addresses. DHCP address changes cause one laptop to appear as several assets and different laptops to share one record over time. Which identifier would BEST support consistent physical-asset tracking?

- A. The employee currently assigned to use the laptop
- B. The current DHCP address alone
- C. The access switch port used during the most recent inventory scan
- D. A verified hardware serial number linked to the asset record

Answer: D

Network identifiers help describe connectivity, but they are not necessarily durable asset identities. A verified serial number can anchor the physical laptop's record while addresses, users, and locations change. The inventory should retain those changing attributes as context rather than using them as the sole identity for the device.

Study tip: A connection address can change or be reassigned without changing the physical asset.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Assignment identifies a custodian rather than a unique permanent device; employees can change devices and devices can be reassigned without becoming new assets.

B: A dynamically assigned address changes over time and may be reused by another laptop, which is the source of the described tracking errors.

C: A port identifies a connection location that devices can change or share over time, rather than the enduring identity of the physical laptop.

D: A hardware serial number can identify the physical device across network-address changes when it is verified and associated with the correct inventory record.

## SEC2-Q168

Cloud workers process customer files for 5–10 minutes and are often created and deleted between hourly inventory scans. Auditors need each worker's identifier, accountable owner, and active period even after deletion. The platform exposes creation and deletion events. Which inventory improvement BEST meets this requirement?

- A. Record lifecycle events with worker identifiers, ownership, and timestamps in a retained asset history
- B. Maintain a current-resource inventory that removes each worker's record immediately when the worker is deleted
- C. Shorten inventory scans to every 30 minutes and retain only the scan results
- D. Retain hourly totals of worker usage and charge each total to the responsible department

Answer: A

Inventory methods must match how assets are created and retired. Periodic snapshots can miss resources whose entire lifetime falls between observations. Retained lifecycle records provide historical identifiers, accountable ownership, and timing even after resources disappear; current-state reconciliation can complement that history without deleting evidence required for accountability.

Study tip: For short-lived resources, track creation and retirement as well as what exists at scan time.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Creation and deletion records capture assets that exist between scans. Retaining their identity, ownership, and lifetime provides the requested history after the workers disappear.

B: Current-state accuracy is useful, but removing all records at deletion discards the identity and lifetime evidence auditors explicitly need afterward.

C: A 5–10-minute worker can still begin and end between 30-minute scans. This adjustment reduces the interval without providing complete historical coverage.

D: Aggregated usage and department charges do not identify each individual worker or establish its active period, so the requested asset-level accountability remains incomplete.

## SEC2-Q169

A leased storage device must be returned to a supplier. Its approved sanitization operation fails, and verification still recovers confidential test records. Policy prohibits release of unsanitized media. Which action BEST follows the policy?

- A. Perform a quick format and return the device without repeating data-recovery verification
- B. Use the vendor's generic reset instructions as completion evidence without verifying this device's result
- C. Retain controlled custody and arrange an approved remediation or media-replacement disposition
- D. Obtain the supplier's standard confidentiality agreement and release the device with recoverable data

Answer: C

Verification determines whether the required sanitization outcome was achieved. Here it was not, so returning the media would violate the stated release condition. Controlled retention allows the organization to pursue a supported erase, supplier-authorized media replacement, or another approved disposition without losing custody of recoverable confidential information.

Study tip: A failed sanitization result requires a controlled exception path, not a success label.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/88/r2/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A quick format does not establish that the previously recoverable records were sanitized, and omitting verification leaves the release condition unsupported.

B: Instructions describe a process, not its success on the actual medium; the demonstrated recovery of confidential records requires resolving the device-specific failure.

C: Holding the device prevents prohibited release while the organization resolves sanitization or an authorized alternative with the relevant owner and supplier.

D: An agreement may govern the supplier's conduct but does not satisfy the explicit policy prohibiting release of media that remains unsanitized.

## SEC2-Q170

New network appliances arrive with serial numbers that do not match the authorized shipment record. Their packaging also shows unexplained tampering. The procurement process requires supplier reconciliation before acceptance. What is the BEST next action?

- A. Replace the shipment record with the received serial numbers without contacting the supplier
- B. Connect the appliances to production to see whether their interfaces work
- C. Accept the appliances solely because the model names match the purchase order
- D. Quarantine the shipment from deployment and reconcile it through the verified supplier channel

Answer: D

Acquisition controls continue through receipt and acceptance. Unexpected identifiers and tampering evidence warrant a pause in deployment and verification through a trusted supplier contact. This does not establish malicious intent by itself; it preserves a controlled boundary until the discrepancy is explained and the authorized acceptance criteria are met.

Study tip: Receipt of working equipment is not the same as verified acceptance of the ordered assets.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Unverified record changes hide the mismatch instead of determining whether the delivered devices are the equipment the organization authorized.

B: Successful operation does not establish shipment authenticity, and connecting unexplained hardware bypasses the stated acceptance condition before the discrepancy is resolved.

C: A matching model does not resolve device-identity and tampering discrepancies, which the required acceptance process specifically obliges the team to reconcile.

D: Holding deployment preserves the acceptance boundary while verified supplier reconciliation determines whether the unexpected hardware and packaging state have an authorized explanation.

## SEC2-Q171

A technician transfers a loaner laptop from one contractor to another without updating its assigned-user record. Months later, the laptop cannot be located. Which process change MOST directly prevents this accountability gap?

- A. Require a recorded handoff linking the device, releasing custodian, receiving custodian, and date
- B. Record equipment returns only at contractor offboarding rather than at each reassignment
- C. Perform an antivirus scan at each loaner issue while retaining the old assigned-user record
- D. Place loaners in a shared contractor pool without recording individual checkouts

Answer: A

Assignment records must change when custody changes. A dated handoff that identifies the device and both parties creates a traceable transition between custodians. Configuration security and account settings remain important, but they cannot replace a record of responsibility for the physical asset when a device is reassigned.

Study tip: Update custody when the device changes hands, not only when it is purchased.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A documented reassignment ties the physical device to its current custodian and preserves the history needed to follow later location or return questions.

B: Offboarding records can miss transfers occurring during active contracts, so they do not maintain current responsibility throughout the device's actual custody changes.

C: A scan checks a different security concern and does not identify the receiving custodian or update responsibility for the transferred physical device.

D: A pool simplifies availability management but leaves the specific current custodian unknown, preserving the accountability gap after a device changes hands.

## SEC2-Q172

An old reporting server has been destroyed, but its long-lived cloud API credential remains active and can still export customer records. No replacement workload needs that credential. Which decommissioning step was missed?

- A. Remove the retired server's DNS records while keeping its cloud client registration active
- B. Move the credential into a central vault without reviewing whether its access is still needed
- C. Change the retired server's inventory location to the disposal facility
- D. Revoke the retired workload's external credentials and access grants

Answer: D

Decommissioning includes logical dependencies outside the retired device. API credentials, service identities, and external access grants may remain usable even after physical destruction. The asset's owner should identify those relationships and revoke unneeded access, while retaining the appropriate audit and retirement records for accountability.

Study tip: Destroying hardware does not revoke credentials that another service still accepts.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Removing names affects discovery of the old host but does not invalidate the external service credential that still authorizes customer-record exports.

B: Vaulting can protect the secret's storage but preserves an unnecessary active authorization rather than completing the retired workload's access decommissioning.

C: An inventory location documents hardware disposition but does not invalidate an independently stored cloud credential or its export permissions.

D: External credentials can outlive the hardware that originally used them, so their revocation is necessary to end the retired workload's remaining access.

## SEC2-Q173

A drive's data was encrypted from initial use with a dedicated key. A team deletes the active key and calls the drive cryptographically erased. An escrow system still retains a usable copy of that same key. Which conclusion is MOST defensible?

- A. Changing the drive's unlock password while leaving the escrow key satisfies the erasure requirement
- B. The escrow key can be ignored because ordinary drive users cannot access the escrow system
- C. A deletion receipt from the active keystore is sufficient evidence of erasure without checking escrow copies
- D. The retained usable key prevents the team from relying on key deletion as completed cryptographic erasure

Answer: D

Cryptographic erasure depends on making the relevant decryption material unavailable under the approved method and assurance requirements. The scenario's usable escrow copy preserves the ability to decrypt, so deletion of the active copy is insufficient evidence of completion. Key inventories and lifecycle controls must account for backup and escrow copies as well.

Study tip: For cryptographic erasure, consider every usable copy of the required decryption material.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/88/r2/final|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: An unlock-password change does not establish destruction of the separate escrow material that the scenario explicitly says can still decrypt the drive.

B: Restricting escrow access is useful protection but does not make a retained usable decryption key cease to exist for sanitization assurance.

C: A deletion receipt verifies one key location, but it does not address another retained usable instance that preserves the ability to decrypt the data.

D: An accessible copy can still decrypt the protected data, so deleting only one key instance does not establish the intended cryptographic-erasure outcome.

## SEC2-Q174

A dataset has reached its approved destruction date, and no hold or retention exception applies. Authorized copies exist in a database, an export share, and a managed analytics workspace. Which TWO activities BEST support complete, accountable disposition? (Select TWO.)

- A. Reconcile the known copy locations and owners against the approved destruction scope
- B. Mark every copy destroyed when the primary database row is deleted
- C. Accept one central job-completion message without checking results from each in-scope location
- D. Limit destruction tracking to locations covered by the primary application's backup plan
- E. Record the completed disposition and verification for each in-scope copy

Answer: A|E

Disposition should follow the information across its authorized copies. Reconciliation identifies the full scope, and per-location completion evidence shows whether the action actually succeeded. A primary deletion or a renamed export does not establish that all retained copies were handled under the approved instruction.

Study tip: A dataset is not completely disposed of merely because its primary copy is gone.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/88/r2/final

A: Scope reconciliation identifies each place and accountable party involved, reducing the chance that a nonprimary copy is omitted from the authorized disposition.

B: Deleting the primary instance does not change independent exports or analytics copies, so it cannot establish completion across all the stated locations.

C: A central status can hide partial failures or omitted copies, so it does not provide the location-specific completion evidence needed for accountable disposition.

D: A backup plan may omit independent export shares or analytics copies, so its scope alone does not establish coverage of every authorized dataset copy.

E: Location-specific completion and verification records support evidence that the authorized dataset copies were processed rather than merely scheduling a general deletion request.

## SEC2-Q175

A vulnerability report says 'job completed, zero local patch findings.' Its execution details say 'credential login failed; authenticated checks skipped.' What should the analyst report about patch compliance?

- A. Infer local patch compliance from a successful unauthenticated scan that checks only open ports
- B. Record a confirmed missing-patch finding for each target because authenticated checks failed
- C. All assessed hosts are patched because the job returned zero findings
- D. Patch compliance is undetermined because the required authenticated checks did not run

Answer: D

An assessment result must be interpreted alongside coverage and execution status. The scanner completed a job, but the checks required to support the patch-compliance claim were skipped. Correct the authorized assessment access or use another approved evidence method, then reassess before recording a conclusion about local patch state.

Study tip: Successful job completion does not prove that the intended checks actually executed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Port reachability does not provide the local patch evidence missing from the skipped authenticated assessment, so it cannot support the requested compliance conclusion.

B: A failed assessment path establishes missing evidence, not a demonstrated patch defect on every target; those outcomes require different reporting and follow-up.

C: Zero findings here result from skipped authenticated checks, so the report does not establish the local patch state of the targets.

D: A completed job can still lack the evidence required for patch assessment; the explicit credential failure means zero findings cannot support a compliance conclusion.

## SEC2-Q176

A team needs to test how a running application handles malformed requests after middleware and runtime configuration are applied. Source code is unavailable. Which approach BEST fits this requirement?

- A. A cryptographic comparison of installation archives without executing the service
- B. Review configuration files without executing the configured application
- C. Dynamic application security testing against an authorized test deployment
- D. Perform software composition analysis limited to dependency names and versions

Answer: C

Dynamic analysis observes an executing application, making it appropriate for testing the effects of actual middleware and runtime settings. The environment must be authorized and representative of the conditions being assessed. This does not replace source or dependency review when those are available, because each method reveals different classes of evidence.

Study tip: Use dynamic testing when the question concerns the behavior of the running deployment.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Archive comparison can assess content consistency but does not observe request handling by the deployed runtime and its active configuration.

B: Configuration review can identify insecure settings, but it does not observe how the running middleware and application actually respond to the malformed requests.

C: Dynamic testing exercises the running application's responses, including effects introduced by its runtime and configuration, without requiring access to source code.

D: Dependency analysis identifies component exposure but does not execute the configured application's request handling or directly test the runtime behavior described.

## SEC2-Q177

A verified vulnerable service remains installed, but a new network control makes it unreachable from the internet. Internal administrators can still reach it. Which status description is MOST accurate?

- A. The original finding becomes a false positive once any network restriction is applied
- B. Treat vulnerability presence as unknown until the service can be tested from the internet again
- C. The vulnerability remains present, with reduced external exposure from a compensating control
- D. The software vulnerability is patched because internet requests now fail

Answer: C

Vulnerability presence and exposure are related but different. The service still contains the verified flaw, while the new network rule reduces the set of potential callers. Report that distinction accurately and track residual risk and remediation rather than treating a compensating control as a patch or retroactively rejecting a valid finding.

Study tip: A blocked attack path can reduce risk without removing the underlying flaw.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The vulnerability was verified as present, and a later exposure reduction does not make the original detection factually incorrect.

B: The flaw was already verified, and retained internal reachability can support further assessment; losing one external path does not erase the existing presence evidence.

C: Network restriction changes who can reach the vulnerable service but does not remove its defective code or eliminate every remaining authorized communication path.

D: A blocked route is not a software fix; the vulnerable service remains installed and reachable through the stated internal administration path.

## SEC2-Q178

An administrator reports a successful fix. A follow-up scanner returns no findings, but every service check says 'connection timed out.' The expected service should remain accessible from the approved scanner. What is the BEST conclusion?

- A. The rescan does not validate remediation; investigate the unexpected reachability failure
- B. Use the pre-repair scan's service version as evidence of the current patch state
- C. Close the finding using the administrator's deployment ticket without checking the affected condition
- D. The vulnerability is confirmed remediated because no finding was returned

Answer: A

Remediation validation requires a meaningful test of the condition, not merely a report with no findings. The expected service was unreachable, so the test's evidentiary value is limited. Determine why the approved assessment path failed and then verify the actual fixed state using an appropriate authorized method.

Study tip: A clean result from a failed observation path is inconclusive.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Timed-out checks provide no effective assessment of the expected service, so the apparent clean result cannot confirm the reported technical fix.

B: A historical scan describes the earlier state and cannot establish what changed after the reported repair or why the service is now unreachable.

C: A deployment record shows a reported action but does not resolve the failed validation path or establish that the original vulnerability is no longer present.

D: The scanner did not reach the service it needed to assess, so an empty result cannot distinguish a fix from an inaccessible target.

## SEC2-Q179

A fleet contains 80 affected servers. The repair team verifies the patch on 12 of them, but the other 68 are offline during the verification window. What is the MOST accurate status to report?

- A. Classify the 68 unavailable servers as confirmed patch failures
- B. Twelve servers are verified remediated; the remaining 68 still require verification
- C. All 80 servers are verified because the sample contained no failures
- D. Report 100% verification coverage using only currently reachable servers as the denominator

Answer: B

An accurate status separates verified outcomes from unresolved evidence. The 12 checked systems support closure at their asset level, while the 68 unavailable systems need a later check or another approved verification method. Do not silently convert incomplete coverage into either a complete success or a universal failure.

Study tip: Report both the result and the population to which the evidence actually applies.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Unavailability prevents verification but does not prove the patch failed; unresolved evidence should remain distinct from a technically confirmed remediation failure.

B: The evidence supports a conclusion for the checked servers only; offline systems have not supplied the patch-state verification needed for fleet-wide closure.

C: A successful subset does not demonstrate the state of every unobserved system, particularly when the requirement is to verify the affected fleet.

D: Excluding previously affected offline assets misrepresents fleet coverage; the verification population still includes systems whose state has not yet been checked.

## SEC2-Q180

A web application vendor has not released a fix for a confirmed flaw. A tested WAF rule blocks the specific exploit request pattern while preserving legitimate use. What is the BEST description of this response?

- A. A vulnerability scan that only reports the exploit without taking action
- B. A source-code patch that removes the defective implementation from the application
- C. Use the blocked exploit request as sufficient evidence that the application itself is patched
- D. Virtual patching that mitigates a known attack path while the application flaw remains

Answer: D

Virtual patching places a protective control around a vulnerable application when a direct fix is unavailable or delayed. The WAF rule can reduce exposure to the known request pattern, but the flaw and any untested bypass paths still require tracking. Validation, monitoring, and eventual vendor remediation remain important.

Study tip: An external filter can mitigate exploitation without changing the vulnerable code.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The rule actively blocks matching requests, making it an enforcement measure rather than a purely observational scanning activity.

B: The application's code has not changed, so the external filtering rule cannot be described as removal of the defective implementation.

C: A blocked request demonstrates filtering behavior on that path, not a change to the underlying application code or complete software remediation.

D: The WAF enforces an external request restriction rather than changing the vulnerable application code, providing a compensating mitigation for the tested attack pattern.

## SEC2-Q181

An employee discovers a reproducible security flaw while testing a vendor product in the company's authorized lab. The vendor publishes a security-reporting channel. Which initial communication BEST supports responsible disclosure?

- A. Send a severity label and scanner screenshot without the affected version or reproduction conditions
- B. Send a private, reproducible report through the vendor's security channel with impact and test conditions
- C. Open a public general-support ticket containing the full exploit instead of using the security channel
- D. Repeat the exploit on the vendor's public production service to obtain more persuasive evidence without separate authorization

Answer: B

Coordinated disclosure begins with actionable information sent through the appropriate private channel when one is available. Affected versions, test conditions, reproduction steps, and observed impact support validation. The researcher should remain within authorization and coordinate further testing and disclosure rather than treating public exploit release as the first verification step.

Study tip: A useful initial disclosure lets the recipient reproduce and assess the observed issue.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Partial summary material may raise awareness but does not provide the concrete conditions and steps the vendor needs to validate the reported flaw efficiently.

B: A private report containing sufficient reproduction and impact evidence lets the vendor validate and coordinate remediation without unnecessarily exposing a workable exploit publicly.

C: A public ticket exposes actionable details unnecessarily when the vendor already provides a dedicated private path for security validation and coordination.

D: Existing lab evidence can support a private report, while additional testing of a public service requires authorization rather than being justified by reporting convenience.

## SEC2-Q182

A threat feed lists an IP address observed serving malware eight months ago. The address now belongs to a shared service used by several business applications, and current evidence has not confirmed malicious activity. What is the BEST way to use this intelligence?

- A. Classify the address as harmless solely because current business applications use its shared provider
- B. Block the address for twenty-four hours and investigate its current business use afterward
- C. Keep the indicator at high confidence solely because the feed provider has a strong reputation
- D. Evaluate freshness, confidence, and current context before turning the old indicator into a blocking rule

Answer: D

Threat intelligence is evidence with scope, confidence, and time context. Historical indicators can guide investigation, but shared infrastructure and changing use affect their value as automatic blocks. Validate current relevance, relate it to observed activity, and choose proportionate actions without treating an old association as a permanent property.

Study tip: Indicators need temporal and environmental context before they become enforcement decisions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://attack.mitre.org/tactics/enterprise/

A: Legitimate use does not prove every activity on shared infrastructure is benign, so current context still needs evaluation instead of an unsupported blanket trust decision.

B: A temporary block still disrupts the shared production dependency before the old indicator's present relevance is established, despite the absence of confirmed current malicious activity.

C: Source credibility is useful, but it does not establish that an eight-month-old address association remains current after changes in infrastructure use.

D: An old indicator on shared infrastructure needs contextual validation so the response reflects present evidence rather than assuming historical association proves current maliciousness.

## SEC2-Q183

Operations teams receive a weekly report containing only the total number of vulnerabilities. They cannot tell which systems to fix or who should act. Which report addition MOST directly enables remediation coordination?

- A. A ranked list of technical severity scores without asset assignments or completion dates
- B. Affected assets, validated findings, responsible owners, and required completion dates
- C. A scanner-health report showing completed jobs and assessment credential errors
- D. A trend chart of total open and closed findings with no asset-level drilldown

Answer: B

Different audiences need different reporting detail. Operations require a mapping from validated findings to assets, owners, and expected actions or deadlines. Aggregate totals can show a trend, but they do not enable repair coordination without that underlying accountability and asset context.

Study tip: Operational reports should tell the recipient what needs action and who is responsible.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Severity rankings can inform priority but do not identify which operations team owns the affected systems or when each repair must be completed.

B: Asset and finding details identify the work, while ownership and deadlines make the remediation assignments accountable and actionable for the operations teams.

C: Assessment health helps evaluate coverage but does not map validated vulnerabilities to the systems, owners, and deadlines needed for remediation coordination.

D: Trend reporting helps management assess progress, but the missing asset and ownership detail still prevents teams from identifying and coordinating their repair work.

## SEC2-Q184

A vulnerability scan discovers a server but tests services only on TCP ports 1–1024. Its administration service uses TCP 8443, is reachable from the scanner, and has a flaw covered by a current enabled detection plugin. Which adjustment MOST directly closes this assessment gap?

- A. Increase scan frequency while retaining the existing TCP service range
- B. Include TCP 8443 in authorized service discovery and verify that the relevant checks run there
- C. Increase host-discovery retries while retaining the existing TCP service range
- D. Refresh the detection-plugin catalog while retaining the existing TCP service range

Answer: B

A scanner can identify a host while leaving some of its services unexamined. Here, the required detector exists and network access works, but the configured service range excludes the application. Adjust the authorized scope and confirm execution on that service; repeated scans with unchanged coverage would preserve the same blind spot.

Study tip: Compare discovered hosts with the specific ports and services the assessment actually tests.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/115/final

A: More frequent execution repeats the same limited coverage. The administration service remains outside the tested range until the assessment configuration includes its port.

B: The configured discovery range excludes the service, preventing the enabled detector from assessing it. Including the port and verifying check execution directly addresses that coverage gap.

C: The server was already discovered and the relevant service is reachable. Retrying host discovery does not add its excluded port to service assessment.

D: The necessary detection plugin is already current and enabled. Updating its catalog does not cause the configured scan to inspect an excluded service port.

## SEC2-Q185

A vulnerability analyst prepares a bulletin by reviewing security notices on vendors' public websites and issue reports in publicly readable project repositories. Which information-source category BEST describes the material being collected?

- A. Proprietary intelligence obtained through a licensed commercial feed
- B. Open-source intelligence collected from publicly available information
- C. Internal assessment evidence generated by the organization's security tests
- D. Restricted intelligence shared within a member-only industry group

Answer: B

Open-source intelligence uses publicly available information, including vendor publications and accessible project records. The category describes how the information is available, not whether the affected software has open-source licensing. The analyst still needs to assess relevance, currency, and credibility before using these reports to guide a response.

Study tip: Open-source intelligence describes information availability, not the software's licensing model.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/115/final

A: A proprietary commercial feed is a different source arrangement. The supplied material comes directly from public notices and repositories rather than a licensed feed.

B: The analyst gathers information available to the general public. Public vendor notices and accessible project reports can supply open-source intelligence for vulnerability management.

C: Internal testing produces evidence about assessed organizational systems. This bulletin collects externally published information without describing any local test or observed system result.

D: A member-only sharing group limits distribution to its participants. The described websites and reports are publicly readable rather than restricted group communications.

## SEC2-Q186

An advisory affects versions of a parsing library only when a specific optional import feature processes untrusted input. An inventory shows the library name somewhere in a large application build. Which TWO facts are MOST important to establish whether this deployment meets the advisory's stated exposure conditions? (Select TWO.)

- A. Whether the advisory's severity score exceeds the organization's emergency-response threshold
- B. Whether the vendor has already released a patch for the affected versions
- C. Whether the component appears in a developer's dependency cache
- D. Whether an affected library version is actually included in the deployed runtime
- E. Whether the affected import feature is enabled and can process untrusted input in this deployment

Answer: D|E

Advisory applicability depends on the affected component and its actual use. A package name in a large inventory may refer to a build dependency rather than deployed runtime code, and the feature condition matters separately. Confirm these facts before describing the specific exposure; other reasons to update the library can still remain.

Study tip: Separate package presence, affected version, and reachable vulnerable behavior.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Severity thresholds can inform response priority after applicability is understood, but they do not establish the deployment's version, enabled feature, or untrusted-input path.

B: Patch availability informs remediation options, but it does not determine whether this deployment contains the vulnerable version and exposes the specified import feature.

C: A development cache can contain packages absent from the deployed runtime, so it does not establish that production contains the affected code.

D: A build inventory can include unused or development-only components; the deployed version establishes whether the runtime contains code within the advisory's affected range.

E: The advisory explicitly conditions exposure on the feature and input path, so confirming those deployment conditions determines whether the described attack route applies.

## SEC2-Q187

A new appliance records result=0 for success and result=1 for failure. The SIEM parser maps 0 to failure, producing alerts for successful administrator logins. What should the team correct FIRST?

- A. Change the appliance's lockout threshold while retaining the parser's existing result mapping
- B. Add a source-address exception for familiar administrator workstations without fixing field interpretation
- C. Raise the failed-login threshold until the incorrect alerts stop
- D. Correct the parser's result mapping and validate it against known success and failure events

Answer: D

Central monitoring depends on correct normalization of source-specific fields. Here, the original events are meaningful, but the parser reverses their outcomes. Correct the mapping and test both event classes before tuning detection logic, because threshold changes cannot compensate reliably for incorrect semantics in the underlying records.

Study tip: Verify event meaning before tuning rules that depend on it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: An appliance policy change does not correct the SIEM's reversed interpretation of success and failure values in the existing event format.

B: Source exceptions may suppress some alerts but leave event outcomes reversed and can hide real failures or suspicious activity from otherwise familiar devices.

C: A threshold change hides symptoms while leaving success and failure meanings reversed, potentially suppressing real problems and corrupting other correlations.

D: The stated field interpretation is reversed, so fixing and testing that mapping addresses the incorrect event meaning before alert thresholds are adjusted.

## SEC2-Q188

An API recorded 20 failed requests out of 2,000 requests last hour and 200 failures out of 20,000 this hour. Which statement is BEST supported when assessing the change in request failure frequency?

- A. The failure rate increased tenfold because the failure count increased from 20 to 200
- B. Both hours have a 1% failure rate; the raw increase alone does not show a higher per-request failure frequency
- C. The current failure rate is 10% because there were ten times more requests
- D. The unchanged percentage establishes that the business impact of failures is unchanged

Answer: B

Rates and counts answer different monitoring questions. The count of failures grew, but dividing by the total request volume shows the same one-percent frequency. This does not make every failure harmless; analysts should still consider impact and context. It prevents a misleading claim that failure probability per request increased solely from raw counts.

Study tip: Use the relevant denominator before interpreting a change in event counts.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: That interpretation omits the tenfold increase in total requests, which leaves the proportion of failed requests unchanged between the two hours.

B: Dividing failures by total requests gives one percent in each period, so the tenfold count increase tracks an equal increase in request volume.

C: A relative volume increase does not determine the failure percentage; 200 divided by 20,000 equals one percent rather than ten percent.

D: A stable rate does not establish stable impact when the absolute failed workload and the importance of individual requests may differ between periods.

## SEC2-Q189

A switch sends a trap when a critical interface goes down. A brief monitoring-network outage can cause that notification to be missed, leaving the dashboard with an old 'up' state. Which addition BEST helps discover a continuing failure afterward?

- A. Periodically poll the interface's current state and reconcile it with the dashboard
- B. Increase the escalation urgency of down alerts without adding another state-observation method
- C. Republish the last known interface status hourly without contacting the switch
- D. Rely exclusively on state-change notifications without reconciling the current interface state

Answer: A

Event notifications provide timely updates when delivered, while periodic polling can reconcile the current condition when an earlier update is missed. Combining them helps avoid a permanently stale state after a collection interruption. Polling intervals should reflect operational needs rather than assuming any single notification path is infallible.

Study tip: Notifications report changes; polling can reestablish the current state.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Polling retrieves current state after connectivity returns, allowing the monitoring system to detect a sustained condition even when its original notification was missed.

B: Higher urgency helps only for events the monitoring system receives; it cannot reveal an interface change whose original notification was missed.

C: Repeating cached state produces more frequent reports but does not obtain new evidence that would correct the stale interface condition.

D: Notification-only monitoring can preserve the stale dashboard when the relevant change event was missed, because no later current-state observation corrects it.

## SEC2-Q190

Policy requires endpoint detection content to be no more than 48 hours old. A laptop reports that its antimalware service is running, but its last successful content update was nine days ago. Which conclusion is correct?

- A. A recent endpoint scan timestamp is sufficient evidence that its detection content is current
- B. The laptop is compliant until the antimalware engine itself requires a version upgrade
- C. The device is compliant because a running service implies current detection content
- D. The running service is not enough; its detection-content age violates the stated requirement

Answer: D

Monitoring should distinguish whether a security service is running from whether its protection data is current. The laptop fails the explicit freshness policy even though the service remains active. Investigate the update path and restore compliant content, while treating any claim of actual infection as a separate question requiring evidence.

Study tip: A healthy service status does not establish that its protection content is current.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A scan can execute using stale content, so its run time does not replace the separate last-successful-update evidence supplied in the scenario.

B: Engine version and detection-content age are separate maintenance dimensions; the stated policy violation exists even if the executable engine is current.

C: A service can remain operational while updates fail, and the provided update timestamp directly contradicts the content-freshness requirement.

D: Service availability and content currency are distinct conditions, and the nine-day update age exceeds the explicit forty-eight-hour policy limit.

## SEC2-Q191

All devices label their logs as UTC, but a switch clock is eleven minutes fast. Correlation repeatedly places switch events after later endpoint actions. What is the BEST long-term correction?

- A. Synchronize monitored systems with approved reliable time sources and detect clock drift
- B. Sort every investigation solely by the order in which logs arrive at the collector
- C. Relabel the switch's UTC records as a different timezone without correcting its clock
- D. Subtract eleven minutes from collector receipt times while leaving source-clock management unchanged

Answer: A

Reliable correlation needs accurate event time and known timestamp semantics. The switch's issue is drift, not a timezone conversion problem. Correcting synchronization and monitoring deviation address future events, while investigators should preserve existing records and document the known offset when interpreting historical data rather than silently rewriting evidence.

Study tip: Timezone labels can be correct while the device's clock is wrong.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Consistent accurate clocks support meaningful cross-source timelines, while drift monitoring reveals when a device again diverges from the intended time reference.

B: Collection delay and buffering can differ across sources, so receipt order is not a reliable replacement for accurate event timestamps.

C: The problem is clock error rather than a stated timezone offset, so changing labels misrepresents the records instead of restoring accurate event time.

D: Receipt time also reflects transport delay, and a fixed manual adjustment does not provide a durable correction for changing drift in the original event clock.

## SEC2-Q192

An intrusion sensor receives mirrored traffic from several links. During peak load its capture-drop counter reaches 35%, and alert volume falls. Which interpretation is MOST defensible?

- A. Threat activity has decreased, as shown by the lower alert count
- B. Inspection coverage is intact because production link counters show successful delivery
- C. The sensor has a visibility gap; fewer alerts may reflect lost inspection input rather than fewer attacks
- D. The inspected 65% is representative of the traffic that was dropped

Answer: C

A sensor can become partially blind without any production connection failing. Capture drops indicate missing input and reduce confidence in negative detection conclusions. Investigate mirror configuration, aggregate bandwidth, sensor capacity, and inspection load before using the declining alert count as evidence that threat activity has fallen.

Study tip: Monitor visibility loss alongside detections; the production path and inspection copy can fail differently.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The count depends on how much traffic the sensor can inspect, so ignoring a large simultaneous visibility loss makes that activity conclusion unreliable.

B: Delivery on the original traffic path does not establish delivery of every mirrored packet to the inspection system's separate capture path.

C: A high capture-drop rate means significant traffic is not available for inspection, so reduced alert volume cannot be assumed to represent improved security.

D: Capacity loss can be selective or correlated with busy flows, so the remaining packets cannot be assumed to represent the missing traffic without validation.

## SEC2-Q193

Two forwarders deliver the same events to a SIEM. Records share the same originating host, native event ID, and event timestamp, but have different collector arrival times. Failure counts double after the second forwarder is enabled. What is the BEST correction?

- A. Delete every event whose message text matches another message that day
- B. Deduplicate using stable source-event identity while retaining genuinely separate events
- C. Double the alert threshold to compensate for the two forwarders without correcting duplicate ingestion
- D. Treat every collector arrival time as proof of a separate failed action

Answer: B

Collection paths can duplicate records without duplicating the underlying activity. Stable source identifiers provide a better basis for deduplication than arrival time or message text alone. Correct the ingestion behavior so reporting and correlation reflect actual events, while preserving distinct occurrences that happen to have similar content.

Study tip: Deduplicate deliveries using event identity, not merely matching messages.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Different legitimate events can share text, so text-only daily suppression can erase real repeated failures rather than target duplicate delivery.

B: Source host and native event identity can distinguish duplicate deliveries from separate events, preventing inflated counts without collapsing legitimate repeated actions.

C: A threshold workaround leaves event counts and other correlations inaccurate and can become misleading again when forwarding paths or coverage change.

D: Different receipt times can represent delivery of the same original event through two paths, as the matching source identifiers demonstrate here.

## SEC2-Q194

A debugging change writes full authorization headers into application error logs. Analysts need request IDs, timestamps, error codes, and component names to troubleshoot, but do not need bearer tokens. Which correction BEST preserves useful monitoring while reducing exposure?

- A. Exclude or mask secret-bearing fields at collection while retaining the required diagnostic fields
- B. Encrypt log storage while leaving complete bearer tokens in readable event fields
- C. Retain only daily error totals and discard request-level diagnostic events
- D. Restrict log-reader membership but continue storing complete bearer tokens in each error event

Answer: A

Logs should collect the information needed for operations without unnecessarily reproducing authentication secrets. Removing secret-bearing fields at the logging boundary preserves request tracing and error diagnosis while reducing exposure. Previously collected tokens need a separate assessment because changing future logging does not remove existing copies or invalidate already exposed credentials.

Study tip: Useful diagnostic context rarely requires storing reusable authentication secrets.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Removing unnecessary credentials from log events reduces secret exposure while preserving the specific fields analysts need to investigate application errors.

B: Storage encryption protects some access paths but still exposes tokens to authorized log-reading interfaces and unnecessarily retains them within the monitoring system.

C: Aggregate counts lose the request identifiers and component context the analysts need, rather than selectively removing the unnecessary secret-bearing fields.

D: Access limits reduce exposure but retain unnecessary reusable secrets in the logging system when analysts explicitly do not need those fields.

## SEC2-Q195

An analyst queue contains 500 informational notices from an approved software rollout and one validated alert that an unauthorized account was added to a production administrator group. The team's policy prioritizes confirmed unauthorized privilege changes over expected maintenance notices. Which action BEST follows that policy?

- A. Apply strict arrival-order processing to the earlier rollout notices before the privilege-change alert
- B. Treat the group change as routine because an administrative management tool generated its audit record
- C. Escalate the administrator-group change through the response process before processing routine rollout notices
- D. Wait for complete forensic imaging before escalating the validated privilege-change alert

Answer: C

Alert prioritization should follow validated context and impact criteria instead of event count alone. The maintenance notices are expected, while the group change is confirmed unauthorized and meets the organization's higher-priority rule. Escalating it first does not mean discarding the remaining notices; it applies the defined order of operational attention.

Study tip: One consequential event can outrank hundreds of expected informational events.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Arrival order does not implement the stated impact-based priority rule and would delay the validated unauthorized privilege change behind expected maintenance events.

B: A familiar management tool can perform unauthorized changes, and the event is already validated as unauthorized rather than merely assumed suspicious from its source.

C: The validated unauthorized privilege change meets the explicit higher-priority criterion and can create significant access risk despite producing only one alert.

D: Escalation can begin from the confirmed unauthorized change; requiring a full image first adds an unsupported delay to the policy's higher-priority response path.

## SEC2-Q196

A detector is tested against 100 labeled events: 20 malicious and 80 benign. It alerts on 18 malicious events and 8 benign events. Which TWO results are correct? (Select TWO.)

- A. There are 8 false positives
- B. There are 72 false negatives
- C. There are 2 false negatives
- D. There are 18 false positives
- E. There are 26 true positives

Answer: A|C

Ground truth determines whether an alert or nonalert is correct. Eight benign events were flagged, giving eight false positives. Twenty malicious events existed but only eighteen were flagged, leaving two false negatives. The remaining eighteen alerts are true positives and the seventy-two unalerted benign events are true negatives.

Study tip: Separate what the detector reported from what the labeled event actually was.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: The eight benign events that generated alerts are false positives because the detector reported a condition that the labeled ground truth says was absent.

B: The seventy-two benign events without alerts are true negatives, not missed malicious events, because both their labels and detector results are negative.

C: Two of the twenty malicious events did not generate alerts, so the detector missed two known positive conditions.

D: The eighteen alerted malicious events are true positives, since both the detector result and the labeled ground truth indicate malicious activity.

E: Twenty-six is the total alert count, which combines eighteen true positives with eight false positives rather than representing confirmed malicious detections only.

## SEC2-Q197

Managed browsers can use alternate encrypted DNS resolvers. A company's domain-blocking rules exist only on its approved resolver, and tests show blocked names resolving through an alternate provider. Which change BEST makes the required filtering apply?

- A. Validate alternate resolver TLS certificates while allowing browsers to choose any authenticated resolver
- B. Enforce approved DNS resolution through managed endpoint and network policy
- C. Refresh the approved resolver's blocklist more frequently while keeping alternate resolvers permitted
- D. Increase query logging on the approved resolver without changing the browser's resolver options

Answer: B

DNS filtering applies where resolution requests are actually evaluated. If managed clients can bypass the approved resolver, the domain policy does not cover those requests. Endpoint settings and suitable network controls should enforce the intended path while accounting for the organization's approved encrypted-DNS design and legitimate application needs.

Study tip: A filtering rule is ineffective on requests sent to a different policy engine.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Authenticating a resolver protects the connection to it but does not make that resolver apply the organization's required domain-blocking policy.

B: Controlling the resolver path closes the demonstrated bypass so managed browsers cannot simply choose an alternate provider that lacks the organization's required filtering.

C: Fresher rules do not affect queries sent to an alternate provider, so this improvement does not close the demonstrated path around the filtering resolver.

D: Additional logging covers traffic reaching that resolver but does not observe or enforce policy on the alternate-resolution path used by the bypass.

## SEC2-Q198

Outbound mail receives a valid DKIM signature, then a downstream company gateway changes signed body content by adding a footer. Receiving servers report body-hash verification failures. Which design change BEST addresses the cause?

- A. Rotate the DKIM signing key while leaving the footer insertion after signing
- B. Tighten SPF sending-server authorization while preserving the existing signing and footer order
- C. Change DMARC policy to monitoring only without correcting the signing pipeline
- D. Apply the footer before the final DKIM signing stage

Answer: D

DKIM verification depends on the relevant signed content remaining consistent under the signature's rules. The stated footer modifies that content after signing, causing the mismatch. Moving final signing after authorized content changes preserves the intended outgoing message while allowing recipients to verify its signature normally.

Study tip: Sign the final content after processing that would change what the signature covers.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://www.rfc-editor.org/rfc/rfc6376.html

A: A new signing key does not prevent later alteration of signed body content, so the same processing order can continue causing body-hash failures.

B: SPF evaluates sending infrastructure rather than the integrity of a DKIM-signed body, so it does not correct this content-modification failure.

C: A monitoring policy can change requested handling of failures but does not make the altered message pass DKIM body-hash verification.

D: Signing the final message content avoids a later body modification invalidating the signature, directly addressing the processing-order problem described by the failures.

## SEC2-Q199

A domain publishes this DMARC record: v=DMARC1; p=none; rua=mailto:dmarc@sender.example. What handling does the p=none policy request for messages that fail DMARC?

- A. Reject DMARC failures as the domain owner's requested disposition
- B. Require both SPF and DKIM to pass before any aggregate report can be generated
- C. No DMARC-requested quarantine or rejection; the domain can collect reports for monitoring
- D. Quarantine DMARC failures as the domain owner's requested disposition

Answer: C

The policy value describes the domain owner's requested treatment for DMARC failures. A value of none supports observation without requesting DMARC-based quarantine or rejection. Receivers can still apply their own spam or security rules, so the record does not guarantee delivery or describe a bypass of every other mail control.

Study tip: DMARC monitoring policy does not guarantee acceptance under a receiver's other rules.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://www.rfc-editor.org/rfc/rfc7489.html

A: Rejection corresponds to a different DMARC policy value; this record explicitly requests none, even though receivers may apply independent local security rules.

B: The none disposition does not redefine authentication into a requirement that both mechanisms pass, and aggregate reporting can include messages that fail authentication.

C: The none policy requests monitoring without asking receivers to quarantine or reject solely under that DMARC policy, while the report address supports aggregate feedback.

D: Quarantine is a distinct requested disposition and is not selected by p=none, which is used here alongside the aggregate reporting address.

## SEC2-Q200

A domain-joined workstation does not enforce a local-account lockout setting from the intended Group Policy Object. The administrator sees several linked policies, security filters, and an inheritance exception. What is the BEST diagnostic step?

- A. Edit the expected GPO repeatedly without checking whether the workstation receives it
- B. Force repeated policy refreshes without examining targeting or resultant settings
- C. Assume the policy linked nearest the domain root supplies the effective setting
- D. Examine the workstation's resultant policy and application evidence to identify the effective setting and winning source

Answer: D

A linked policy is not necessarily the effective policy on a particular target. Resultant settings and application evidence show which objects applied and how conflicts or filters were resolved. Diagnose that effective state before changing scope or removing controls so the correction addresses the actual policy path.

Study tip: Inspect what applied to the target, not merely what exists in the policy console.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Changing a policy that is filtered out or overridden may have no effect on the target, leaving the application or precedence problem unexplained.

B: Refresh can retrieve applicable policy but does not by itself correct filtering, inheritance, or precedence that causes the intended setting not to apply.

C: Link location alone does not resolve the described filters and inheritance behavior, so the target's actual policy results are needed before selecting the winning source.

D: Resultant-policy evidence shows what actually applies to the target and can reveal filtering, inheritance, or precedence that prevents the intended setting from winning.

## SEC2-Q201

Approved support tools need limited local administrative access, but a support script has been stopping the endpoint security agent. The product supports centrally managed tamper protection and an authorized maintenance-unlock process. Which change BEST preserves protection and legitimate maintenance?

- A. Restart the security service each night without restricting unauthorized stops during the day
- B. Grant a standing protection exception to the entire support-tool publisher for routine convenience
- C. Alert after the agent stops but leave support scripts free to stop it
- D. Enable tamper protection and require the approved unlock process for security-agent maintenance

Answer: D

The issue is unauthorized modification of the security control, not the existence of every support task. Tamper protection can separate ordinary local administration from protected-agent maintenance when the product supports that distinction. A controlled unlock procedure preserves a legitimate operational path without making agent disablement a standing entitlement.

Study tip: Security-agent maintenance can require authorization beyond ordinary local administration.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A scheduled restart can restore a stopped service later but leaves avoidable unprotected intervals and does not distinguish authorized from unauthorized agent maintenance.

B: A broad publisher exception can cover activity beyond approved agent maintenance and removes the controlled authorization boundary that the supported unlock process provides.

C: Post-event detection can support response, but it does not preserve the running protection against unauthorized stopping when preventive tamper controls are available.

D: Centrally controlled tamper protection restricts unauthorized agent changes while the documented unlock process provides a controlled path for legitimate maintenance when needed.

## SEC2-Q202

A file-integrity monitor alerts after an approved application release changes protected binaries. The change record identifies expected release hashes. Which action BEST maintains a trustworthy baseline?

- A. Suspend binary monitoring during maintenance and resume without reconciling expected release contents
- B. Accept new file hashes from any activity inside the maintenance window without checking release evidence
- C. Verify the installed changes against the approved release evidence before updating the baseline
- D. Restore the previous release solely because the hashes differ after deployment

Answer: C

Integrity monitoring needs a baseline that changes through a trusted process. Approved release hashes and change records provide a reference independent of the system's newly observed state. Verifying the update before accepting it prevents ordinary maintenance from creating endless noise while avoiding automatic trust in potentially unauthorized changes.

Study tip: A baseline update needs independent approval evidence, not merely the current observed state.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A monitoring pause does not establish what changed, and resuming without trusted reconciliation leaves either stale references or unsupported acceptance of the new state.

B: An approved window does not prove every observed change was authorized, so blindly learning its results can incorporate unexpected modifications into the trusted baseline.

C: Comparison with independent approved release evidence establishes that the observed changes are expected before they become the new trusted reference for future monitoring.

D: An intended update necessarily changes some hashes, so difference alone does not justify rollback without comparing the installed state to the approved release evidence.

## SEC2-Q203

A printer cannot perform certificate-based network authentication. It needs only print-server traffic, but its MAC address can be copied by another device. An approved exception permits MAC-based admission. Which design BEST limits the exception's risk?

- A. Constrain admitted traffic to a dedicated printer segment and required print-server paths
- B. Reduce switch MAC-learning aging time without narrowing access granted after admission
- C. Rotate the print-server password while retaining unrestricted internal access for the admitted printer
- D. Place the printer on the employee access network and restrict internet egress while retaining broad internal access

Answer: A

A weak identification method can be acceptable only within a carefully bounded exception under the supplied policy. MAC-based admission does not provide the same assurance as certificate authentication, so network placement and allowed flows should constrain its consequences. Stronger-capability devices should continue using the standard admission method.

Study tip: Limit the access consequence when a device needs a weaker admission exception.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Restricted placement and flows limit the access obtained through the weaker admission method, reducing the value of copying the printer's MAC address.

B: Shorter learning intervals do not turn a copied address into certificate proof or reduce the network permissions granted when that address is accepted.

C: Changing one service credential does not bound the broader network access provided through the weaker admission method or address unnecessary lateral reachability.

D: Limiting internet access does not confine the weaker admitted device to its required print-server path, leaving unnecessary internal reachability available to a copied MAC identity.

## SEC2-Q204

A partner requires encrypted file transfer using an SSH-based service over TCP port 22. The firewall change authorizes that service only. Which protocol should the administrator select?

- A. FTP
- B. SFTP
- C. FTPS
- D. TFTP

Answer: B

Similar names do not mean identical protocols. The requirement specifically names an SSH-based file-transfer service on TCP port 22, which is SFTP. FTPS is FTP protected with TLS and has different connection requirements. Choose the protocol that matches the partner's actual service and the approved firewall change.

Study tip: SFTP uses SSH; FTPS uses FTP with TLS.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Ordinary FTP is a different protocol and does not provide the required SSH-based encrypted connection through the stated service authorization.

B: SFTP is an SSH-based file-transfer protocol and fits the partner's specified service and authorized TCP port without requiring an FTP control channel.

C: FTPS protects FTP using TLS rather than SSH, so it does not match the explicitly required SSH-based service on the authorized port.

D: TFTP is a lightweight file-transfer protocol using UDP, not the required authenticated and encrypted SSH-based service over TCP port 22.

## SEC2-Q205

A service specification requires client connections to 192.0.2.60 using TCP destination port 443. A packet capture confirms TCP connection attempts, but the approved allow rule mistakenly specifies UDP destination port 443. All other applicable traffic is denied. Which correction is required?

- A. Change the service rule to permit the required TCP destination port 443 flow
- B. Retain the UDP rule and increase the TCP connection timeout
- C. Permit new TCP 443 connections only in the reverse server-to-client direction
- D. Permit TCP source port 443 from clients instead of the required destination port

Answer: A

A firewall service match includes the transport protocol as well as the port. TCP 443 and UDP 443 are different flows even if both can carry legitimate applications. The supplied specification and capture establish TCP here, so correct that narrow rule while retaining unrelated protections.

Study tip: Protocol and port are separate fields in a traffic decision.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The protocol is part of the match, so the existing UDP rule does not permit the captured TCP attempts despite using the same numeric port.

B: A longer timeout does not make a denied TCP flow match a UDP permission, so it cannot correct the demonstrated protocol mismatch.

C: A reverse-direction initiation rule does not authorize the client's required new connection to the server under the stated default-deny conditions.

D: The service listens on the destination port, while clients normally use other source ports; changing the wrong field does not match the specified outbound connection.

## SEC2-Q206

Employees may send approved encrypted archives to a partner. The mail gateway cannot decrypt them, but policy prohibits including Restricted documents. The organization controls the endpoint encryption workflow. Which control placement BEST addresses this visibility gap?

- A. Enforce classification-aware inspection on the endpoint before the approved archive is encrypted
- B. Classify the email's visible body and assume encrypted attachments inherit the same classification
- C. Require a longer archive password while retaining no source-document classification check
- D. Accept encrypted archives at the gateway when their filenames match an approved pattern

Answer: A

A control needs visibility at the point where it evaluates a data-handling rule. Since the gateway cannot inspect these encrypted archives and the endpoint workflow is controlled, pre-encryption DLP can check the source documents. Encryption and authorization serve different purposes; an encrypted transfer can still violate the permitted disclosure policy.

Study tip: Place content inspection where the content is available and before the prohibited action becomes opaque.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Inspection before encryption can evaluate the documents' classifications while their content and labels remain available to the controlled workflow.

B: The body and archive can contain different information, so classifying only the visible text does not establish the handling requirements of the concealed documents.

C: Stronger encryption protects the package from unauthorized reading but does not determine whether the sender is permitted to disclose its contents to the partner.

D: An archive name does not disclose the classification of its contents, so a naming convention cannot establish that Restricted documents were excluded.

## SEC2-Q207

A company must stop executable attachments disguised with harmless filenames and also block links that become malicious after an email is delivered. Which TWO capabilities BEST address these separate conditions? (Select TWO.)

- A. An attachment rule that trusts the sender-supplied filename extension alone
- B. Use a passing SPF result as sufficient evidence to bypass attachment inspection
- C. URL protection that reevaluates the destination when the recipient follows the link
- D. A permanent allow decision based only on the link's reputation at message arrival
- E. Attachment inspection that evaluates actual file type and supported archive contents

Answer: C|E

Attachment disguise and delayed destination changes require different inspection points. File-content evaluation addresses misleading filenames, while link reevaluation at use addresses changes after delivery. These capabilities need appropriate support and tuning, and domain authentication remains complementary rather than a substitute for checking content and destinations.

Study tip: Match the inspection point to when the relevant threat can become visible.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://www.rfc-editor.org/rfc/rfc7208.html

A: A filename-only decision is bypassed by the exact disguise described, so it cannot establish whether the attachment's actual content is executable.

B: SPF authenticates permitted sending infrastructure rather than attachment safety, so an authorized sender can still deliver executable or malicious content.

C: Time-of-use URL checks can respond to a destination's changed status after delivery, addressing links that were not malicious when the message first arrived.

D: A delivery-time-only allow decision misses later changes in destination behavior, which is the second condition the company explicitly needs to address.

E: Content-aware attachment inspection can detect executable material despite a misleading filename, including within archive formats the inspection system supports.

## SEC2-Q208

A company defines permission bundles for help desk technician, inventory viewer, and inventory administrator. Users receive the bundle matching their approved job function rather than individual file grants. Which model is MOST directly described?

- A. Discretionary access control
- B. Role-based access control
- C. Mandatory access control
- D. Attribute-based access control

Answer: B

Role-based administration groups the permissions needed for a job into a reusable role. Assigning approved users to those roles simplifies consistent provisioning and review. The roles still require appropriate scope and maintenance; the model does not automatically ensure every role contains only the permissions its members currently need.

Study tip: A named job function with a reusable permission bundle points to RBAC.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: DAC emphasizes a resource owner's discretionary grants, whereas the described administration assigns standardized permission bundles according to approved job functions.

B: RBAC associates permission bundles with organizational roles, then grants users access through their approved role assignments rather than managing each permission individually.

C: MAC commonly enforces central classification labels and clearances; this scenario describes job-function roles rather than clearance comparisons for resources.

D: ABAC evaluates policy using attributes across a request's context; the scenario specifically describes predefined role bundles and membership-based permission administration.

## SEC2-Q209

Before issuing a first employee credential, an enrollment team validates the applicant's claimed identity using approved evidence and authoritative personnel records. Which activity is this?

- A. Identity proofing
- B. Attestation that existing permissions remain appropriate
- C. Authentication of an existing issued credential
- D. Authorization for a particular application operation

Answer: A

Proofing and authentication serve different points in the identity lifecycle. Proofing validates the claimed person during enrollment, while later authentication checks the issued authenticator. An accurate enrollment binding matters because strong later authentication cannot correct a credential that was issued to an impostor during the initial proofing process.

Study tip: Proof the identity before binding the credential; authenticate the credential during later use.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Identity proofing establishes confidence that the applicant is the claimed person before the organization binds and issues credentials for later authentication.

B: Access attestation reviews previously granted entitlements, whereas this activity validates the applicant's identity before initial credentials are issued.

C: Authentication verifies control of an established authenticator, while the scenario occurs before the applicant has received the first organizational credential.

D: Authorization decides what an established identity may do; the enrollment team is validating who the applicant is rather than assigning a specific operation.

## SEC2-Q210

A nightly billing job uses a service account whose named owner has left the company. The job remains authorized and business critical, and no compromise is suspected. Before making a disruptive access change, what should the identity team do?

- A. Place the account in an unowned-service-account group and exempt it from normal offboarding
- B. Leave the account outside access reviews until the billing software is replaced
- C. Disable the service account immediately without checking which jobs depend on it
- D. Identify the account's dependencies and assign an accountable current owner to review its continued access

Answer: D

Nonhuman identities need lifecycle accountability even when their workloads outlive individual employees. The owner departure does not prove the service should stop, but it does require reassignment and review. Understanding dependencies lets the organization plan permission and credential changes without unintentionally disrupting the approved billing function.

Study tip: A departing human owner does not necessarily end the business need for a service identity.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A holding category can prevent immediate disruption but does not identify an accountable owner or review the continued permissions and dependencies of the active workload.

B: A future replacement does not resolve present orphaned ownership, so ongoing authorized operation still needs an accountable owner and access review.

C: Immediate unplanned disablement can interrupt the explicitly authorized critical job when no active compromise is stated to justify that disruption.

D: Dependency identification and accountable ownership allow the team to maintain the legitimate job while reviewing the orphaned account's permissions and credential lifecycle.

## SEC2-Q211

A proposed new password meets the application's length and character requirements, but it appears on the verifier's blocklist of known compromised passwords. The password policy requires blocklist screening. What should the verifier do?

- A. Accept it because satisfying composition requirements makes the blocklist irrelevant
- B. Reject the proposed password and require a different value
- C. Accept it after adding more hash iterations on the server
- D. Accept it with a shorter expiration period instead of enforcing the blocklist

Answer: B

Password length, composition, and known-compromise screening are separate checks. A candidate can look complex while already appearing in attacker wordlists or breach material. The stated blocklist requirement therefore warrants rejection and a different choice, rather than treating server hashing or a shorter lifetime as equivalent compliance.

Study tip: A complex-looking password can still be a known compromised value.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html

A: Composition and known-compromise checks address different weaknesses; the stated policy requires the blocklist check in addition to the other conditions.

B: The proposal fails the explicit compromised-password check even though it meets composition requirements, so the user must choose a value that satisfies both.

C: Stronger password hashing can increase offline guessing cost but does not make the user's known-compromised candidate satisfy the blocklist requirement.

D: Shorter validity leaves a known-compromised password usable during that interval and substitutes a different control for the expressly required rejection check.

## SEC2-Q212

A user enters the correct password, but newly generated time-based OTP codes fail. The identity service's clock is accurate, while the authenticator phone is five minutes slow. Other users authenticate normally. Which action MOST directly addresses the observed cause?

- A. Expand the OTP acceptance window broadly for every user before correcting the phone
- B. Restore accurate time on the authenticator phone and test a newly generated code
- C. Reset the successful password and retry the authenticator without correcting its clock
- D. Re-enroll a new authenticator seed while leaving the phone five minutes slow

Answer: B

A time-based OTP relies on agreement about the current time interval. The scenario isolates a significant clock error on the user's phone, making correction and a fresh-code test the direct response. Adjusting global tolerance or unrelated account settings is unnecessary when the observed local cause can be resolved.

Study tip: For time-based codes, check the authenticator's clock as well as the user's input.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html

A: A broad acceptance change weakens replay timing constraints for unrelated users when a local clock correction directly addresses the identified single-device problem.

B: Time-based codes depend on the current time interval, and the identified phone-clock error can place generated codes outside the verifier's accepted window.

C: The password already passes, so resetting it does not address the identified time error affecting the separate one-time-code calculation.

D: A new seed changes the secret but still generates codes using the wrong time interval, so it does not directly correct the observed cause.

## SEC2-Q213

An expense application receives a SAML assertion signed by its trusted identity provider. The signature and validity times pass, but the assertion names the separate payroll application as its audience. What should the expense application do?

- A. Accept it because any assertion signed by the trusted provider is valid for every application
- B. Refresh the cached signing certificate and retry without evaluating the audience
- C. Accept the assertion if the employee has active accounts in both applications
- D. Reject the assertion because it was not issued for the expense application's audience

Answer: D

A trusted signature is necessary but not sufficient for accepting a federation assertion. The receiving service must also check constraints such as intended audience and validity. Here, the assertion belongs to payroll, so accepting it at the expense service would disregard a specific restriction despite successful signature verification.

Study tip: Validate who issued an assertion and the service for which it was issued.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://pages.nist.gov/800-63-4/sp800-63b.html|https://docs.oasis-open.org/security/saml/v2.0/saml-core-2.0-os.pdf

A: Signature trust establishes the issuer and integrity, but it does not override the assertion's intended audience or make the assertion transferable among services.

B: The signature already verifies, and a certificate refresh does not change the assertion's intended recipient or remove the mismatched audience condition.

C: Existing accounts do not remove the assertion's audience restriction; a token intended for payroll does not become valid at expense solely through shared user membership.

D: Audience validation prevents an otherwise valid assertion intended for one service from being reused at a different relying service with another identity boundary.

## SEC2-Q214

A portal accepts identities from two trusted providers. Each provider guarantees a unique, non-reassignable subject ID within its own system, but the providers can use the same subject strings. Email addresses can be renamed or assigned to new employees. Which account-linking key BEST avoids accidental identity collisions?

- A. The displayed full name combined with the current department
- B. The subject ID alone without recording which provider issued it
- C. The trusted issuer identity combined with its non-reassignable subject ID
- D. The current email address combined with the provider's name

Answer: C

Federated identifiers need both namespace and lifecycle meaning. The provider's issuer identity defines the namespace, and its non-reassignable subject ID supplies the stable identity inside it. Email is useful contact information but can be a poor long-term key when renamed or reused. The portal must validate the trusted issuer before using this mapping.

Study tip: A stable subject needs its issuer namespace; a contact address is not necessarily a permanent identity.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Names and departments can change or be shared, so that combination does not provide the guaranteed persistent identity properties supplied by the issuer and subject.

B: The scenario permits the same subject string in both provider systems, so omitting issuer context can merge unrelated identities.

C: The issuer distinguishes the two provider namespaces, while the stable subject identifies the person within that issuer despite email changes or reassignment.

D: Issuer context separates providers, but a reassigned email can still identify a different employee within the same provider over time.

## SEC2-Q215

A legacy appliance supports only one maintenance administrator account. Several authorized technicians use it interactively, and changing its password does not affect service processes. The company needs individual accountability and reduced reuse of checked-out secrets. Which approach BEST fits?

- A. Rely only on the source workstation address in appliance logs while keeping the shared password unchanged
- B. Keep one unchanged password in an encrypted document shared by the technician group
- C. Rotate the password yearly and rely only on the appliance's shared username for attribution
- D. Broker named technician access through a vault and rotate the shared secret after authorized use

Answer: D

Where a legacy system cannot support individual administrator accounts, a privileged-access vault can provide an accountable access point. Named checkout or brokered sessions connect actions to authorized technicians, and rotation after use limits reuse of a shared secret. The stated absence of service dependencies makes that rotation feasible here.

Study tip: Vaulting should address who used the shared credential and how long an obtained copy remains useful.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An address is not necessarily a unique technician identity, and retaining the same secret does not reduce its reuse after an earlier maintenance session.

B: The document may protect storage confidentiality but does not provide individual checkout accountability or reduce reuse through supported credential rotation.

C: The appliance's common username cannot identify the technician by itself, and annual rotation leaves long reuse windows compared with the stated maintenance capability.

D: Named vault access links maintenance use to a technician, while post-use rotation limits later reuse of a secret obtained during a prior session.

## SEC2-Q216

A temporary analysis job needs API access for no more than fifteen minutes. Its host can crash before cleanup runs. Which credential design BEST ensures the access expires even if the job cannot execute its cleanup code?

- A. Use a permanent token inside a container configured to stop after fifteen minutes
- B. Rotate the shared API password at the next monthly maintenance window
- C. Issue a narrowly scoped token with a server-enforced fifteen-minute expiration
- D. Use a permanent token and delete its local file only after successful job completion

Answer: C

Ephemeral credentials reduce dependence on perfect cleanup. A server-enforced token expiry ends acceptance after the defined lifetime even if the client crashes. Permissions should also match the job's narrow needs because lifetime and scope protect different dimensions of access. Local file deletion is useful hygiene but is not equivalent to server-side expiration.

Study tip: Credential lifetime should be enforced by the service that accepts it, not only by client cleanup.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A container lifetime limits local execution but does not make a copied permanent token expire at the API that continues accepting it.

B: A monthly rotation does not enforce the required fifteen-minute limit and unnecessarily links the temporary job to a longer-lived shared credential.

C: A verifier-enforced expiration limits acceptance independently of whether the temporary host remains alive to delete local files or call a revocation routine.

D: A crash can prevent the cleanup step, and deleting a local copy does not by itself make a previously copied permanent token unacceptable to the API.

## SEC2-Q217

A support portal permits sensitive operations only from 08:00 through 17:00. A technician logs in at 16:55 and receives an eight-hour authentication session. The technician must not perform a sensitive operation at 17:10. Which design BEST enforces the requirement?

- A. Check the hours only when the browser first displays the sensitive-operation button
- B. Shorten the authentication session to one hour from each successful login
- C. Check the allowed hours only when issuing the initial authentication session
- D. Evaluate the time restriction when each sensitive operation is authorized

Answer: D

Authentication session validity does not necessarily imply authorization for every later action. The portal's business rule applies when the sensitive operation occurs, so it should evaluate current time at that decision point. This maintains the specified access boundary without relying on a session lifetime that can extend beyond the approved hours.

Study tip: A continuing session does not remove the need to evaluate current authorization conditions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A user interface check can become stale or be bypassed by a direct request, so the server must evaluate the rule when authorizing the actual operation.

B: A one-hour session beginning at 16:55 still remains valid after 17:00, so relative session duration does not enforce the fixed daily operation window.

C: A login-time-only check permits the session to outlast the window, allowing the prohibited later operation under the scenario's eight-hour session duration.

D: Checking the operation's current context enforces the permitted hours even when a valid authentication session began before the access window ended.

## SEC2-Q218

A contractor needs twenty-one days of access to view asset metadata. The approved application offers separate permissions for viewing, editing, and bulk export. Editing and bulk export are prohibited, and access must end automatically with the contract. Which TWO provisioning actions meet these requirements? (Select TWO.)

- A. Assign the view-only permission set without edit or bulk-export grants
- B. Rely only on a calendar reminder to ask the sponsor about access after twenty-one days
- C. Copy an employee analyst role that includes viewing and bulk export
- D. Set password expiration to sixty days while leaving application permissions indefinite
- E. Configure an enforced contract-end expiration and access-revocation workflow

Answer: A|E

Provisioning must control both the capabilities granted and their duration. A narrowly defined view permission meets the functional requirement, while enforced expiration and revocation implement the contract boundary. Existing roles should be examined for extra capabilities rather than copied for convenience, and reminders should not be mistaken for automated enforcement.

Study tip: Provision the required capability and its required end condition together.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The scoped permission set provides the specific approved metadata access while excluding the two application capabilities explicitly prohibited for the contractor.

B: A reminder supports administration but does not enforce automatic expiration or ensure that the contractor's access actually ends at the required time.

C: The existing role may be convenient but includes a specifically prohibited capability, so it exceeds the contractor's approved permissions.

D: Password aging is neither the required twenty-one-day lifecycle limit nor a reliable revocation of already granted application access.

E: An automatic lifecycle action tied to the contract end satisfies the required access termination instead of relying solely on someone remembering a manual review.

## SEC2-Q219

A security playbook depends on an API field that its vendor will remove in the next version. No engineer owns the integration, and there are no tests using representative API responses. Which action BEST reduces the impending supportability risk?

- A. Retain the old field indefinitely without checking the vendor's supported compatibility period
- B. Assign integration ownership and validate an updated adapter against the announced API contract
- C. Increase the playbook's retry count while keeping the removed-field dependency
- D. Ask analysts to memorize the expected result without documenting the integration's behavior

Answer: B

Automation creates software dependencies that need maintenance. A published interface change is a predictable risk, so assign responsibility and verify the adapter against representative responses before migration. Retry handling and informal operator knowledge cannot replace compatibility work when the expected response contract itself is changing.

Study tip: Automated integrations need owners and contract validation as their dependencies evolve.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Depending on a field scheduled for removal leaves the announced failure unaddressed and assumes a compatibility guarantee the scenario does not provide.

B: An accountable owner and representative contract checks provide a controlled way to adapt the playbook before the known interface change breaks its behavior.

C: Retries do not restore a field absent from the new interface and can repeatedly execute the same incompatible parsing logic.

D: Undocumented personal knowledge does not provide reliable ownership or a repeatable check that the changed API is interpreted correctly.

## SEC2-Q220

An HR integration emits monotonic sequence numbers for each employee. Event 40 activates an account, and event 41 terminates it. The workflow applies event 41 first, then receives a delayed copy of event 40. What should secure processing do?

- A. Apply event 40 because its arrival time is later than event 41's arrival time
- B. Create a second active account to represent the delayed event separately
- C. Ignore the stale state change because sequence 41 is already the latest accepted employee event
- D. Discard sequence numbers and reconcile using only the employee's display name

Answer: C

Distributed delivery can reorder legitimate events. The HR system explicitly supplies a monotonic per-employee sequence, so the integration should compare it with the latest applied state. This differs from simply suppressing identical retries: a unique but older event can also be unsafe if it reverses a newer authoritative decision.

Study tip: Use authoritative event order rather than delivery order when applying identity state changes.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Transport arrival order is not the authoritative HR event order, and applying the delayed older activation would reverse the later termination.

B: An older update for the same employee does not justify a new identity and would preserve access that the later authoritative event ended.

C: Comparing the source's authoritative sequence prevents an older activation from overriding a later termination when delivery order differs from business-event order.

D: Display names do not express event order, so removing the supplied sequence information loses the basis for preventing a stale activation.

## SEC2-Q221

An asset-enrichment API returns 100 records with next_cursor set and total_count=640. A script processes that first response and reports a complete inventory. Which correction is necessary?

- A. Treat the first 100 records as a complete inventory because the HTTP request succeeded
- B. Report the first page as complete and use total_count only for a dashboard annotation
- C. Repeat the first request without using its cursor and append every response
- D. Follow the supported pagination cursor until the complete authorized result set is retrieved

Answer: D

Integration correctness includes result coverage, not just successful HTTP status. A cursor indicates continuation, and the total count confirms that the first page is incomplete. The script should follow the supported pagination process, handle errors, and verify completion before claiming a complete asset inventory or using it for dependent security decisions.

Study tip: A successful page is not necessarily a complete query result.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Request success confirms that one page was returned, not that all 640 records were enumerated; the response explicitly indicates additional pages.

B: Displaying the larger count does not retrieve the omitted records, so dependent decisions would still rely on incomplete inventory despite the annotation.

C: Repeating the same initial request can duplicate the first page instead of advancing through the remaining records in the result set.

D: The nonempty cursor and total count show that more pages exist, so complete enumeration requires the API's continuation mechanism rather than stopping after one page.

## SEC2-Q222

A scheduled security script contains a reusable API secret directly in its source repository. The deployment platform supports authenticated retrieval from a managed secrets service. Which change BEST reduces exposure of the secret through code copies?

- A. Include the secret in the repository's usage instructions instead of the executable file
- B. Encode the secret with Base64 before committing it to the repository
- C. Retrieve the secret at runtime through the approved secrets service instead of storing it in source
- D. Move the same secret into a second source file committed beside the script

Answer: C

A repository can be copied, forked, backed up, and read by more parties than the automation needs to trust with a credential. An authenticated secrets service separates that secret from code distribution and supports controlled retrieval. Previously committed credentials should also be assessed and rotated because removing a current file does not erase prior copies.

Study tip: Keep runtime credentials out of artifacts intended to be copied and reviewed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Documentation is copied with the repository too, so moving the credential into instructions preserves the same exposure to source recipients.

B: Reversible encoding changes representation but does not meaningfully protect the secret from someone who receives and can inspect the source.

C: Runtime retrieval separates the credential from repository copies and can use controlled access, rotation, and auditing through the supported secrets-management mechanism.

D: A different committed file remains part of repository copies, so this relocation does not remove the credential from the code distribution path.

## SEC2-Q223

A rule opens an incident for every event received from an event bus. Opening an incident publishes a case-created event back to that same bus, which opens another incident. Trusted event provenance is available. Which change MOST directly stops this feedback loop while retaining original security events?

- A. Exclude the automation's case-lifecycle events from the incident-creation trigger using verified provenance
- B. Deduplicate solely by hostname and keep only one incident for each host indefinitely
- C. Rotate the event-bus credential while preserving the same subscribed event set
- D. Slow the rule to one execution per minute without changing which events trigger it

Answer: A

Integrations can feed their own output back into their input path. The correct boundary is based on trusted event origin and type, so internal lifecycle messages do not initiate new cases. Rate limits can limit damage but do not fix recursion, and overly broad deduplication can suppress unrelated genuine events.

Study tip: Trace whether a workflow's output can satisfy its own trigger.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A provenance-aware trigger can distinguish workflow-generated lifecycle notifications from original security inputs, breaking the recursive creation path without dropping genuine initial events.

B: Host-only indefinite suppression may hide separate legitimate incidents and does not specifically distinguish the workflow-generated events responsible for the loop.

C: Credential rotation does not change the trigger relationship between case creation and new events, so it does not remove the recursive workflow behavior.

D: Rate limiting reduces speed but leaves each generated case-created event eligible to create another case, so the loop continues.

## SEC2-Q224

An approved workflow changes access on four independent systems. The policy requires the batch to finish with either all four changes applied or the original state restored. Three changes succeed, and the fourth permanently fails. The systems lack a shared transaction mechanism. Which design BEST meets the policy?

- A. Retry the permanently failing fourth operation indefinitely without evaluating rollback
- B. Record the original states and execute verified compensating actions for the successful changes
- C. Report the batch as failed but leave the three successful changes active
- D. Reapply the three successful changes and mark the fourth as optional

Answer: B

Separate systems often cannot participate in one atomic transaction. If the required outcome is all changes or restoration, the workflow needs known prechange state and compensating actions for completed steps. Rollback itself must be verified and failures escalated; declaring a batch unsuccessful does not automatically undo its partial effects.

Study tip: A failed workflow can leave successful side effects that require explicit, verified reversal.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Unbounded retry does not resolve a permanent failure and leaves the other systems in a partial changed state rather than restoring the required original state.

B: Compensating actions can restore previously changed systems when a cross-system batch cannot complete atomically, using captured state to avoid guessing the rollback target.

C: Failure reporting alone does not restore the required all-or-original state; it leaves the unauthorized partial outcome explicitly prohibited by the batch policy.

D: Reapplying successes does not complete the missing system, and redefining a required change as optional contradicts the approved batch condition.

## SEC2-Q225

A production response job usually proposes two or three endpoint actions. After a feed-format change, one run proposes 900 actions, and required evidence fields are missing. Policy forbids acting on malformed inputs and requires review of unusually large action sets. Which TWO guardrails meet these requirements? (Select TWO.)

- A. Substitute wildcard values for missing required evidence fields
- B. Stop for authorized review when the proposed action count exceeds the defined operational threshold
- C. Reduce execution speed but continue processing all 900 proposed actions
- D. Record the count anomaly only after the entire response batch finishes
- E. Validate required input fields and reject malformed feed records before generating actions

Answer: B|E

Runtime guardrails protect a deployed automation when its inputs or proposed effects depart from expected conditions. Required-field validation addresses malformed evidence, and a count threshold addresses abnormal scale even if individual records appear plausible. Both should produce an observable stop or review path instead of silently widening the scope.

Study tip: Validate input quality and bound action scope before automated changes take effect.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Inventing permissive defaults turns missing evidence into broader action scope and violates the requirement not to act on malformed input.

B: A bounded-action threshold prevents an anomalous batch from executing automatically and provides the required review before an unusually large response affects endpoints.

C: Slower execution does not satisfy either malformed-input rejection or the explicit requirement to review unusually large action sets before acting.

D: Postexecution reporting cannot provide the required pre-action review and leaves the proposed large response free to execute before its anomaly is assessed.

E: Schema and required-field validation enforce the condition that incomplete or malformed evidence must not become an actionable response instruction.

## SEC2-Q226

Unauthorized commands reach an industrial controller through a compromised engineering jump server. The controller must keep communicating with its normal control server for safe operation. The jump server is not needed for that normal control path, and the incident plan authorizes isolating it. Which containment action BEST fits?

- A. Block the entire controller subnet at its uplink rather than isolating the engineering source
- B. Isolate the compromised jump server while preserving the controller's required control-server connection
- C. Disconnect the controller's network interface before evaluating its operating state
- D. Restart the normal control server while leaving the compromised jump server connected

Answer: B

Containment should interrupt the attack path while respecting identified operational dependencies. The compromised jump server is both the demonstrated command path and an authorized isolation target. Removing it preserves the required control-server communication, whereas disconnecting the controller or its network would introduce a known safety concern.

Study tip: Choose containment around the demonstrated path and the system's required safe-operation dependencies.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: A subnet-wide block can interrupt the specified required control-server path, while the authorized targeted source isolation avoids that known operational dependency.

B: Targeting the demonstrated malicious entry path limits further commands without breaking the explicitly safety-dependent communication that the controller must retain.

C: That action breaks the required control-server connection and introduces the safety problem the scenario specifically says containment must avoid.

D: Restarting the legitimate dependency can disrupt safe operation while preserving the source of the unauthorized commands, so it does not target the supported attack path.

## SEC2-Q227

Legal counsel provides named custodians, date ranges, and search criteria for records relevant to a dispute. An authorized team locates, collects, and prepares responsive electronic records for review while preserving their context. Which activity is MOST directly described?

- A. Eradication of malicious persistence
- B. Electronic discovery
- C. A tabletop test of incident-response responsibilities
- D. Threat hunting for previously undetected attacker behavior

Answer: B

Electronic discovery concerns electronically stored information relevant to a legal process. The custodian, date, and search scope guide which records are responsive. Preservation and handling controls remain important, but the distinguishing purpose is preparing relevant electronic information for authorized review rather than testing systems or removing a compromise.

Study tip: Identify the purpose of collection: legal responsiveness differs from technical threat discovery.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Eradication removes attacker mechanisms from affected systems; locating and preparing responsive records for legal review does not perform that removal.

B: Electronic discovery involves identifying, collecting, and reviewing electronically stored information responsive to a legal matter, guided here by the supplied scope and custodians.

C: A tabletop is a discussion exercise, whereas the team here performs actual scoped collection and preparation of electronic records.

D: Threat hunting searches for adversary activity using investigative hypotheses, while this task identifies legally responsive records using counsel's defined discovery criteria.

## SEC2-Q228

An investigation verifies that API credential K17, approved only for reading reports, was committed to a public repository at 08:30. Audit records show K17 used from an unauthorized source at 09:04 to create a privileged account. Separate failed password attempts occurred at 09:00. Which control failure should root-cause remediation directly address?

- A. Focus on the created account alone without reviewing how K17 authorized its creation
- B. Focus remediation on blocking the observed source address while retaining the exposed credential
- C. A successful password brute-force login at 09:00
- D. Exposure and excessive privileges of the API credential distributed through the repository

Answer: D

Root-cause work should follow the supported access path instead of treating the earliest alarming event as the cause. The password attempts failed, while the exposed credential is directly linked to the privileged API action. Remediation should address its exposure, revocation, and scope, while the investigation evaluates whether other paths also existed.

Study tip: The first suspicious timestamp is not necessarily the successful entry mechanism.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Removing the resulting account can be necessary, but it leaves the credential exposure and permissions that enabled creation unaddressed as a causal control failure.

B: A source block may reduce one access route but leaves the publicly exposed credential usable from other sources, so it does not resolve the supported root cause.

C: The supplied password events failed, while the subsequent privileged operation is tied to K17, so successful password guessing is not established by the evidence.

D: The public credential and its logged privilege beyond the approved report-reading role identify a supported path requiring secret-handling and permission-scope remediation.

## SEC2-Q229

Responders remove a confirmed malicious scheduled task from one workstation. They have reliable task artifacts and related behavior from that compromise, but have not checked the rest of the fleet. What should they do before claiming the incident is limited to that workstation?

- A. Search relevant fleet and historical telemetry for the artifacts and related behavior, then validate matches
- B. Search only the currently active process list on the first workstation
- C. Treat the absence of matching alerts elsewhere as sufficient scope evidence without searching retained telemetry
- D. Close the enterprise incident when the local removal command reports success

Answer: A

The first affected host provides indicators and behavioral context for scoping the wider incident. Searching relevant systems and history can reveal additional affected assets or evidence that narrows the case. Matches should be validated, because an artifact name alone may not uniquely prove compromise. Local cleanup and enterprise scope are separate conclusions.

Study tip: Verify the extent of compromise separately from whether one cleanup action succeeded.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final|https://attack.mitre.org/tactics/enterprise/

A: A scoped search extends the evidence beyond the first detected host, while validation distinguishes related compromise from benign or unrelated matches.

B: That view excludes other devices and historical activity, so it cannot establish whether the incident extends beyond the initially detected endpoint.

C: Detection coverage may miss related activity, so an unexamined absence of alerts does not establish that other assets lack the known artifacts or behavior.

D: A successful action on one endpoint does not establish whether other hosts contain the same persistence or related attacker activity.

## SEC2-Q230

A powered-off drive must be acquired for forensic analysis. The examiner needs to prevent the acquisition computer from writing to the source medium during the process. Which setup MOST directly meets that requirement?

- A. Connect through a validated write-blocking acquisition path and create a forensic image
- B. Mount the original filesystem normally and copy selected files into a folder
- C. Run a filesystem repair utility on the original before taking the image
- D. Open the original drive in the examiner's normal desktop environment without acquisition controls

Answer: A

An offline source can still be changed by the computer used to examine it. A validated write-blocking acquisition path addresses that risk during imaging. The examiner should document the method, preserve the acquired evidence, and use working copies for subsequent analysis rather than treating an ordinary file copy as equivalent forensic handling.

Study tip: Protect the source from acquisition-system writes before connecting it for analysis.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: A write-blocking path prevents host writes to the source during acquisition, supporting preservation while the examiner obtains an image for controlled analysis.

B: A normal mount can write filesystem metadata, and selected-file copying does not provide the stated source-write protection during acquisition.

C: Repair deliberately changes the source filesystem, conflicting with the requirement to prevent acquisition-side writes before preserving the evidence.

D: Ordinary desktop handling may mount or update the drive automatically and does not establish the requested protection against writes to the source.

## SEC2-Q231

A discussion exercise confirmed that analysts know who should authorize endpoint isolation. The next objective is to verify that analysts can execute the actual approved tools and that isolation takes effect. Production disruption is prohibited. Which exercise BEST meets the next objective?

- A. Audit the response tool's installation and licensing without running a containment case
- B. Another discussion of the authorization chart without executing tools
- C. Perform only a failover of an unrelated redundant application service
- D. A controlled technical simulation using representative lab endpoints and the approved response tools

Answer: D

Different exercises validate different capabilities. The earlier discussion addressed authority, while the new objective requires observed execution and effect. A representative lab simulation can provide that evidence without affecting production, assuming its configuration reflects the response path being assessed. Merely repeating the tabletop would leave the technical capability untested.

Study tip: Choose an exercise that produces evidence for the specific capability still unverified.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Installed tools and valid licenses support readiness but do not provide the requested evidence that the workflow executes correctly and has its intended endpoint effect.

B: A discussion can retest coordination but does not supply the operational evidence required about command execution and actual isolation results.

C: A service-continuity test validates a different capability and does not demonstrate that analysts can execute and verify the endpoint isolation workflow.

D: A lab simulation can test execution and resulting endpoint state with the real workflow while respecting the prohibition on disrupting production.

## SEC2-Q232

An incident report can confirm creation of an unauthorized account, but the initial credential-theft mechanism remains uncertain because some earlier logs are unavailable. Which reporting approach BEST supports an informed decision?

- A. Report only that an incident occurred and omit the confirmed account-creation details
- B. Defer the interim report until the initial credential-theft mechanism is established
- C. Separate confirmed facts, supported hypotheses, and evidence gaps, with references to the available records
- D. Choose the most plausible theft theory and present it as confirmed to avoid an incomplete report

Answer: C

An incident report should accurately communicate both evidence and its limits. Confirmed account creation can be reported now, while the initial credential theft remains a hypothesis or unresolved question. Traceable facts and explicit gaps support proportionate decisions and further investigation without fabricating certainty or withholding all useful information.

Study tip: An accurate report can be incomplete if it clearly identifies what is known and unknown.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Discarding known facts deprives decision makers of useful evidence that can be reported accurately even while the initial mechanism remains unresolved.

B: Waiting for a complete entry explanation delays reporting confirmed unauthorized account creation, even though the evidence gap can be communicated accurately alongside known facts.

C: Clear separation communicates what the evidence establishes and what remains uncertain, allowing decisions without presenting an unverified access theory as a confirmed fact.

D: A plausible hypothesis does not become evidence merely to complete a narrative, and labeling it confirmed can misdirect response and follow-up decisions.

## SEC2-Q233

A revised playbook is intended to reduce the time between a confirmed alert and verified containment. Which measurement would MOST directly show whether that objective improved?

- A. Compare the number of API integrations listed in the response platform
- B. Compare the number of completed playbook steps without measuring when containment was verified
- C. Compare attendance and completion rates for training on the revised playbook
- D. Compare alert-to-verified-containment times across comparable exercises before and after the revision

Answer: D

A measurement should match the claimed improvement. The objective is elapsed time to verified containment, so compare that interval under sufficiently similar conditions before and after the revision. Document distribution, page count, and integration inventory may be useful supporting information, but they do not directly establish better operational response time.

Study tip: Measure the outcome the change was meant to improve, under comparable conditions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: More integrations can expand capability but do not by themselves demonstrate faster verified containment for the scenarios the playbook is intended to handle.

B: Step completion supports process review but does not directly measure the elapsed interval the revision is specifically intended to shorten.

C: Training participation can support readiness but does not demonstrate faster execution and verified containment in comparable operational scenarios.

D: The elapsed time directly measures the playbook's stated objective, while comparable scenarios reduce the chance that unrelated case differences explain the observed change.

## SEC2-Q234

An incident affects a SaaS tenant. The customer can export tenant audit records now, but the provider alone holds relevant backend logs under a short retention period. The response plan authorizes evidence-preservation requests through a designated provider channel. Which TWO actions BEST protect the available evidence? (Select TWO.)

- A. Wait for the final incident report before asking the provider to preserve backend evidence
- B. Promptly request preservation of the scoped backend logs through the authorized provider channel
- C. Export and preserve relevant tenant audit records with their original metadata
- D. Keep only a screenshot of the tenant's total event count instead of exporting records
- E. Rely on the provider's standard backups without verifying whether the relevant backend logs are included

Answer: B|C

Evidence availability depends on who controls each source and how long it persists. Preserve tenant records the customer can access and use the approved provider channel for backend records at risk of expiration. A scoped request and documented handling support coordinated collection; neither a dashboard summary nor assumptions about backups replace the actual records.

Study tip: Preserve what you control and promptly coordinate retention for evidence controlled by a provider.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Waiting can allow the provider's short retention period to expire, losing relevant records before the investigation and reporting process are complete.

B: The provider controls those records, so a timely scoped request through the established channel addresses the retention risk the customer cannot directly manage.

C: Customer-accessible records can be collected immediately, preserving available event context before ordinary retention or later tenant activity changes the evidence available.

D: An aggregate screenshot lacks the event detail and original metadata needed for investigation and is not an equivalent substitute for available audit exports.

E: Unspecified backups do not establish preservation of logs subject to short retention, so the response team still needs scoped retention verification and coordination.

## SEC2-Q235

An external service logs a connection at 14:04 from 203.0.113.7:51044. Valid NAT records covering that time show 192.0.2.44:62002 translated to 203.0.113.7:51044 and 192.0.2.88:51044 translated to 203.0.113.7:61310. Which internal source should the investigator associate with that external connection?

- A. 192.0.2.44
- B. Associate the event with both hosts using only the shared public IP and ignoring translated ports
- C. Associate the event with the NAT gateway as the original application client
- D. 192.0.2.88

Answer: A

Shared public addressing requires correlation beyond the IP alone. The external service sees the translated source port, so match that public tuple and time to the NAT record. Here it maps to 192.0.2.44, not the internal host whose untranslated port happens to have the same number. This identifies a network source, not automatically a human operator.

Study tip: Match the observed translated tuple and time, not a coincidentally matching original port.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Its recorded translated public address and port match the external observation at the relevant time, linking that connection to the correct internal source tuple.

B: Ignoring the available time-matched port mappings discards the evidence that distinguishes the two flows behind the same public address.

C: The gateway supplies translation, but the preserved mapping identifies a different internal originating endpoint for the observed public connection.

D: Although this host's original source port is 51044, its translated public port is 61310, which does not match the external service's observed tuple.

## SEC2-Q236

A security event records source 192.0.2.37 at 09:35. Reliable DHCP history assigns that address to laptop-alpha from 08:00 to 10:00, then to laptop-beta from 10:00 to 12:00. The current inventory shows laptop-beta. Which device should be examined as the lease holder at the event time?

- A. laptop-beta
- B. laptop-alpha
- C. Both devices as simultaneous lease holders during the event
- D. The DHCP server as the client that generated the security event

Answer: B

An address-to-device relationship can change during an investigation. The timestamp must be joined to the historical lease interval rather than to the latest inventory state. That points to laptop-alpha for this event and provides a starting point for corroborating endpoint evidence; it does not alone establish who operated the device.

Study tip: Use the address assignment at the event time, not the assignment visible now.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The current holder did not receive the address until 10:00, which is after the 09:35 event being investigated.

B: The event falls within laptop-alpha's recorded lease interval, making it the relevant historical holder rather than the device currently associated with the address.

C: The supplied intervals do not overlap at 09:35, so the history identifies one lease holder for that time rather than simultaneous assignments.

D: The server assigned the address but is not thereby the endpoint using it; lease records identify the relevant client for the event interval.

## SEC2-Q237

For one TCP flow, a packet capture at the client contains repeated SYN packets and no matching return packets during the capture interval. What does this evidence MOST directly establish?

- A. The server explicitly refused each connection with a reset
- B. Attribute the missing return packets to the perimeter firewall without obtaining evidence from that device
- C. The client attempted to establish a connection, but no matching return traffic was observed at that capture point
- D. The client and server completed TCP setup before an application authentication failure

Answer: C

The capture supports a limited but useful conclusion about what the client attempted and received. Repeated SYNs without observed responses do not prove server refusal or a particular firewall action. Additional captures, routing evidence, or device logs are needed to locate the failure along the path.

Study tip: A capture establishes what was visible at its observation point, not every event along the path.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: An explicit refusal would require an observed reset or other supporting evidence, but the capture contains no matching RST packets.

B: Several network or server conditions can produce absent responses, so a client-side capture alone does not establish that particular firewall as the cause.

C: The repeated SYN attempts and absent return packets describe an incomplete observed handshake, without identifying where a packet or response was lost.

D: The available packets do not show a completed handshake, so a later application authentication failure is not established by this capture.

## SEC2-Q238

A gateway logs request_id=r71, user=mina, status=200. In the same second, application logs show request_id=r72, document=941, decision=deny and request_id=r71, document=319, decision=allow. Request IDs are unique and propagated correctly. Which document decision belongs to Mina's gateway request?

- A. Both document decisions belong to Mina because their timestamps share one second
- B. Document 319 was allowed
- C. Document 941 was denied
- D. Neither application record can be correlated because their message formats differ from the gateway

Answer: B

A propagated request identifier can link events across system layers more precisely than a coarse timestamp. Mina's r71 event joins to document 319's allowed decision. The r72 denial is a different request even though it occurred in the same second. Correlation quality depends on the identifier properties explicitly supplied by the scenario.

Study tip: Prefer a valid shared request identifier over timestamp proximity when joining concurrent events.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Concurrent requests can share timestamps, and the unique request identifiers explicitly distinguish the two application events in this evidence.

B: The shared unique request ID r71 connects Mina's gateway event to the application decision for document 319 despite another request occurring in the same second.

C: That decision belongs to request r72, not Mina's r71 event, so matching solely on the timestamp would join unrelated request records.

D: Identical log formatting is unnecessary when both sources preserve a valid shared correlation identifier with known unique-request semantics.

## SEC2-Q239

An SSH log records 'Failed password for deploy from 203.0.113.22' followed by 'Accepted publickey for deploy from 203.0.113.22'. What conclusion is BEST supported?

- A. The deploy account's password was successfully guessed
- B. All authentication attempts from that address failed
- C. The successful session necessarily ran commands with root privileges
- D. A public-key authentication succeeded, so failed-password totals alone would omit the successful access

Answer: D

Authentication records distinguish methods and outcomes. A failed password attempt can be followed by a legitimate or unauthorized successful key-based login, so failed-password counts alone are incomplete evidence. Investigators should examine the accepted key, account authorization, and subsequent actions before attributing compromise or asserting elevated execution.

Study tip: Read the accepted authentication method, not only the failures that preceded it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The successful event specifies public-key authentication, so the evidence does not establish that the password was guessed or used successfully.

B: The accepted-publickey event directly contradicts a conclusion that every attempt failed and must be included in the investigation's account of access.

C: Successful authentication as deploy does not itself establish later privilege elevation or command execution; additional session and endpoint evidence would be required.

D: The accepted-publickey event records a successful authentication through a different method even though the preceding password attempt failed.

## SEC2-Q240

A cloud audit event attributes a sensitive policy change to role DeployRole, session s-884. Several human and automation identities can obtain sessions for that role. Which additional evidence BEST identifies the origin of this particular session?

- A. The total number of policy-change events recorded in the cloud account that day
- B. The role's display name and creation date alone
- C. The current list of permissions granted to DeployRole
- D. The corresponding role-session issuance records linked to session s-884

Answer: D

An assumed-role identity can be shared by many independently issued sessions. The specific session identifier is therefore essential for linking a control-plane action to its origin. Correlating issuance records supports attribution to the initiating identity or workload, while role permissions and aggregate counts describe different aspects of the environment.

Study tip: Trace the specific credential session, not just the reusable role name.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An aggregate event count does not connect session s-884 to its origin and cannot resolve who or what obtained the credentials for this action.

B: Static role metadata does not distinguish the multiple human and automation principals that can assume the shared role over time.

C: Role permissions show what a session may do, but they do not identify which permitted caller obtained the particular session involved in the change.

D: Session issuance evidence can connect the specific assumed-role session to the originating identity or workload, unlike a shared role name alone.

## SEC2-Q241

An acceptable use policy permits limited personal web browsing but requires customer information to remain in approved business services. An employee wants to paste customer notes into a personal web application because personal browsing is allowed. Which interpretation is correct?

- A. Personal browsing permission does not authorize moving customer information into the personal application
- B. The application is permitted if the employee retains a copy in the approved system
- C. The personal application is permitted if the employee uses it during a break
- D. The personal application is permitted if its connection uses HTTPS

Answer: A

Policy provisions must be read together. The employee may browse for personal purposes, but customer notes remain business information subject to the approved-service restriction. Timing, transport encryption, and retaining another copy do not satisfy that separate requirement. The appropriate business application must meet the information-handling rule.

Study tip: Permission for one activity does not override a separate restriction on the data.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The two provisions govern different activities. Permission for personal browsing does not override the separate requirement governing where business information may be processed.

B: Keeping an approved copy does not authorize an additional copy elsewhere. The destination restriction applies to moving or processing the information.

C: Break time may affect permitted personal browsing, but it does not change the information-handling requirement for customer notes stored in an unapproved service.

D: HTTPS protects transport to a service. It does not make that service approved for processing customer information under the stated policy.

## SEC2-Q242

An approved laptop standard requires disk encryption before issue. An older setup procedure calls encryption optional, and technicians have followed that step. The standard is current and no exceptions exist. Which response BEST repairs the governance problem?

- A. Add a technician reminder to check encryption while leaving the older procedure as the formal setup instruction
- B. Treat the older procedure as an exception because technicians have used it routinely
- C. Align the procedure with the current standard and verify affected laptop compliance
- D. Revise the encryption standard to match the established setup procedure, using consistent technician practice as the justification

Answer: C

A procedure tells technicians how to implement a requirement; it cannot silently waive a current standard. The organization should correct the procedure through document control, communicate the change, and assess laptops configured under the inaccurate instructions. This closes the implementation gap rather than simply making the paperwork look current.

Study tip: Correct both the conflicting instruction and the systems affected by it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A reminder may help some staff, but the formal instructions would still conflict with the mandatory standard and continue generating inconsistent implementation.

B: Routine use does not establish an authorized exception. The scenario expressly states that no exceptions exist to the current encryption requirement.

C: The implementation instructions conflict with the authoritative requirement. Updating them and checking affected systems addresses both the documentary error and its operational consequences.

D: Consistent practice can reveal implementation problems, but it does not establish that the approved protection requirement should be weakened to match an outdated procedure.

## SEC2-Q243

Employees find two policy PDFs with different requirements. Both carry an executive signature, but one was superseded last month. Which publication practice MOST directly helps employees follow the effective version?

- A. Leave both copies equally prominent and ask employees to choose the stricter paragraph
- B. Maintain an authoritative current-policy location with effective dates and clearly retired versions
- C. Assume both versions remain effective because each contains an executive signature
- D. Keep both PDFs in the current-policy folder and resolve version questions through informal guidance from team leads

Answer: B

Policies need controlled publication as well as approval. An authoritative location, effective dates, and unambiguous retirement labels help people identify the requirements in force. Historical versions can remain available for records purposes without appearing to be competing instructions for current work.

Study tip: Approved once and currently effective are different document states.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Combining selected paragraphs from different versions can create an unintended policy. Employees need the effective approved document rather than an improvised collection of requirements.

B: A controlled publication location identifies the effective requirements and distinguishes archived history from current instructions. Employees can verify which approved version applies.

C: A signature establishes approval of a version, not that it remains effective indefinitely. Supersession and effective dates determine which document currently applies.

D: Informal guidance does not reliably identify the effective approved requirements. Leaving competing versions labeled as current preserves the publication problem.

## SEC2-Q244

A board receives monthly counts of scanner findings but cannot decide whether funding should go to payment-system resilience or developer training. Which reporting change would BEST support that decision?

- A. Break finding counts down by scanning tool, plugin identifier, affected system, and ticket status
- B. Compare security-team task completion rates with last quarter and fund the program with the most overdue work
- C. Rank investments by their departments' average vulnerability score and direct funding to the highest-scoring group
- D. Connect material risk scenarios to business impact, remaining exposure, and proposed treatment options

Answer: D

Governance reporting should help decision makers compare choices in business terms. Finding counts can contribute context, but they do not express the consequences of interruption, data misuse, or control gaps. Summarizing relevant scenarios, remaining risk, treatment costs, and expected effects connects the evidence to the board's funding responsibility.

Study tip: Report the risk decision a metric informs, not just the metric's volume.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: More technical detail can improve operational tracking, but it does not establish the business impact or treatment tradeoffs needed for this funding decision.

B: Task completion and overdue work measure activity. They do not directly show which proposed investment best reduces business consequences or remaining exposure.

C: Technical scores help prioritize vulnerabilities, but department averages do not establish how resilience or training investments affect the organization's material business risks.

D: The board needs the consequences and tradeoffs associated with funding choices. Linking risks to business objectives makes the report useful for governance decisions.

## SEC2-Q245

A company needs a common minimum level of security across branches, while some regions require additional controls. Regional teams must retain flexibility in implementation. Which governance design BEST meets both needs?

- A. Use identical procedures and tools at each branch, treating central implementation consistency as the primary design requirement
- B. Publish the enterprise baseline as advisory guidance and let regional managers decide which portions fit local priorities
- C. Let each branch adopt its preferred baseline and consolidate the chosen requirements in an annual enterprise report
- D. Set an enterprise minimum and permit approved regional additions that meet or exceed it

Answer: D

A centralized minimum can coexist with delegated implementation. The enterprise defines outcomes that every branch must meet, while regions add justified requirements and choose suitable methods within their authority. Documented variations and escalation paths make the arrangement manageable without making every operational action a board decision.

Study tip: Common minimum outcomes can coexist with controlled local implementation choices.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: This can produce uniform implementation, but it does not preserve the requested regional flexibility or ensure that additional regional needs are appropriately addressed.

B: Advisory guidance does not establish the required common minimum. Regional flexibility should operate within mandatory enterprise outcomes rather than replace them.

C: Reporting local choices provides visibility after selection, but it does not ensure that every branch meets a common minimum protection requirement.

D: A common floor preserves enterprise expectations while allowing stricter local requirements and suitable implementation choices. Defined approval paths make variations accountable.

## SEC2-Q246

Finance and support issue conflicting access requirements for a shared customer dataset. Both claim ownership, and the storage team can implement either request. What should be resolved FIRST to prevent arbitrary permission decisions?

- A. Use the account listed as the filesystem owner to determine which department controls business access decisions
- B. Use the combined permission requests as the permanent access baseline so both departments' stated needs are represented
- C. Treat the storage team's platform administration responsibility as authority to choose between the business access requirements
- D. Establish accountable business decision rights and an approved conflict-escalation path for the dataset

Answer: D

The storage team is facing a governance conflict rather than a difficult access-control command. The organization must define who is accountable for shared-data decisions and how competing requirements are resolved. Custodians can then implement approved requirements without inventing business authority or broadening access merely to satisfy both requesters.

Study tip: Resolve who may decide before asking administrators to enforce conflicting decisions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A technical ownership field identifies platform permissions, not necessarily the accountable business owner. It cannot resolve competing organizational claims by itself.

B: Combining requests may broaden access beyond a justified purpose. It bypasses the unresolved question of authority instead of establishing a defensible access decision.

C: Operating the storage platform does not establish business decision rights over the shared dataset. This would conflate custodial responsibilities with accountable ownership.

D: The conflict concerns authority over business access requirements. Clarifying accountable ownership and escalation gives custodians a defensible basis for implementing permissions.

## SEC2-Q247

New applications repeatedly reach final testing before anyone decides what personal information they may collect. Late reviews require major redesigns. Which policy change would MOST directly move the decision to the appropriate point in the lifecycle?

- A. Require documented data-purpose and security review during planning before architecture is finalized
- B. Let developers record assumed purposes in design notes and have the relevant owners review them at final acceptance
- C. Audit completed release packages each quarter and use that review as the initial approval of data collection purposes
- D. Add data-use questions to the existing prerelease penetration test while keeping planning and architecture approvals unchanged

Answer: A

Secure development governance makes protection requirements part of planning and design. The organization should involve the relevant business, privacy, and security owners before architecture locks in unnecessary collection or unsuitable controls. Later testing remains useful, but it cannot replace decisions that determine what should be built.

Study tip: Requirements that shape architecture should be reviewed before architecture becomes expensive to change.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Early review establishes acceptable processing and protection requirements while design choices remain flexible. It reduces the likelihood that fundamental issues first emerge at release.

B: Recording assumptions is useful, but postponing owner review until final acceptance preserves the problem. Approved requirements should shape design before major choices are fixed.

C: A retrospective audit can identify gaps, but it does not put purpose decisions into planning. Fundamental approval would still follow design and release.

D: This might identify issues before deployment, but it retains the late decision point that is causing major redesigns after architecture is finalized.

## SEC2-Q248

A newly formed security committee issues recommendations, but departments disagree about whether those recommendations are binding or who must implement them. Which governance artifact would MOST directly clarify the committee's operating authority?

- A. Meeting minutes recording recommendations, attendees, and unresolved discussion points from each committee session
- B. An action-tracking queue that assigns the committee's recommendations to departmental service-desk teams
- C. An approved charter defining its mandate, decision rights, responsibilities, and escalation route
- D. A technical control standard listing the security settings the committee considers appropriate for production systems

Answer: C

A committee needs more than attendees and recurring meetings. Its approved charter should establish what it governs, what it can decide, who is accountable for actions, and when issues must be escalated. This helps departments distinguish recommendations from authorized decisions and prevents responsibility from disappearing between meetings.

Study tip: A committee's charter defines authority; a calendar only defines when it meets.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Minutes provide a record of committee activity. They do not, by themselves, establish the approved authority behind recommendations or who must implement them.

B: A queue can track work, but assigning tickets does not resolve whether the committee has authority to require the work or direct those teams.

C: A charter establishes the committee's purpose and authority. Defined responsibilities and escalation clarify which decisions it can make and how implementation is assigned.

D: Technical requirements describe expected configurations, but the committee's authority to issue binding decisions and assign responsibilities still needs an approved mandate.

## SEC2-Q249

An organization's charter assigns data stewards responsibility for maintaining business definitions and resolving quality inconsistencies under data-owner direction. Two departments use incompatible meanings of 'active customer.' Which task BEST fits that stewardship responsibility?

- A. Approve the departments' database access entitlements while leaving the meanings of the shared term unchanged
- B. Perform an independent audit of the storage infrastructure's security controls and document the resulting assurance conclusion
- C. Tune database indexes so each department's existing definition can be processed more efficiently
- D. Coordinate a common approved definition and document its consistent use in both datasets

Answer: D

The charter makes the responsibility explicit: stewards maintain consistent business meaning and data quality under owner direction. Agreeing on and documenting what 'active customer' means addresses the discrepancy. This is separate from deciding classification, granting access, or administering the database that holds the records.

Study tip: Use the organization's stated role responsibilities when stewardship titles vary.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Access approval concerns authorization to use data. It does not resolve the conflicting definition, and the charter does not assign that approval authority to stewards.

B: Independent control assessment is a different responsibility. The stated stewardship task concerns agreed business meaning and data quality under owner direction.

C: Database tuning is a technical operating task. It does not reconcile the inconsistent business definitions that the stated stewardship responsibility covers.

D: The stated steward role covers business definitions and data quality. Resolving inconsistent terminology supports reliable use without independently changing ownership or access authority.

## SEC2-Q250

A customer agreement introduces an additional access-review requirement for one service. The requirement appears in the contract register but has no linked policy, control owner, or operating process. What is the BEST governance improvement?

- A. Announce the contract requirement to service users and close implementation after they acknowledge reading the announcement
- B. Track signatures, renewal dates, and clause versions in procurement's register and use its signoff as implementation evidence
- C. Map the requirement to applicable governance documents, an accountable control owner, and operating evidence
- D. Add the requirement to the next audit agenda and defer assigning operating responsibility until the audit produces findings

Answer: C

External obligations need to be translated into organizational requirements and operating controls. A traceable mapping identifies the affected service, responsible owner, supporting policy or procedure, and evidence of performance. Storing the contract alone does not establish that the organization can meet or demonstrate the commitment.

Study tip: A recorded obligation becomes operational through scope, ownership, controls, and evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Acknowledgment confirms communication, but it does not establish a functioning review process or assign responsibility for the additional service requirement.

B: Those records demonstrate contract administration. They do not establish that an accountable owner has implemented the access-review activity required for the service.

C: Traceability connects an external commitment to implementation and verification. Assigning ownership and an evidence-producing process helps prevent a recorded requirement from remaining unenforced.

D: Audit planning provides future oversight, but it leaves the current commitment without an operating owner. Implementation should not depend on first receiving an audit finding.

## SEC2-Q251

A new policy restricts customer-data exports to approved purposes. All staff acknowledged it, but a review finds exports whose business justification cannot be established. Which TWO governance actions BEST address the implementation gap? (Select TWO.)

- A. Assign owners to translate each relevant policy requirement into enforceable or verifiable controls
- B. Use quarterly training completion rates as the principal evidence that the export-purpose control is operating effectively
- C. Approve users' export permissions annually and treat that account-level approval as evidence of each export's business purpose
- D. Review sampled export workflows and feed verified implementation gaps into corrective action and policy review
- E. Repeat the policy rollout with additional acknowledgment reminders as the main corrective action for the unsupported exports

Answer: A|D

Acknowledgement is one part of policy rollout, but effective governance also requires implementation and feedback. Accountable control owners should connect the export-purpose rule to practical approval, access, or review mechanisms. Sampling actual workflows can then reveal gaps and support corrective action without assuming that reading a policy proves compliance.

Study tip: Verify policy operation through behavior and evidence, beyond acknowledgement counts.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Policy implementation needs accountable mechanisms that make the required behavior operational. Owners can connect purpose approval, access, monitoring, and evidence to the requirement.

B: Training completion is a program measure. It does not show whether actual exports were for approved purposes or whether the required evidence exists.

C: Permission to use an export function does not establish the purpose of a particular export. The gap requires transaction-relevant justification or equivalent evidence.

D: Examining actual workflows tests whether the policy operates in practice. Documented findings can drive corrections and reveal requirements that need clarification.

E: The staff already acknowledged the policy. Repeating communication may reinforce awareness, but it does not establish approval mechanisms or evidence for particular exports.

## SEC2-Q252

A risk assessment estimates the exposure of a document service first without considering its safeguards, then with its implemented access restrictions and tested recovery controls. Which mapping correctly describes the two estimates?

- A. Both estimates are risk appetite because they describe potential organizational losses
- B. The estimate without safeguards is inherent risk; the estimate with controls is residual risk
- C. Both estimates are risk transfer because the recovery controls may involve a supplier
- D. The estimate without safeguards is residual risk; the estimate with controls is inherent risk

Answer: B

The distinction depends on which controls the estimate includes. The first estimate describes the scenario before those safeguards are considered. The second models the remaining exposure with their effects included. Residual risk can still be significant, and estimating it does not by itself mean an authorized owner has accepted it.

Study tip: Check which controls are included in a risk estimate before naming it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Risk appetite expresses organizational willingness to accept risk. Estimating exposure under different control conditions does not itself state that willingness.

B: Inherent risk describes exposure before the considered controls. Residual risk is the exposure remaining after those controls are taken into account.

C: The estimates describe exposure before and after safeguards. Supplier involvement alone does not establish a contractual transfer of specified consequences.

D: This reverses the relationship. Residual risk specifically concerns what remains after accounting for the controls relevant to the scenario.

## SEC2-Q253

A service has an asset value of $500,000 and a modeled exposure factor of 20% per incident. Management sets a maximum ALE of $25,000 per year. Assuming the exposure factor stays constant, what is the HIGHEST ARO that meets the limit?

- A. 0.05 incidents per year
- B. 0.25 incidents per year
- C. 4 incidents per year
- D. 1 incident per year

Answer: B

First determine the loss per incident: $500,000 × 0.20 = $100,000. Since ALE = SLE × ARO, the highest acceptable frequency is $25,000 ÷ $100,000 = 0.25 incidents per year. This is a limit within the supplied model, not a guarantee that actual annual losses remain below it.

Study tip: To solve an ARO limit, divide the acceptable annual loss by SLE.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: This divides the annual limit by total asset value without applying exposure factor. It is more restrictive than the highest rate allowed by this model.

B: SLE is $500,000 times 0.20, or $100,000. Dividing the $25,000 annual limit by that loss gives 0.25 incidents per year.

C: This reverses the division by comparing single-incident loss with the annual limit. Four incidents would produce expected annual loss far above the limit.

D: One modeled incident annually would yield $100,000 in ALE. That exceeds management's stated maximum of $25,000 per year.

## SEC2-Q254

For this exercise, an insurance policy pays the covered incident loss minus a $20,000 deductible, capped at a $100,000 insurer payment per incident. A fully covered incident causes $180,000 in loss. Ignore premiums and other exclusions. How much of this incident loss does the organization retain?

- A. $100,000
- B. $60,000
- C. $80,000
- D. $20,000

Answer: C

The policy's deductible and payment cap both matter. The otherwise payable amount is $180,000 − $20,000 = $160,000, so the cap limits reimbursement to $100,000. The retained incident loss is $80,000. Transferring some financial exposure does not mean only the deductible can remain with the insured organization.

Study tip: Calculate the insurer's payment under every stated limit, then subtract it from the loss.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: This is the insurer's maximum payment under the given terms. The question asks for the loss remaining with the organization after that payment.

B: This is the amount above the cap after subtracting the deductible. Retained loss also includes the deductible, producing a larger total.

C: Subtracting the deductible leaves $160,000, but the insurer payment is capped at $100,000. The organization therefore retains $180,000 minus $100,000.

D: This accounts only for the deductible and ignores the payment cap. The organization also retains covered loss that exceeds the maximum insurer payment.

## SEC2-Q255

Two proposed controls have similar expected financial benefit, but one estimate depends heavily on an uncertain incident-frequency assumption. The investment committee wants to know whether the preferred option would change under plausible values of that assumption. Which analysis BEST answers the question?

- A. Replace the uncertain frequency with the industry median and compare the controls using that single revised value
- B. Compare both controls at the most adverse frequency value and select the one with the smaller loss at that point
- C. Vary the uncertain input across justified ranges and compare the resulting decisions
- D. Compare both investments at their existing point estimates and select the option with the slightly higher expected return

Answer: C

A model can produce a precise-looking answer from uncertain assumptions. Sensitivity analysis tests how much the choice depends on those inputs by varying them within justified bounds. If the preferred option changes easily, the committee may need better evidence or a decision that explicitly accounts for the uncertainty.

Study tip: Test whether plausible input changes alter the decision, not merely the reported number.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: An industry median may inform an assumption if relevant, but a single replacement value does not examine how the decision changes across plausible frequencies.

B: A worst-case comparison examines one scenario. The committee asks whether the preferred option changes across plausible values, which requires broader sensitivity analysis.

C: Sensitivity analysis shows how an uncertain assumption affects the modeled outcomes and preferred choice. Justified ranges make the decision's dependence on that input visible.

D: A point-estimate comparison can provide a baseline, but it does not show whether plausible changes in the uncertain frequency would reverse the preferred choice.

## SEC2-Q256

Two business-unit risk estimates describe the same cloud outage. Each includes the same $50,000 customer-refund pool in its loss total. An executive dashboard plans to add the two totals as if they were separate losses. What should the risk analyst do FIRST?

- A. Add the totals because separate business-unit owners make the financial losses independent
- B. Average the two totals without examining their included cost categories
- C. Remove the entire smaller risk entry without examining its unique losses
- D. Reconcile the shared scenario and overlapping loss categories before aggregating the estimates

Answer: D

Aggregation requires understanding what each estimate represents. The same incident and refund pool appear in both entries, so a simple sum double-counts that cost. The analyst should identify shared causes and overlapping consequences, then combine distinct losses consistently rather than assuming independent events or discarding an entire business-unit perspective.

Study tip: Different risk entries can describe the same event or the same financial consequence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Separate ownership does not make a shared loss independent or additional. The same refund pool cannot be counted twice merely because two units report it.

B: Averaging may also misrepresent the consequences. The analyst must identify shared and distinct costs before deciding how to combine the estimates.

C: The smaller entry may contain legitimate consequences absent from the other estimate. Deleting it wholesale can omit real loss while failing to document the overlap.

D: The same refund pool is represented twice. A consistent scenario and loss breakdown are needed to avoid overstating aggregate consequences and misrepresenting shared exposure.

## SEC2-Q257

A business impact analysis sets a two-hour restoration target for order entry. Order entry cannot operate until the identity service is restored, but that service currently has a six-hour recovery target. What is the BEST conclusion?

- A. Preserve both targets because each technical team can be assessed independently against its own component recovery commitment
- B. Adopt the identity service's six-hour target as the order-entry commitment before revisiting the business impact analysis
- C. The dependency recovery targets must be reconciled with the order-entry business requirement
- D. The order-entry target is satisfied if its application server starts within two hours

Answer: C

Recovery targets must describe usable business functions and their dependencies. If order entry needs identity before it can serve users, a six-hour identity target cannot reliably support a two-hour order-entry target. Business and technical owners should reconcile the requirements and sequence restoration and validation accordingly.

Study tip: A service RTO depends on its critical prerequisites being available in time.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Independent component reporting can hide a business-service dependency. Meeting isolated targets would not make order entry usable within its required two-hour period.

B: A technical dependency cannot silently redefine the business requirement. The conflict needs review with the relevant owners rather than automatic relaxation of the service target.

C: An unavailable prerequisite prevents order entry from operating. Recovery planning must account for dependency restoration and the time needed to restore and validate the business service.

D: A running server is not a usable order-entry service when required authentication remains unavailable. The business requirement concerns operational service, not a component boot.

## SEC2-Q258

A risk indicator triggers escalation when more than 8% of production devices use unsupported software. Last month, 20 of 400 devices were unsupported. After consolidation, 20 of 200 remain unsupported. What should the analyst do?

- A. Compare the 20 unsupported devices against 8% of the earlier 400-device inventory when checking the escalation condition
- B. Rebaseline the indicator at consolidation and apply the escalation threshold only to subsequent increases from the new state
- C. Escalate because the unsupported proportion increased from 5% to 10% and now exceeds the threshold
- D. Avoid escalation because the number of unsupported devices did not increase

Answer: C

Risk indicators need their measurement definitions and populations preserved. The original proportion was 20 ÷ 400 = 5%; the new proportion is 20 ÷ 200 = 10%. Although the absolute unsupported count did not grow, the stated threshold has been crossed and calls for escalation.

Study tip: When a metric is a percentage, check the denominator as well as the count.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: The trigger applies to the current production population. Reusing the earlier denominator understates the present unsupported proportion after consolidation.

B: The established trigger concerns the current unsupported percentage. Resetting its meaning after consolidation would bypass the threshold already crossed by the new proportion.

C: The numerator is unchanged but the population halved. Twenty divided by 200 is 10%, which crosses the expressly defined percentage threshold.

D: The trigger is a proportion of production devices, not an absolute count. An unchanged numerator can still cross the threshold when its denominator changes.

## SEC2-Q259

One risk model predicts a $1,000,000 loss at an ARO of 0.02 incidents per year. Another predicts a $20,000 loss at an ARO of 1 incident per year. Both have an ALE of $20,000. Which conclusion is MOST accurate?

- A. Equal ALE does not make the risks interchangeable because individual loss size and frequency differ
- B. Give the second risk higher financial importance based on its larger occurrence rate without considering the smaller incident loss
- C. Give the first risk lower treatment priority based on its smaller occurrence rate without considering the larger incident loss
- D. Treat the two risks as financially interchangeable because the expected annual loss is identical in both models

Answer: A

ALE is useful for comparing expected losses, but it compresses frequency and impact into one value. A rare event costing $1,000,000 can challenge the organization differently from smaller recurring losses. Risk appetite, financial capacity, service consequences, and uncertainty still matter when choosing treatment.

Study tip: The same expected annual loss can conceal very different single-event consequences.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: The same annual expected value can result from very different loss profiles. Organizational capacity and tolerance for a severe single event can affect treatment.

B: Higher frequency alone does not establish greater financial exposure. Impact and frequency must be considered together, with the organization's relevant risk constraints.

C: Lower frequency alone does not establish lower priority. The rare event's much larger consequence may exceed organizational capacity or tolerance.

D: Equal expected annual loss does not capture the ability to withstand an individual event. Different loss profiles can justify different treatment decisions.

## SEC2-Q260

A temporary remote-access arrangement is unexpectedly introduced during a facility relocation. The normal quarterly assessment is not due yet, and management requests an unscheduled review focused on this new arrangement. Which assessment type BEST describes that review?

- A. Ad hoc risk assessment
- B. Risk acceptance
- C. Continuous automated assessment
- D. Recurring scheduled assessment

Answer: A

The review is ad hoc because a particular unplanned change prompts it outside the regular assessment calendar. Such a review can be proportionate to the new arrangement and inform temporary safeguards or approval. It complements scheduled assessments without automatically becoming an acceptance decision.

Study tip: An unscheduled assessment for a specific new concern is ad hoc.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: An ad hoc assessment is initiated for a particular need outside the routine schedule. The unexpected temporary arrangement creates that focused review need.

B: Risk acceptance is a treatment decision to retain exposure. Requesting an assessment gathers information and does not itself approve the new arrangement's risk.

C: Continuous assessment uses ongoing evidence and monitoring to keep risk evaluation current. The scenario describes a discrete, specially initiated review rather than continuous assessment.

D: A recurring assessment follows an established cadence. This review is specifically initiated between scheduled assessments because of an unexpected operational change.

## SEC2-Q261

A public-service organization ranks its souvenir shop above its emergency-notification system because the shop earns direct revenue and the notification system does not. Which improvement is MOST important for the business impact analysis?

- A. Use normal daily utilization as the primary recovery ranking so the most frequently used systems are restored first
- B. Include mission, safety, service obligations, and dependency impacts alongside direct financial loss
- C. Use server acquisition cost as the primary recovery ranking so the largest capital investments are restored first
- D. Use the most recent vulnerability-severity ratings as the primary ranking when assigning business recovery priorities

Answer: B

A business impact analysis examines consequences to the organization's mission, obligations, people, and operations as well as financial loss. The absence of sales revenue does not make an emergency-notification system unimportant. Recovery priorities should reflect what interruption would prevent or harm, including dependent functions.

Study tip: Business criticality comes from consequences of loss, not only revenue or asset price.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Typical usage frequency does not establish the consequence of unavailability. A rarely used emergency service may be critical when an exceptional event occurs.

B: Business impact is broader than revenue. The notification service's mission and consequences of unavailability can make it critical even without generating direct income.

C: Acquisition cost does not capture the consequences of service interruption. A relatively inexpensive system can support an essential mission or safety function.

D: Vulnerability severity helps assess technical weaknesses, but recovery priorities require the consequences of unavailable business functions, including mission, safety, and dependencies.

## SEC2-Q262

A branch stocks replacement equipment so technicians can restore a failed device in minutes instead of waiting hours for delivery. Assume the change does not affect how often devices fail. Which metric should improve MOST directly?

- A. Mean time between failures should increase
- B. The recovery point objective should decrease
- C. The annualized device-failure occurrence rate should decrease
- D. Mean time to repair should decrease

Answer: D

The improvement affects the period after a failure: technicians can restore operation more quickly. That directly lowers repair time. It does not establish a change in device reliability or business data-loss tolerance. Distinguishing failure frequency from restoration duration helps evaluate what an operational investment actually improves.

Study tip: Fewer failures affects MTBF; faster restoration affects MTTR.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: MTBF concerns operating time between failures. Faster access to replacement equipment shortens restoration but does not change the stated frequency of failures.

B: RPO describes acceptable data-loss age. Faster replacement changes restoration capability, but it does not directly change the business's permitted loss of recent data.

C: Replacement stock affects the response after a device fails. Under the stated assumption, it does not reduce the frequency of those failures.

D: Ready replacement equipment reduces the duration needed to restore a failed device. The scenario explicitly leaves failure frequency unchanged.

## SEC2-Q263

A company adds isolated, tested backups. Its risk model assumes ransomware incidents will occur at the same frequency, but each incident will require less reconstruction of lost data. Which model input should MOST directly reflect that benefit?

- A. Reduce the asset value by the purchase cost of the new backup infrastructure
- B. Lower the modeled per-incident loss or exposure factor
- C. Reduce the modeled occurrence rate to represent the shorter recovery period after a ransomware incident
- D. Subtract the annual backup operating budget directly from the current annualized loss expectancy

Answer: B

Controls can reduce likelihood, impact, or both, but the modeled effect must match the scenario. Here, incident frequency remains unchanged and recovery reduces the loss from each incident. Adjusting per-incident loss or exposure factor captures that benefit without incorrectly claiming fewer attacks or no residual risk.

Study tip: Model the mechanism a control changes: event likelihood, event consequence, or both.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Control purchase costs belong in the investment evaluation. They do not directly reduce the business value of the asset exposed to ransomware.

B: The control reduces the consequences of an incident under the stated assumption. Lower loss per occurrence represents that impact reduction.

C: Recovery duration affects the consequences after an incident. The scenario explicitly keeps incident frequency unchanged, so a lower ARO would represent the wrong effect.

D: Spending on a control is not itself a reduction in incident loss. The model needs the control's effect on loss, separately from its operating cost.

## SEC2-Q264

A new Internet-facing service has operated for 30 days without a recorded incident. Available comparison data includes longer histories from internal services and public services with different controls. Which TWO actions BEST support a defensible initial risk assessment? (Select TWO.)

- A. Adopt the internal service's historical rate as the final forecast because its longer observation period provides the largest local dataset
- B. Pool the available comparison rates into one average and treat it as representative before examining their exposure and control differences
- C. Document observation limits and estimation uncertainty, with reassessment triggers as better service-specific evidence becomes available
- D. Annualize the new service's 30-day observed rate as the final forecast because direct observations should outweigh comparison data
- E. Use relevant threat and exposure evidence, evaluating how well each comparison's operating conditions match the new service

Answer: C|E

Sparse local history requires careful use of relevant evidence and explicit uncertainty. Longer comparison histories can help, but internal and public services may differ in exposure, controls, and threat activity. The analyst should assess comparability, document assumptions and limits, and plan reassessment. An incident-free month or an unexamined pooled average does not establish a reliable future occurrence rate.

Study tip: Check comparability and observation limits before trusting the apparent precision of a risk estimate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: A larger dataset may improve precision about the internal service while remaining poorly matched to an Internet-facing service's different exposure and control conditions.

B: Pooling can conceal material differences between services. An average is not automatically representative of the new service merely because it combines more observations.

C: A short incident-free history leaves substantial uncertainty. Recording limitations and review triggers avoids treating preliminary estimates as settled evidence of future exposure.

D: Direct observations are valuable, but a short interval with no recorded events cannot by itself establish a dependable forecast of future incident frequency.

E: Comparison data can inform estimates, but its relevance depends on exposure, controls, and threat conditions. Longer histories do not automatically describe this service.

## SEC2-Q265

A SaaS assurance report covers the correct service and period. It states that its conclusions depend on customers enforcing administrator MFA and reviewing their own tenant logs. The customer has done neither. What should the vendor review conclude?

- A. The independent report provides sufficient evidence because it covers the exact service the customer purchased
- B. The customer should request another provider audit before making changes to its administrator and logging settings
- C. Provider assurance must be considered alongside implementation and verification of the customer's specified responsibilities
- D. The report's conclusions should be rejected because any customer responsibility makes independent provider assurance unusable

Answer: C

Vendor assurance can depend on activities outside the provider's control. Here, the report explicitly identifies administrator MFA and tenant log review as customer responsibilities. The customer should implement and verify those activities, then evaluate assurance across both sides of the service relationship. A correctly scoped provider report alone cannot close these customer gaps.

Study tip: Read assurance-report dependencies as well as its service scope.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://aws.amazon.com/compliance/shared-responsibility-model/

A: Correct service coverage is necessary, but the report expressly depends on controls performed by each customer, which remain unimplemented here.

B: Another provider audit would not implement the tenant responsibilities already identified. The current evidence is sufficient to reveal the customer's gap.

C: The report identifies customer dependencies. Its coverage does not demonstrate that this customer's administrator authentication and log review requirements are operating.

D: Customer responsibilities do not invalidate provider assurance. Reviewers must understand its boundaries and combine provider evidence with evidence for the customer's controls.

## SEC2-Q266

A managed service provider will maintain one application's servers. Its draft work order requests standing administrator access to every production system, although no task requires access outside that application. Procurement is finalizing the engagement. Which change BEST addresses the identified risk?

- A. Define the required systems, approved access methods, individual accountability, and limited privileges in the engagement terms
- B. Keep the requested access scope but require the provider to report every privileged session in its monthly review
- C. Shorten the contract renewal period while retaining the requested access so procurement can reassess the provider sooner
- D. Require a stronger confidentiality agreement while leaving technical access decisions entirely to the provider's service manager

Answer: A

Third-party risk management should connect the contracted service to the access needed to deliver it. The provider's tasks cover one application, while the requested privileges cover every production system. The engagement should define authorized targets, methods, privileges, and accountable identities. Reporting, renewal cycles, and confidentiality terms support governance but do not resolve excessive access.

Study tip: Compare supplier privileges with the actual statement of work, not with the supplier's preferred convenience.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The requested access exceeds the service's demonstrated needs. Defining boundaries before engagement aligns supplier privileges and accountability with the authorized work.

B: Session reporting supports oversight after access occurs. It does not justify standing administrative privileges over systems outside the provider's responsibilities.

C: More frequent renewal creates a review opportunity, but unnecessary production access would remain available throughout each contract period.

D: Confidentiality obligations do not define which systems the provider may administer. The customer still needs explicit, proportionate access boundaries.

## SEC2-Q267

A hosting SLA promises acknowledgment of critical tickets within 15 minutes. During a six-hour outage, the provider acknowledges the ticket after eight minutes. The customer had expected its service to be restored within one hour, but the contract contains no restoration target. Which SLA change MOST directly closes this gap?

- A. Replace incident measurements with a monthly support-satisfaction score reviewed jointly at each service meeting
- B. Reduce the critical-ticket acknowledgment target from 15 minutes to five minutes and keep the remaining terms unchanged
- C. Add a measurable service restoration objective for critical incidents, with agreed measurement boundaries and escalation terms
- D. Require more frequent progress updates during critical tickets while retaining the same incident performance measurements

Answer: C

The provider met the stated acknowledgment target, even though the outage lasted much longer than the customer expected. An SLA must distinguish receiving or acknowledging a ticket from restoring usable service. Defining the restoration metric, its clock boundaries, and escalation terms makes that expectation reviewable. This scenario does not establish a breach of an unstated restoration promise.

Study tip: Identify exactly what starts and stops each SLA measurement.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: Satisfaction feedback can inform service improvement, but it is not a measurable restoration commitment for an individual critical incident.

B: A faster acknowledgment commitment changes when work is recognized. It still provides no target for restoring service after acknowledgment.

C: The current commitment measures acknowledgment, not recovery. A defined restoration objective addresses the customer's missing expectation about usable service.

D: Progress updates improve communication, but their frequency does not define the time by which the service should be restored.

## SEC2-Q268

A records platform advertises a complete export feature. A sample export contains document files but loses the links connecting each file to its case and approval history. Those relationships are required for continued operations. What should the customer require before accepting the vendor's portability claim?

- A. A successful download of the export over an encrypted connection, with transfer logs retained as acceptance evidence
- B. A representative migration test that demonstrates required files, relationships, and history remain usable in an alternative system
- C. A count comparing exported files with stored files, using identical totals as the primary acceptance criterion
- D. A larger export size limit so the entire repository can be transferred in one scheduled migration batch

Answer: B

A usable exit capability requires more than possession of exported bytes. The customer's operations depend on case relationships and approval history, which the sample loses. A representative migration test should define acceptance criteria for these dependencies and demonstrate their reconstruction. Transfer encryption, file counts, and batch size can support migration without proving portability.

Study tip: Test whether exported information can support its intended business use.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Transport protection and download success are useful controls. They do not address the missing relationships that prevent operational use.

B: Portability must preserve the information needed for business use. Testing reconstruction exposes whether exported files retain their required relationships and history.

C: Matching file counts can detect omissions, but they do not demonstrate that case associations and approval histories remain usable.

D: Transfer capacity affects the movement of data, while the identified gap concerns the meaning and completeness of exported relationships.

## SEC2-Q269

A signed master service agreement requires named customer approval before a supplier grants subcontractors access to customer data. It states that this clause can change only through a signed amendment expressly naming it. A later statement of work permits access by affiliates acting as subcontractors but contains no such amendment. Under the stated precedence rule, what should the customer do?

- A. Apply the existing approval requirement and resolve the conflicting statement of work through the authorized amendment process
- B. Treat the later statement of work as replacing the approval requirement because it describes the current project's delivery
- C. Ask the supplier to document its internal approval of the affiliates and treat that record as the required amendment
- D. Allow affiliate access after receiving notice because affiliation makes the separate named-approval requirement unnecessary

Answer: A

The answer follows the precedence rule provided in the scenario, rather than assuming a universal rule for conflicting contracts. The master agreement specifies how this access-approval clause can be changed, and the later work statement does not meet that requirement. The customer should preserve the existing approval condition while resolving the inconsistent project language through the authorized process.

Study tip: Use the contract hierarchy supplied in the question; do not invent a different precedence rule.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The scenario supplies an express amendment rule. A conflicting statement of work that does not follow that rule does not establish the required change.

B: Later timing and project specificity do not satisfy the explicitly stated method for changing this particular master agreement clause.

C: Supplier approval does not replace the customer's named approval or the signed amendment expressly required to change the contract clause.

D: The supplied terms require named approval before subcontractor access. No exception based on affiliation is stated in the agreement.

## SEC2-Q270

Two organizations want to record their shared intention to cooperate on threat-information exchanges and identify broad responsibilities before negotiating detailed service deliverables. Which document BEST fits this immediate purpose?

- A. A memorandum of understanding describing the intended cooperation and each organization's general role
- B. A statement of work specifying a project's detailed deliverables, acceptance criteria, schedule, and payment milestones
- C. A non-disclosure agreement establishing confidentiality restrictions for protected information exchanged between the organizations
- D. A service-level agreement defining measurable availability, response times, and remedies for missed service targets

Answer: A

The organizations need a high-level statement of shared intent and general responsibilities, which fits an MOU. Detailed deliverables belong in a statement of work, measurable service commitments in an SLA, and confidentiality restrictions in an NDA. The document's title alone does not determine its legal enforceability; that depends on its terms and context.

Study tip: Match the document to the level of agreement: shared intent, detailed work, service measures, or confidentiality.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: An MOU can document a common understanding and broad cooperation responsibilities. Its exact obligations depend on its wording and applicable context.

B: A statement of work defines particular work to be delivered. These organizations have not yet negotiated that level of project detail.

C: An NDA can protect shared information, but confidentiality terms alone do not record the broader intended cooperation and general responsibilities.

D: An SLA addresses measurable service commitments. The organizations are currently documenting broader cooperation before defining a specific service and its targets.

## SEC2-Q271

A supplier answers 'Yes' to 'Are restoration procedures tested?' Its supporting evidence consists only of successful nightly replication-job logs. The customer depends on this supplier to recover a working application after data corruption. What additional evidence BEST addresses the unanswered question?

- A. Results of a representative restoration exercise showing application validation, data usability, recovery scope, and unresolved findings
- B. A current architecture diagram listing replication endpoints and the network bandwidth allocated between the supplier's sites
- C. An attestation that the supplier purchases enough storage capacity to retain every scheduled replicated copy
- D. Additional replication logs covering a longer period, with failed transfer attempts and retry results included

Answer: A

The questionnaire asks whether restoration procedures were tested, while the evidence demonstrates that replication jobs completed. Those are different activities: replication can copy corrupted data, and successful transfers do not prove application recovery. A representative exercise should document what was restored, how usability was validated, and what limitations or findings remain.

Study tip: Match the evidence to the exact control claim; copying data is different from proving recovery.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Restoration results demonstrate whether the supplier can recover usable service. Replication success alone shows copying activity, not successful recovery from corruption.

B: An architecture diagram describes the recovery design. It does not demonstrate that restoration procedures have actually recovered a working application.

C: Capacity supports retention, but retained copies may be unusable or contain replicated corruption. The question requires evidence of tested restoration.

D: Longer transfer history can reveal replication reliability, but it still does not show that a corrupted application can be restored and validated.

## SEC2-Q272

A company contracts with two separately owned messaging providers for redundancy. Due diligence reveals that both rely on the same regional identity service, and neither can accept customer logins when it fails. What should the company conclude about this arrangement?

- A. The risk can be evaluated from each provider's standalone availability percentage without analyzing the shared identity service
- B. The providers share a failure dependency that must be included when evaluating whether the redundancy meets the business requirement
- C. The common dependency is adequately addressed if each provider offers an equivalent credit after a service outage
- D. The arrangement provides independent availability because the messaging providers have separate contracts and management teams

Answer: B

Supplier diversification should be assessed through actual dependencies, not provider names alone. Both services require the same regional identity system, creating a common point of failure for customer access. The company should evaluate that correlated failure against its continuity requirement and consider alternatives or compensating arrangements that address the identified dependency.

Study tip: Trace critical suppliers through their common supporting services before claiming redundancy.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: Individual availability summaries may hide correlated outages. The company must understand the shared dependency before treating the services as independent alternatives.

B: Separate ownership does not remove a common operational dependency. A single identity outage could prevent access to both contracted services.

C: Credits may compensate some contractual loss, but they do not keep either messaging service accessible when their common identity dependency fails.

D: Commercial independence does not establish technical failure independence. The same identity service can interrupt access through both providers simultaneously.

## SEC2-Q273

A customer's contract permits examination of a supplier's relevant security documents and records. It separately requires written authorization for active security testing. The customer now wants to scan the supplier's production application for exploitable weaknesses. What should happen before the scan?

- A. Have the customer's internal audit department run the scan so the activity remains within contractual audit rights
- B. Proceed with a low-intensity scan because a limited rate converts active testing into ordinary evidence review
- C. Obtain the separately required testing authorization and agree on the permitted scope and operating constraints
- D. Notify the supplier of the scan and proceed under the existing right to examine security records

Answer: C

The scope of a contractual audit right matters. This contract authorizes reviewing existing evidence and sets a separate condition for active testing. The customer must obtain that testing authorization and establish boundaries before scanning production. A lower rate, a different internal team, or notice to the supplier does not override the stated requirement.

Study tip: An audit clause grants the rights it states; active testing may require separate authorization.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Changing which customer team performs the scan does not expand the activity authorized by the contract's document and records clause.

B: Reducing scan intensity may reduce operational impact, but it does not change an active scan into the document examination authorized here.

C: The document-review right does not satisfy the separate authorization requirement for active testing. Scope and constraints should be agreed before scanning.

D: Notification alone does not meet the expressly stated written-authorization requirement. Active scanning is distinct from examining existing documents and records.

## SEC2-Q274

During a joint exercise, a supplier waits for final attacker attribution before notifying its customer and routinely deletes relevant logs before the customer can request them. The contract defines support availability but says little about incident cooperation. Which changes MOST directly address these findings? (Select TWO.)

- A. Increase outage service credits and use the larger financial penalty as the main mechanism for improving incident cooperation
- B. Define notification triggers and approved contacts that permit timely reporting while investigation details remain preliminary
- C. Increase the frequency of customer-satisfaction reports for support tickets while retaining the current incident communication process
- D. Make completion of the supplier's final root-cause report the initial notification milestone, using a standard template for validated facts
- E. Define preservation and evidence-sharing responsibilities, including how incident-related records are retained and made available

Answer: B|E

The exercise exposes two contract gaps: delayed notification and unavailable evidence. The parties should establish notification criteria that allow preliminary reporting, with reliable contacts and subsequent updates, and define preservation and evidence-sharing responsibilities. The exact timing and handling requirements should reflect applicable obligations and the service relationship. Support metrics and financial remedies alone do not resolve either finding.

Study tip: Translate exercise findings into specific supplier duties that make joint response possible.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Financial remedies can influence incentives, but they do not define notification triggers or preservation duties. The exercise identifies specific coordination commitments that are missing.

B: Notification criteria should support early coordination without requiring complete attribution. Agreed contacts and triggers reduce delays caused by uncertainty during investigation.

C: Support satisfaction reporting evaluates service experience. It does not establish incident notification triggers or preserve the records needed for a joint investigation.

D: A final report may improve later understanding, but making it the first notification milestone preserves a delay when the customer needs preliminary information for coordination.

E: The observed deletion gap requires clear preservation and cooperation duties. Evidence availability must be addressed before routine processes remove relevant records.

## SEC2-Q275

An EU retailer's provider stores customer records under the retailer's instructions. The provider then independently decides to use a copy to select targets for its own advertising, without the retailer jointly determining that activity. Under GDPR role terminology, how should the provider's NEW advertising activity be classified?

- A. The provider acts as a controller for the advertising activity because it independently determines that processing purpose
- B. The provider and retailer become joint controllers for advertising because both organizations possess copies of the records
- C. The provider's role stays unchanged until a revised contract formally assigns responsibility for the advertising activity
- D. The provider remains a processor for the advertising activity because the original records came from the retailer

Answer: A

Privacy roles are evaluated for a particular processing activity. The provider may be a processor for storage performed under the retailer's instructions, while acting as a controller for advertising whose purpose it independently determines. This classification does not establish that the new use is lawful. A contractual label or shared possession of records does not replace analysis of actual decisions.

Study tip: Determine who chooses the purpose of the specific activity being assessed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/controllers-and-processors/controllers-and-processors/what-are-controllers-and-processors/|https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng

A: Controller status follows the actual decision about purposes and essential means. Acting as a processor for one activity does not settle every other activity.

B: Possessing related data does not by itself establish joint determination of the advertising activity. The scenario explicitly excludes such joint decision-making.

C: Contract labels do not override the actual processing decisions. A provider can assume controller responsibilities through its independent use of personal data.

D: The source of the records does not determine the provider's role for a new purpose it independently chooses for itself.

## SEC2-Q276

Under an EU organization's GDPR program, survey responses use random employee codes instead of names. HR retains a separate code-to-person table that the organization can use to reconnect responses to individuals. Which statement BEST describes the responses?

- A. They remain personal data, with separation of the lookup table providing a protection through pseudonymization
- B. They become anonymous when ordinary survey analysts lack permission to access the separately protected lookup table
- C. Only the lookup table is personal data because the survey answers are stored in a different departmental system
- D. They qualify as anonymous data because the response file contains no names or direct employee contact details

Answer: A

Pseudonymization replaces direct attribution with additional information held separately, such as this code-to-person table. It can reduce disclosure risk and support controlled analysis. However, the organization can still identify the employees associated with the responses, so the data should remain within its applicable personal-data protections. An access restriction on the lookup table is not equivalent to irreversible anonymity.

Study tip: Ask whether the available information can still reconnect a record to a person.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng|https://csrc.nist.gov/pubs/ir/8053/final

A: The organization can reconnect the codes to identifiable people. Separating the additional identifying information reduces exposure without making the responses anonymous.

B: Restricting analyst access is a useful safeguard, but the organization's retained ability to reconnect records still matters when evaluating anonymity.

C: Storage location does not remove identifiability. The response data remains attributable to employees through the available table, even across departmental systems.

D: Removing direct identifiers does not establish anonymity when the organization retains a practical means to attribute records to individuals.

## SEC2-Q277

An EU retailer receives an access request for a customer's full account history. The requester knows the customer's publicly listed name and address but asks that the export be sent to a newly supplied email account. Identity has not been verified. What is the BEST next step?

- A. Send a confirmation code to the newly supplied email address and treat successful entry as verification of the customer
- B. Rely on the requester's correct account description and deliver the export with a warning against sharing it further
- C. Ask for two more facts visible on the customer's public profile and use matching answers to authorize the export
- D. Use the approved, proportionate identity-verification process through a trusted channel before disclosing the account history

Answer: D

An access right should be fulfilled through a process that protects the data subject from impersonation. The supplied public facts and new email address leave identity uncertain. The retailer should apply its approved verification process proportionately, rather than collecting unnecessary information or trusting destination ownership alone, and then deliver the response through the appropriate verified channel.

Study tip: Verifying control of a new email account is different from verifying the data subject's identity.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/dealing-requests-individuals_en|https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng

A: This verifies control of the requested destination, not its connection to the actual customer. It leaves the identity uncertainty unresolved.

B: An accurate description and a warning do not verify identity. Sending personal information to an unverified recipient could create an unauthorized disclosure.

C: Additional public details remain available to an impersonator. Verification should use an approved process suited to the risk of the requested disclosure.

D: The retailer must establish that the requester is entitled to receive the records. Publicly available details and a newly supplied destination do not establish identity.

## SEC2-Q278

An EU service provider verifies a customer's correction request and fixes an inaccurate delivery address in its main customer system. A downstream dispatch system still uses its old copy and continues generating labels with the wrong address. What action BEST addresses the remaining privacy accuracy gap?

- A. Trace the affected operational copies, propagate the verified correction, and confirm that dispatch uses the corrected value
- B. Add an explanatory note to the original request while allowing dispatch to continue using its existing address field
- C. Remove the customer's delivery preferences from the main system so dispatch no longer receives future profile updates
- D. Keep the source correction as completion evidence and leave the downstream address unchanged until its usual annual refresh

Answer: A

The accuracy issue concerns data actually used in operations, not simply a corrected master record. Dispatch continues to act on a known inaccurate copy. The organization should trace the affected data flow, apply the verified correction where needed, and confirm the operational result. It should document the handling of relevant copies and recipients according to its applicable correction process.

Study tip: Follow a correction into the systems that use the information, not just the system where it was entered.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/dealing-requests-individuals_en|https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng

A: Correcting the source alone has not corrected ongoing use. The provider should address the relevant copies that continue processing known inaccurate information.

B: A request note records awareness but does not correct the value used to produce labels. The known inaccurate information remains operational.

C: Stopping profile updates would not repair the inaccurate downstream address and could prevent future corrections from reaching the system that needs them.

D: The provider knows that a current operational copy is inaccurate and causing errors. A source-only correction does not resolve that ongoing processing gap.

## SEC2-Q279

An approved retention policy keeps protected, immutable backups for a fixed recovery period and requires completed erasures to remain effective when a backup is restored. After a disaster, a restored application contains customer records erased after that backup was created. The system has not reopened to users. What should the recovery team do?

- A. Use the restored accounts' enabled status to infer which records need removal instead of consulting the completed-erasure record
- B. Reapply the controlled record of completed erasures, validate the result, and then authorize the restored application for use
- C. Reopen the restored application immediately and apply only erasure requests received after the recovery operation finishes
- D. Keep the older customer records available as read-only historical entries until the retained backup reaches its expiry date

Answer: B

Recovery must restore the required business and privacy state, not merely the contents of an older snapshot. The scenario's policy permits retained backups but requires effective erasures to survive restoration. Applying a controlled erasure record and validating the outcome before reopening the application reconciles those requirements without assuming that every historical backup must immediately be destroyed.

Study tip: Include approved data-lifecycle changes in restoration validation, alongside application functionality.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Account status is not reliable evidence of which erasures were completed. The controlled record is needed to reconcile the restored data accurately.

B: The backup predates valid erasures. Reconciliation before release restores the intended data state while preserving the organization's stated backup and recovery requirements.

C: This would leave previously erased records available again. The policy explicitly requires completed erasures to remain effective through a restoration.

D: Read-only access still makes the erased records available in the live application. Backup retention does not authorize this restored operational use.

## SEC2-Q280

Requirement A calls for monthly access reviews of critical applications. Requirement B calls for quarterly access reviews of all applications. The organization wants evidence supporting both while minimizing duplicate review work. Which approach is BEST?

- A. Use the quarterly all-application reviews for both requirements because their broader scope includes every critical application
- B. Maintain completely separate reviews and evidence repositories for both requirements, even when the same completed review satisfies each
- C. Use the monthly critical-application reviews for both requirements because their review frequency exceeds the quarterly requirement
- D. Map each requirement's scope and cadence, reuse qualifying critical-application reviews, and obtain the additional evidence needed for remaining applications

Answer: D

Control requirements can overlap along one dimension while differing along another. Monthly critical-application reviews may support the relevant portion of the quarterly requirement, but the remaining applications still need coverage. A requirements-to-evidence mapping should preserve both scope and cadence. Neither a broader population nor a faster frequency automatically satisfies the other requirement's missing dimension.

Study tip: Compare scope, frequency, and evidence criteria separately before reusing compliance evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Broader scope does not compensate for the lower frequency. Quarterly review alone fails the monthly cadence required for critical applications.

B: Separate work could satisfy the requirements, but unnecessary duplication conflicts with the stated efficiency goal when evidence legitimately meets both criteria.

C: More frequent review does not compensate for missing applications. Requirement B includes applications outside the critical-only population of Requirement A.

D: The requirements overlap but are not identical. Reusing evidence where it meets both criteria avoids duplication while covering the broader quarterly population.

## SEC2-Q281

An organization's approved policy requires certain customer records to be deleted 18 months after the contract ends. Nine months after termination, the records are migrated into a new archive whose default retention timer starts on ingestion. No hold or exception applies. What should the compliance team require?

- A. Apply the policy's original expiry only to the source system and let archived copies follow the archive's default settings
- B. Carry the original termination-based expiry into the archive and verify that its deletion process uses that date
- C. Accept the archive's ingestion date as a new retention trigger because the records now belong to a different storage system
- D. Start the retention timer from the most recent read so records that remain useful stay available for current staff

Answer: B

The retention period and its triggering event must travel with the records. The archive's default timer is an implementation setting that conflicts with the organization's termination-based rule. The team should preserve the original expiry in metadata or equivalent controls and verify deletion behavior. The 18-month period is the scenario's policy, not a claimed universal legal deadline.

Study tip: When records move, check whether their retention trigger moves with them.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The requirement applies to the records, not merely their former location. An archived copy still needs handling consistent with the same applicable policy.

B: The policy anchors retention to contract termination. Migration must preserve that trigger rather than extending the allowed lifetime through a new ingestion date.

C: Changing storage systems does not change the stated policy requirement. Restarting retention would keep the records longer than the authorized termination-based period.

D: Recent use is not the authorized trigger in this scenario. It could repeatedly extend retention beyond the period the organization has approved.

## SEC2-Q282

A security standard was revised to require administrator MFA for a managed service. The compliance dashboard still evaluates only the earlier password settings and reports every tenant as compliant. What should the compliance team do FIRST to make the dashboard's result meaningful?

- A. Map the current requirement to the automated checks, update the missing evaluation, and reassess the affected tenants
- B. Raise the severity of existing password findings so service owners give the dashboard's current results higher priority
- C. Run the existing checks more frequently so any password-setting drift appears sooner on the compliance dashboard
- D. Compare the current password-check results with last quarter's results and use a stable trend as evidence of compliance

Answer: A

Automated monitoring is only as relevant as its rule coverage. The dashboard can accurately report that old password checks pass while failing to evaluate the current MFA obligation. The compliance team should trace approved requirements to tests, update the missing evaluation, and reassess the tenants. Increasing frequency or adjusting priorities cannot correct this coverage gap.

Study tip: A green result means the configured tests passed; confirm they test the current requirements.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The checks no longer cover the approved standard. A passing result cannot demonstrate a requirement that the evaluation never examines.

B: Changing severity affects response prioritization. It does not align the evaluated conditions with the revised standard or establish whether MFA is enforced.

C: Higher frequency improves timeliness for existing checks, but it does not add evaluation of the administrator MFA requirement that is missing.

D: Historical consistency can reveal drift relative to old criteria. It cannot demonstrate compliance with a newly introduced requirement absent from those criteria.

## SEC2-Q283

An EU company's privacy team approves a verified customer's access request. In-scope records refer to the customer by name and by account ID. The source folder also contains unrelated customers' records that the privacy team says must not be disclosed. Which actions BEST support an accurate, protected response? (Select TWO.)

- A. Review the prepared copy for scope and unintended disclosure, then use an approved secure channel to the verified recipient
- B. Assemble the approved customer's records using the relevant identifiers, retaining necessary context and applying the privacy team's disclosure boundaries
- C. Return the company's privacy notice and a description of the folder instead of preparing a copy of the approved personal data
- D. Export the entire source folder into an encrypted archive and send its password separately to the verified customer
- E. Search only the customer's displayed name and treat that search result as complete without checking account-ID references

Answer: A|B

The approved access response must be complete for the requester and respect the stated boundaries protecting others. Both name and account ID matter when assembling the records. Reviewing the prepared copy and delivering it securely addresses separate selection and transmission risks. Encrypting an overbroad export would not make its unrelated contents appropriate to disclose.

Study tip: Separate completeness for the requester, protection of others, and secure delivery.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/dealing-requests-individuals_en|https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng

A: A final review catches selection and redaction errors. Secure delivery to the verified recipient protects the prepared response from an additional disclosure.

B: The response must cover the customer's in-scope data without including unrelated customers' records. Both name and account identifiers are relevant to completeness.

C: General information about processing does not substitute for the in-scope data copy the privacy team has approved for this access response.

D: Encryption protects delivery but does not authorize disclosure of unrelated customers' information. The source folder exceeds the approved response scope.

E: The scenario states that some relevant records use the account ID. A name-only selection can omit data that belongs in the approved response.

## SEC2-Q284

An assessor must evaluate whether a quarterly control operated throughout the period. The control owner offers ten records selected because they were processed correctly. A complete population of 600 records is available. What is the BEST response?

- A. Use only records created during the most recent week because their procedures are most likely to match current documentation
- B. Define a sampling approach appropriate to the assessment objective and select from the complete population rather than only the owner's examples
- C. Ask the owner to provide ten additional successful records so the sample includes more evidence of the same behavior
- D. Accept the ten records because the owner understands the control well enough to choose its clearest demonstrations

Answer: B

Sampling should serve the assessment objective and preserve a defensible relationship to the population being evaluated. The owner's curated successes demonstrate selected instances, not control performance throughout the quarter. The assessor should define an appropriate selection method, considering period coverage and relevant risks. A larger sample of known-good records would retain the same bias.

Study tip: More evidence does not correct a sample chosen to exclude failures.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Recent records may inform current operation, but the objective covers the quarter. Restricting the sample this way could omit earlier failures or changes.

B: Known-good examples create selection bias. An assessor-controlled, justified sample can address the period and relevant conditions within the complete population.

C: Increasing the number of deliberately successful cases does not remove the selection bias. The sample still excludes records because of their outcome.

D: Clear demonstrations show how the control can work, but deliberate selection of successful cases does not support a balanced assessment of its operation.

## SEC2-Q285

An assessor has already examined an escalation procedure and confirmed that its required fields exist in the ticket system. The remaining question is whether on-call staff understand which incidents require escalation and can explain their reasoning. Which assessment method MOST directly addresses this question?

- A. Test whether the automated notification service can send a message to the configured on-call distribution list
- B. Interview a suitable selection of on-call staff using example incidents and ask them to explain their escalation decisions
- C. Inspect the ticket system's database schema to confirm that escalation status is stored as a required field
- D. Examine another copy of the approved escalation procedure and compare its wording with the version already reviewed

Answer: B

Assessment methods should match the question being asked. The missing evidence concerns people's understanding, so interviews using relevant examples are a direct way to explore their reasoning. Document examination and technical tests address other parts of the control. Interview responses alone would not establish that the control operated consistently over an entire review period.

Study tip: Use interviews for personnel knowledge, examination for artifacts, and tests for exercised behavior.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: This tests a technical delivery mechanism. It does not directly examine the staff's ability to reason about the escalation criteria.

B: Interviews can examine personnel's knowledge and reasoning. Example incidents connect their explanations to the decisions the procedure expects them to make.

C: A required data field supports process implementation, but its presence does not demonstrate the staff's understanding of when escalation is appropriate.

D: Document examination can confirm the prescribed process. It does not directly reveal whether the on-call staff understand how to apply it.

## SEC2-Q286

A report lists a critical vulnerability based on a product-version match. Management asks whether the weakness has actually been shown to permit unauthorized access in this environment. Which evidence would MOST directly support that stronger claim?

- A. A screenshot showing that the affected service is reachable from the test network using its documented application port
- B. A documented, authorized test that reproduces the access violation under the environment's stated conditions and records the observed result
- C. A higher severity score for the vulnerability, supported by a vendor advisory describing the affected product versions
- D. A publicly available exploit report describing successful use against the same product in a different organization's configuration

Answer: B

Product-version matching, severity scores, and published exploits can support a vulnerability finding and prioritization. The stronger assertion here is that unauthorized access has been demonstrated in this environment. A reproducible, authorized test with recorded starting conditions and observed impact is the most direct evidence for that claim. The report should distinguish verified outcomes from potential exposure.

Study tip: Match the strength of a report's claim to the strength of the evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Reachability establishes an exposure path. It does not demonstrate successful exploitation or unauthorized access through the suspected weakness.

B: Reproducing the relevant boundary violation directly demonstrates the claimed outcome under recorded conditions. Version matching alone identifies potential exposure, not that observed result.

C: Severity and affected-version information support prioritization, but they do not show that unauthorized access was achieved in this particular environment.

D: External exploit evidence can increase concern and guide authorized testing, but different controls and conditions limit its proof about this environment.

## SEC2-Q287

A penetration test found that a user could download another customer's invoice through an older application route. Developers disabled that route, but the same invoice objects are also served through a newer route. What retest plan BEST supports closing the underlying authorization finding?

- A. Confirm that the older route returns an error and close the finding without examining other routes to the same objects
- B. Verify the original route's behavior and test equivalent unauthorized invoice access through the remaining route under the same user conditions
- C. Confirm that the change ticket includes developer approval and a successful deployment status for the route-removal update
- D. Wait for a period without customer complaints and use the absence of reports as evidence that invoice access is corrected

Answer: B

Retesting should connect the original security finding to the behavior that must now be enforced. Removing one route may block a reproduction without correcting access to the underlying objects elsewhere. Verifying both the old route and equivalent access through the remaining route provides better evidence that the authorization boundary holds under the original user conditions.

Study tip: Close the security condition identified by the finding, not only its first observed path.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/115/final|https://owasp.org/Top10/2025/

A: An unavailable route proves the specific path changed. It does not show whether the same authorization weakness remains through another available path.

B: The finding concerns unauthorized access to invoice objects. Retesting equivalent paths checks whether the fix addresses that boundary rather than merely one URL.

C: Change records provide implementation evidence, but they do not demonstrate that unauthorized object access is prevented in the running application.

D: A lack of complaints does not exercise the vulnerable condition. The known remaining route provides a concrete reason for targeted technical verification.

## SEC2-Q288

A facility requires an alarm at the staffed security desk when a restricted door remains open beyond its configured interval. Maintenance records confirm that the door sensor operates. The assessor must verify the complete alarm control under an approved safety plan. Which activity provides the BEST evidence?

- A. Compare the configured door-open interval with the documented requirement and use the matching value as the completion criterion
- B. Inspect the purchase records to confirm that both the door sensor and central alarm console are supported equipment models
- C. Ask the maintenance contractor to reconfirm its sensor inspection while postponing any observation of the security console
- D. Conduct a coordinated door-open test and verify that the expected alarm reaches the staffed desk within the required interval

Answer: D

The control's intended outcome is a timely alarm at the staffed desk, not merely a functioning door sensor. A coordinated test under the approved safety plan can exercise the physical trigger, timing, transmission, and receipt. Documentation and component checks remain useful evidence, but the scenario requires verification of the complete operating path.

Study tip: Test the required control outcome across its dependencies, not just a working component.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Configuration review checks one element of the control. It cannot alone demonstrate sensor activation, message transmission, and alarm receipt at the staffed desk.

B: Supported equipment may reduce maintenance concerns, but purchase records do not demonstrate the required alarm path operating at the site.

C: Repeating sensor confirmation does not address the unverified delivery path. The assessment objective includes the alarm's arrival at the security desk.

D: This exercises the full control path from the physical condition through alert delivery. Sensor operation alone does not establish timely notification to security staff.

## SEC2-Q289

A governance requirement calls for an independent assessment of a new access-control design. The engineer who selected, configured, and approved the design is proposed as the sole assessor. Which arrangement BEST satisfies the stated independence requirement while preserving useful technical knowledge?

- A. Select the original design consultant for an external review and use its separate company status as the independence criterion
- B. Allow the engineer to assess the control after transferring daily administration to an operator, without changing responsibility for the original design
- C. Assign an assessor independent of the design and implementation responsibility, with the engineer available to explain the system and provide evidence
- D. Keep the engineer as sole assessor and ask the project manager who approved the design to countersign the final conclusion

Answer: C

Independence depends on the assessor's relationship to the work, not simply a job title or external affiliation. The sole evaluator should not be the person responsible for the design being independently assessed. An appropriately independent assessor can obtain technical explanations and evidence from the engineer while retaining responsibility for the evaluation and conclusion.

Study tip: Distinguish providing evidence about your work from independently evaluating that work.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: External employment alone does not remove a role conflict. A consultant assessing its own design can face the same independence concern.

B: Transferring routine administration does not by itself make the designer independent of the work being assessed. The requirement concerns the evaluation relationship.

C: Separating evaluation from responsibility for the design supports independence. The engineer can still contribute technical evidence without being the sole evaluator of their own work.

D: Countersigning by another person responsible for the same project does not establish an independent evaluation of the control's design and operation.

## SEC2-Q290

A sponsor wants separate conclusions about exposure to an internet user with no account and exposure to an ordinary authenticated customer. The testers receive a target URL and a standard customer account. Which reporting approach BEST preserves the distinction the sponsor requested?

- A. Present every finding as unauthenticated exposure because both test phases reached the same internet-facing application address
- B. Combine the findings by severity and omit starting privileges because severity alone communicates who could exploit each weakness
- C. Present every finding as authenticated exposure because the test team was supplied with a customer account at kickoff
- D. Document the two starting conditions separately and attribute each verified finding to the unauthenticated or authenticated access actually required

Answer: D

The same application can expose different weaknesses before and after login. The sponsor explicitly needs both perspectives, so the test and report should retain their starting conditions and required privileges. Neither the public URL nor the team's possession of credentials determines the access required for every finding. Those conditions must follow the actual evidence.

Study tip: Keep each finding's initial knowledge and privileges visible in the conclusion.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/115/final

A: An internet-facing URL does not make authenticated actions available without credentials. The privileges required for each finding must remain clear.

B: Severity supports prioritization, but it does not replace the concrete access conditions requested by the sponsor for interpreting each verified result.

C: Possessing an account does not mean every tested weakness requires one. Unauthenticated findings should retain their actual starting conditions.

D: Separating starting privileges preserves the meaning of each result. The sponsor can distinguish exposure without an account from weaknesses requiring a customer session.

## SEC2-Q291

A defensive exercise scored well after analysts received the exact test file hashes and scheduled activity times in advance. The next objective is to assess recognition of similar, previously unrehearsed behavior within approved limits. Which design choices BEST support a valid assessment? (Select TWO.)

- A. Give participating defenders a revised list of every indicator immediately before execution so unfamiliar alerts can be classified quickly
- B. Use approved behaviorally relevant variants whose specific indicators and execution times are withheld from participating defenders until the debrief
- C. Repeat only the original hashes at the original scheduled times so the team can improve its score under identical conditions
- D. Measure progress by the number of enabled detection rules that mention the exercise's techniques, without observing their response to execution
- E. Compare confirmed executed actions and timestamps with the resulting alerts, investigations, and response decisions using predefined evaluation criteria

Answer: B|E

The first result may reflect advance knowledge rather than general detection and response capability. Approved but unrehearsed variants improve the next assessment's fit to its objective. Recording what actually executes and comparing it with defensive actions provides a defensible basis for scoring. Repeated known indicators and rule counts serve different purposes and cannot alone demonstrate the requested capability.

Study tip: Choose exercise conditions and measurements that match the capability being assessed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/115/final|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Providing the specific indicators again retains the rehearsal advantage. It makes the new assessment less informative about recognition without that preparation.

B: Unrehearsed variants reduce dependence on memorized indicators while preserving an authorized exercise. Withholding specifics better tests recognition of the intended behavior.

C: Identical repeats can support regression testing, but they do not address this exercise's objective of recognizing similar behavior beyond rehearsed indicators.

D: Rule coverage is a useful planning input, but enabled rule counts do not establish whether defenders detect and handle the behavior under test.

E: Ground truth connects defensive observations to actions that actually occurred. Predefined criteria support meaningful evaluation beyond raw alert volume or participant expectations.

## SEC2-Q292

An authorized exercise is intended to test an alert triggered by a particular child-process behavior. Execution logs show that an endpoint prevention policy blocked the simulator before any child process was created. No child-process alert appeared. What is the MOST defensible assessment conclusion?

- A. The endpoint block demonstrates that the child-process detector passed because the simulator failed to complete its planned action
- B. The intended behavior did not execute, so this run does not establish the child-process detector's result; arrange an approved retest with verified ground truth
- C. The planned simulation timestamp is sufficient to score the child-process alert even though execution was blocked before that stage
- D. The missing child-process alert demonstrates a detection failure and should be recorded as a confirmed missed event for that rule

Answer: B

The execution log establishes an earlier prevention outcome and the absence of the behavior required to test the detector. No child-process alert is therefore inconclusive about that detector's effectiveness. The report should preserve the prevention finding and mark the intended detection test as not exercised, then arrange a suitably authorized retest that confirms the relevant behavior occurred.

Study tip: Before scoring a missing alert, verify that the event it should detect actually happened.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: The prevention control may have worked, but that does not demonstrate the separate child-process alert being tested. The assessed outcomes must remain distinct.

B: The required stimulus never occurred. The prevention result is useful, but the downstream detector cannot be judged from a behavior that was not executed.

C: A planned action is not ground truth that the behavior occurred. Scoring the later alert requires evidence that its trigger actually executed.

D: There was no child-process event for the rule to detect. Calling it a confirmed miss would misrepresent the execution evidence.

## SEC2-Q293

An employee locks their workstation before leaving but sends customer case notes to an unattended shared printer. The notes remain in the output tray where visitors can read them. Which awareness guidance MOST directly addresses this exposure?

- A. Change the customer's name in the print-job title while leaving the complete case notes available in the output tray
- B. Use the approved secure-release printing process and promptly collect or securely dispose of sensitive printed material
- C. Shorten the workstation's automatic screen-lock interval so customer records disappear from the display more quickly
- D. Encrypt the workstation's local storage before printing customer notes to the same unattended shared output tray

Answer: B

Information-handling awareness must cover the form in which data is actually exposed. Here, locking the computer and protecting its storage do not control the printed copy. Employees should use approved secure-release features, collect sensitive output promptly, and dispose of unneeded paper through the organization's approved process. Job metadata changes do not protect the contents of the pages.

Study tip: Follow sensitive information after it leaves the screen.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A less revealing job title can reduce metadata exposure, but the sensitive contents remain readable on the unattended printed pages.

B: The exposed information is on paper outside the locked workstation. Secure release and appropriate handling reduce unauthorized access at the printer.

C: Screen locking protects an unattended display. It does not protect copies already printed and left in a publicly accessible output tray.

D: Storage encryption protects data on the workstation under its threat model. It does not prevent a visitor from reading the paper output.

## SEC2-Q294

Employees know they should report suspicious email promptly, but the approved desktop reporting button is unavailable on their managed phones. Interviews show they delete suspicious messages while traveling because the training provides no mobile alternative. What is the BEST awareness-program improvement?

- A. Have managers collect descriptions of deleted messages at weekly team meetings and send a consolidated summary to the response team
- B. Provide and practice an approved mobile reporting path that preserves useful message details and routes reports to the response team
- C. Send more reminders to use the desktop reporting button while keeping the reporting instructions and supported devices unchanged
- D. Tell mobile users to wait until they return to a desktop before taking any reporting step for suspicious messages

Answer: B

Awareness succeeds when employees can perform the required behavior in their actual work environment. These users understand the goal but lack a supported mobile path. The program should coordinate an approved alternative, teach and practice its use, and verify that reports reach the response team with useful details. Additional reminders alone do not resolve the workflow barrier.

Study tip: When people know the rule but cannot follow the workflow, fix and rehearse the workflow.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Weekly summaries delay notice and may lose useful message evidence. The observed need is a usable reporting path when mobile users encounter suspicious email.

B: The observed barrier is an unavailable workflow, not a missing slogan. A usable approved alternative enables timely reporting and preserves information for analysis.

C: Repetition does not remove the mobile access barrier. Employees still lack an actionable reporting method at the time they encounter suspicious messages.

D: A desktop can provide useful reporting features, but requiring a delay does not meet the program's goal of prompt reporting during travel.

## SEC2-Q295

A person carrying a familiar supplier's equipment names an internal project and asks an employee to admit them through a staff-only door. Site policy requires visitors to check in and have their host verified. The person says the appointment is urgent. What should the employee do?

- A. Direct the person through the established visitor check-in process and use the approved channel to verify the host
- B. Escort the person directly to the named project room because accompanying them compensates for skipping visitor check-in
- C. Accept the supplier logo and accurate project name as sufficient proof and record the visit in a personal note
- D. Admit the person to an internal waiting area while a colleague attempts to confirm the claimed appointment

Answer: A

Social engineering often creates pressure to bypass familiar procedures using plausible details and urgency. The employee does not need to determine the visitor's intent. Following the established check-in and host-verification process provides a respectful, practical response that preserves the access requirement. Informal escorting or personal notes do not replace the explicit site policy.

Study tip: Use the visitor process when a convincing story asks you to bypass it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Familiar details and urgency do not replace the required visitor process. Established check-in and host verification preserve the facility's access boundary.

B: An escort can be part of an approved visitor process, but it does not replace the site's explicit check-in and host-verification requirements.

C: Observable logos and project knowledge can be obtained or imitated. A personal note does not perform the site's required identity and host checks.

D: Moving an unverified visitor through the staff-only boundary grants access before the required checks are complete, even if confirmation is attempted afterward.

## SEC2-Q296

Staff repeatedly upload restricted documents to an unapproved conversion website because the approved tools cannot perform a required conversion. They understand the prohibition but face a daily business deadline. Which program change BEST addresses the reason this behavior keeps recurring?

- A. Require another annual acknowledgment of the existing prohibition without changing the available conversion tools or instructions
- B. Increase the severity of monitoring alerts for conversion-site uploads while leaving users responsible for finding their own alternative
- C. Work with the business to provide a vetted conversion workflow and train staff to use it with the required information-handling controls
- D. Add more spot checks for uploads and report their results at monthly meetings without examining the conversion requirement

Answer: C

An effective awareness response considers why the risky behavior occurs. The users already know the rule but lack an approved way to complete required work. Coordinating a vetted alternative and practicing the correct workflow addresses both the business constraint and the data exposure. Acknowledgments, monitoring, and checks can support the program without fixing the underlying gap.

Study tip: Investigate the work requirement behind repeated workarounds before relying on more reminders.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: Acknowledgment documents receipt of the rule, but staff already understand it. The underlying need for a workable approved conversion path remains unresolved.

B: Monitoring can detect violations, but higher alert severity does not provide the business capability that is driving the repeated workaround.

C: The recurring behavior serves an unmet work need. Providing a usable approved alternative addresses that cause while maintaining the required protection for restricted documents.

D: Spot checks can improve visibility, but they do not address the stated cause. The program needs to resolve the task and protection requirements together.

## SEC2-Q297

A required security module consists of images containing all instructions and quiz text. Employees who use screen readers cannot access the content, and the program currently measures only completion clicks. Which change BEST supports equitable learning and meaningful verification?

- A. Provide equivalent accessible content and exercises, then verify understanding through an accessible assessment of the same learning objectives
- B. Extend the deadline for the existing image-based module and retain the same content and completion measurement
- C. Ask managers to submit completion confirmations for employees who cannot use the module instead of providing equivalent learning content
- D. Improve the visual branding and color contrast of the images while retaining the same image-only instructions and quiz text

Answer: A

A required program must provide a practical route to the intended learning for its participants. Image-only text creates a known screen-reader barrier that extra time and completion confirmations cannot solve. Equivalent accessible content, usable exercises, and an accessible assessment preserve the security objective while making the outcome measurable beyond attendance or clicks.

Study tip: Adapt delivery to the learner while preserving the intended security skill.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Accessible delivery removes the participation barrier without weakening the learning goal. An appropriate assessment checks understanding rather than merely registering a completion click.

B: Extra time can help some learners, but it does not make image-only text available to a screen reader or verify understanding.

C: A manager's confirmation removes an administrative obstacle but does not establish that employees received accessible instruction or met the same learning objectives.

D: Visual improvements may help some users, but they do not provide the accessible text and interaction required by the stated screen-reader users.

## SEC2-Q298

A team plans a remote meeting about restricted customer records. The invite list is appropriately limited, but the meeting platform's default recording setting shares recordings with everyone in the organization. Policy requires recordings to have the same access restrictions as the discussed records. What should the host do?

- A. Verify and apply approved recording, storage, sharing, and retention settings before the discussion so the resulting recording follows the required restrictions
- B. Require meeting participants to use a VPN while leaving the organization's default recording permissions unchanged
- C. Disable recording downloads but allow everyone in the organization to stream the saved meeting from the platform
- D. Keep the invite list restricted and rely on it to limit access to the recording without reviewing the separate sharing default

Answer: A

Collaboration can create new copies of sensitive information with different permissions from the live meeting. The recording's default audience conflicts with the supplied policy even though the invite list is correct. The host should verify the approved settings before discussion, including sharing and retention. Network protection or download restrictions do not correct who can view the recording.

Study tip: Treat meeting recordings and transcripts as information assets with their own permissions and retention.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A restricted live audience does not automatically restrict the recording. The host must address the artifact's access and handling under the stated policy.

B: A VPN can protect a network path under its design, but it does not correct overly broad permissions assigned to the recording.

C: Streaming still discloses the restricted discussion to unauthorized employees. Preventing file download does not satisfy the required audience restriction.

D: The scenario explicitly gives the recording a broader default audience. The invitation boundary does not enforce the required restriction on the saved artifact.

## SEC2-Q299

Employees score well on an immediate post-training quiz but often forget the reporting steps when tested two months later. The reporting workflow has not changed. Which adjustment BEST addresses the demonstrated learning gap?

- A. Use a longer quiz immediately after the same annual presentation and treat the resulting score as the primary readiness measure
- B. Report the percentage of employees trained within the last year and stop tracking the delayed practice results separately
- C. Introduce short, spaced retrieval and practice activities, then check performance again after a delay using the actual reporting steps
- D. Require monthly acknowledgments that employees have read the reporting procedure without asking them to retrieve or perform its steps

Answer: C

The immediate quiz and delayed exercise measure different outcomes. The evidence shows that staff initially learn the steps but do not retain reliable access to them over time. Short recurring retrieval and practice activities, followed by delayed performance checks, directly address that problem. Completion rates and acknowledgments remain weaker evidence of a retained operational skill.

Study tip: Distinguish learning at the end of a session from retaining a skill for later use.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: A longer immediate test may examine more content, but it still does not show whether employees can recall and apply the steps months later.

B: Training recency is an administrative measure. Removing delayed performance data would hide the specific retention problem the program has already observed.

C: The gap concerns retention and practical recall over time. Spaced practice with delayed checks targets that outcome more directly than immediate quiz success.

D: Acknowledgment can record exposure to guidance, but it provides little evidence that the reporting skill is retained and can be used when needed.

## SEC2-Q300

A company rewards the department with the fewest reported security mistakes. Follow-up interviews and incident timelines show that employees delay reporting to protect their department's score. Leadership wants earlier, accurate reporting without treating a raw increase in reports as proof that security worsened. Which changes BEST support that goal? (Select TWO.)

- A. Require manager approval before employees submit lower-severity reports so the departmental totals contain fewer mistaken suspicions
- B. Evaluate reporting delay and quality against exercise or investigation evidence, interpreting report volumes alongside exposure and other relevant context
- C. Keep the fewest-reports award but normalize each department's total by its number of employees before comparing results
- D. Replace the low-report-count reward with recognition for prompt, useful reporting and reinforce the handling of good-faith mistakes as learning opportunities
- E. Count only confirmed security mistakes for the existing award, while continuing to rank departments by the lowest reported count

Answer: B|D

The problem is an incentive that makes reporting look like failure. Leadership should reward the desired behavior and use measures that reflect timeliness, usefulness, and actual outcomes. Raw counts can rise when people report more confidently, so they need context and corroboration. Adjusting denominators or counting only confirmed cases would retain the underlying pressure to conceal mistakes.

Study tip: Ask which behavior a metric rewards before interpreting movement in the metric.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: An additional approval gate can delay reporting and preserve pressure to protect the score. It does not resolve the incentive identified in the interviews.

B: Timeliness and quality measures address the stated goal. Corroborating evidence and context help distinguish improved reporting from a change in actual incident frequency.

C: Normalization can improve a comparison of differently sized groups, but rewarding fewer reports still encourages employees to suppress or delay disclosure.

D: The current reward discourages disclosure. Recognizing timely, useful reports changes the incentive toward the behavior leadership needs and supports constructive learning.

E: Confirmation may improve classification, but the reward still makes disclosed mistakes costly to a department's score and can discourage timely reporting.
