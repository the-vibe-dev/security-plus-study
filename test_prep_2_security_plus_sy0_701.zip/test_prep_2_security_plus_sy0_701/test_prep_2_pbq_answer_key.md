# Original Security+ PBQ solutions — v1.2.0


## SEC2-PBQ-001 — Authorize the next step in a failing change


You are the change coordinator for an access-gateway upgrade. Complete the change-board fields using the approval record and canary telemetry. A rollback is an available branch of the plan, not an instruction implied by this scenario. Evaluate whether it should be used. All times use the same synchronized UTC clock.

### Approved change record


CHG-20 permits gateway release 7.4 during 22:00–22:30 UTC. The canary serves 5% of users. Expand only after five consecutive minutes with failed logins below 1%. Trigger backout if failures exceed 1% for two consecutive minutes. An emergency extension requires the change authority's approval before the current window ends.

The tested backout restores signed release 7.3 and its saved configuration in seven minutes. Database schema migration is explicitly excluded. The gateway depends on directory service DS-1; no change to DS-1 is approved.

### Canary observations and pending requests


| Interval | Failed logins | DS-1 health |
| --- | ---: | --- |
| 22:14–22:15 | 3.0% | Healthy |
| 22:15–22:16 | 3.2% | Healthy |
| 22:16–22:17 | 3.1% | Healthy |
| 22:17–22:18 | 3.4% | Healthy |
| 22:18–22:19 | 3.0% | Healthy |
| 22:19–22:20 | 3.2% | Healthy |

It is now 22:20. An engineer proposes expanding the canary, restarting DS-1, and performing an unapproved schema migration. A representative sign-in test and gateway error monitoring are available for acceptance checks.

### T01


Select the disposition supported by the canary criteria.

- o1: Expand to the next deployment group

- o2: Restart the healthy directory service

- o3: Continue unchanged until the window expires

- o4: Use the approved backout branch

### T02


How many minutes remain in the approved window at the decision time?

### T03


If the backout branch is selected now, evaluate its documented duration against the remaining window.

- o3: The documented backout exactly consumes the remaining window

- o4: The documented backout cannot be evaluated until DS-1 is restarted

- o1: The documented backout requires an approved extension

- o2: The documented backout can finish within the window

### T04


Choose the version/configuration pair authorized for the backout branch.

- o1: A locally rebuilt 7.3 image without integrity verification

- o2: Release 7.3 with an untested 7.4-only configuration

- o3: The newest available release with default settings

- o4: Signed release 7.3 with its saved configuration

### T05


Evaluate the proposed database migration.

- o1: Keep it outside this change and obtain separate assessment and approval

- o2: Include it because the gateway change is approved

- o3: Perform it now and request retrospective scope approval

- o4: Proceed if the engineer verbally accepts the risk

### T06


Evaluate the proposed DS-1 restart.

- o1: Move directory traffic to standby before diagnosing the gateway

- o2: Restart it concurrently to save time

- o3: Leave the healthy dependency unchanged unless evidence and authorization justify a change

- o4: Restart it because it is a gateway dependency

### T07


Select TWO checks that directly demonstrate the affected sign-in service meets its acceptance criteria. (Select TWO.)

- o1: Gateway failures return within the defined acceptance criterion

- o2: The deployment ticket has an assigned approver

- o3: The installer reports a successful exit code

- o4: The package is listed in the software inventory

- o5: Representative users can complete legitimate sign-ins

### T08


Choose the appropriate final record for the change.

- o1: Retain the configuration difference without functional test results

- o2: Retain the approved plan without recording execution differences

- o3: Replace the detailed observations with a completion status

- o4: Record the actual actions, versions, results, and any deviations

T01: "o4"

The failure rate remained above the threshold for longer than its specified trigger period. The approved response is backout, rather than expanding a failing canary or changing an unaffected dependency.


T02: 10

The current time is 22:20 and the window ends at 22:30, leaving ten minutes.


T03: "o2"

The planned backout takes seven minutes and the remaining window is longer. This evaluates the documented plan; actual execution still needs monitoring. Ten minutes remain against a seven-minute backout, so margin exists, and the healthy, unapproved DS-1 restart has no bearing on the duration check.


T04: "o4"

The tested and approved pair is signed release 7.3 plus the saved configuration. Mixing configurations or using an unverified build changes the recovery plan.


T05: "o1"

The migration is explicitly excluded. Its dependencies, impact, recovery path, and approval need their own assessment before execution.


T06: "o3"

A dependency relationship alone does not justify modifying a healthy system. The evidence points to the changed gateway, and DS-1 is outside the approved scope.


T07: ["o5", "o1"]

Functional sign-ins and the defined failure-rate criterion test the business outcome and observed fault. Ticket status or installation artifacts do not demonstrate restored behavior.


T08: "o4"

The change record must show what actually occurred and the evidence for its result. Preserving deviations and observations supports later troubleshooting and accountable review.


References: 

## SEC2-PBQ-002 — Protect an offline software-transfer package


An isolated engineering network receives software on removable media. An adversary could replace files and checksums on the media. The receiving team already has the authorized publisher's public verification key through a separate trusted process. A signed manifest lists package digests. Treat the synthetic digest tokens below as full digest values for this exercise. Signature and digest results are supplied; do not perform cryptographic calculations.

### Verification worksheet


| Item | Manifest digest | Independently computed digest |
| --- | --- | --- |
| Package Cedar | DIGEST-11 | DIGEST-11 |
| Package Maple | DIGEST-27 | DIGEST-72 |

The manifest signature verifies under the separately trusted publisher key. Package approval also requires malware inspection and a representative compatibility test before production installation. A confidential site configuration accompanies the public software; only the destination recovery team may read it.

### Additional requirements


Two departments both possess an HMAC key used for internal transfer checks. Management wants to know whether an HMAC alone can prove to an independent reviewer which department authored a disputed file. Release policy also requires different people to build a package and authorize its publication. Historical signed releases must remain verifiable after the signing private key is replaced.

### T01


Select the evidence that authenticates the manifest to the expected publisher.

- o1: The manifest signature verified using the separately trusted publisher key

- o2: A courier signature confirming delivery of the labeled media

- o3: A checksum stored beside the file on the same removable media

- o4: A manifest signature verified only with a key supplied on that media

### T02


Evaluate Package Cedar against the digest check only.

- o2: It passes this digest comparison

- o4: It passes and therefore needs no further inspection or testing

- o3: It fails because the manifest arrived on the same removable media

- o1: It fails this digest comparison

### T03


Evaluate Package Maple against the digest check only.

- o2: It fails this digest comparison and requires investigation

- o3: It passes because the manifest signature verified under the trusted key

- o1: It passes this digest comparison

- o4: It passes if either digest value appears in the signed manifest

### T04


Choose the additional protection required for the confidential site configuration.

- o1: Encode the configuration using a reversible text representation

- o2: Publish a digest of its plaintext contents

- o3: Sign it but send the configuration in plaintext

- o4: Encrypt it for the authorized destination recovery team

### T05


What can the shared HMAC arrangement establish about disputed departmental authorship?

- o1: Authenticate the file to one uniquely identifiable department

- o2: Keep the file contents confidential from external parties

- o3: Verify integrity among key holders without identifying which holder signed

- o4: Let any third party verify the file without access to the key

### T06


Choose the release authorization design matching the stated personnel requirement.

- o1: A different authorized person approves the completed build

- o2: The same builder rotates a password before approving

- o3: The builder also approves publication using a second account

- o4: The builder approves alone after an additional MFA prompt

### T07


Choose the next evaluation path for a package that passes cryptographic checks.

- o1: Perform malware inspection but omit the representative compatibility test

- o2: Promote it using the signature result as the production gate

- o3: Inspect and compatibility-test it in the approved staging process

- o4: Perform compatibility testing but rely on the signature for malware assurance

### T08


Choose the record needed to preserve verification of historical releases after key replacement.

- o1: Retain the trusted historical public verification key and release records

- o2: Replace historical signatures with checks using the departments' shared HMAC key

- o3: Retain historical package hashes without the corresponding signature trust records

- o4: Retain only the replacement public key and current release records

T01: "o1"

The signature must be bound to the separately trusted publisher key. A replaceable checksum or media-supplied key lacks that trust anchor, while a courier receipt establishes delivery rather than publisher authorship.


T02: "o2"

The computed value matches the authenticated manifest value. This passes the integrity comparison, while the separate inspection and compatibility requirements still remain. The manifest is trusted through the separately obtained key, not the media, and a digest match never replaces the required malware and compatibility checks.


T03: "o2"

The package digest differs from the authenticated manifest value. A valid manifest signature does not make a nonmatching payload trustworthy. The signature only proves the manifest is authentic; the package itself must match the listed digest, and DIGEST-72 is not in the manifest.


T04: "o4"

The requirement is confidentiality. Signatures and digests address authentication or integrity, while ordinary encoding does not restrict who can read the data.


T05: "o3"

Both departments can generate a valid HMAC because both know the secret. That makes an HMAC alone insufficient to attribute the file uniquely to one of those holders.


T06: "o1"

The requirement is separation between people performing build and approval. Another account or authentication factor for the same person does not create that independent decision.


T07: "o3"

The scenario requires inspection and compatibility testing in addition to cryptographic verification. A publisher can sign vulnerable or incompatible software, so those checks serve separate purposes.


T08: "o1"

Historical signatures are verified with the corresponding trusted public key and associated records. The new key, unauthenticated hashes, or a new shared-key check does not preserve verification of the original publisher signature.


References: 

## SEC2-PBQ-003 — Investigate a switched-network impersonation event


A single IPv4 office VLAN suddenly routes some workstations through an unauthorized device. The topology, addresses, and switch-port mappings below were verified before the incident. All clients use DHCP; the gateway's fixed binding is separately approved. No gateway replacement, redundancy change, or authorized DHCP server on an endpoint port is expected. The access switch can quarantine a confirmed unauthorized endpoint port and enforce validated address bindings.

### Baseline and observed state


| Object | IP | Approved MAC | Switch port |
| --- | --- | --- | --- |
| Gateway | 192.0.2.1 | 02:00:00:00:00:01 | 1, infrastructure uplink |
| Workstation Larch | 192.0.2.35 | 02:00:00:00:00:35 | 7 |
| Unauthorized device | 192.0.2.66 | 02:00:00:00:00:66 | 12 |

Larch's ARP entry for 192.0.2.1 changes to 02:00:00:00:00:66 after an unsolicited ARP message. The switch still learns that MAC on port 12. A capture also shows DHCP offers arriving from port 12. Authorized DHCP responses enter through port 1. DNS answers remain unchanged.

### Control capabilities


The switch's DHCP protection can permit server responses only on designated infrastructure ports. Its address-validation feature can reject ARP messages inconsistent with approved DHCP-derived or static bindings. The analyst is authorized to quarantine the identified unauthorized endpoint while preserving port and packet evidence.

### T01


Identify the manipulation supported by the changed gateway mapping.

- o1: VLAN hopping

- o2: Switch MAC-table exhaustion

- o3: ARP poisoning

- o4: DNS cache poisoning

### T02


Choose the switch port most directly associated with the suspicious source.

- o1: Port 12

- o4: Every access port, since ARP is broadcast on the VLAN

- o3: Port 1

- o2: Port 7

### T03


Choose the narrow containment action supported by the authority and evidence.

- o1: Move the entire VLAN to a replacement DNS service

- o2: Quarantine the endpoint port and preserve its evidence

- o3: Change the workstation's address while keeping the port active

- o4: Disable the infrastructure uplink and preserve its evidence

### T04


Choose the DHCP-server-response trust setting for this topology.

- o1: Trust every port because clients need DHCP

- o2: Trust port 12 because it recently sent an offer

- o3: Trust only the workstation access ports

- o4: Trust only port 1 for DHCP server responses

### T05


Choose the feature that directly blocks the observed address-claim manipulation.

- o1: Rate-limit broadcast traffic without validating address claims

- o2: Enable DHCP-server-response protection without validating ARP claims

- o3: Validate ARP claims against approved IP/MAC/port bindings

- o4: Limit the number of learned MAC addresses on each port

### T06


Choose the transport protection that limits credential exposure if traffic is observed along its path.

- o1: An address allowlist that trusts the advertised gateway binding

- o2: Encryption without verifying the remote service identity

- o3: Authenticated TLS with peer validation

- o4: Password hashing at the destination storage system only

### T07


Select the expected gateway ARP binding when validating recovery.

- o4: 192.0.2.66 to 02:00:00:00:00:01

- o1: 192.0.2.1 to 02:00:00:00:00:01

- o3: 192.0.2.1 to 02:00:00:00:00:66

- o2: 192.0.2.1 to 02:00:00:00:00:35

### T08


Choose the conclusion justified without inspecting application traffic.

- o1: The device owner personally generated the suspicious packets

- o2: The affected workstation executed a malicious program

- o3: A device advertised the wrong gateway association; credential theft is not established

- o4: The workstation transmitted a reusable credential to the unauthorized device

T01: "o3"

The IP-to-MAC association for the gateway changed after an unsolicited ARP message, while DNS and the approved gateway remain unchanged. That evidence supports ARP poisoning.


T02: "o1"

The suspicious MAC is learned on port 12, and the unexpected DHCP offers also arrive there. Port 7 is the affected workstation, while port 1 is the approved infrastructure uplink. Broadcast reach does not make every port the source; the switch learned the offending MAC on a single port.


T03: "o2"

The evidence identifies the unauthorized endpoint port. Quarantining it removes that source while avoiding an unnecessary infrastructure-wide outage and preserving useful evidence.


T04: "o4"

Only the infrastructure uplink is an approved source of DHCP server responses. Clients can request addresses without their access ports being trusted to supply server responses.


T05: "o3"

Binding validation checks the claimed address association against trusted state. DHCP-response protection, learned-address limits, and broadcast-rate limits serve useful purposes but do not validate this particular ARP claim.


T06: "o3"

Authenticated encryption protects credential contents in transit even if an intermediary can observe packets. It complements correction of the local network compromise.


T07: "o1"

The approved fixed gateway binding is the one recorded in the baseline. The other displayed MAC addresses belong to the unauthorized endpoint and the affected client. 192.0.2.66 is the unauthorized device's address; the gateway MAC must map to the gateway IP 192.0.2.1.


T08: "o3"

The records show address impersonation and an unauthorized server-response source. They do not establish application contents, endpoint execution, a human actor, or actual credential theft.


References: 

## SEC2-PBQ-004 — Select defenses from three service-availability dashboards


Three services report availability problems. Use the measured bottleneck for each service, not a single response for every event. Traffic figures are application observations from the same interval. The edge team can request upstream traffic scrubbing, enable the documented connection protections, and configure application quotas. No traffic-generation or attack execution is part of this exercise.

### Dashboard snapshots


| Case | Observations |
| --- | --- |
| A | 70,000 inbound TCP SYNs/second, 20 completed handshakes/second, nearly full half-open connection table; link and application CPU below capacity. |
| B | A 1,000 Mb/s access link receives 980 Mb/s of mostly unsolicited UDP DNS responses from many resolvers; no matching client queries exist. The link saturates before the on-site firewall can discard traffic. |
| C | Normal request count, but repeated expensive export requests consume nearly all application CPU. Other request types are fast when export work is paused. |

For headroom arithmetic, use 1,000 minus 980 Mb/s and ignore protocol overhead. A device can support SYN-cookie-style validation before allocating the protected connection state. The application supports per-identity export quotas and bounded job queues.

### T01


Classify the most directly supported pattern in Case A.

- o1: SYN flood targeting connection state

- o2: Storage-capacity exhaustion

- o3: DNS response amplification traffic

- o4: An authorized DNS zone transfer

### T02


Choose the most targeted available protection for Case A.

- o1: Limit only requests received after completed handshakes

- o2: Keep half-open state for a longer connection timeout

- o3: Reduce the allowed duration of established application sessions

- o4: Validate handshake completion before allocating protected state

### T03


Choose the best placement for filtering Case B traffic.

- o1: Filter at the on-site edge after the access link

- o2: Filter on the destination application server

- o3: Filter between the internal server and database networks

- o4: Scrub or filter unwanted traffic upstream of the constrained access link

### T04


Choose the most direct available control for Case C.

- o1: Apply export quotas and bounded processing queues

- o2: Increase the maximum number of concurrent export jobs

- o3: Extend export execution timeouts without bounding job admission

- o4: Prioritize every export above interactive application work

### T05


How much nominal access-link headroom remains in Case B, in Mb/s?

### T06


What can the many DNS response source addresses establish by themselves?

- o1: They identify apparent response sources, which may be reflectors rather than original attackers

- o2: They identify the affected users who requested the traffic

- o3: They identify the original attacking hosts

- o4: They establish that the traffic is legitimate because resolvers sent it

### T07


Select TWO checks for validating the selected protections. (Select TWO.)

- o1: The specific constrained resource returns to an acceptable level

- o2: An analyst manually lowered the alert severity

- o3: Legitimate clients can complete representative service requests

- o4: The approved rule file is present in the configuration repository

- o5: The mitigation request was acknowledged by the provider

### T08


A proposed second ingress path must avoid the existing access-link bottleneck. Choose the most relevant design evidence.

- o1: A successful start of another replica behind the current link

- o2: Verified carrier routing, physical path diversity, and usable ingress capacity

- o3: The aggregate CPU capacity of application replicas

- o4: The presence of a second DNS name for the application

T01: "o1"

Many starts but very few completed TCP handshakes fill half-open state while bandwidth and CPU are available. That pattern identifies the connection-state bottleneck.


T02: "o4"

The provided feature targets half-open state allocation. Longer half-open retention worsens the pressure, while established-session and application-request limits act after the failing handshake stage.


T03: "o4"

Filtering after the narrow link cannot recover bandwidth already consumed on that link. Upstream mitigation removes unwanted volume before it reaches the bottleneck.


T04: "o1"

The expensive job workload is consuming application CPU. Quotas and bounded queues constrain that resource use without treating all ordinary requests as malicious.


T05: 20

The supplied arithmetic is 1,000 minus 980, leaving 20 Mb/s of nominal headroom before the excluded overhead.


T06: "o1"

Reflection can make legitimate servers the apparent source of unwanted responses. Source addresses in this traffic do not by themselves identify the original party that induced the responses.


T07: ["o3", "o1"]

Validation needs both restored legitimate service and evidence that the actual bottleneck improved. Configuration inventory and ticket metadata alone do not establish those results.


T08: "o2"

A second name or backend replica can still use the same constrained ingress. Path and capacity evidence is needed to establish that the proposal actually bypasses that bottleneck.


References: 

## SEC2-PBQ-005 — Investigate abuse of a trusted script interpreter


A workstation permits a signed system script interpreter because approved administration depends on it. Two execution chains are recorded below. The interpreter binary's signature and hash match the approved operating-system copy. Security has not yet determined what data, if any, left the workstation. Use process context and the approved-change record to complete the investigation fields.

### Process and task evidence


```text
CHAIN J1: scheduler -> signed script interpreter -> inventory query
          account=svc-inventory; script=approved-inventory; change=CHG-81
          destination=192.0.2.80; scheduled daily at 06:00
CHAIN J2: document viewer -> signed script interpreter -> in-memory script
          account=ordinary user; change=none; destination=203.0.113.202
          input=encoded text; newly created task=UserUpdate
TASK UserUpdate: runs the same J2 script under the user account at each sign-in
```

CHG-81 authorizes the daily inventory job to 192.0.2.80. Policy does not authorize documents to launch script interpreters or create sign-in tasks. Process-linked connection records associate the external connection with J2. The responder may block the unapproved parent-child execution pattern while retaining the inventory job.

### T01


Choose the execution chain requiring investigation under the policy.

- o1: Both are equally unsupported by the supplied approval record

- o2: J2 only

- o3: Neither, because the interpreter is signed

- o4: J1 only

### T02


What do the validated publisher signature together with the hash matching the approved OS baseline establish about the interpreter binary?

- o1: Verification that the interpreter binary is the approved copy

- o2: Integrity of the newly created scheduled-task definition

- o3: Approval of the external destination used during execution

- o4: Authorization of the encoded script supplied to the interpreter

### T03


Choose the record that most directly associates the external connection with an execution chain.

- o1: DNS query records without process ownership information

- o2: The approved-software inventory and interpreter file hash

- o3: Process-linked network telemetry identifying the responsible execution chain

- o4: Aggregated interface counters without process ownership information

### T04


Choose the narrow preventive rule matching the stated authority.

- o1: Block unauthorized document-viewer-to-interpreter launches while preserving the approved job

- o2: Remove the interpreter from every managed system

- o3: Allow every interpreter execution whenever its binary is signed

- o4: Allow any interpreter launch made under an authenticated employee account

### T05


Choose the additional telemetry most useful for understanding the in-memory script actions.

- o1: Available interpreter/script execution logging with process correlation

- o2: The signed-binary catalog for installed system tools

- o3: The endpoint software inventory without execution records

- o4: Network-flow metadata without application content

### T06


Select the persistence artifact supported by the records.

- o1: The newly created UserUpdate sign-in task

- o2: The approved interpreter executable existing on disk

- o3: The preapproved inventory server address

- o4: The mere presence of a document viewer

### T07


Choose an appropriate handling plan for the persistence mechanism identified from the evidence.

- o1: Suspend the scheduling service for both approved and unapproved tasks

- o2: Capture the task definition and disable its trigger under the response plan

- o3: Preserve the task and leave its trigger active because the interpreter is signed

- o4: Rename the task and keep the same trigger and execution settings

### T08


Choose the strongest conclusion supported about the external activity.

- o1: The external service delivered an executable file to the workstation

- o2: The script uploaded confidential documents to the external service

- o3: The unapproved execution chain made an external connection; transferred content is not established

- o4: The connection identifies the person who authored the script

T01: "o2"

J2 lacks an approved change and crosses the prohibited document-to-interpreter boundary. J1 matches the documented task, service identity, schedule, and destination.


T02: "o1"

The validated signature and matching hash establish only that the interpreter binary is the approved, unmodified operating-system copy. A trusted signed program can run malicious or unauthorized instructions. Its binary provenance does not authenticate the intent or safety of arbitrary script input.


T03: "o3"

A connection record linked to the responsible process ties the network event to J2. DNS records, aggregated interface counters, and binary inventory without process ownership do not establish that association.


T04: "o1"

The authorized rule targets the prohibited execution relationship without breaking the approved inventory use. A binary-signature allowlist alone does not constrain that relationship.


T05: "o1"

Interpreter execution telemetry can expose actions that are not represented by a downloaded executable file. Correlating it with the process chain connects the content to the event.


T06: "o1"

The task is configured to run the unapproved script at subsequent sign-ins, establishing a persistence mechanism. The ordinary presence of legitimate software does not establish persistence by itself.


T07: "o2"

Preserving the task definition records the mechanism before disabling repeat execution. Its use of a signed interpreter does not make the unapproved trigger and action legitimate.


T08: "o3"

The connection is tied to the unapproved chain, but its contents are not supplied. Connection metadata alone does not establish a document upload, executable download, or human authorship.


References: 

## SEC2-PBQ-006 — Evaluate a container release before promotion


A team will promote a containerized document-conversion service. The service must read uploaded documents and write results under /work; it does not administer its host. The registry permits mutable tags. Treat DIG-A and DIG-B as complete content digests. Review the image and runtime evidence together; a scan of one artifact does not automatically cover a different artifact.

### Release evidence


| Record | Observation |
| --- | --- |
| Registry yesterday | converter:release pointed to DIG-A |
| Registry now | converter:release points to DIG-B |
| Scan R-1 | Assessed DIG-A; no applicable high-priority findings |
| Scan R-2 | Assessed DIG-B; one applicable dependency fix required |
| Layer inspection | A production API key was copied into an earlier image layer, then deleted in a later layer; authorized inspection can recover it from the earlier layer. |
| Runtime draft | Privileged mode enabled; host runtime-management socket mounted; entire root filesystem writable. |

In this environment, the host runtime-management socket grants control over host containers. The service has no business need for it. Running containers are replaced from the image during every rollout.

### T01


Choose the report applicable to the artifact currently referenced for release.

- o1: R-2, because its assessed content digest matches the current artifact

- o2: R-1, because it used the same tag name yesterday

- o3: Neither report can identify its assessed artifact

- o4: Either report, because tags identify immutable content

### T02


Choose the reference that makes the reviewed artifact explicit during deployment.

- o1: Use only the repository name

- o2: Use the image creation date without its digest

- o3: Pin the reviewed content digest

- o4: Use the moving latest tag

### T03


Choose the response to the exposed image-layer credential.

- o1: Delete the key only from the final visible filesystem

- o2: Retag the existing image without rebuilding

- o3: Change the final file permissions while preserving the exposed layer

- o4: Revoke or rotate the exposed key and rebuild without including it in image layers

### T04


Choose the appropriate runtime-management socket setting.

- o1: Keep the socket mount and rely on a read-only file flag to limit API operations

- o2: Expose the socket only while each conversion worker starts

- o3: Remove the host runtime-management socket mount

- o4: Keep the socket and document that application code should not use it

### T05


Choose the privilege setting that matches the service requirements.

- o1: Retain privileged mode for troubleshooting convenience

- o2: Reuse the deployment administrator credentials at runtime

- o3: Run in the host administrator context

- o4: Use a non-root identity with only required capabilities

### T06


Choose the durable way to apply the dependency fix.

- o1: Patch one running container without changing the image

- o2: Rebuild from a fixed dependency, assess the new digest, and redeploy it

- o3: Update the build manifest while continuing to deploy the cached image

- o4: Refresh the scanner vulnerability database without rebuilding the image

### T07


Choose the filesystem policy that meets the stated file-write need.

- o1: Use a read-only root filesystem with controlled writable /work storage

- o2: Mount the host root filesystem as the workspace

- o3: Make /work read-only without changing the application

- o4: Make every filesystem path writable

### T08


Select the most complete promotion evidence.

- o1: A familiar tag and a successful container start

- o2: Assessment of the exact image plus validation of the intended restricted runtime

- o3: The previous digest scan and current image size

- o4: A publisher signature without examining identified dependencies or privileges

T01: "o1"

R-2 identifies the current digest DIG-B. The tag moved, so the earlier report for DIG-A does not establish the state of the artifact now being promoted.


T02: "o3"

A content-digest reference identifies the specific reviewed image. A mutable tag, repository name, or timestamp is not an equivalent content identity.


T03: "o4"

Later deletion does not remove a secret recoverable from an earlier layer. The credential must be treated as exposed, and the build process must stop embedding it.


T04: "o3"

The application has no need for the host administration API. Removing that capability addresses the boundary; temporary exposure, coding convention, or a file-view flag does not establish the required API restriction.


T05: "o4"

Document conversion needs bounded file access, not host administration. A restricted runtime identity reduces the authority available if untrusted input compromises the service.


T06: "o2"

A replacement container inherits its image. Updating and assessing the deployment image makes the fix survive normal recreation; changing a running instance or assessment metadata does not update that deployed artifact.


T07: "o1"

The service needs a specific output workspace. Restricting writes to that area limits unnecessary changes without breaking the required job.


T08: "o2"

Image content and runtime authority are separate contributors to risk. Promotion should cover the exact artifact and the configuration in which it will process untrusted documents.


References: 

## SEC2-PBQ-007 — Place controls at application data-flow boundaries


A personnel application is accessed through an edge broker. The broker terminates client TLS, authenticates users, evaluates per-resource policy, and forwards approved requests. The application network crosses a shared provider network, so the company requires authenticated encryption on that hop too. Assess the marked flow segments and proposed control placements.

### Flow and visibility


| Segment | Current path | Protection |
| --- | --- | --- |
| A | Client to edge broker | Authenticated TLS |
| B | Edge broker to application | Plain HTTP over the shared network |
| C | Application to database | Authenticated TLS |

Sensor S1 passively observes segment A before TLS termination and has no decryption keys. Inspection point S2 operates inside the broker after authorized decryption. The application should accept requests only through the broker. Public clients can supply an X-User header, and the broker currently forwards that value unchanged.

### Policy decision sample


A user has successfully authenticated as a contractor. Policy allows contractors to read their own task list but forbids payroll access. The policy decision component evaluates identity, device context, resource, and action. A separate enforcement component applies its permit or deny result to the request.

### T01


Select the segment that fails the stated transport requirement.

- o1: Segment C

- o2: Segment A

- o3: Segment B

- o4: None of the segments

### T02


Choose the repair for the segment identified in T01.

- o1: Use authenticated TLS on that hop with destination-service validation

- o2: Authenticate the broker at the application while retaining plaintext requests

- o3: Strengthen only the client-to-broker cipher configuration

- o4: Use private addresses over the shared network without adding transport protection

### T03


Choose the application-content visibility available to S1 as configured.

- o1: Read request and response bodies after checking the TLS certificate

- o2: Identify the authenticated application role from the TCP session

- o3: Recover policy decisions from the packet timestamps

- o4: Observe flow metadata without reading encrypted bodies

### T04


Choose the point suitable for authorized inspection of request content before application forwarding.

- o3: S1 before client TLS termination

- o1: S2 after broker decryption and before forwarding

- o4: The policy decision component, using its permit or deny results

- o2: A passive packet mirror of encrypted segment C

### T05


Assign the component that must actually stop a denied request.

- o1: Policy decision engine

- o2: Asset inventory service

- o3: Audit-log archive

- o4: Policy enforcement point

### T06


Apply the supplied contractor policy to a payroll request.

- o1: Permit it while recording a warning

- o2: Deny it because the requested resource is outside the authorized policy

- o3: Permit it whenever it originates on a company network

- o4: Permit it because authentication succeeded

### T07


Choose the application ingress policy that preserves broker enforcement.

- o1: Limit application request ingress to the authenticated broker path

- o2: Publish the application interface alongside the broker

- o3: Rely on keeping the application hostname out of public DNS

- o4: Allow clients to bypass the broker if they know the application address

### T08


Choose the handling of the client-supplied identity header.

- o1: Remove the untrusted value and set verified identity context through the trusted broker channel

- o2: Trust the supplied value whenever the application sees a private source address

- o3: Trust the supplied value after length and schema validation

- o4: Preserve the supplied value whenever the front-end TLS connection is valid

T01: "o3"

Segment B carries HTTP across the shared network. The other marked segments already use authenticated TLS.


T02: "o1"

Transport security must cover the hop carrying the data across the shared network. Securing another hop, authenticating without encryption, or using private addresses does not meet that transport requirement.


T03: "o4"

A passive observer without the decryption material cannot read TLS-protected application content. Visibility is limited to the metadata available at its observation point.


T04: "o1"

S2 is placed where the broker has legitimately decrypted the request. The passive points on encrypted segments lack the needed plaintext request content. The decision component evaluates identity, device, resource, and action attributes; it does not inspect request content.


T05: "o4"

The decision engine determines policy outcome; the enforcement point applies that outcome to traffic or access. Logging a denial alone does not stop the request.


T06: "o2"

Authentication establishes identity, while authorization governs the requested action on a resource. The explicit contractor policy denies payroll access.


T07: "o1"

The application should not accept an alternative client path that bypasses the broker decision and enforcement. A hidden hostname alone is not an access boundary.


T08: "o1"

The client controls its submitted header. TLS, input formatting, and private addressing do not establish the claimed user; the broker must derive identity from the authenticated session.


References: 

## SEC2-PBQ-008 — Choose execution models for a burst-processing service


A research organization compares offered execution models. Select a model or control for each workload using the explicit constraints. All offered services can be configured in an approved data location; this exercise concerns execution limits, isolation, connectivity, and operations rather than region selection.

### Offered models


| Model | Characteristics |
| --- | --- |
| Functions | Provider-managed OS; scales to zero; cold start up to 20 seconds; maximum execution five minutes; local scratch disappears afterward. |
| Shared-kernel containers | Fast startup and per-container process isolation; containers on a host share its kernel. |
| Virtual machines | Separate guest kernels; guest can load approved custom kernel modules; capacity can be kept running. |
| Local edge workers | Preprovisioned workers that can process locally without the WAN. |

Workload F is stateless, takes 40 seconds, arrives sporadically, and tolerates a one-minute startup delay. Workload K requires a custom guest kernel module and runs for 20 minutes. Untrusted extension jobs require separate guest-kernel boundaries. Branch acquisition must continue when the WAN fails. A new interactive workload later requires first responses in under one second.

### T01


Choose the model most directly matching F while avoiding continuously running capacity.

- o1: Functions

- o2: Virtual machines

- o3: Local edge workers

- o4: Shared-kernel containers

### T02


Choose the hosted model that supports K under the offered constraints.

- o1: Virtual machines

- o2: Local edge workers

- o3: Shared-kernel containers

- o4: Functions

### T03


Choose the offered hosted isolation boundary for the untrusted extensions.

- o1: Functions

- o2: Virtual machines

- o3: Shared-kernel containers

- o4: Local edge workers

### T04


Choose the model that directly supports branch processing during a WAN outage.

- o1: Local edge workers

- o2: Shared-kernel containers

- o3: Functions

- o4: Virtual machines

### T05


Which component remains common across the offered container isolation boundaries?

- o1: Each container's isolated process namespace

- o2: Each container's application configuration

- o3: The host kernel

- o4: A separate guest kernel inside each container

### T06


Choose the logging design for function execution records that must survive completion.

- o1: Keep all audit records only in disposable local scratch

- o2: Retain records only in function memory

- o3: Send required execution records to approved durable centralized storage

- o4: Assume a successful return value preserves the full audit trail

### T07


Evaluate an unmodified scale-to-zero function configuration for the new subsecond interactive requirement.

- o1: Its documented cold-start behavior can violate the first-response requirement

- o2: Its startup behavior fits the specified first-response limit

- o3: It fits because the five-minute execution limit exceeds one second

- o4: It fits once the one-second limit is measured after startup completes

### T08


Choose a design change that directly addresses that first-response constraint.

- o1: Measure only completed-job processing time and exclude startup

- o2: Use preprovisioned running capacity that is validated against the latency requirement

- o3: Raise the client timeout without changing startup behavior

- o4: Require clients to retry until a cold worker starts

T01: "o1"

F fits the supplied duration and startup limits, is stateless, and benefits from scaling to zero. The other models can run work but do not directly supply the stated no-idle-capacity behavior.


T02: "o1"

K requires a custom guest kernel module and exceeds the function execution limit. The offered virtual machine model supports a separate configurable guest kernel.


T03: "o2"

The explicit requirement is separate guest kernels. Shared-kernel container isolation is not equivalent to that specified boundary.


T04: "o1"

The local edge workers do not depend on the WAN for the described processing. A cloud service may be available while still unreachable from the disconnected branch.


T05: "o3"

Containers in the offered model share the host kernel. A host-kernel issue can affect multiple workloads even when their process namespaces and application configuration differ.


T06: "o3"

The function scratch environment is explicitly temporary. Durable external logging preserves the required execution evidence beyond the lifetime of a worker.


T07: "o1"

First-response latency includes startup. The offered cold-start bound exceeds the new limit, so the unmodified configuration cannot assure that requirement. The execution limit is unrelated to startup delay, and excluding the cold start from the measurement ignores what the user actually waits for.


T08: "o2"

Keeping suitable capacity ready removes the documented scale-from-zero delay from the expected first-request path. The resulting latency still needs representative validation.


References: 

## SEC2-PBQ-009 — Preserve encrypted-backup recovery through key rotation


A backup system uses two key layers. A data-encryption key (DEK) encrypts an object. A key-encryption key (KEK) wraps that DEK for storage. Object metadata names the KEK required to unwrap its DEK. Rewrapping a DEK under another KEK changes the protected key metadata, not the already encrypted object contents. Use this supplied model to assess a rotation plan.

### Key and object inventory


| Item | Dependency or state |
| --- | --- |
| Old backups B1–B90 | DEKs are wrapped by KEK-OLD; backups remain required for recovery. |
| Recent backups B91–B95 | DEKs are wrapped by KEK-NEW. |
| KEK-OLD | Disabled for new wrapping; authorized recovery can still unwrap. |
| KEK-NEW | Active for new backups. |
| Proposed cleanup | Destroy KEK-OLD tomorrow without migrating or testing old backup dependencies. |

Backup storage administrators must not independently control recovery-key access. The recovery test environment can restore an old object using the documented key references. A separate hypothetical incident confirms that an attacker obtained the plaintext DEK for one object, not merely its wrapped copy.

### T01


Evaluate the proposed cleanup while old backups are still required.

- o1: Destroy it after setting the historical backups to read-only

- o2: Defer destruction until required dependencies are migrated or expired and recovery is verified

- o3: Destroy the old key after successfully restoring a newly created backup

- o4: Destroy it after copying the same wrapped DEKs to another disk

### T02


Choose the migration that can move a required old object to KEK-NEW without changing its existing data ciphertext.

- o1: Copy the existing wrapped DEK into a vault named for KEK-NEW

- o2: Change the KEK reference without transforming the wrapped DEK

- o3: Decrypt and re-encrypt the entire object under a different DEK

- o4: Unwrap and rewrap its DEK through the authorized key service

### T03


Choose the appropriate continuing permission on KEK-OLD before migration completes.

- o1: Allow backup readers to invoke key operations without the separate approval

- o2: Restrict its remaining use to approved recovery and migration operations

- o3: Suspend unwrapping until the required historical objects are migrated

- o4: Return it to the default for new backups during migration

### T04


Choose the access boundary matching the administrator separation requirement.

- o1: Use separately authorized key access with audited recovery approvals

- o2: Give each storage administrator a second account for self-approving key access

- o3: Let storage administrators approve their own logged recovery-key requests

- o4: Encrypt key-access credentials under a password controlled by storage administrators

### T05


Choose the strongest pre-destruction recovery evidence.

- o1: Restore representative historical objects using the migrated key access

- o2: Restore the newest backup using only the new key access

- o3: Compare ciphertext sizes before and after the key rotation

- o4: Verify that the rotation ticket was marked complete and approved

### T06


In the hypothetical plaintext-DEK exposure, choose the corrective action for future protection of the affected object.

- o1: Make the encrypted object read-only while retaining the existing DEK

- o2: Rotate repository login credentials while retaining the existing DEK

- o3: Only wrap the exposed DEK under a different KEK

- o4: Encrypt the affected data under a fresh DEK and protect that key appropriately

### T07


Choose the audit event most useful for detecting unauthorized use of historical keys.

- o1: Configuration changes and the administrators who made them

- o2: Inventory of enabled keys and their rotation dates

- o3: Key creation time, region, and service principal

- o4: Old-key unwrap requester, target object, and policy decision

### T08


Choose additional evidence needed to retire KEK-OLD once migration tests succeed.

- o1: Historical objects remain encrypted in the repository

- o2: The key service records successful recent backup operations

- o3: New backup jobs select the replacement key

- o4: The dependency inventory shows no required object still needs KEK-OLD

T01: "o2"

Existing required backups still depend on KEK-OLD. A new-object restore, storage permission, or copy does not remove the key dependency of historical objects.


T02: "o4"

The supplied envelope model allows the same DEK to be protected under a new KEK while preserving data ciphertext. Renaming or copying does not rewrap a key, and whole-object re-encryption changes the ciphertext.


T03: "o2"

The key remains necessary for controlled historical recovery and migration. Limiting its allowed operations preserves that use without making it the default for new work or removing required authorization.


T04: "o1"

Separate authorization prevents storage administration alone from granting decryption authority. Additional accounts, logs, or credentials controlled by the same authority do not create independent approval.


T05: "o1"

The risk concerns historical objects that depended on the retiring key. A representative old-object restore tests those dependencies rather than only current backup creation.


T06: "o4"

Rewrapping does not change an exposed plaintext DEK. Future copies need a fresh data key and appropriate handling of the compromised material; historical attacker copies cannot be made secret retroactively.


T07: "o4"

Key-operation logs show identity, object, action, and decision at the relevant decryption boundary. Inventory and configuration records are useful but do not establish who performed an unwrap.


T08: "o4"

Representative restore tests validate the migration mechanism; the inventory must also establish that no required object retains the retiring dependency. Successful new backups alone do not prove coverage of historical objects.


References: 

## SEC2-PBQ-010 — Find continuity gaps after a compute failover


A service passed a test that started replacement virtual machines, but users still could not work during a site outage. Review the dependencies and capacity assumptions. Each application node can sustain 250 requests/second at the required latency. Peak demand is 500 requests/second. Required resilience is enough capacity after any one application node fails; assume load can distribute evenly and no other compute bottleneck.

### Current continuity design


Two application nodes are running at Site B. A copied database is available there. Authoritative internal DNS and the identity provider exist only at Site A. Site A and Site B currently share the same regional utility and flood zone.

The last test checked virtual-machine power state and a load-balancer TCP port; it did not perform user sign-in or application transactions. Operations now wants a live standby capacity test without interrupting production. A discussion-only exercise is also proposed for reviewing communication responsibilities.

### T01


What is the minimum number of these application nodes needed to meet peak demand after one node fails?

### T02


Evaluate the existing application-node count against the resilience requirement.

- o4: It meets peak capacity after one node fails but not during normal operation

- o1: It meets peak capacity both normally and after one node fails

- o3: It meets ordinary peak capacity but not peak capacity after one node fails

- o2: It cannot meet peak capacity even when both nodes are available

### T03


Select TWO non-compute services whose current placement can block Site B operation during a Site A outage. (Select TWO.)

- o1: The tested Site B load-balancer listener alone

- o2: The application nodes already running at Site B

- o3: The identity provider

- o4: The database copy already available at Site B

- o5: Authoritative internal DNS

### T04


Choose the health check that best covers the missing user-facing dependency chain.

- o1: Verify a TCP connection to the standby load balancer

- o2: Complete a sign-in and transaction through the standby path

- o3: Confirm a recent backup artifact exists on the standby system

- o4: Verify the standby virtual machines are running

### T05


Choose the exercise type best suited to testing live standby capacity without interrupting production.

- o1: A full production interruption without the requested continuity

- o2: A discussion-only tabletop exercise

- o3: A parallel test using the standby environment and controlled workload

- o4: A document review without operating standby resources

### T06


Choose the most appropriate purpose for the proposed discussion-only exercise.

- o1: Walk through decisions, communications, and assigned responsibilities

- o2: Prove the exact maximum standby throughput

- o3: Measure actual network latency during a regional outage

- o4: Prove that all backup data can be restored

### T07


Choose the design change that addresses the stated shared regional failure exposure.

- o1: Move the two environments into different racks in the same flood zone

- o2: Use separate application VLANs within the current regional locations

- o3: Use a suitably independent location with validated dependencies and connectivity

- o4: Create another local disk mirror at Site A

### T08


Choose the strongest capacity-test evidence for the resilience requirement.

- o1: All standby nodes start while idle

- o2: Peak representative load meets the latency target while one node is unavailable

- o3: The inventory lists more virtual machines than before

- o4: Average utilization is low during an ordinary quiet period

T01: 3

Two surviving nodes provide 500 requests/second. Therefore three nodes are needed so that any single failure still leaves two.


T02: "o3"

The existing design has capacity for the stated load before a node failure. Losing one node leaves less capacity than peak demand, so normal sizing alone is insufficient. Capacity can only decrease when a node is lost, so a design cannot satisfy the degraded case while failing the normal case.


T03: ["o5", "o3"]

Both named services exist only at Site A and are required by users or applications. Starting compute at Site B does not make those dependencies independently available.


T04: "o2"

An end-to-end sign-in and transaction exercises more of the necessary DNS, identity, application, and data path. Power and port checks can succeed while the service remains unusable.


T05: "o3"

A parallel exercise can operate the standby environment with a controlled workload while production continues. A discussion or document review cannot measure actual standby capacity.


T06: "o1"

A tabletop exercise is useful for practicing roles and decisions. Physical capacity, latency, and data restoration need execution or other technical testing evidence.


T07: "o3"

Geographic and infrastructure diversity can reduce common regional failure exposure. Local rack, network, or storage separation does not remove the shared flood and utility dependency.


T08: "o2"

The requirement is specifically about peak demand with a node unavailable. Testing that condition provides direct evidence instead of relying on idle startup or average-load observations.


References: 

## SEC2-PBQ-011 — Validate a one-way telemetry boundary


A treatment plant must export telemetry while preventing enterprise systems from sending network commands into the control environment. The selected transfer appliance has protocol relays on each side and enforces payload flow only from the control side to the enterprise side. Each relay handles its own local protocol acknowledgements; no reverse payload channel is provided. Maintenance uses a separately controlled offline process, not this link.

### Proposed flows


| Flow | Source | Destination | Purpose |
| --- | --- | --- | --- |
| F1 | Control historian | Enterprise analytics collector | Periodic measurement batches |
| F2 | Enterprise dashboard | Control historian | Live request to retrieve an older record |
| F3 | Control alarm exporter | Enterprise notification receiver | Event notification batch |
| F4 | Enterprise administrator | Control device | Remote management command |

The enterprise collector is exposed to more external content than control equipment. Analytics can work from scheduled snapshots, but its developers propose adding a callback API into the control network. The collector parser handles exported files and must remain hardened against malformed input.

### T01


Evaluate F1.

- o3: Not permitted until a reverse acknowledgement channel is added

- o1: Permitted by this directional design

- o2: Not permitted by this directional design

- o4: Not permitted because the historian stores older records

### T02


Evaluate F2.

- o3: Permitted because the historian only returns a read-only record

- o4: Permitted if the request is sent through the maintenance process

- o1: Permitted by this directional design

- o2: Not permitted by this directional design

### T03


Evaluate F3.

- o2: Permitted by this directional design

- o3: Not permitted because alarm events are not periodic measurements

- o1: Not permitted by this directional design

- o4: Permitted only if the enterprise receiver can request retransmission

### T04


Evaluate F4.

- o3: Permitted because administrators are trusted enterprise users

- o2: Not permitted by this directional design

- o4: Permitted if the command is sent as a signed batch

- o1: Permitted by this directional design

### T05


Choose the analytics design that preserves the boundary.

- o1: Export scheduled snapshots sufficient for the approved analytics use

- o2: Create a bidirectional tunnel around the appliance

- o3: Add the proposed enterprise-to-control callback API

- o4: Permit dashboard users to query control devices directly

### T06


If the enterprise collector is compromised, what protection does this link specifically provide?

- o1: Prevention of reverse payload commands through this one-way link

- o2: Authentication of the human operator for each exported record

- o3: Filtering of malformed telemetry before application parsing

- o4: Encryption of historical records in the enterprise repository

### T07


Choose the receiving-side design that addresses malformed exported data.

- o1: Validate file structure and process it in a restricted parser context

- o2: Use a familiar filename extension as the file-validation decision

- o3: Accept file content without parser validation whenever its signature verifies

- o4: Retry failed parsing in the collector administrator context

### T08


Choose the most direct boundary test plan.

- o1: Review the intended directional policy without exercising the link

- o2: Check that each relay starts without testing traffic across the appliance

- o3: Verify approved outward transfers and attempts to send reverse payloads through this link

- o4: Verify only that an outward batch arrives

T01: "o1"

F1 exports historian data from the control side to the enterprise side, which is the allowed payload direction. Each relay acknowledges locally, so no reverse channel is needed, and the historian's stored data does not change the outward direction of F1.


T02: "o2"

F2 requires an enterprise-originated request into the control environment. The design does not provide a reverse payload path. A read request is still an inbound payload into the control side, and the offline maintenance process is explicitly not part of this link.


T03: "o2"

F3 sends an event batch outward from control equipment to an enterprise receiver. That direction matches the boundary requirement. The design limits direction, not content type, and a retransmission request would be a reverse payload the appliance does not provide.


T04: "o2"

Remote management commands would flow from enterprise into control equipment. The required boundary excludes that network direction. User trust and message signing do not create an enterprise-to-control payload path; the appliance blocks that direction regardless of sender.


T05: "o1"

Scheduled outward exports meet the stated analytics capability without creating a reverse access path. A callback or bypass tunnel would change the security boundary.


T06: "o1"

The described appliance enforces the direction of this specific network path. Operator authentication, repository encryption, and payload validation are separate controls not provided by directionality alone.


T07: "o1"

An allowed outward flow can contain malformed data. Input validation and limited parser authority address that risk; provenance and file naming do not establish that content is safe to parse.


T08: "o3"

Testing both the permitted operation and the forbidden direction checks the actual requirement. Outward success, component startup, and intended policy alone do not demonstrate reverse-path enforcement.


References: 

## SEC2-PBQ-012 — Complete a device-admission policy matrix


A research office is replacing a flat access network with policy-based admission. Device authentication and current security posture are separate inputs. Evaluate each connection using the policy below. Network profiles already exist; choose the narrowest permitted profile. A successful employee sign-in does not substitute for the required managed-device evidence.

### Admission policy


| Condition | Required treatment |
| --- | --- |
| Managed device with a valid device identity, supported OS, current patches, and working endpoint protection | Research access permitted |
| Managed device with a valid identity but failed or missing posture evidence | Access only to identity, management, and remediation services |
| Approved visitor with an active sponsor and no managed-device identity | Internet-only visitor access |
| Revoked device identity, or no applicable authorized admission category | Deny network admission |

Posture must be evaluated at connection time and periodically afterward. Remediation access must allow the tools needed to repair a device without exposing research services.

### Connection attempts


| Record | Device identity | Posture or sponsorship |
| --- | --- | --- |
| N1 | Valid managed-device identity | Supported OS, current patches, endpoint protection healthy |
| N2 | Valid managed-device identity | Supported OS, patches overdue, endpoint protection healthy |
| N3 | No managed-device identity | Approved visitor; sponsor active until the end of today |
| N4 | Device identity revoked yesterday | Supported OS, current patches, endpoint protection healthy |

The remediation profile currently allows the management server but blocks its approved update repository. An existing research session later reports that its endpoint protection has stopped. A technician proposes trusting a remembered MAC address instead of reevaluating the posture report.

### T01


Assign the admission result for N1.

- o1: Remediation profile

- o2: Deny admission

- o3: Research profile

- o4: Internet-only visitor profile

### T02


Assign the admission result for N2.

- o1: Deny admission

- o2: Research profile

- o3: Remediation profile

- o4: Internet-only visitor profile

### T03


Assign the admission result for N3.

- o1: Managed research profile

- o2: Internet-only visitor profile

- o3: Restricted remediation profile

- o4: Admission denied

### T04


Assign the admission result for N4.

- o1: Internet-only visitor profile

- o2: Deny admission

- o3: Research profile

- o4: Remediation profile

### T05


Choose the appropriate correction to the remediation profile.

- o1: Permit all research services while updates are downloading

- o2: Permit the approved update repository while retaining required identity and management access

- o3: Retain the profile and classify each device as compliant manually

- o4: Use the visitor profile without management-service access

### T06


Choose the response to the existing session whose endpoint protection stops.

- o1: Keep research access until the employee password expires

- o2: Use the successful initial admission result for the rest of the device lifetime

- o3: Request only another employee sign-in without checking device health

- o4: Reevaluate posture and move the session to the permitted restricted profile

### T07


Assess the proposed remembered-MAC shortcut.

- o1: Use it to replace posture checks while keeping employee authentication

- o2: Use it as sufficient proof of both current identity and posture

- o3: Use it to move every recognized address into the visitor category

- o4: Use it as an inventory clue while retaining the required identity and posture checks

### T08


Choose the strongest focused acceptance test for the admission policy.

- o1: Check that all switch ports establish physical link

- o2: Compare the inventory count with the number of policy records

- o3: Exercise valid, unhealthy, visitor, and revoked cases and verify reachable services for each

- o4: Verify one healthy employee can reach the research application

T01: "o3"

N1 supplies a valid managed identity and meets every current posture requirement. The research profile is permitted by the policy.


T02: "o3"

N2 is a recognized managed device but fails the patch requirement. The remediation profile permits repair without granting research access.


T03: "o2"

The active sponsor and approved visitor status satisfy the visitor category. They do not establish a compliant managed research device.


T04: "o2"

Revocation invalidates the device identity even when its software posture appears healthy. This explicit deny condition takes precedence over the posture observations.


T05: "o2"

The profile must support repair while retaining its limited purpose. Allowing the approved repository fixes the broken dependency without opening the research network.


T06: "o4"

The policy requires periodic posture evaluation. Authentication at the start of a session does not keep a device compliant after its security state changes.


T07: "o4"

A remembered network identifier can help correlate inventory, but it does not establish current patch or endpoint-protection state. The supplied policy still requires those checks.


T08: "o3"

The matrix includes distinct positive and negative decisions. Testing all of them and their effective reachability provides evidence of both permitted access and intended isolation.


References: 

## SEC2-PBQ-013 — Validate a federated sign-in at the service boundary


An archive application accepts signed federation assertions from a configured identity provider. Use the simplified local evaluation rules and supplied validation results; XML parsing and cryptographic calculations are outside this exercise. A valid federation assertion establishes an authenticated identity, while application roles are assigned separately by the local mapping policy.

### Configured acceptance rules


The permitted issuer is `https://id.example/idp`; its verification key is installed through a trusted administrative process. The audience must equal `https://archive.example/sp`. At evaluation time, require `NotBefore <= now < NotOnOrAfter`. Use zero clock-skew allowance for these rows. Reject an assertion ID already consumed by this application. Require every listed check to pass.

The service clock has been independently confirmed as 10:00:00 UTC. All four assertions have valid signatures under the configured provider key and the expected issuer. Their other required fields are valid unless a difference is shown. The replay cache already contains assertion ID `A-104`.

### Assertions and role mapping


| Record | Assertion ID | Audience | NotBefore | NotOnOrAfter |
| --- | --- | --- | --- | --- |
| A | A-101 | https://archive.example/sp | 09:55:00 | 10:05:00 |
| B | A-102 | https://payroll.example/sp | 09:55:00 | 10:05:00 |
| C | A-103 | https://archive.example/sp | 09:55:00 | 10:00:00 |
| D | A-104 | https://archive.example/sp | 09:55:00 | 10:05:00 |

Application mapping: a valid assertion with `archive_access=reader` receives the Reader role. Curator privileges require a separate approved local grant; no such grant exists for user U7. U7's assertion has passed every configured acceptance check. It has `archive_access=reader` and a free-form `job_title=Senior Curator` claim.

A separate assertion E comes from an unconfigured issuer and includes its own public key. An upcoming legitimate provider-key rotation must be enrolled through the existing trusted change process.

### T01


Evaluate assertion A.

- o1: Accept under the supplied checks

- o2: Reject because the assertion ID was already consumed

- o3: Reject because the validity interval check fails

- o4: Reject because the audience check fails

### T02


Evaluate assertion B.

- o1: Reject because the audience check fails

- o2: Accept under the supplied checks

- o3: Reject because the validity interval check fails

- o4: Reject because the assertion ID was already consumed

### T03


Evaluate assertion C.

- o1: Reject because the assertion ID was already consumed

- o2: Accept under the supplied checks

- o3: Reject because the validity interval check fails

- o4: Reject because the audience check fails

### T04


Evaluate assertion D.

- o1: Reject because the assertion ID was already consumed

- o2: Reject because the audience check fails

- o3: Accept under the supplied checks

- o4: Reject because the validity interval check fails

### T05


Choose the handling of assertion E.

- o1: Accept it if it arrived over an encrypted browser connection

- o2: Accept it if its username matches an existing local account

- o3: Accept it if its signature verifies with the public key it supplies

- o4: Reject it unless its issuer and key become trusted through the authorized configuration process

### T06


Assign U7 the role supported by the stated application mapping.

- o1: Reader

- o2: Curator

- o3: Application administrator

- o4: No role because a job-title claim is present

### T07


Choose the durable operational control for reliable validity-interval evaluation.

- o1: Increase every assertion lifetime to avoid time-related rejections

- o2: Monitor and maintain trusted time synchronization on the application and provider

- o3: Skip the interval check whenever the signature is valid

- o4: Use an unverified time value supplied by the browser

### T08


Choose the appropriate enrollment path for the legitimate provider-key rotation.

- o1: Authenticate the replacement key through the change process and test the transition

- o2: Enroll the key when its self-declared provider name matches the existing provider

- o3: Ask a signing-in user to confirm the new provider key before enrollment

- o4: Enroll the first replacement key presented in an incoming assertion

T01: "o1"

A has the expected audience, is inside the stated half-open validity interval, and has an unused assertion ID. Its signature and issuer checks were also supplied as valid.


T02: "o1"

The assertion is addressed to a different service provider. A valid signature does not allow the archive application to accept an assertion intended for the payroll audience.


T03: "o3"

The rule requires now to be strictly earlier than NotOnOrAfter. Equality with that boundary does not pass, even though the signature and other fields are valid.


T04: "o1"

The application has already consumed the assertion ID. A still-valid signed assertion must also satisfy the supplied replay check.


T05: "o4"

A self-supplied key does not establish that the issuer is an authorized identity provider. The application must bind accepted signatures to its configured trust relationship.


T06: "o1"

The explicit access claim maps to Reader, and the separately required Curator grant is absent. A free-form title does not substitute for the approved authorization mapping.


T07: "o2"

Assertion validity depends on trustworthy current time. Time synchronization and monitoring address clock drift without discarding the expiry protection or accepting a client-controlled clock.


T08: "o1"

The verification key defines whom the application trusts to assert identities. Its replacement therefore needs the established authenticated administrative process and transition validation.


References: 

## SEC2-PBQ-014 — Reconcile inherited access after a directory merger


A merger combined two directories whose group names were reviewed more carefully than their nested grants. Complete the requested access-review fields. Effective permissions are the union of direct grants and all transitive group grants; this exercise has no explicit-deny rules. Each row's group inherits the permissions of the group(s) named in that row's Includes column. Names are labels, not evidence of the permissions a group actually grants.

### Group and permission graph


| Group | Includes | Direct permission |
| --- | --- | --- |
| ReportReaders | None | ReadReports |
| ReportEditors | ReportReaders | ModifyReports |
| Analysts | ReportReaders | None |
| LegacyTools | ReportEditors | RunConverter |
| Converters | None | RunConverter |
| KeyAdmins | None | RotateKeys |
| ReleaseOps | KeyAdmins | DeployRelease |

| Person | Current groups | Direct user grants | Approved work |
| --- | --- | --- | --- |
| Maya | Analysts, LegacyTools | ExportRaw | Read reports and run the converter |
| Noah | ReportEditors | None | Read reports only |
| Leah | ReleaseOps | None | Run the converter only |

Group owners must approve changes to group definitions because the changes affect all members. Individual membership corrections may be approved by the access-review owner.

### Session and identity rules


Application sessions cache effective permissions until the session is renewed or explicitly invalidated. A directory update does not refresh an existing session automatically.

The two source directories both contain a username `jlee`, belonging to different people. Each source supplies a verified issuer identifier and an immutable subject identifier. Those pairs are unique in the merged environment, while display names and email aliases can change.

### T01


Evaluate whether Maya currently has ModifyReports under the supplied effective-permission rules.

- o1: The effective grants do not permit ModifyReports

- o2: The effective grants permit ModifyReports

- o4: ModifyReports is granted only through her direct ExportRaw user grant

- o3: Only ReadReports and RunConverter are granted, matching her approved work

### T02


Choose the narrowest group correction for Noah.

- o1: Add Analysts while retaining ReportEditors

- o2: Replace ReportEditors with LegacyTools

- o3: Replace ReportEditors membership with ReportReaders

- o4: Replace ReportEditors with KeyAdmins

### T03


Choose the correction for Maya's direct ExportRaw grant.

- o1: Remove the direct user grant because the approved work does not require it

- o2: Copy the same grant into Analysts and leave the direct grant in place

- o3: Rename the grant as a temporary entitlement without setting an expiry

- o4: Retain the direct grant after requiring another sign-in

### T04


Choose the narrowest membership correction for Leah.

- o1: Replace ReleaseOps with LegacyTools

- o2: Replace ReleaseOps with Converters

- o3: Replace ReleaseOps with KeyAdmins

- o4: Add Converters while retaining ReleaseOps

### T05


A membership correction has been approved and applied. Choose the next action before testing an existing application session for reduced access.

- o1: Update the asset inventory without refreshing application authorization

- o2: Treat the directory update as proof that the current session is already restricted

- o3: Change the display name while keeping the same active session

- o4: Invalidate or renew the cached session, then test effective permissions

### T06


Choose the identity-mapping key that avoids merging the two unrelated jlee accounts.

- o1: The display name after removing spaces

- o2: Verified issuer plus immutable subject identifier

- o3: The current email alias without its source-directory identity

- o4: The shared username alone

### T07


An analyst proposes changing a nested group definition for every member. Choose the required approval path.

- o1: Let the directory operator approve it solely because the operator can edit groups

- o2: Obtain the responsible group owner's approval and assess the affected member population

- o3: Use one affected user's membership approval to authorize the group-wide change

- o4: Treat the existence of an open help-desk ticket as group-owner approval

### T08


Choose the strongest acceptance test for a corrected read-only report user.

- o1: Confirm the intended group name appears in the directory console

- o2: Confirm the total number of assigned groups decreased

- o3: Use a fresh session to verify permitted reading and rejected modification requests

- o4: Confirm authentication succeeds without testing a report operation

T01: "o2"

LegacyTools includes ReportEditors, which grants ModifyReports. Reviewing only Maya's direct user grants or the Analysts group would miss this inherited permission. Her effective set also includes ModifyReports via LegacyTools, and ExportRaw is a separate direct grant that confers nothing about reports.


T02: "o3"

ReportReaders grants the one approved permission. Adding a smaller role without removing the broader membership does not reduce the effective union of permissions.


T03: "o1"

The direct export grant is outside Maya's approved work. Moving, relabeling, or reauthenticating does not change the authorization it provides.


T04: "o2"

Converters supplies the required operation without deployment, key-administration, or report-editing grants. Retaining the old group or choosing a broader nested group preserves unnecessary access.


T05: "o4"

The supplied session model caches permissions. The application must refresh that state before its existing session can demonstrate the intended access reduction.


T06: "o2"

The issuer identifies the source identity system and the immutable subject identifies the person within it. A shared or changeable label is not a reliable cross-directory identity key.


T07: "o2"

Changing a group definition changes inherited access for its member population. The stated ownership rule requires the group owner and a review of that wider impact.


T08: "o3"

Effective authorization is the outcome that matters. A fresh session with both permitted and prohibited operations tests the resulting permission boundary rather than a label or count.


References: 

## SEC2-PBQ-015 — Validate vulnerability-scan coverage and conclusions


A scan dashboard reports that its jobs completed, and a manager wants to declare the environment fully assessed. Reconcile the actual evidence. The server assessment objective requires completed credentialed operating-system checks on four servers: W1, W2, D1, and D2. Network-device assessment is tracked separately. Treat a timeout, failed login, or omitted target as a coverage gap, not a clean finding result.

### Inventory and scan evidence


| Asset | Location or constraint | Recorded scan result |
| --- | --- | --- |
| W1 | Public web service, 192.0.2.41 | External HTTPS checks completed; no host credentials supplied |
| W2 | Public web service, 192.0.2.42 | External scan timed out; host checks not performed |
| D1 | Internal database server | Credential authentication succeeded; required host checks completed |
| D2 | Internal database server | Credential authentication failed; port discovery completed only |
| N1 | Legacy sensor gateway | Not targeted; owner approval and a supported assessment method are required before active testing |

The inventory is authoritative for the intended asset population. Per-host scan records include target identity, vantage point, authentication status, completed checks, and timestamp. W1 returned a service response to the authorized external scanner. D2 has an approved account that can be corrected and tested without granting domain-wide administrator rights.

### T01


Choose the conclusion supported by the W1 scan about operating-system vulnerabilities.

- o1: No host credentials are needed to conclude that installed packages are fully patched

- o2: A responding HTTPS service establishes that all required host checks completed

- o3: Its external service checks do not establish completion of the required host assessment

- o4: A current scanner signature database establishes completion of the operating-system assessment

### T02


Choose the next corrective step for the D2 scan.

- o1: Close the host assessment using the completed port-discovery result

- o2: Correct the approved scan account or access path, verify authentication, and rerun the required checks

- o3: Replace the scan account with unrestricted domain-wide administration by default

- o4: Lower the finding severity because the scan account failed to log in

### T03


Choose the result category for W2 under the supplied coverage rule.

- o1: Operating-system patching verified by the lack of service response

- o2: No vulnerabilities found because the scan received no response

- o3: Assessment incomplete; investigate the timeout and reschedule authorized testing

- o4: Permanently remove the asset from scope because one attempt timed out

### T04


Select TWO records that directly support a coverage reconciliation. (Select TWO.)

- o1: A sorted list of vulnerability severity scores without target completion status

- o2: The authoritative asset inventory for the intended scope

- o3: A green overall job-completion indicator alone

- o4: Per-host records of target identity, vantage, authentication, checks, and time

- o5: The total number of findings without asset-level scan status

### T05


Choose the most direct evidence that W1 was reachable from the tested external vantage at that time.

- o1: The host inventory lists a web-server package

- o2: A firewall design document says the service should be published

- o3: An internal administrator could log on through a management network

- o4: The authorized external scanner received W1's service response

### T06


What percentage of the four servers completed the required credentialed host checks? Enter a whole-number percentage.

### T07


Choose the next assessment action for N1.

- o1: Remove the gateway from the asset inventory to make coverage appear complete

- o2: Work with its owner on an approved supported method and testing conditions

- o3: Reuse the database scan account and assume the gateway supports it

- o4: Add it to the current aggressive scan profile without further review

### T08


Choose the most accurate structure for the report delivered to management.

- o1: Treat each completed scheduler job as a fully assessed asset

- o2: Report scope and assessment limitations alongside validated findings and remediation needs

- o3: Average vulnerability scores and omit authentication or reachability status

- o4: Use a low finding count as the sole evidence of complete coverage

T01: "o3"

An external service assessment has useful but different visibility from the required credentialed host checks. Its completion does not prove that operating-system packages and local settings were assessed.


T02: "o2"

The scan lost its intended authenticated visibility. Repairing and verifying the approved access allows the missing checks without treating authentication failure as a clean result or adding unnecessary privileges.


T03: "o3"

No response does not distinguish filtering, service failure, routing issues, or other causes, and it does not establish vulnerability state. The intended assessment remains incomplete.


T04: ["o2", "o4"]

Coverage requires a denominator of intended assets and evidence of what was actually assessed for each. Finding volume and aggregate job status do not establish that match.


T05: "o4"

An observed external service response directly tests reachability from that vantage. Intended policy, installed software, and a different network path do not establish the same observation.


T06: 25

Only D1 completed the required credentialed checks. One divided by four, multiplied by 100, is 25 percent.


T07: "o2"

The gateway has explicit assessment constraints. The coverage gap should lead to a supported and authorized plan rather than an unsafe scan or a changed denominator that hides the asset.


T08: "o2"

Finding quality depends on scope, vantage, authentication, and completed checks. Management needs those limitations to distinguish a verified result from an unassessed portion of the environment.


References: 

## SEC2-PBQ-016 — Tune an alert threshold using adjudicated events


A SOC is tuning a detector with a labeled evaluation set. Independent case review established which events were malicious; closing an alert is not itself a benign label. All threshold experiments use the same 200 distinct events: 20 malicious and 180 benign. Higher scores are more suspicious. An event generates an alert when its score is at least the configured threshold.

### Measured threshold results


| Threshold | Malicious events alerted | Benign events alerted |
| ---: | ---: | ---: |
| 60 | 18 | 60 |
| 70 | 15 | 30 |
| 80 | 12 | 12 |

All remaining events at each threshold produce no alert. For this exercise, detection rate = alerted malicious events / all malicious events. False-positive rate = alerted benign events / all benign events.

The proposed operating requirement is detection rate at least 85% and false-positive rate no greater than 35%. Evaluate only the offered thresholds. For percentage answers requesting one decimal place, round normally.

### Operational tuning constraints


Approved maintenance suppression may cover expected backup connections from asset IDs B-01 and B-02 to repository R-1 during a recorded change window. It must not suppress deletion or security-control-change alerts, even during maintenance. The detector receives events through a queue with measurable ingestion lag. A sharp fall in alerts can result from either cleaner activity or missing input.

After selecting a threshold, the team can run it in shadow mode against a fresh, independently labeled evaluation set before enabling automatic response.

### T01


At threshold 70, identify the false-positive population.

- o1: Benign events that generated no alert

- o2: Malicious events that generated no alert

- o3: Malicious events that generated alerts

- o4: Benign events that generated alerts

### T02


At threshold 70, calculate the detection rate as a whole-number percentage.

### T03


At threshold 70, calculate the false-positive rate as a percentage rounded to one decimal place.

### T04


Choose the offered threshold that meets both operating requirements.

- o1: None of the offered thresholds

- o2: 60

- o3: 80

- o4: 70

### T05


Choose the maintenance-suppression condition that fits the stated policy.

- o1: Expected backup-connection events for the named assets, repository, and approved window

- o2: All events from the backup subnet while any change ticket is open

- o3: All alerts generated by the backup account during the day

- o4: All alert types from the named assets during the approved window

### T06


An analyst wants to label every closed alert benign. Choose the appropriate handling.

- o1: Use evidence-based case outcomes and keep unresolved cases unknown

- o2: Mark the alert benign once it stops repeating

- o3: Mark the alert benign after the case reaches its age limit

- o4: Use the ticket's closed status as the benign label

### T07


Choose the strongest next validation before enabling automatic response at the chosen threshold.

- o1: Approve the threshold when the total alert count decreases

- o2: Approve the threshold when its configuration value is saved successfully

- o3: Use shadow mode on fresh independently labeled events and check both detection and operational impact

- o4: Repeat only the same dataset until its alert count is familiar

### T08


Choose the evidence most useful for checking whether a sudden fall in alert volume reflects missing input.

- o1: Source-event volume, queue ingestion lag, and detector-processing health

- o2: The number of incident tickets closed by analysts

- o3: The average assigned severity of the remaining alerts

- o4: The number of analysts trained on the new dashboard

T01: "o4"

A false positive is an alert for activity established as benign. Missed malicious events are false negatives, while the two correctly classified groups are true positives and true negatives.


T02: 75

Fifteen of the twenty malicious events generated an alert. The supplied formula gives 15 / 20 × 100 = 75 percent.


T03: 16.7

Thirty of the 180 benign events generated alerts. The supplied formula gives 30 / 180 × 100 = 16.666..., rounded to 16.7 percent.


T04: "o2"

Threshold 60 detects 18 of 20 malicious events, or 90%, and alerts on 60 of 180 benign events, or about 33.3%. It meets both limits; the other offered thresholds miss the detection requirement.


T05: "o1"

The exception is bounded by event type, specific asset identities, destination, and time. Broader account, subnet, or host-wide suppression could hide the explicitly excluded security events.


T06: "o1"

An operational workflow state is not ground truth about maliciousness. Reliable detector measurement requires evidence-based outcomes, with uncertainty retained when the review cannot establish a label.


T07: "o3"

Fresh evaluated data tests whether the measured behavior extends beyond the tuning set. Shadow mode also exposes response impact without assuming that fewer alerts means better detection.


T08: "o1"

Input volume and pipeline health can reveal ingestion or processing gaps. Ticket activity and the characteristics of alerts that still arrive cannot establish that the expected source stream is complete.


References: 

## SEC2-PBQ-017 — Contain an exposed workload credential without losing service


An invoice-processing workload exchanges a registered client key for short-lived access tokens. The key K1 is confirmed exposed. The local issuer model is explicit: disabling a client key prevents new token issuance with that key but does not cancel previously issued access tokens. The resource service can separately deny specific token IDs. All times below use synchronized UTC; no actual secret values are included.

### Credential and token evidence


It is 09:00. An unauthorized client used K1 to obtain token T91, which expires at 09:18. Existing legitimate workers hold token T90, which expires at 09:15. They can continue work with T90 while a replacement credential is deployed; deployment and validation take at most two minutes.

The responder is authorized to disable the exposed client key and deny the confirmed unauthorized token. Replacement key K2 can be registered with only the required scopes. The business operation needs ReadInput on its assigned invoice queue and WriteOutput on its own result location. It does not need identity administration, other departments' data, or key-management permissions.

### Replacement workflow rules


A worker may reference K2 only after K2 is registered and stored in the approved secret service. A K2 issuance-and-job test requires the worker configuration to have been updated. Removal of legacy deployment references follows a successful issuance-and-job test. The incident review must record identifiers and actions without storing raw keys or bearer-token values in ordinary tickets or logs.

### T01


Choose the control that immediately prevents new token issuance using K1.

- o1: Disable K1 at the token issuer

- o2: Delete K1 only from one legitimate worker's local configuration

- o3: Deny T91 at the resource service without changing issuer configuration

- o4: Shorten the legitimate worker session timeout only

### T02


Choose the control that stops resource access with the previously issued unauthorized T91 under this model.

- o1: Rely solely on changing K1's issuer registration

- o2: Remove the old key name from a deployment template

- o3: Add T91 to the resource service's enforced token-denial mechanism

- o4: Remove the token from the legitimate worker cache

### T03


How many minutes remain before legitimate token T90 expires at the stated decision time?

### T04


Select TWO scopes that meet the replacement workload's stated job. (Select TWO.)

- o1: Administer employee identities

- o2: Manage signing and encryption keys

- o3: Read other departments' result locations

- o4: ReadInput on its assigned invoice queue

- o5: WriteOutput on its own result location

### T05


Choose the deployment secret-handling design for K2.

- o1: Embed K2 in the reusable workload image

- o2: Store K2 in the approved secret service and grant the workload access to its reference

- o3: Place K2 in the deployment ticket for operator convenience

- o4: Put K2 in the configuration repository and restrict the branch name

### T06


Order the four replacement-workflow actions using the explicit dependencies.

- o1: Update the worker configuration to reference K2

- o2: Remove the legacy credential references from deployment configuration

- o3: Register K2 and store it in the approved secret service

- o4: Verify K2 token issuance and a representative processing job

### T07


Choose the incident record that preserves useful correlation without exposing another reusable secret.

- o1: Screenshots of the secret-service reveal screen

- o2: Only the application name without token or action identifiers

- o3: Key ID, token ID, client identity, timestamps, actions, and resource decisions

- o4: Raw client key and bearer-token values attached to the incident ticket

### T08


Choose the strongest focused validation of containment and continued operation.

- o1: Verify only that the replacement key appears in the issuer inventory

- o2: Verify K1 cannot issue tokens, T91 is denied, and authorized replacement jobs succeed

- o3: Verify only that one old legitimate session can still read input

- o4: Verify only that an administrator can open the workload dashboard

T01: "o1"

The issuer controls whether the client key can mint new tokens. Removing one local copy or denying a particular already-issued token does not disable the exposed key at that boundary.


T02: "o3"

The supplied model separates token issuance from access-token validity. The resource service must enforce a denial for this still-valid unauthorized token instead of relying on a change to its parent key.


T03: 15

T90 expires at 09:15 and the decision time is 09:00, leaving fifteen minutes under the supplied synchronized-clock model.


T04: ["o4", "o5"]

The workload needs only its assigned input and output operations. Identity, unrelated-data, and key-management authority exceed the defined business operation.


T05: "o2"

A protected secret service can keep the credential out of distributable images, source history, and ordinary tickets while giving the workload a controlled retrieval path.


T06: ["o3", "o1", "o4", "o2"]

The credential must exist before workers reference it, and workers must use it before the test can exercise it. Successful validation is the supplied prerequisite for removing the legacy deployment references.


T07: "o3"

Identifiers and decision records support reconstruction of issuance and resource use. Raw reusable credentials create additional exposure, while an application name alone loses the needed correlation.


T08: "o2"

Validation must cover the disabled parent credential, the separately denied issued token, and successful authorized replacement work. An inventory entry or dashboard session does not establish those three outcomes.


References: 

## SEC2-PBQ-018 — Build a timeline with clock skew and delivery delay


An investigator correlates logs from three sources. Source clocks have stable measured offsets throughout this interval. Corrected event time = recorded source time minus the source offset. A positive offset means that source clock is ahead of reference UTC. Keep timing uncertainty separate from the point estimate. Collector receipt time is synchronized UTC but includes variable delivery delay.

### Clock measurements


| Source | Measured offset from reference UTC | Uncertainty around corrected event time |
| --- | ---: | ---: |
| A, application | +90 seconds | ±10 seconds |
| B, endpoint | -30 seconds | ±10 seconds |
| C, gateway | 0 seconds | ±1 second |

Uncertainties for different sources are independent. Do not claim a definite cross-source order when the possible event-time intervals overlap. Source times and receipt times refer to the same date.

### Event records


| Event | Source | Recorded source time | Collector receipt time | Observation |
| --- | --- | --- | --- | --- |
| E1 | A | 10:01:50 | 10:03:00 | Application role setting changed |
| E2 | B | 09:59:55 | 10:00:40 | A local process started |
| E3 | C | 10:00:50 | 10:00:52 | An outbound connection was denied |
| E4 | B | 10:00:40 | 10:01:20 | A local archive was created |

The records do not contain a shared transaction identifier or evidence that the role setting caused the process launch. Original logs and the offset-measurement records are available for preservation.

### T01


Choose the corrected point estimate for E1.

- o1: 10:03:00 UTC

- o2: 10:03:20 UTC

- o3: 10:01:50 UTC

- o4: 10:00:20 UTC

### T02


Choose the corrected point estimate for E2.

- o1: 09:59:25 UTC

- o2: 10:00:40 UTC

- o3: 09:59:55 UTC

- o4: 10:00:25 UTC

### T03


Evaluate the definite order of E1 and E2 after applying both correction and uncertainty.

- o1: E1 definitely occurred before E2

- o2: The supplied uncertainty does not establish a definite order

- o3: E2 definitely occurred before E1

- o4: They definitely occurred at exactly the same instant

### T04


Which event is definitely the latest of the four under the supplied offset and uncertainty model?

- o1: E3

- o2: E4

- o3: E2

- o4: E1

### T05


Choose the appropriate basis for the occurrence timeline.

- o1: The order in which exported log files were copied into the case folder

- o2: Uncorrected source timestamps sorted as if all source clocks agreed

- o3: Collector receipt order alone, regardless of source clocks and queue delay

- o4: Corrected source event times with their uncertainty and retained receipt-time context

### T06


Using the point estimates only, what is E3's nominal delivery delay to the collector in seconds?

### T07


Choose the preservation approach that makes the timeline reproducible.

- o1: Retain only collector receipt times to avoid storing multiple time fields

- o2: Keep original records, corrected values, offset evidence, uncertainty, and the transformation method

- o3: Overwrite original timestamps with corrected values and discard the offset worksheet

- o4: Keep only a screenshot of the sorted timeline without its source records

### T08


Choose the most useful next evidence for assessing whether the application change caused the process launch.

- o1: Sort the same events by collector arrival time

- o2: Correlate authenticated actor, transaction, process-parent, and change-context records

- o3: Treat the closest pair of point estimates as a causal relationship

- o4: Treat similar event names as sufficient proof of a shared cause

T01: "o4"

Source A is ahead by ninety seconds, so subtract ninety seconds from 10:01:50. The point estimate is 10:00:20; its separate uncertainty remains plus or minus ten seconds.


T02: "o4"

Source B is behind by thirty seconds. Subtracting its negative offset adds thirty seconds, giving a point estimate of 10:00:25 with the stated uncertainty.


T03: "o2"

E1 can fall from 10:00:10 through 10:00:30, while E2 can fall from 10:00:15 through 10:00:35. Those intervals overlap, so their point-estimate order is not a definite event order.


T04: "o2"

E4 normalizes to 10:01:10 with an interval of 10:01:00–10:01:20. That entire interval is later than the possible times for each of the other events.


T05: "o4"

Occurrence time should use the source event timestamps with documented corrections and uncertainty. Receipt and file-copy order describe later handling and can differ from the original event order.


T06: 2

E3 occurred at the synchronized point estimate 10:00:50 and arrived at 10:00:52. The nominal delivery delay is two seconds; this task explicitly excludes the uncertainty interval.


T07: "o2"

Another analyst needs the raw evidence and the basis for each transformation to reproduce the timeline. Replacing originals or retaining only a rendered summary removes that auditability.


T08: "o2"

Temporal proximity can guide investigation but does not establish causation. Correlated actor, transaction, and execution context can support or disprove a specific mechanism connecting the events.


References: 

## SEC2-PBQ-019 — Configure managed-app boundaries on personal devices


Employees may use personal mobile devices for a managed work application. The organization wants to protect work data while leaving ordinary personal use available. Its supplied management platform can distinguish managed from personal apps, evaluate device posture, restrict work-data transfers, and exclude work content from personal cloud backups. Evaluate only the supported capabilities described here; do not assume every mobile platform has identical controls.

### Data and admission policy


Managed-to-managed clipboard transfers are allowed. Work data may not be copied or exported into personal apps or personal cloud backup. Personal-to-managed transfer of public information is allowed. Corporate files must open in approved managed apps. Rooted or otherwise noncompliant devices must not receive corporate application access until required posture is restored and verified.

| Flow | Source | Destination | Data |
| --- | --- | --- | --- |
| F1 | Managed work notes | Managed work mail | Internal task notes |
| F2 | Managed work record | Personal messenger | Customer record text |
| F3 | Personal browser | Managed work notes | A public office address |
| F4 | Managed work document | Personal cloud backup | Internal planning document |

F1–F3 are clipboard copy/paste transfers; F4 is a backup transfer.

Device R supplies a valid employee login but reports rooted posture. Device S is compliant but attempts to open a corporate attachment in an unmanaged personal mail app. Personal photos and personal messages are outside the work-data policy.

### T01


Assign the transfer result for F1.

- o4: Allow only if the notes are first classified as public

- o2: Block under the stated data-flow policy

- o3: Block because internal task notes are work data

- o1: Allow under the stated data-flow policy

### T02


Assign the transfer result for F2.

- o2: Block under the stated data-flow policy

- o1: Allow under the stated data-flow policy

- o4: Allow after the employee acknowledges a data warning

- o3: Allow because the copy stays on the same device

### T03


Assign the transfer result for F3.

- o3: Block because the source is a personal application

- o1: Allow under the stated data-flow policy

- o2: Block under the stated data-flow policy

- o4: Allow only if the personal browser is enrolled as a managed app

### T04


Assign the transfer result for F4.

- o1: Allow under the stated data-flow policy

- o3: Allow because backup is not a copy or export

- o4: Allow if the backup is encrypted by the personal cloud provider

- o2: Block under the stated data-flow policy

### T05


Choose the corporate-access decision for Device R.

- o1: Grant access if the managed app is current despite the rooted state

- o2: Withhold corporate app access until required posture is restored and verified

- o3: Grant access after another employee MFA prompt without addressing posture

- o4: Grant access whenever the device joins the office wireless network

### T06


Choose the handling for Device S's corporate attachment.

- o1: Allow a personal application while the device uses an encrypted network tunnel

- o2: Allow a personal application if the attachment is deleted at the end of the day

- o3: Require an approved managed application to open the corporate file

- o4: Allow a personal application after the employee acknowledges the data warning

### T07


Choose the most direct control placement for clipboard and open-in restrictions while preserving personal use.

- o1: Rely on device inventory collection without work-data enforcement

- o2: Rely on device storage encryption without application data restrictions

- o3: Rely on an encrypted network tunnel without application data restrictions

- o4: Configure managed-application data controls around work content

### T08


Choose the strongest acceptance-test set for the configuration.

- o1: Verify that the management application installs and reports a device identifier

- o2: Verify the personal cloud service is reachable without checking work-data exclusion

- o3: Verify one compliant user can sign in without testing data movement

- o4: Exercise allowed and blocked work-data flows, posture denial, and continued ordinary personal use

T01: "o1"

Both applications are managed, and the policy permits this managed-to-managed clipboard transfer. It stays within the defined work-data boundary. Work data may move freely between managed apps; the public-data condition applies only to personal-to-managed transfers.


T02: "o2"

The customer record would leave a managed work application for a personal messenger. The policy forbids that work-to-personal transfer. The boundary is between managed and personal apps, not between devices, and a user acknowledgement does not override the policy.


T03: "o1"

The source is personal, but the data is public and the destination is managed. The policy explicitly permits that personal-to-work direction. The policy explicitly allows personal-to-managed transfer of public information, so neither a personal source nor enrollment status blocks F3.


T04: "o2"

The proposed backup would place internal work content in a personal cloud store. That destination is outside the permitted work-data boundary. The policy names personal cloud backup as a forbidden destination for work data, and provider encryption does not change where the data lands.


T05: "o2"

A valid user identity does not satisfy the separate device-posture requirement. The explicit rooted-device condition must be resolved and checked before corporate access is restored.


T06: "o3"

The policy controls where corporate content can be handled. Consent, network encryption, or a later deletion promise does not put the unmanaged application inside that boundary.


T07: "o4"

The requirement concerns movement between application data contexts. A tunnel, inventory record, or encrypted disk can be useful but does not enforce these copy and open-in decisions.


T08: "o4"

The test should cover positive and negative transfer decisions, posture enforcement, and the intended personal-use boundary. Installation or sign-in alone does not demonstrate those outcomes.


References: 

## SEC2-PBQ-020 — Make an event-driven response pipeline reliable


An approved automation service can move a managed endpoint into a remediation profile. Events are delivered through a queue and may arrive late or more than once. An asset ID is stable, but IP addresses and inventory versions can change. The automation must evaluate current identity and authorization before changing the target; a queued event is evidence to evaluate, not permanent authority.

### Delayed event and current inventory


| Record | Values |
| --- | --- |
| Queued event | Event EV-91 at 14:00; asset ID A-91; IP 192.0.2.91; inventory version 7 |
| Processing time | 14:36 |
| Current asset A-91 | IP 192.0.2.92; inventory version 8 |
| Current asset B-42 | IP 192.0.2.91; inventory version 3 |

An automatic remediation decision requires current confirming evidence no older than five minutes. The change API accepts an expected inventory version and rejects a request if that version is stale. The authorization is limited to the approved remediation operation; the worker may not grant itself more access.

### Queue and API rules


A queue acknowledgement removes the event from pending delivery. The pipeline must first commit the action outcome and its processing record durably; crashes must not silently discard unprocessed work. For rate limiting, HTTP 429 with Retry-After: 30 requires waiting at least 30 seconds before another attempt. The configured maximum is three total attempts. HTTP 403 means the request lacks authorization and requires review rather than a timing retry. Events that cannot complete within the policy go to a retained dead-letter queue for controlled recovery.

### T01


Which current endpoint address belongs to the asset identified by EV-91?

- o1: 192.0.2.91

- o2: 192.0.2.92

- o3: Both addresses are equivalent targets

- o4: The stable asset ID cannot be reconciled with the supplied inventory

### T02


The API rejects expected version 7 because the current version differs. Choose the appropriate response.

- o1: Overwrite inventory with the queued version to make the request match

- o2: Reload current asset state and reevaluate the intended change before retrying

- o3: Apply the same change to whichever asset now has the old IP

- o4: Remove the version precondition and force the queued change

### T03


Evaluate whether EV-91 alone meets the current-evidence requirement at processing time.

- o1: It is sufficient once the queue acknowledges delivery

- o2: It requires fresh confirming evidence before automatic remediation

- o3: It is sufficient because the asset ID is stable

- o4: It is sufficient after changing only the inventory version field

### T04


Choose when the worker should acknowledge a successfully handled queue event.

- o1: After the required action outcome and processing record are durably committed

- o2: Immediately when the event is received, before evaluating it

- o3: Immediately after sending the change request, before receiving its result

- o4: After writing a success flag only to volatile worker memory

### T05


The first API attempt receives HTTP 429 with the stated Retry-After value. Choose the retry policy.

- o1: Use five-second delays with a maximum of three total attempts

- o2: Retry immediately using more concurrent workers

- o3: Honor the minimum delay and retry within the three-total-attempt limit

- o4: Honor the delay but retry without an attempt limit

### T06


A request receives HTTP 403. Choose the authorized failure path.

- o1: Repeat the identical request every 30 seconds as a timing issue

- o2: Retain the event and failure details for controlled authorization review

- o3: Send the same denied request through a different worker without reviewing authorization

- o4: Acquire a broader credential automatically to bypass the denied scope

### T07


A dead-lettered event is ready for recovery after its underlying problem is fixed. Choose the handling.

- o1: Use the original IP because the event was previously approved

- o2: Omit the version precondition for recovered events

- o3: Revalidate target identity, evidence freshness, current state, and authority before any new action

- o4: Replay the old mutation exactly as originally queued regardless of elapsed time

### T08


Choose the most useful processing record for investigating a disputed automated change.

- o1: Record event and asset IDs, version, decision, attempts, and outcome

- o2: Record the original event description and its receipt timestamp

- o3: Record endpoint hostname, detection source, and alert severity

- o4: Record processed event totals and counts of completed actions per shift

T01: "o2"

The stable asset ID A-91 now resolves to 192.0.2.92. Its former address belongs to B-42, so acting on the old address would affect a different endpoint.


T02: "o2"

The failed precondition signals that the state used for the decision is stale. Reconciliation and reevaluation preserve target correctness instead of bypassing the concurrency safeguard.


T03: "o2"

The event is older than the five-minute confirmation limit. Stable identity and successful delivery do not make the underlying security observation current.


T04: "o1"

Acknowledgement removes the pending work. Committing the result and processing record first avoids losing unprocessed or uncertain work if the worker crashes.


T05: "o3"

The stated response supplies a minimum retry delay, and the pipeline has a bounded attempt policy. Concurrency bursts, unbounded attempts, and shorter fixed delays violate one of those constraints.


T06: "o2"

The local model defines 403 as an authorization problem. It requires investigation within the permitted scope, not automatic privilege expansion or retries that preserve the same authorization failure.


T07: "o3"

Recovery occurs later and may involve changed identity, state, or authority. Dead-letter retention preserves the work for review; it does not freeze the validity of the original action.


T08: "o1"

These fields connect the initiating evidence, target state, decision, and actual outcome across retries. Aggregate counts or names cannot explain which state and authority supported a particular change.


References: 

## SEC2-PBQ-021 — Validate protected monitoring and directory sessions


A small data center is replacing legacy administration flows. Work from the supplied protocol capabilities and captured session summaries. The requirement is authenticated confidentiality for monitoring values and directory credentials, an approved SSH-based file-transfer workflow, and validated DNS results with encrypted client-to-resolver transport. Protocol names or open ports alone do not establish that the intended protections were actually negotiated.

### Supported modes and session evidence


Monitoring modes: SNMPv3 authPriv provides message authentication and privacy; authNoPriv provides authentication without privacy; noAuthNoPriv provides neither. A legacy SNMPv2c mode uses a community string without these SNMPv3 protections.

The directory supports immediate TLS on its designated TLS listener and StartTLS on its LDAP listener. StartTLS must complete with valid service-identity checks before a password-bearing bind; clients must fail closed if that protection cannot be established. The following are distinct observed sessions:

| Session | Observed sequence |
| --- | --- |
| L1 | LDAP connection; password-bearing simple bind; successful StartTLS later |
| L2 | LDAP connection; successful StartTLS; service identity validated; password-bearing bind inside TLS |

The file-transfer workflow must provide directory listing and file transfer over SSH transport. Protocol choices are provided in the task. A stored trusted SSH host key exists for transfer.example, but a connection attempt presents an unexpected replacement key; no approved rotation is recorded.

### DNS and verification rules


The DNS validator for this application requires a secure DNSSEC result. Query Q1 is labeled bogus because its signature validation failed. Treat that supplied result as authoritative for this exercise; do not analyze DNS packet bytes. DNSSEC validation does not encrypt the client query. The approved resolver also offers an authenticated TLS transport, which protects the client-to-resolver hop while DNSSEC validation remains enabled.

An isolated client-and-server lab is available for exercising the intended configuration before deployment.

### T01


Choose the monitoring mode that meets both required protections.

- o1: SNMPv3 authPriv

- o2: SNMPv3 noAuthNoPriv

- o3: SNMPv3 authNoPriv

- o4: SNMPv2c with a community string

### T02


Evaluate the credential-protection requirement for L1.

- o1: It passes if the directory stores the password as a hash

- o2: It fails because the password-bearing bind preceded establishment of TLS

- o3: It passes because TLS was eventually enabled on the session

- o4: It passes whenever the server supports a separate TLS listener

### T03


Evaluate the credential-protection requirement for L2.

- o3: It fails because StartTLS is weaker than the dedicated TLS listener

- o4: It passes only because the directory hashes stored passwords

- o1: It fails solely because the connection began on the LDAP listener

- o2: It meets the supplied sequence and peer-validation requirements

### T04


Choose the offered file-transfer service matching the SSH-based workflow.

- o1: FTPS

- o2: FTP

- o3: TFTP

- o4: SFTP

### T05


Choose the handling of the unexpected SSH host key.

- o1: Accept the new server key if the user can complete MFA

- o2: Pause the connection and verify the replacement through the trusted administrative process

- o3: Accept the new key because the requested hostname is unchanged

- o4: Replace the stored trusted key with the presented key automatically

### T06


Choose the application disposition for Q1 under the supplied DNS validation rule.

- o1: Reject the result under the secure-validation requirement

- o2: Accept it because a DNS answer was returned

- o3: Accept it if the same unvalidated answer appears twice

- o4: Accept it with a shorter cache lifetime

### T07


Choose the client-to-resolver configuration that also meets the stated confidentiality requirement.

- o1: Use ordinary DNS with a shorter cache lifetime

- o2: Use ordinary DNS with less predictable query identifiers

- o3: Use the approved authenticated TLS transport while retaining DNSSEC validation

- o4: Use unencrypted DNS transport and rely on signatures for query confidentiality

### T08


Choose the strongest focused acceptance test for the protected-session policies.

- o1: Verify only that the configured protocol names match the design document

- o2: Verify only that supported client software is installed

- o3: Verify only that the expected listener ports are open

- o4: Verify valid operations plus refusal of wrong peers and unavailable required protection

T01: "o1"

The requirement includes both authentication and confidentiality of monitoring values. The supplied authPriv mode provides those together; the other offered modes omit one or both.


T02: "o2"

Enabling TLS after a password-bearing bind cannot protect credentials already transmitted before that layer existed. Storage hashing and a different available listener do not change this observed session.


T03: "o2"

The supplied sequence establishes and validates TLS before the password-bearing bind. An LDAP listener using StartTLS can meet this stated policy when it fails closed and validates the peer. StartTLS is an approved mode when completed and validated before the bind, and server-side hashing does not protect a password in transit.


T04: "o4"

SFTP performs file transfer over SSH transport. FTPS uses TLS with FTP, while the other listed alternatives do not provide the specified SSH-based workflow.


T05: "o2"

A changed host key can reflect a legitimate rotation or a changed endpoint, but the presented key alone does not distinguish them. Independent verification preserves server identity trust.


T06: "o1"

The application requires a secure validation result, and Q1 is explicitly bogus. Cache duration and repeated responses do not repair the failed signature validation.


T07: "o3"

The supplied TLS transport encrypts the client-to-resolver hop, while DNSSEC retains its validation role. Signatures, caching, and query identifiers do not encrypt the query contents.


T08: "o4"

The controls must negotiate the required protection and reject cases that cannot satisfy it while preserving legitimate use. Listener and inventory checks do not establish those effective behaviors.


References: 

## SEC2-PBQ-022 — Complete a time-limited risk-exception decision


A legacy service cannot immediately meet a configuration standard. Complete the risk-exception record using this fictional organization's matrix and approval rules. These are local governance rules, not external legal deadlines. Likelihood and impact labels have already been assessed by the risk team; apply them without assigning an unsupported financial value.

### Risk matrix and authority


| Likelihood \ Impact | Minor | Moderate | Major |
| --- | --- | --- | --- |
| Low | Low | Low | Medium |
| Medium | Low | Medium | High |
| High | Medium | High | High |

Ordinary exception authority: a system owner may accept Low risk for up to 90 days; a business director may accept Medium risk for up to 30 days; the risk committee may accept High risk for up to 14 days. Any exception longer than its ordinary duration limit requires risk-committee approval. Implementers cannot approve their own exception merely because they can apply the control.

Exceptions require an accountable business owner, an expiry date, named controls, monitoring, and a remediation plan. At expiry, the documented restricted-service fallback applies unless a new approval is already in effect.

### Requested exception


Before compensating controls, likelihood is High and impact is Major. After the assessed controls, likelihood is Low and impact remains Major. The proposed duration is 40 days.

Sam is the accountable system owner for the business service. Dana is the business director. Rami implements the configuration and network controls. Lee maintains the risk register. The compensating controls restrict the legacy interface to an approved access path and require MFA at that path; weekly control monitoring is planned. A later project may expose the legacy interface directly to the Internet.

### T01


Assign the risk level before the compensating controls.

- o4: Not assignable without an annualized loss figure

- o1: Medium

- o2: Low

- o3: High

### T02


Assign the assessed residual risk level after the compensating controls.

- o4: Unchanged at High because impact remains Major

- o3: High

- o1: Low

- o2: Medium

### T03


Which role can approve an ordinary 20-day exception at the assessed residual level?

- o1: Risk-register maintainer

- o2: System owner

- o3: Business director

- o4: Technical implementer

### T04


Choose the approval path for the proposed 40-day duration.

- o1: Treat a recorded expiry date as approval for the longer duration

- o2: Obtain risk-committee approval for exceeding the applicable ordinary duration limit

- o3: Use the ordinary authority without further duration review

- o4: Let the implementer extend the ordinary limit after applying the controls

### T05


Assign the accountable business owner in the exception record.

- o1: Sam

- o2: Rami

- o3: Dana

- o4: Lee

### T06


Choose the strongest ongoing evidence that the named compensating controls operate as intended.

- o1: Confirm that the exception document lists the control names

- o2: Verify the effective access restriction and required MFA, and review their monitored exceptions

- o3: Rely on a test performed before the latest access-path change

- o4: Confirm that the implementation ticket was assigned to an engineer

### T07


The exception expires before remediation is complete and no new approval exists. Choose the required handling.

- o1: Close the risk record while the configuration remains outside the standard

- o2: Apply the documented restricted-service fallback and seek a new authorized decision

- o3: Continue the same exception because the original remediation ticket remains open

- o4: Let the implementer move the expiry date without an approval decision

### T08


Choose the risk-governance action before the proposed direct Internet exposure.

- o1: Change the service classification label without reassessing the exposure

- o2: Wait for the normal patch deadline before reviewing the changed access path

- o3: Reuse the existing exception unchanged until its date passes

- o4: Reassess likelihood, control effectiveness, and the approval before relying on the existing exception

T01: "o3"

The supplied matrix maps High likelihood and Major impact to High risk. This is a categorical assessment using the local matrix rather than a monetary calculation. The local matrix is qualitative; no monetary value is needed or permitted to read the High/Major cell.


T02: "o2"

The assessed residual combination is Low likelihood with Major impact. That cell is Medium; the impact remains material even though the likelihood has been reduced. The matrix reads both axes; Low likelihood with Major impact is Medium, so unchanged impact does not freeze the rating at High.


T03: "o3"

The residual level is Medium, and a 20-day duration falls within its ordinary 30-day limit. The supplied authority is the business director, not the implementer or register maintainer.


T04: "o2"

The proposed duration exceeds the ordinary limit for the assessed residual category. The local policy reserves such extensions to the risk committee; recording a date alone does not approve it.


T05: "o1"

Sam owns the business service and is explicitly accountable for it. Approval authority, technical implementation, and maintaining the register are separate responsibilities in this scenario.


T06: "o2"

The exception depends on controls that must remain effective. Current enforcement checks and exception monitoring provide operating evidence, while a document or assignment records intent and responsibility.


T07: "o2"

The local rule specifies the fallback when an exception expires without replacement approval. An open remediation ticket or edited date does not continue the expired authority.


T08: "o4"

The exception was based on a restricted access path and an assessed likelihood. A material exposure change can invalidate those assumptions, so the decision needs review before that change proceeds.


References: 

## SEC2-PBQ-023 — Review supplier-renewal evidence for a new service feature


A document-service supplier is being renewed while adding a search-indexing feature. The company requires assurance evidence for the actual services and data flows it uses. Existing approval covers the Basic archive service in Region E. The new feature is not automatically authorized by that approval. Complete the renewal-review fields using the supplied evidence and contract rules.

### Evidence packet


| Evidence | Scope and limitation |
| --- | --- |
| Independent operating-effectiveness report | Basic archive service, January–June; new indexing service and its search subprocessor are excluded. |
| Supplier bridge letter | Management states no material Basic-service changes in July–September; it contains no independent tests for that later period. |
| New-feature description | Indexing introduced in August; search subprocessor and processing region not yet documented in the review packet. |
| Report exception | A deletion control missed its target in two sampled cases; corrective action is claimed but no retest is attached. |
| Customer responsibilities | Customer must enforce MFA on human administrator accounts and export the required tenant logs. |
| Customer tenant review | One human administrator lacks MFA; required log export is operating. |

The signed contract grants access to relevant additional assurance evidence. The account manager proposes substituting a general sales presentation for the missing records.

### Interim and recordkeeping rules


Any temporary continuation requires approval documenting its service scope and unresolved risks. The approved Basic service can be considered separately from the new feature, but customer-side control failures must be addressed. New real-data processing cannot begin until mandatory scope and data-location conditions are met.

The renewal decision must be traceable to its reviewed evidence and an authorized customer approval. A high overall vendor score does not substitute for an unmet mandatory condition.

### Alternative completed decision records


For this record-comparison task, assume the customer-control corrections have been verified. All four proposed records concern the same limited Basic-service continuation. Dana is the authorized customer decision owner. Evidence package ER-7 version 3 is a locked copy of the reviewed source reports, periods, scope, exceptions, and review conclusion.

| Record | Evidence reference | Decision status |
| --- | --- | --- |
| R1 | ER-7 version 3 | Approved by the supplier account manager; no customer approval |
| R2 | ER-7 version 3 | Draft submitted to Dana; approval still pending |
| R3 | ER-7 version 3 | Dated approval by Dana for the documented scope and duration |
| R4 | An overwritten shared link; reviewed evidence version cannot be recovered | Dated approval by Dana for the documented scope and duration |

### T01


Choose the conclusion supported by the independent report about the new indexing feature.

- o1: The report covers features added after its assessment period by default

- o2: Shared branding makes the Basic and indexing control scopes equivalent

- o3: The report does not assess the new feature or its excluded subprocessor

- o4: The supplier name on the report extends coverage to the new feature

### T02


Choose the appropriate interpretation of the bridge letter.

- o1: It replaces review of reported control exceptions

- o2: It extends the report to excluded indexing and subprocessor controls

- o3: It is useful management evidence about the gap period, not independent testing of that period

- o4: It independently tests the operating effectiveness of the later period

### T03


Choose the required customer-side action in the renewal review.

- o1: Ask the supplier to state that the customer exception is outside report scope

- o2: Treat the supplier report as proof that customer MFA responsibilities are satisfied

- o3: Correct and verify the human administrator MFA gap in the tenant

- o4: Use the successful log export as a substitute for administrator MFA

### T04


Choose the most important missing evidence for the new search subprocessor.

- o1: A certification logo without its assessed systems and locations

- o2: Its relevant control scope and the actual data-processing locations and flows

- o3: Its availability agreement without data-processing scope or location terms

- o4: The primary supplier's corporate controls report without the subprocessor scope

### T05


Choose the strongest follow-up for the deletion-control exception.

- o1: Accept the corrective-action claim without supporting operating evidence

- o2: Offset the exception with high scores for unrelated controls

- o3: Wait for the next annual report without interim verification of the correction

- o4: Review the cause and correction, then obtain relevant evidence that the control now operates effectively

### T06


Choose the appropriate response to the proposed sales-presentation substitution.

- o1: Treat the renewal deadline as sufficient justification to stop the evidence review

- o2: Waive the missing evidence because the account relationship is established

- o3: Accept the sales presentation as equivalent to the required assurance evidence

- o4: Use the agreed evidence-access right to request the relevant missing assurance records

### T07


Choose an acceptable interim proposal while mandatory new-feature evidence remains unresolved.

- o1: Keep indexing disabled and seek scoped Basic-service approval with corrected controls

- o2: Enable a limited real-data indexing pilot while the missing reviews are pending

- o3: Treat the approved Basic-service scope as temporary indexing authorization

- o4: Enable indexing when the supplier score meets the threshold despite missing evidence

### T08


Choose the completed record that demonstrates both a traceable evidence basis and an authorized customer decision.

- o1: R4

- o2: R1

- o3: R3

- o4: R2

T01: "o3"

The report explicitly excludes the feature and its subprocessor, and its period predates their introduction. Assurance must be matched to the actual service and assessed boundaries.


T02: "o3"

The letter is a management assertion with a stated Basic-service scope. It can inform follow-up but does not become independent testing or expand the original report to excluded services.


T03: "o3"

The report identifies customer responsibilities, and the tenant review finds a specific unmet one. A supplier report or an unrelated working control does not implement that customer-side requirement.


T04: "o2"

The mandatory conditions concern assurance scope and where the real data will be processed. Corporate reports, unspecific certifications, and availability terms do not resolve the particular scope and location gaps.


T05: "o4"

A corrective-action statement describes intended remediation. Cause, implemented correction, and relevant operating evidence are needed to assess whether the observed control failure has been addressed.


T06: "o4"

The contract provides an appropriate route to obtain the relevant records. General marketing material does not supply the defined scope, operating tests, or unresolved control evidence.


T07: "o1"

The local rule allows scoped consideration of the existing service and requires customer controls to be addressed. It does not permit new real-data processing before its mandatory conditions are satisfied.


T08: "o3"

R3 retains the exact reviewed evidence package and a dated approval by the authorized customer owner. R1 lacks customer authority, R2 is not approved, and R4 cannot reconstruct which evidence supported its decision.


References: 

## SEC2-PBQ-024 — Review secondary use of employee training data


A learning team collected employee training records for course delivery and improvement. A marketing team now proposes giving identifiable records to a new advertising partner. Apply the fictional privacy rules below. This exercise does not assume a jurisdiction-specific legal deadline or that consent is the only possible basis for processing; it concerns the stated purpose, minimization, and review requirements.

### Local data-use policy


The approved purpose covers course administration and improvement. Reuse for a new purpose requires a privacy assessment, an approved basis, and appropriate notices before the proposed processing. Technical access alone does not approve a purpose change.

The business owner wants completion trends by department over quarterly reporting periods, with no need to analyze individual histories or coaching content. Release only information needed for that aggregate question. Suppress department cells with fewer than five people; do not publish overlapping totals that would reconstruct a suppressed cell.

Individual access requests must be fulfilled to the actual individual or an authorized representative. An established authenticated identity and recovery process is available. Personal information used by the organization and authorized partners must remain accurate. An individual export must protect unrelated personal information about others. Export decisions must be accountable to their approved purpose and permitted scope.

### Review queue


The proposed trend table has Department A: 12 people, Department B: 3 people, and Department C: 8 people. No overlapping totals are planned.

Dataset P replaces names with stable participant codes, but a separate protected table links each code to an employee. An email message from an unverified sender requests an employee's full record. A verified correction changes one employee's completion status; an authorized learning partner holds the previous value. The individual's export also contains private comments about another employee.

The review team will later need to reconstruct whether an export matched the authorization that applied when it occurred.

### T01


Choose the handling of the proposed advertising use.

- o1: Proceed once the advertising partner signs a confidentiality agreement alone

- o2: Complete the required new-purpose privacy and authorization review before processing

- o3: Proceed after replacing names with stable codes while retaining the mapping

- o4: Proceed because the marketing team can technically read the records

### T02


Choose the minimum data design for the approved completion-trend request.

- o1: Department-level counts plus all coaching comments for context

- o2: Department, quarter, and needed completion counts with the required small-cell handling

- o3: Stable participant code, department, and individual completion history

- o4: Employee name, email, department, quarter, and completion status

### T03


Classify Dataset P based on the described retained mapping.

- o1: Public data solely because names were replaced

- o2: Anonymous

- o3: Pseudonymized

- o4: Encrypted solely because the values are codes

### T04


Choose the treatment of Department B in the proposed trend release.

- o1: Publish the exact count under an alternative department label

- o2: Suppress its small cell under the stated rule

- o3: Publish a B-plus-C total while also publishing the exact C count

- o4: Release its exact count because the table omits employee names

### T05


Choose the next step for the unverified email request.

- o1: Treat a familiar-looking sender domain as sufficient identity verification

- o2: Send the full record to the reply address because the request names an employee

- o3: Use the established identity or recovery verification process before disclosure

- o4: Copy the employee's manager and release the record without verifying the requester

### T06


Choose the handling of the verified completion-status correction.

- o1: Correct only the on-screen display while leaving the stored value unchanged

- o2: Correct the local record but leave the known authorized copy unaddressed

- o3: Correct the authoritative record and notify the authorized recipient using the outdated value

- o4: Apply the corrected value only to records collected next quarter

### T07


Choose the preparation required for the individual's export that includes another employee's private comments.

- o1: Review and redact unrelated third-party personal information while retaining the appropriate requester records

- o2: Remove names but retain the unrelated distinctive private comments

- o3: Release the complete file because it contains some requester information

- o4: Encrypt the complete file and release it without reviewing the unrelated contents

### T08


Choose the audit record best suited to demonstrating that an approved export matched its permitted purpose and scope.

- o1: File checksum and delivery receipt without the approved purpose or fields

- o2: Dataset version, approved purpose, authorizing owner, recipient, released fields, and time

- o3: Recipient address and transfer time without the purpose or released-field record

- o4: Login identity and application name without the export decision

T01: "o2"

Advertising is outside the approved purpose and triggers the stated review requirements. Access, confidentiality terms, and pseudonymization do not by themselves authorize that new processing purpose.


T02: "o2"

The requested trend can be answered with the listed aggregate fields. Identifiers, individual histories, and free-text notes add data that the stated request does not need.


T03: "o3"

The protected mapping can reconnect each stable code to an employee. Because the identities remain recoverable through that mapping, the dataset is pseudonymized rather than anonymous.


T04: "o2"

The department has fewer than five people, so the explicit small-cell rule applies. Names and labels do not change that size, while overlapping totals could reconstruct the suppressed count.


T05: "o3"

The requester must be linked to the relevant identity through the approved process. Knowing a name, using a familiar domain, or copying another person does not establish that verification.


T06: "o3"

The supplied rule covers both the authoritative record and authorized recipients using the affected data. A display-only or future-only change does not correct the existing information flow.


T07: "o1"

Meeting the third-party protection requirement requires reviewing the contents and redacting unrelated personal information. Delivery encryption or removal of names alone does not determine which information belongs in the export.


T08: "o2"

These fields connect the released data to its version, approved purpose, authority, and recipient. Delivery integrity and login records are useful but do not establish the authorization scope of that release.


References: 

## SEC2-PBQ-025 — Decide whether audit findings have sufficient closure evidence


An assessor is reviewing remediation evidence for four findings. Implementers apply changes, the assessor evaluates whether evidence supports closure, and the accountable risk authority can separately accept residual risk. Use the actual scope and timing of the evidence when deciding what each submitted record demonstrates.

### Assessment-method cards


For this exercise, examining means reviewing records or artifacts; interviewing means asking people about their knowledge or practices; testing means exercising a control or process and comparing observed behavior with a requirement.

| Evidence card | Activity |
| --- | --- |
| M1 | Review the approved remote-access standard and its version history |
| M2 | Ask operators how they handle failed restore jobs |
| M3 | Attempt an authorized prohibited-path connection in the test environment and record the enforced result |

### Finding and evidence board


| Finding | Required outcome | Evidence submitted |
| --- | --- | --- |
| F1 | A prohibited administration path is denied after the latest configuration change | A new configuration screenshot; the attached traffic test predates the change |
| F2 | Review permissions of all 60 privileged identities, including service identities | Reviews for 50 human identities; the remaining service identities are absent |
| F3 | A representative backup can be restored into the approved test environment | A signed recovery procedure and an operator interview; no executed restore result |
| F4 | Required audit events reach the collector from every in-scope host | A deployment completion ticket and recent events from only a subset of the host inventory |

The assessor can request focused retesting, reconcile evidence to the required population, and keep a finding open when its requirement is not yet demonstrated.

### T01


Assign the assessment method used by M1.

- o3: Interview

- o2: Test

- o1: Examine

- o4: Observe

### T02


Assign the assessment method used by M2.

- o2: Examine

- o3: Test

- o1: Interview

- o4: Reperform

### T03


Assign the assessment method used by M3.

- o2: Test

- o4: Attest

- o3: Interview

- o1: Examine

### T04


Choose the most directly missing evidence for F1.

- o1: A focused traffic test of the prohibited path against the current configuration

- o2: Another signature on the original change request

- o3: A duplicate copy of the pre-change traffic result

- o4: A statement that the configuration screenshot appears correct

### T05


How many privileged identities remain outside the submitted F2 review population?

### T06


Choose the strongest evidence needed for F3.

- o1: A list showing that backup files exist in storage

- o2: A second approval of the same recovery procedure

- o3: A longer interview describing how a restore should work

- o4: A controlled representative restore with recorded data and application checks

### T07


Choose the best next evidence step for F4.

- o1: Use a high total collector-event volume without source attribution

- o2: Use the available subset as proof of the full population without justification

- o3: Treat the deployment ticket as proof that every host is sending required events

- o4: Reconcile in-scope hosts to current event receipt and investigate each missing source

### T08


A control remains ineffective, but the authorized owner accepts its residual risk. Choose the accurate finding disposition.

- o1: Record the finding as out of scope solely because the owner accepted the risk

- o2: Record the control as technically remediated because an owner signed the risk decision

- o3: Record the control as effectively compensated without testing any alternative control

- o4: Record the approved accepted-risk status and its conditions without calling the control remediated

T01: "o1"

M1 reviews a policy artifact and its version history. It can establish documented requirements and changes, but it does not directly exercise the control. Observe is not one of the three defined methods here, and reviewing documents is examination, not watching a control operate.


T02: "o1"

M2 obtains information by asking operators about their practices. Interview evidence can explain a process and guide corroboration, but it is distinct from executing the process. Reperformance would mean redoing the restore handling; asking operators about it is an interview, and it is not a defined method in this exercise.


T03: "o2"

M3 exercises a permitted test attempt against the control and records actual enforcement. That is a test of observed behavior against the access requirement. Attestation is a statement by a responsible party, not a defined method here; M3 directly exercises the control, which is testing.


T04: "o1"

The earlier traffic result does not test the changed state. A focused current test can establish effective enforcement of the prohibited path instead of relying on intended configuration alone.


T05: 10

The requirement covers sixty identities and the submission covers fifty. Ten identities remain outside the submitted review, regardless of whether they are human or service identities.


T06: "o4"

The requirement is demonstrated recovery. An executed representative restore and checks provide operating evidence that documentation, interviews, and file existence cannot establish by themselves.


T07: "o4"

The control requirement names every in-scope host. Reconciliation to current source-level receipt reveals coverage gaps that aggregate volume or deployment status can conceal.


T08: "o4"

Risk acceptance is a governance decision about a remaining condition. It should be traceable and accurately labeled rather than treated as technical remediation, scope exclusion, or demonstrated compensating-control effectiveness.


References: 