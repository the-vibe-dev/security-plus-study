# Studying with Test Prep 2 — Security+ SY0-701

This second package targets **SY0-701**. It adds 300 new quiz questions and 25 new PBQs to Test Prep 1. Use the [objective coverage map](test_prep_2_objective_coverage.md) to track the concepts behind each question. The questions are original practice material; learning the reason for an answer is more useful than memorizing its position.

## Using both sets

Make a first attempt at Test Prep 2 before opening its explanations. This gives you a fresh check on whether you can apply the same syllabus to different evidence and constraints. Keep first-attempt scores separate from scores after repeated practice.

When an objective was strong in Test Prep 1 but weak here, compare the reasoning. Identify the changed constraint, the new data source, or the competing control that altered the best answer. Record the distinction instead of only the selected letter. After reviewing it, mix questions from both sets and revisit the objective later.

Use the three Test Prep 2 practice configurations and its reserve questions as fresh material. Each configuration is disjoint from the other two; all Test Prep 2 item IDs are distinct from Test Prep 1. The two banks together provide 600 quiz questions and 50 PBQs.

## A practical study cycle

1. Start with a mixed, untimed set. Commit to an answer before revealing the explanation. For multi-select questions, account for every requested selection.
2. For each miss, identify the actual gap: an unfamiliar term, a confused distinction, missed evidence, a calculation mistake, or overlooking a constraint such as FIRST, BEST, or least privilege.
3. Read the explanation for the correct choice and the distractor you selected. Explain aloud which fact in the prompt makes one answer better.
4. Review that objective in the official blueprint and the linked technical reference. Then try a different question from the same objective.
5. Return to a missed question after a delay. If you remember its letter, cover the choices and explain the answer in your own words before checking it.

Treat a correct guess as something to review. Track why it was uncertain. Keep an eye on all five domains: strong practical troubleshooting does not automatically cover governance, risk calculations, privacy roles or assessment terminology.

## Distinctions that often decide the answer

| Distinction | What to look for in the scenario |
| --- | --- |
| Authentication vs authorization vs accounting | Is the system proving identity, deciding permitted actions, or recording what happened? |
| Control category vs control function | Category describes how the control is implemented; function describes its intended effect. A technical control can be preventive or detective depending on its job. |
| Least privilege vs separation of duties | Minimum access limits what one identity can do. Separation of duties splits a sensitive process across different identities. |
| Password spraying vs credential stuffing | Spraying tries a small password set across many accounts. Stuffing reuses previously obtained username/password pairs. |
| Vulnerability severity vs business risk | A severity score does not by itself capture asset importance, exposure, active exploitation and existing controls. |
| Hash vs HMAC vs digital signature | A hash can support integrity comparison when the reference is trusted. HMAC adds shared-secret authentication. A signature uses a private key and can be verified with its public key. |
| Encryption vs masking vs tokenization | Encryption protects data with cryptographic keys. Masking hides parts of a displayed value. Tokenization substitutes a value whose mapping is protected separately. |
| RPO vs RTO | RPO limits acceptable data loss measured in time. RTO sets the restoration-time objective. |
| Redundancy vs backup | Redundancy can sustain service through component failure. Backups support restoration from a retained copy. A synchronized replica may also synchronize damage. |
| Containment vs eradication vs recovery | Containment limits the spread or impact. Eradication removes the cause and persistence. Recovery restores trusted service and checks its operation. |
| Risk appetite vs tolerance | Appetite is the broad amount/type of risk the organization is willing to take. Tolerance gives more specific acceptable boundaries. |
| Data owner vs custodian vs controller/processor | Internal owners decide protection requirements; custodians implement handling. Controller/processor are privacy roles determined by the processing relationship. |

The references for these concepts include [NIST access and control guidance](test_prep_2_sources.md#s11), [NIST authentication guidance](test_prep_2_sources.md#s04), [NIST contingency planning](test_prep_2_sources.md#s08), [NIST key management](test_prep_2_sources.md#s14), [NIST risk guidance](test_prep_2_sources.md#s24), and [privacy-role guidance](test_prep_2_sources.md#s23). The short descriptions above are reasoning reminders; the constraints in each question still matter.

## Reading a scenario efficiently

Identify what the question asks you to decide. A prompt asking for the most likely cause differs from one asking for the next action. A prompt asking for prevention differs from one asking for evidence collection.

Separate facts from assumptions. If a service must remain available, an answer that simply shuts down the environment may fail the requirement. If the prompt gives a defined emergency procedure, use that procedure. If logs show only failed attempts, do not infer successful compromise unless another exhibit establishes it.

When several controls sound reasonable, test them against the specific failure. Encryption at rest does not authorize a logged-in user. A VLAN label does not enforce a boundary without traffic controls. A high-severity finding does not automatically outrank an actively exploited issue on a critical exposed asset.

## Working through PBQs

Open the candidate document or the site's PBQ view first. Each exercise supplies a scenario, exhibits and separately scored tasks. Start by identifying the environment, the required end state and any fixed constraints.

For firewall tasks, note direction, source, destination, protocol, port and evaluation order. Read whether the firewall is stateful and whether reply traffic is already handled. An allow rule must permit the required traffic without granting additional access.

For log tasks, correlate timestamps, identities, hosts, event types and outcomes. Verify whether clocks are normalized before constructing a timeline. Distinguish an indicator worth investigating from proof of a successful event.

For IAM tasks, state who needs what access, to which resource, for how long. Check approval, expiration, group membership, service-account needs and removal of old access. Do not grant a permanent broad role to solve a temporary narrow need.

For recovery tasks, calculate from the actual available restore points and elapsed times. Distinguish the stated target from the measured result. Include validation time when the scenario defines recovery as restored and validated service.

For data handling and vendor tasks, use the given classification, permitted purpose, retention requirements, contract terms and decision authority. A convenient technical action may conflict with one of those requirements.

Submit every task, then compare your reasoning with the worked solution. The practice rubric gives independent credit for each correct task. Revisit the scenario when several related fields were wrong; that often indicates a mistaken assumption about the environment.

## Risk arithmetic reminders

For questions that supply a simplified annualized loss model:

```text
Single loss expectancy (SLE) = asset value × exposure factor
Annualized loss expectancy (ALE) = SLE × annualized rate of occurrence
Expected annual reduction = ALE before − ALE after
Net annual benefit = expected annual reduction − annual safeguard cost
```

Convert percentages to decimals. An occurrence expected once every five years corresponds to an annualized rate of 0.2 in this simplified model. Keep dollars per event separate from dollars per year. If a question includes one-time and recurring costs, follow its stated time horizon. Real risk decisions may include uncertainty and nonfinancial consequences; use the assumptions the question supplies. See [the risk references](test_prep_2_sources.md#s09).

## Timed practice

The package includes three disjoint practice configurations, each with 85 quiz questions and 5 PBQs, plus fresh reserve items. Their suggested limit is 90 minutes. This is a study configuration: it does not predict how many PBQs your actual exam will contain or how CompTIA weights items. CompTIA's published SY0-701 blueprint lists a maximum of 90 questions and a 90-minute test. See [the official source](test_prep_2_sources.md#s01).

Use timed attempts after you can work through unfamiliar scenarios without repeatedly looking up basic terms. Mark time-consuming items for review if the site supports it. Afterward, review the missed objectives and incomplete PBQ tasks separately; a single combined percentage can hide a specific weakness.

Do not interpret repeated high scores on memorized questions as proof of readiness. Use fresh reserve questions, explain the distractors, and work through the PBQ exhibits without viewing their solutions. The package's percentages and points are practice measures, not the official scaled exam score.
