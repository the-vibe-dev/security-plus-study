# Test Prep 2 — objective coverage

The quiz bank follows the five domain percentages in the [official SY0-701 blueprint](https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6). All 28 numbered objectives are represented. Counts within a domain are editorial allocations; CompTIA does not publish these sub-objective weights. PBQs often cover more than one objective and are counted separately.

| Domain | Name | Exam weight | Questions | Single-answer | Multi-select |
| --- | --- | ---: | ---: | ---: | ---: |
| 1 | General Security Concepts | 12% | 36 | 32 | 4 |
| 2 | Threats, Vulnerabilities, and Mitigations | 22% | 66 | 59 | 7 |
| 3 | Security Architecture | 18% | 54 | 49 | 5 |
| 4 | Security Operations | 28% | 84 | 76 | 8 |
| 5 | Security Program Management and Oversight | 20% | 60 | 54 | 6 |
| Total | | 100% | 300 | 270 | 30 |

## Objective detail

| Objective | Focus (paraphrased) | Quiz count | Quiz IDs | PBQs touching objective |
| --- | --- | ---: | --- | --- |
| 1.1 | Security control categories and functions | 7 | SEC2-Q001–SEC2-Q007 | — |
| 1.2 | Fundamental security concepts | 11 | SEC2-Q008–SEC2-Q018 | SEC2-PBQ-001, SEC2-PBQ-002, SEC2-PBQ-007, SEC2-PBQ-014 |
| 1.3 | Secure change management | 7 | SEC2-Q019–SEC2-Q025 | SEC2-PBQ-001 |
| 1.4 | Cryptography and public key infrastructure | 11 | SEC2-Q026–SEC2-Q036 | SEC2-PBQ-002, SEC2-PBQ-009, SEC2-PBQ-013 |
| 2.1 | Threat actors and motivations | 9 | SEC2-Q037–SEC2-Q045 | — |
| 2.2 | Attack vectors and surfaces | 13 | SEC2-Q046–SEC2-Q058 | — |
| 2.3 | Vulnerability types | 15 | SEC2-Q059–SEC2-Q073 | SEC2-PBQ-006 |
| 2.4 | Indicators of malicious activity | 18 | SEC2-Q074–SEC2-Q091 | SEC2-PBQ-003, SEC2-PBQ-004, SEC2-PBQ-005 |
| 2.5 | Mitigation methods | 11 | SEC2-Q092–SEC2-Q102 | SEC2-PBQ-003, SEC2-PBQ-004, SEC2-PBQ-005, SEC2-PBQ-006 |
| 3.1 | Architecture models and security implications | 13 | SEC2-Q103–SEC2-Q115 | SEC2-PBQ-008, SEC2-PBQ-010, SEC2-PBQ-011 |
| 3.2 | Secure enterprise infrastructure | 15 | SEC2-Q116–SEC2-Q130 | SEC2-PBQ-007, SEC2-PBQ-011, SEC2-PBQ-012 |
| 3.3 | Data protection strategies | 13 | SEC2-Q131–SEC2-Q143 | SEC2-PBQ-007, SEC2-PBQ-009, SEC2-PBQ-011, SEC2-PBQ-024 |
| 3.4 | Resilience and recovery design | 13 | SEC2-Q144–SEC2-Q156 | SEC2-PBQ-004, SEC2-PBQ-008, SEC2-PBQ-009, SEC2-PBQ-010 |
| 4.1 | Resource hardening | 10 | SEC2-Q157–SEC2-Q166 | SEC2-PBQ-006, SEC2-PBQ-008, SEC2-PBQ-012, SEC2-PBQ-019, SEC2-PBQ-021 |
| 4.2 | Asset lifecycle management | 8 | SEC2-Q167–SEC2-Q174 | SEC2-PBQ-020 |
| 4.3 | Vulnerability management | 12 | SEC2-Q175–SEC2-Q186 | SEC2-PBQ-015 |
| 4.4 | Monitoring and alerting | 10 | SEC2-Q187–SEC2-Q196 | SEC2-PBQ-016, SEC2-PBQ-020 |
| 4.5 | Enterprise security capabilities | 11 | SEC2-Q197–SEC2-Q207 | SEC2-PBQ-019, SEC2-PBQ-021 |
| 4.6 | Identity and access implementation | 11 | SEC2-Q208–SEC2-Q218 | SEC2-PBQ-012, SEC2-PBQ-013, SEC2-PBQ-014, SEC2-PBQ-017, SEC2-PBQ-019 |
| 4.7 | Automation and orchestration | 7 | SEC2-Q219–SEC2-Q225 | SEC2-PBQ-016, SEC2-PBQ-017, SEC2-PBQ-020 |
| 4.8 | Incident response | 9 | SEC2-Q226–SEC2-Q234 | SEC2-PBQ-017, SEC2-PBQ-018 |
| 4.9 | Investigation data sources | 6 | SEC2-Q235–SEC2-Q240 | SEC2-PBQ-003, SEC2-PBQ-005, SEC2-PBQ-013, SEC2-PBQ-015, SEC2-PBQ-016, SEC2-PBQ-018, SEC2-PBQ-021 |
| 5.1 | Security governance | 11 | SEC2-Q241–SEC2-Q251 | SEC2-PBQ-014, SEC2-PBQ-022, SEC2-PBQ-023, SEC2-PBQ-024, SEC2-PBQ-025 |
| 5.2 | Risk management | 13 | SEC2-Q252–SEC2-Q264 | SEC2-PBQ-010, SEC2-PBQ-022, SEC2-PBQ-025 |
| 5.3 | Third-party risk | 10 | SEC2-Q265–SEC2-Q274 | SEC2-PBQ-023 |
| 5.4 | Compliance and privacy | 9 | SEC2-Q275–SEC2-Q283 | SEC2-PBQ-024 |
| 5.5 | Audits and assessments | 9 | SEC2-Q284–SEC2-Q292 | SEC2-PBQ-015, SEC2-PBQ-023, SEC2-PBQ-025 |
| 5.6 | Security awareness | 8 | SEC2-Q293–SEC2-Q300 | — |

## Difficulty labels

Foundational questions focus on recognizing or applying one core concept. Intermediate questions combine a practical scenario with competing choices. Advanced questions require closer reading, calculations, or competing constraints. These are editorial study labels, not a measured prediction of real-exam item difficulty.
