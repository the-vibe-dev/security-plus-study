# Sources and research notes

Researched on October 3, 2026. Questions, fictional organizations, addresses, logs, exhibits and scoring rubrics are original practice material. These references establish scope and explain the underlying security concepts; the questions are not taken from them.

## Exam alignment

This package targets **SY0-701**. The verified official source is CompTIA’s SY0-701 objectives document, version 6.0. It lists a maximum of 90 multiple-choice and performance-based questions in 90 minutes. The bank does not predict the number, format distribution, item weights or proprietary scoring rules of a particular exam form. Check the exam code on your booking when choosing a bank.

The live CompTIA certification page could not be retrieved during this research, so no retirement date or successor launch date is asserted. Security concepts were cross-checked using the primary references below. Where current professional guidance uses newer organization or terminology, the quiz remains mapped to the SY0-701 objective IDs.

## Reference registry

### S01

[CompTIA Security+ SY0-701 exam objectives, document version 6.0](https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6)

Scope: Exam scope, objective numbering, domain weights, maximum question count and duration.

Accessed: 2026-10-03.

### S02

[NIST Cybersecurity Framework 2.0](https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final)

Scope: Governance, risk outcomes, and the Govern function.

Accessed: 2026-10-03.

### S03

[NIST SP 800-61 Revision 3: Incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)

Scope: Incident preparation, detection, response, recovery and improvement. Current guidance complements the exam vocabulary.

Accessed: 2026-10-03.

### S04

[NIST SP 800-63B-4: Authentication and authenticator management](https://pages.nist.gov/800-63-4/sp800-63b.html)

Scope: Authentication factors, phishing resistance, passwords and authenticator lifecycle.

Accessed: 2026-10-03.

### S05

[NIST SP 800-207: Zero Trust Architecture](https://csrc.nist.gov/pubs/sp/800/207/final)

Scope: No implicit trust from location; identity and policy decisions.

Accessed: 2026-10-03.

### S06

[OWASP Top 10:2025](https://owasp.org/Top10/2025/)

Scope: Web application risks. Category numbers are not used as exam memorization requirements.

Accessed: 2026-10-03.

### S07

[CISA Known Exploited Vulnerabilities: official data mirror](https://github.com/cisagov/kev-data)

Scope: Known exploitation as a remediation-priority signal; no live vulnerability entry is required to solve a question.

Accessed: 2026-10-03.

### S08

[NIST SP 800-34 Revision 1: Contingency planning](https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final)

Scope: Recovery requirements, continuity, backups and testing.

Accessed: 2026-10-03.

### S09

[NIST SP 800-30 Revision 1: Risk assessment](https://csrc.nist.gov/pubs/sp/800/30/r1/final)

Scope: Threats, vulnerabilities, likelihood and impact.

Accessed: 2026-10-03.

### S10

[AWS shared responsibility model](https://aws.amazon.com/compliance/shared-responsibility-model/)

Scope: Responsibility depends on service model; guest operating systems and physical infrastructure.

Accessed: 2026-10-03.

### S11

[NIST SP 800-53 Revision 5: Security and privacy controls](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final)

Scope: Access, audit, configuration, personnel, physical and system controls.

Accessed: 2026-10-03.

### S12

[NIST SP 800-88 Revision 2: Media sanitization](https://csrc.nist.gov/pubs/sp/800/88/r2/final)

Scope: Clear, purge, destroy and verification; media-appropriate methods.

Accessed: 2026-10-03.

### S13

[OWASP Transport Layer Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html)

Scope: TLS deployment and certificate validation.

Accessed: 2026-10-03.

### S14

[NIST SP 800-57 Part 1 Revision 5: Key management](https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final)

Scope: Cryptographic keys, protection, lifecycle and recovery.

Accessed: 2026-10-03.

### S15

[MITRE ATT&CK enterprise tactics](https://attack.mitre.org/tactics/enterprise/)

Scope: Adversary behavior and evidence interpretation.

Accessed: 2026-10-03.

### S16

[OWASP SQL Injection Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html)

Scope: Parameterized queries and code/data separation.

Accessed: 2026-10-03.

### S17

[NIST SP 800-53A Revision 5: Assessing controls](https://csrc.nist.gov/pubs/sp/800/53/a/r5/final)

Scope: Control assessment evidence and methods.

Accessed: 2026-10-03.

### S18

[NIST SP 800-50 Revision 1: Cybersecurity and privacy learning](https://csrc.nist.gov/pubs/sp/800/50/r1/final)

Scope: Role-based training, behavior and awareness program evaluation.

Accessed: 2026-10-03.

### S19

[NIST SP 800-41 Revision 1: Firewalls and firewall policy](https://csrc.nist.gov/pubs/sp/800/41/r1/final)

Scope: Firewall policies, rule handling and traffic control.

Accessed: 2026-10-03.

### S20

[NIST SP 800-190: Application container security](https://csrc.nist.gov/pubs/sp/800/190/final)

Scope: Containers, image and runtime security.

Accessed: 2026-10-03.

### S21

[NIST SP 800-82 Revision 3: Operational technology security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

Scope: OT constraints, segmentation and safe maintenance.

Accessed: 2026-10-03.

### S22

[NIST SP 800-218: Secure Software Development Framework](https://csrc.nist.gov/pubs/sp/800/218/final)

Scope: Secure development, software integrity and vulnerability reduction.

Accessed: 2026-10-03.

### S23

[UK ICO: Controllers and processors](https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/controllers-and-processors/controllers-and-processors/what-are-controllers-and-processors/)

Scope: Privacy-role definitions, not jurisdiction-specific legal advice.

Accessed: 2026-10-03.

### S24

[NIST IR 8286A Revision 1: Identifying and estimating cybersecurity risk](https://csrc.nist.gov/pubs/ir/8286/a/r1/final)

Scope: Risk registers, appetite, tolerance, and risk estimation.

Accessed: 2026-10-03.

### S25

[European Commission: Requests from individuals under the GDPR](https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/dealing-requests-individuals_en)

Scope: Data-subject requests and exceptions to erasure where legal obligations require retention.

Accessed: 2026-10-03.

### S26

[IETF RFC 9525: Service Identity in TLS](https://www.rfc-editor.org/rfc/rfc9525.html)

Scope: Certificate service identities and wildcard matching in DNS subject alternative names.

Accessed: 2026-10-03.

### S27

[Microsoft Learn: Confidential computing](https://learn.microsoft.com/en-us/azure/confidential-computing/overview)

Scope: Trusted execution environments and data in use.

Accessed: 2026-10-03.

### S28

[IETF RFC 7489: DMARC](https://www.rfc-editor.org/rfc/rfc7489.html)

Scope: Email authentication alignment and policy.

Accessed: 2026-10-03.

### S29

[IETF RFC 7208: Sender Policy Framework](https://www.rfc-editor.org/rfc/rfc7208.html)

Scope: Sending-host authorization for email domains.

Accessed: 2026-10-03.

### S30

[IETF RFC 6376: DomainKeys Identified Mail](https://www.rfc-editor.org/rfc/rfc6376.html)

Scope: Email signatures and signing-domain identity.

Accessed: 2026-10-03.

### S31

[Microsoft Learn: Trusted Platform Module overview](https://learn.microsoft.com/en-us/windows/security/hardware-security/tpm/trusted-platform-module-overview)

Scope: Hardware-backed key protection and platform measurements.

Accessed: 2026-10-03.

### S32

[NIST SP 800-115: Technical Guide to Information Security Testing and Assessment](https://csrc.nist.gov/pubs/sp/800/115/final)

Scope: Technical assessments, planning and rules of engagement.

Accessed: 2026-10-03.

### S33

[FIRST: CVSS version 4.0 specification](https://www.first.org/cvss/v4.0/specification-document)

Scope: Vulnerability severity scoring and the role of additional context.

Accessed: 2026-10-03.

### S34

[CVE Program frequently asked questions (official archive)](https://www.cve.org/Resources/Media/Archives/OldWebsite/about/faqs.html)

Scope: Common identifiers and records for publicly disclosed vulnerabilities.

Accessed: 2026-10-03.

## Important interpretation choices

- General practice guidance is not a claim that every organization must implement every referenced NIST control. Scenario requirements determine the best answer.
- The incident-response questions use the phase terms in the exam objectives while accounting for context; they do not assert that every investigation follows one rigid sequence.
- Authentication questions distinguish two factors from two steps, and distinguish phishing resistance from ordinary MFA.
- Privacy questions state the relevant obligations in the scenario. They do not require memorizing an unstated jurisdictional notification deadline.
- Network logs use fictional environments. A suspicious indicator alone is not treated as conclusive attribution without corroborating facts.
- The official domain weights govern the 300-question allocation. The 25 PBQs are additional practice and are not a claim about CompTIA’s PBQ distribution.
