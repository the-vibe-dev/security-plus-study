# Original Security+ PBQ scenarios — v1.0.0


## SEC-PBQ-001 — Complete the branch security-control plan


A branch office is opening in a building shared with other tenants. You must select controls that directly address the gaps in the assessment. Funding is approved for one primary control per gap. Choose the most direct fit; assume each offered control works as described. The final two fields classify the specific controls named in those tasks, not the whole security program.

### Assessment


| Gap | Observation | Required result |
| --- | --- | --- |
| G1 | Vehicles can reach the glass entrance from the parking area. | Physically stop a vehicle before it reaches the entrance. |
| G2 | One employee badge can let several people through the server-room door together. | Enforce controlled entry one person at a time. |
| G3 | The security team learns about overnight door openings the following morning. | Alert staff when the door opens outside approved hours. |
| G4 | People ignore verbal guidance about visitor escorts. | Establish a mandatory, approved escort requirement. |
| G5 | An approved legacy console cannot support MFA for six months. | Add an alternative control that limits access to a guarded room. |
| G6 | A detector needs to flag use of a credential that legitimate employees should never use. | Generate a high-confidence alert when the decoy credential is used. |

### T01


G1: select the primary control.

- o1: Require badges at the reception checkpoint

- o2: Install high-visibility security warning signs

- o3: Install entrance cameras with motion alerts

- o4: Install crash-rated vehicle barriers at the entrance

### T02


G2: select the primary control.

- o1: Enable badge anti-passback on the existing single door

- o2: Replace the single-door badge reader with a biometric reader

- o3: Provide refresher training on challenging unbadged followers

- o4: Use an interlocked vestibule with one-person entry enforcement

### T03


G3: select the primary control.

- o1: Send real-time alerts from an after-hours door-contact sensor

- o2: Review overnight camera footage during the next security shift

- o3: Review the previous night access report each morning

- o4: Apply an automatic after-hours door-lock schedule

### T04


G4: select the primary control.

- o1: Add an escort-name field to the visitor sign-in log

- o2: Demonstrate the escort process during an awareness session

- o3: Publish optional suggestions for escorting visitors

- o4: Issue an approved policy requiring visitor escorts

### T05


G5: classify the guarded-room restriction relative to the temporarily unavailable MFA requirement.

- o1: Compensating

- o2: Directive

- o3: Detective

- o4: Corrective

### T06


G6: select the primary control.

- o1: Deploy a decoy web service that records anonymous visitors

- o2: Create an unused decoy credential with a use-triggered alert

- o3: Alert on every successful production administrator sign-in

- o4: Aggregate failed authentication attempts across employees

### T07


Classify the PRIMARY category of the approved visitor-escort policy document.

- o1: Physical

- o2: Technical

- o3: Managerial

- o4: Operational

### T08


Classify the PRIMARY function of the after-hours door-open alert.

- o1: Corrective

- o2: Preventive

- o3: Directive

- o4: Detective

References: 

## SEC-PBQ-002 — Repair the service certificate configuration


The branch migration has three independent TLS faults. Client clocks are correct, required roots are trusted, DNS returns the intended servers, and network connectivity works. Use the simulated certificate inspection results to complete a repair ticket. Each fault must be fixed without disabling certificate validation. The current time is 2026-10-03 14:00 UTC.

### TLS inspection results


| Service | Requested hostname | Certificate details | Client result |
| --- | --- | --- | --- |
| Inventory | inventory.branch.example | SAN: inventory-old.branch.example; validity 2026-01-01 to 2027-01-01; complete chain; not revoked | Host identity validation failed |
| Scheduling | shifts.branch.example | SAN: shifts.branch.example; validity 2026-01-01 to 2027-01-01; leaf only; issuer is Branch Issuing CA | Unable to build the chain to the trusted root |
| Admin gateway | admin.branch.example | SAN: admin.branch.example; complete chain; validity 2026-01-01 to 2027-01-01; OCSP status revoked | Certificate rejected |

The issuing CA confirms the admin gateway private key was exposed yesterday. The scheduling client does not retrieve missing intermediate certificates automatically.

### Change requirements


New gateway private keys must be non-exportable inside dedicated cryptographic hardware. The deployment package must carry a verifiable publisher signature. A rollback configuration and maintenance window are required before production changes.

### T01


Inventory: identify the failed certificate property.

- o1: Validity period

- o2: Requested hostname versus SAN

- o3: Revocation freshness

- o4: Trust-store root

### T02


Inventory: choose the appropriate repair.

- o1: Refresh the revocation information for the current certificate

- o2: Replace it with a certificate whose SAN includes inventory.branch.example

- o3: Reinstall the current certificate and its intermediate chain

- o4: Renew the current certificate with its existing SAN values

### T03


Scheduling: choose the missing item to install with the leaf certificate.

- o1: The issuing authority certificate revocation list

- o2: The Branch Issuing CA intermediate certificate

- o3: A duplicate of the already trusted root certificate

- o4: A fresh OCSP response for the leaf certificate

### T04


Admin gateway: choose the repair that addresses the disclosed private key.

- o1: Renew the certificate using the current private key

- o2: Generate a new key pair and obtain a replacement certificate

- o3: Reinstall the current certificate with a complete CA chain

- o4: Generate a new CSR that reuses the current private key

### T05


Admin gateway: choose the required location for its new non-exportable private key.

- o1: An operating-system keystore with exportable private keys

- o2: A password-manager vault with private-key export enabled

- o3: An HSM enforcing non-exportable private-key operations

- o4: An encrypted configuration file unlocked at service startup

### T06


Deployment verification: which key verifies the publisher's digital signature?

- o1: The publisher private key used to create the signature

- o2: The receiving system private key used for its own identity

- o3: The symmetric key established for the download TLS session

- o4: The publisher public key linked to the trusted publisher identity

### T07


Which TWO records are explicitly required by the stated change requirements before production modification? (Select TWO.)

- o1: A summary of current TLS handshake metrics

- o2: An approved maintenance-window record

- o3: A list of the trusted-root store contents

- o4: A certificate inventory refresh record

- o5: A documented rollback-configuration record

### T08


After the fixes, choose the strongest focused acceptance test.

- o1: Query the replacement leaf certificates for current revocation status

- o2: Verify a TCP connection and cipher negotiation with validation disabled

- o3: Test each hostname from a normal client with all certificate checks enabled

- o4: Match certificate serial numbers against files on the deployment server

References: https://www.rfc-editor.org/rfc/rfc9525.html

## SEC-PBQ-003 — Classify authentication attacks and apply controls


A SOC receives four normalized authentication reports. The reports describe password activity in analyst categories; no actual passwords are shown. Match each report to the best-supported attack pattern and select the most directly useful control from that task's choices. Treat each report independently. Do not infer an actor's nationality from an IP address.

### Report A


Between 09:00 and 09:03, one source at 198.51.100.24 tries the same common password against 65 different employee accounts. Each account receives one attempt; none succeeds.

### Report B


The application owner confirms that a list of previously breached username/password pairs was submitted from rotating sources. Several reused pairs authenticate successfully; there is no sequence of guesses against each account.

### Report C


From 09:15 to 09:20, 203.0.113.88 submits 4,200 different password guesses for the single account build-admin. The service does not slow or reject repeated failures.

### Report D


A help-desk account receives 19 unrequested push approval prompts in four minutes. The user reports pressing Approve just to stop the prompts. The attacker then receives a valid session.

### T01


Report A: select the attack pattern.

- o1: MFA fatigue

- o2: Password spraying

- o3: Credential stuffing

- o4: Password brute force against one account

### T02


Report A: select the best detection improvement.

- o1: Correlate common-source failures distributed across many accounts

- o2: Alert on a success after repeated failures for the same account

- o3: Alert only when one account has ten failures in a short period

- o4: Alert on geographically inconsistent successful sign-ins

### T03


Report B: select the attack pattern.

- o1: MFA fatigue

- o2: Password brute force against one account

- o3: Password spraying

- o4: Credential stuffing

### T04


Report B: select the strongest authentication control among these choices.

- o1: Increase the minimum permitted password length

- o2: Require a scheduled password change every 90 days

- o3: Reduce the maximum duration of authenticated sessions

- o4: Require phishing-resistant MFA for account sign-in

### T05


Report C: select the attack pattern.

- o1: Password spraying

- o2: Password brute force against one account

- o3: Credential stuffing

- o4: MFA fatigue

### T06


Report C: choose the control that directly reduces online guessing speed.

- o1: Add unique salts to stored password verifiers

- o2: Increase minimum password length and complexity requirements

- o3: Require password changes after administrative recovery events

- o4: Apply rate limits and progressive delays to repeated failed sign-ins

### T07


Report D: select the attack pattern.

- o1: MFA fatigue

- o2: Password spraying

- o3: Credential stuffing

- o4: Password brute force against one account

### T08


Report D: select the BEST immediate account response after the unauthorized session is confirmed.

- o1: Replace the push authenticator without revoking existing sessions

- o2: Reduce push frequency while retaining current sessions

- o3: Revoke active sessions and secure the affected account

- o4: Reset the password without invalidating existing sessions

References: 

## SEC-PBQ-004 — Triage three endpoint alerts


You are the on-call analyst for a retailer. The playbook authorizes network isolation of ordinary workstations through EDR, while leaving the operating system powered on for evidence collection. None of the workstations below is a safety-critical device. Do not run or reproduce any suspicious program; work from these static observations.

### Endpoint observations


| Host | Evidence | Current state |
| --- | --- | --- |
| POS-SUPPORT-7, 192.0.2.47 | Hundreds of documents changed extension; originals became unreadable; a payment demand appeared; writes are continuing to a shared folder. | EDR connected, active file changes |
| DESIGN-2, 192.0.2.52 | User installed an application advertised as a photo viewer. It secretly installed a remote-control component that receives commands. | Running, outbound connection to 203.0.113.19 |
| ADMIN-3, 192.0.2.63 | A memory-resident implant hides unauthorized privileged activity. Signed firmware inspection shows no change, but kernel-level monitoring reports hidden processes. | Under investigation |

File-server logs identify POS-SUPPORT-7 as the only workstation currently making the mass file changes. A known-good offline backup exists and has not been connected.

### Authorized response constraints


The analyst may isolate a workstation and block a confirmed malicious destination. Incident command must approve broad production shutdowns. Acquired evidence must retain timestamps, collection notes, and integrity hashes.

### T01


POS-SUPPORT-7: select the best-supported malware classification.

- o1: Adware

- o2: Trojan

- o3: Rootkit

- o4: Ransomware

### T02


DESIGN-2: select the delivery classification best supported by the disguised photo application.

- o1: Trojan

- o2: Adware

- o3: Ransomware

- o4: Rootkit

### T03


ADMIN-3: select the best-supported concealment classification.

- o1: Trojan

- o2: Rootkit

- o3: Adware

- o4: Ransomware

### T04


Choose the FIRST authorized action to stop POS-SUPPORT-7 from continuing the shared-folder damage.

- o1: Block its Internet traffic while leaving shared-folder access active

- o2: Schedule malware removal after the current shift completes

- o3: Isolate POS-SUPPORT-7 through the authorized EDR action

- o4: Finish a full disk image before restricting its network access

### T05


Choose the destination suitable for a targeted outbound block based on DESIGN-2 evidence.

- o1: 192.0.2.52, the local DESIGN-2 source address

- o2: 192.0.2.63, the local ADMIN-3 source address

- o3: 192.0.2.47, the local POS-SUPPORT-7 source address

- o4: 203.0.113.19, the observed outbound remote-control destination

### T06


Select TWO evidence items that most directly establish the workstation-to-share activity. (Select TWO.)

- o1: The latest backup-job completion report for the shared folder

- o2: DNS query records for external command-and-control domains

- o3: Endpoint process and file events from the same workstation and period

- o4: File-server audits showing the client and affected file operations

- o5: Antimalware signature-update status for the three workstations

### T07


Choose the appropriate backup handling while containment and eradication are incomplete.

- o1: Synchronize the current share into the sole offline recovery copy

- o2: Keep the offline backup isolated until a clean recovery environment is ready

- o3: Mount the offline backup read-write on the affected file server now

- o4: Use the backup as a live replacement share before completing containment

### T08


Which conclusion is supported by the supplied evidence?

- o1: DESIGN-2 was the initial source of every observed endpoint infection

- o2: Unchanged firmware establishes that ADMIN-3 has no host compromise

- o3: POS-SUPPORT-7 is a confirmed source of the current mass shared-file changes

- o4: The observed remote-control address identifies a particular attacker group

References: 

## SEC-PBQ-005 — Choose durable repairs for three application defects


A development team has reproduced three defects in an isolated test application. The following pseudocode and observations are intentionally simplified. Select the root cause and the durable correction for each case. The task is defensive review; no network requests or exploit execution are needed.

### Case A: customer search


```text
statement = "SELECT name FROM customers WHERE region = '" + request.region + "'"
database.execute(statement)
```
Controlled testing confirms the region value can change the structure of the database statement, allowing records outside the intended region to be returned.

### Case B: staff bulletin


```text
save_bulletin(request.message)
later_render = "<section>" + stored_message + "</section>"
```
A tester stores markup in a bulletin. Another user later views it, and the browser executes active content under the application's origin. The feature needs plain text, not user-supplied HTML.

### Case C: privileged file utility


```text
if path_is_allowed(user_path):
    wait_for_worker()
    privileged_write(open(user_path))
```
The user can modify a directory in the path. Testing shows the path can be redirected after the check and before the open, so a different file is modified.

### T01


Case A: choose the root cause.

- o1: Time-of-check/time-of-use race condition

- o2: SQL injection

- o3: Buffer overflow

- o4: Stored cross-site scripting

### T02


Case A: choose the durable correction.

- o1: Add a WAF rule blocking common SQL keyword patterns

- o2: Use a parameterized query and bind the region value as data

- o3: Limit the length of the submitted region value

- o4: HTML-encode query results before browser display

### T03


Case B: choose the root cause.

- o1: Stored cross-site scripting

- o2: SQL injection

- o3: Time-of-check/time-of-use race condition

- o4: Buffer overflow

### T04


Case B: choose the most appropriate correction for the plain-text-only requirement.

- o1: Check submitted markup only in the browser-side form validator

- o2: Remove only literal script tags before storing the message

- o3: Use a text-only rendering API or encoding for the HTML output context

- o4: Set HttpOnly on session cookies without changing bulletin rendering

### T05


Case C: choose the root cause.

- o1: Time-of-check/time-of-use race condition

- o2: Buffer overflow

- o3: SQL injection

- o4: Stored cross-site scripting

### T06


Case C: choose the strongest correction among the offered designs.

- o1: Repeat the pathname check, then open the path in a later operation

- o2: Check the filename extension before opening the user-controlled path

- o3: Safely open, validate, and use the same stable object handle

- o4: Lock only this process's threads while external directory writers remain active

### T07


Choose a common risk-reduction measure that limits the database impact if another injection defect remains.

- o1: Limit the application account to its required database privileges

- o2: Encrypt the database storage volumes

- o3: Enable detailed database-query audit logging

- o4: Require TLS for application-to-database connections

### T08


Select the BEST validation plan after the code changes.

- o1: Complete a code review without exercising the repaired behaviors

- o2: Run a general unauthenticated scan without the reproduced test cases

- o3: Retest each security defect and the associated legitimate operations

- o4: Compile the changes and run only existing happy-path unit tests

References: 

## SEC-PBQ-006 — Triage supplier and social-engineering reports


Four reports arrive at a distributor's help desk. Use the supplied facts to classify each event and select proportionate controls. The organization's payment policy requires independent verification of any bank-detail change using a previously recorded contact, and software releases are normally verified with a trusted publisher signature.

### Reports


| Report | Verified facts |
| --- | --- |
| A | An employee receives an SMS claiming a delivery fee is due. It links to a look-alike sign-in page at parcel-pay.example. |
| B | An attacker controls a supplier's real email account and uses an existing invoice thread to request payment to a different bank. The supplier confirms the change is fraudulent and intended to divert funds. |
| C | Attackers compromise a public industry forum regularly visited by the distributor's engineers. The site now serves a browser exploit to visitors. |
| D | A supplier's build environment is compromised. Its normal signing pipeline signs an altered update, which customers receive through the genuine updater. The organization validates that publisher's signature, so the altered package passes that check. |

### Scope notes


No evidence identifies the attackers' nationality or sponsor. The supplier update is under investigation. Existing release-hash records and deployment inventories are available for internal review.

### T01


Report A: select the delivery method.

- o1: Instant-message phishing

- o2: Email spear phishing

- o3: Smishing

- o4: Vishing

### T02


Report B: select the best-supported attack category.

- o1: Email domain spoofing

- o2: Business email compromise

- o3: Credential stuffing

- o4: An on-path network attack

### T03


Report B: select the required response to the bank-detail request.

- o1: Use passing mail authentication as approval for the bank change

- o2: Request confirmation in the existing supplier email thread

- o3: Verify the change through the supplier contact previously on file

- o4: Compare the request formatting with earlier legitimate invoices

### T04


Report C: select the attack pattern.

- o1: A compromised update distribution

- o2: A malicious removable-media delivery

- o3: Watering-hole attack

- o4: A targeted spear-phishing attachment

### T05


Report C: choose the most direct preventive combination among the options.

- o1: Increase attachment scanning on the corporate email gateway

- o2: Restrict unauthorized removable storage on engineering laptops

- o3: Patch browsers and restrict the confirmed compromised site during cleanup

- o4: Require stronger passwords at the industry forum

### T06


Report D: identify the compromised trust path.

- o1: Software build and distribution supply chain

- o2: Customer wireless authentication path

- o3: Customer DNS resolution path

- o4: Customer local network forwarding path

### T07


Report D: what does the valid publisher signature establish in this scenario?

- o1: The package passed an independent review of its code behavior

- o2: The customer approved every component included in the package

- o3: The publisher build environment was uncompromised when it signed

- o4: The package verifies under the trusted publisher signing key

### T08


Which motive is DIRECTLY supported for Report B?

- o1: Political advocacy

- o2: Military espionage

- o3: Financial gain through payment diversion

- o4: Authorized security research

References: 

## SEC-PBQ-007 — Configure a segmented application firewall


Complete the eight blank fields in the intended firewall policy. This simulated firewall is stateful: established return traffic is permitted automatically. Rules apply to NEW connections, evaluate from top to bottom, and stop at the first match. NAT and IPv6 are outside this exercise. Use the narrowest values that satisfy the requirements; the final rule handles all unmatched traffic.

### Network and traffic requirements


| Object | Address |
| --- | --- |
| Public reverse proxy | 192.0.2.10/32 |
| Application service | 192.0.2.20/32 |
| Database | 192.0.2.30/32 |
| Administrator subnet | 198.51.100.0/28 |

Clients from any source, including internal networks, may reach the reverse proxy on TCP 443. Internet clients have no other permitted destination or service in this policy. The reverse proxy may initiate connections to the application on TCP 8443. ONLY the application may initiate database sessions on TCP 5432. The administrator subnet may initiate SSH on TCP 22 to these three servers. All other new connections are denied.

### Policy editor


| Row | Action | Source | Destination | Protocol | Destination port |
| --- | --- | --- | --- | --- | --- |
| R1 | Allow | Any | [T01] | TCP | [T02] |
| R2 | Allow | [T03] | 192.0.2.20/32 | TCP | [T04] |
| R3 | Allow | [T05] | 192.0.2.30/32 | TCP | [T06] |
| R4 | Allow | [T07] | Server group: the three /32 addresses above | TCP | 22 |
| R5 | [T08] | Any | Any | Any | Any |

### T01


R1 destination: choose the permitted public-facing host.

- o1: 192.0.2.0/24

- o2: 192.0.2.10/32

- o3: 192.0.2.30/32

- o4: 192.0.2.20/32

### T02


R1 destination port: select the allowed service.

- o1: 5432

- o2: 8443

- o3: 443

- o4: 22

### T03


R2 source: choose the host allowed to reach the application service.

- o1: 192.0.2.0/24

- o2: 192.0.2.10/32

- o3: 192.0.2.20/32

- o4: 192.0.2.30/32

### T04


R2 destination port: select the application back-end listener.

- o1: 8443

- o2: 22

- o3: 443

- o4: 5432

### T05


R3 source: select the only allowed database client.

- o1: 192.0.2.30/32

- o2: 192.0.2.20/32

- o3: 192.0.2.10/32

- o4: 192.0.2.0/24

### T06


R3 destination port: select the database listener.

- o1: 8443

- o2: 443

- o3: 5432

- o4: 22

### T07


R4 source: select the narrowest approved administrator range.

- o1: 0.0.0.0/0

- o2: 198.51.100.0/24

- o3: 198.51.100.0/28

- o4: 192.0.2.0/24

### T08


R5 action: choose the policy for unmatched new connections.

- o1: Allow

- o2: Deny

References: 

## SEC-PBQ-008 — Complete the cloud deployment responsibility worksheet


A small company uses two cloud services. Service I provides virtual machines with a customer-managed guest operating system; the provider manages the physical host and virtualization platform. Service S is a fully managed SaaS payroll application; the provider manages its application software, but the customer configures users and data-sharing rules. These contract assignments are explicit for this exercise. Complete the ownership and configuration worksheet.

### Deployment review


| Item | Current condition | Required result |
| --- | --- | --- |
| I-VM | Guest OS security update is pending. | The assigned owner deploys and verifies the update. |
| I-HOST | Physical host replacement is required. | The assigned owner replaces and secures the infrastructure. |
| S-APP | SaaS payroll application code needs a security fix. | The assigned owner fixes the hosted application. |
| S-USERS | A departed employee still has an active customer-created payroll account. | Access ends under the customer joiner/mover/leaver process. |
| STORAGE | A storage policy permits anonymous reads of private invoices. | Only the invoice service can read those private invoices. |
| APP-ID | The invoice service currently uses an organization-wide administrator credential. | It can read only its required invoice objects. |
| BACKUP | Production administrators can delete production and every backup. | A production compromise must not automatically grant backup deletion. |
| DATA | Contract permits invoice processing only in Region R. | The deployment and copies stay in approved Region R. |

### T01


I-VM: assign guest operating-system patch deployment.

- o1: Customer

- o2: Cloud service provider

### T02


I-HOST: assign physical host replacement.

- o1: Cloud service provider

- o2: Customer

### T03


S-APP: assign the SaaS payroll application code fix.

- o1: Customer

- o2: Cloud service provider

### T04


S-USERS: choose the appropriate action and owner.

- o1: The customer disables the tenant account and revokes its active access

- o2: The customer removes the directory entry without checking SaaS account state

- o3: The customer changes the password but preserves all existing sessions

- o4: The provider is asked to remove the user during its next application update

### T05


STORAGE: choose the effective access-policy change.

- o1: Remove anonymous reads and authorize only required invoice-service access

- o2: Add storage encryption while retaining the current read policy

- o3: Place the objects behind unpredictable URLs with the same read policy

- o4: Enable storage access logging without changing the read policy

### T06


APP-ID: choose the least-privilege identity design.

- o1: Use a distinct workload identity with read access to all company data

- o2: Use a distinct workload identity limited to required invoice reads

- o3: Use one administrator workload identity shared by all applications

- o4: Use a team employee identity with the team existing permissions

### T07


BACKUP: choose the design that best meets the deletion-separation requirement.

- o1: Use separately administered backups with protected retention settings

- o2: Use a continuously synchronized replica managed by production admins

- o3: Enable backup versioning that production admins can still purge

- o4: Encrypt backups while retaining the production deletion credentials

### T08


DATA: choose the configuration that meets the stated regional constraint.

- o1: Use Region R labels while allowing automatic cross-region failover

- o2: Use Region R for the primary copy and the provider default backup region

- o3: Use Region R for storage but a global processing service

- o4: Use Region R for processing and all copies, then verify actual placement

References: 

## SEC-PBQ-009 — Configure protection for the employee-data workflow


You are reviewing a new employee-data workflow. Apply the organization's classification policy and choose controls that meet each stated functional requirement. The policy in the exhibit is authoritative for this fictional organization; no external legal deadlines or classification schemes are assumed.

### Policy and workflow


Classification priority, highest first: **Restricted** includes national identifiers and authentication secrets; **Confidential** includes employee compensation; **Internal** includes non-public operating instructions; **Public** includes approved press releases. A mixed dataset receives the highest classification of any included field.

The export contains names, annual salaries, and national identifiers. Support staff need to see only the last four identifier digits. A production service must replace identifiers with reusable substitute values and retrieve originals only through a separately authorized mapping service. Field laptops store the export while powered off, and uploads cross the public Internet. Marketing needs only an already-approved public announcement. Encryption recovery keys must remain available to authorized recovery staff without being stored beside every encrypted export.

### T01


Assign the classification of the complete employee export.

- o1: Confidential

- o2: Public

- o3: Internal

- o4: Restricted

### T02


Support display: select the transformation that exposes only the allowed last four digits.

- o1: Encrypt each identifier and display its ciphertext

- o2: Replace each identifier with an unrelated lookup token

- o3: Mask all identifier digits except the approved last four

- o4: Hash each identifier and display a shortened digest

### T03


Production substitution: select the mechanism matching reusable substitutes and a separately protected mapping service.

- o1: Whole-volume encryption

- o2: Display masking

- o3: Tokenization

- o4: One-way hashing

### T04


Powered-off laptop: choose the primary control for confidentiality of the local storage if the device is stolen.

- o1: Endpoint DLP rules for removable-media copies

- o2: TLS protection for the upload channel

- o3: An operating-system login with account lockout

- o4: Full-disk encryption with protected recovery keys

### T05


Internet upload: choose the primary protection for confidentiality and integrity in transit.

- o1: Encryption of the destination storage volume only

- o2: A keyed integrity tag attached to an unencrypted upload

- o3: Digital signing of the unencrypted export

- o4: Authenticated TLS with certificate validation

### T06


Marketing request: choose the minimum data release that satisfies the request.

- o1: Release the announcement plus identifiers because four digits are masked

- o2: Release the announcement plus salary details

- o3: Release only the approved public announcement

- o4: Release the complete employee export

### T07


Recovery-key storage: select the best fit for the stated access and separation requirement.

- o1: Store the key in the same archive under the same access permissions

- o2: Use restricted and audited key-management or escrow recovery access

- o3: Keep a key copy in every local export directory for convenience

- o4: Keep recovery solely in one employee personal password vault

### T08


Choose the BEST DLP test after deployment.

- o1: Check that DLP agents are online without testing an export

- o2: Inspect the configured DLP rules without submitting test data

- o3: Test synthetic Restricted data blocking and the permitted public release

- o4: Review historical DLP alerts without testing the new workflow

References: 

## SEC-PBQ-010 — Select and validate a recovery design


A branch ordering service may lose no more than 15 minutes of committed transactions and must resume within 30 minutes after an outage. The recurring budget is at most $1,000 per month. Choose the lowest-cost design that satisfies BOTH recovery requirements and the budget. Assume the listed performance estimates are achievable; all amounts and times are synthetic.

### Design candidates


| Design | Maximum data loss | Estimated service restoration | Monthly cost |
| --- | --- | --- | --- |
| A | 24 hours | 90 minutes | $200 |
| B | 5 minutes | 12 minutes | $800 |
| C | 0 minutes | 3 minutes | $2,500 |
| D | 60 minutes | 20 minutes | $500 |

### Recovery exercise


The service fails at 14:00 UTC. The recovered copy contains all transactions committed through 13:56 UTC and none after that time. Users can complete normal ordering at 14:22 UTC.

The recovery runbook requires these dependencies in this order: name/identity services must work before the database can start; the database must work before the application can start; the application must pass its health check before the public portal is enabled. This exercise has one instance of each component.

### T01


Enter the required recovery point objective (RPO), in minutes.

### T02


Enter the required recovery time objective (RTO), in minutes.

### T03


Select the lowest-cost design that meets both objectives AND the budget.

- o1: Design B

- o2: Design A

- o3: Design C

- o4: Design D

### T04


Calculate the gap, in minutes, between the latest recovered commit time and the outage time.

### T05


For the exercise, how many minutes elapse before normal service is restored?

### T06


Evaluate the exercise against the requirements.

- o1: Both RPO and RTO were met

- o2: Only RTO was met

- o3: Neither was met

- o4: Only RPO was met

### T07


Choose an additional measure that preserves a recovery option if malicious deletion replicates immediately.

- o1: Increase live-replication frequency to minimize ordinary data loss

- o2: Keep a continuously synchronized replica with the same deletion access

- o3: Mirror the production disks within the same storage array

- o4: Maintain tested isolated or immutable backups with protected retention

### T08


Place all four recovery components in the exact dependency order stated in the runbook.

- o1: Restore name and identity services

- o2: Enable the public portal

- o3: Start and health-check the application

- o4: Start and validate the database

References: 

## SEC-PBQ-011 — Secure a constrained warehouse control network


A warehouse uses legacy conveyor controllers. The vendor does not support endpoint agents or active vulnerability scans during operation. A four-hour maintenance window is available next month. The safety team has approved a separate physical emergency stop system. Your design must reduce cyber exposure without violating these operating constraints. Choose the best configuration for each field.

### Requirements


| Area | Requirement |
| --- | --- |
| Monitoring | Observe traffic now without sending probe traffic to controllers. |
| Segmentation | Office workstations must not initiate controller connections. An approved management jump host may reach the required management service. |
| Updates | Test vendor-supported updates on a representative spare before the maintenance window. |
| Network failure | For this non-safety management data path, loss of security enforcement must not create unrestricted office-to-controller access. |
| Emergency exit | The safety-approved exit hardware must permit emergency egress if power is lost. |
| Short power loss | Bridge the 45 seconds required for the installed generator to stabilize. |
| Extended power loss | Keep the approved network equipment powered through a four-hour utility outage. |
| Recovery | Verify a known-good controller configuration on a spare before restoring a failed production unit. |

### T01


Monitoring: select the compatible approach.

- o1: Install an endpoint-monitoring agent on each legacy controller

- o2: Run a low-intensity active vulnerability scan during operations

- o3: Observe a copied traffic stream through a configured mirror or TAP

- o4: Poll controller management services for state every minute

### T02


Segmentation: choose the access policy.

- o1: Separate VLANs but retain unrestricted inter-VLAN routing

- o2: Allow the approved jump host to all controller service ports

- o3: Deny office access and permit only the jump host required service

- o4: Allow the office subnet to the controller management service

### T03


Updates: select the next appropriate action.

- o1: Replace the controller image with the latest generic OS release

- o2: Deploy the signed update to production without a representative test

- o3: Prepare the installer without testing its recovery procedure

- o4: Test the update and rollback on the spare, then schedule the change

### T04


Non-safety management data path: choose the required enforcement-failure behavior.

- o1: Fail open to unrestricted office traffic

- o2: Fail closed for that management data path

### T05


Emergency exit: choose the required behavior for outward egress when power fails.

- o1: Permit emergency outward egress as approved by the safety design

- o2: Prevent all outward egress until authentication recovers

### T06


Short power loss: choose the device that bridges generator startup.

- o1: Automatic transfer switch without stored energy

- o2: Uninterruptible power supply

- o3: Rack power distribution unit

- o4: Surge suppression unit

### T07


Extended power loss: choose the source intended to supply the four-hour outage, given the installed design.

- o1: A UPS with 45 seconds of runtime at the required load

- o2: A transfer switch with no functioning alternate power source

- o3: The installed correctly sized generator with adequate fuel

- o4: Redundant power supplies connected to the same utility feed

### T08


Recovery: choose the strongest acceptance evidence before restoring the production unit.

- o1: The verified backup restores and passes functional tests on the spare

- o2: The saved configuration passes a syntax-only inspection

- o3: The scheduled backup job reports successful completion

- o4: The backup file hash matches its recorded acquisition hash

References: 

## SEC-PBQ-012 — Configure staff and guest wireless access


You are configuring two SSIDs in a simulated wireless controller. All managed staff laptops support WPA3-Enterprise and client-certificate authentication. The organization wants individual device identities, no shared staff Wi-Fi password, validation of the legitimate authentication server, and guest separation. Complete the eight settings. All listed VLANs already exist and routing policies have been tested.

### Approved design


| Object | Approved setting or role |
| --- | --- |
| staff-wifi | Managed staff devices with organization-issued client certificates |
| guest-wifi | Internet-only visitors; no corporate resources |
| 198.51.100.10 | RADIUS authentication server, DNS name radius.branch.example |
| 198.51.100.20 | Guest captive portal, not an authentication server for staff |
| VLAN 20 | Staff network |
| VLAN 99 | Internet-only guest network |
| VLAN 10 | Network-device management |

Staff devices must trust only the approved certificate authority for the RADIUS server and verify radius.branch.example. Guest clients must not communicate directly with other guest clients. Push-button/PIN enrollment is prohibited.

### T01


staff-wifi security mode: choose the required mode.

- o1: Enhanced Open with OWE

- o2: WPA2-Personal with a shared passphrase

- o3: WPA3-Enterprise

- o4: WPA3-Personal with a shared passphrase

### T02


Staff authentication method: choose the certificate-based method.

- o1: A shared pre-shared key

- o2: EAP-TLS

- o3: EAP-TTLS with username/password authentication

- o4: PEAP with username/password authentication

### T03


Staff RADIUS server: choose the approved address.

- o1: 192.0.2.10

- o2: 198.51.100.10

- o3: 192.0.2.20

- o4: 198.51.100.20

### T04


Staff supplicant server validation: choose the setting.

- o1: Check certificate dates without checking the issuing authority

- o2: Require the approved CA and radius.branch.example identity

- o3: Require the approved CA without checking the server name

- o4: Trust the first server certificate observed during enrollment

### T05


Staff VLAN: choose the correct network assignment.

- o1: VLAN 20

- o2: VLAN 99

- o3: Native VLAN 1

- o4: VLAN 10

### T06


Guest VLAN: choose the correct network assignment.

- o1: Native VLAN 1

- o2: VLAN 99

- o3: VLAN 20

- o4: VLAN 10

### T07


Guest client isolation: choose the setting.

- o1: Disabled

- o2: Enabled

### T08


Push-button/PIN enrollment feature (WPS): choose the setting.

- o1: Disabled

- o2: Enabled

References: 

## SEC-PBQ-013 — Apply a secure server and session baseline


A Linux web server is being promoted from test to production. Administrators have individual accounts and tested SSH keys. The web application needs to read its own configuration and write its own upload directory; it needs no root privileges. Its session cookie is used over HTTPS. Users must be able to follow a normal top-level link from an external email into an authenticated view, but the application requires no cross-site POST or embedded third-party session access. Complete the baseline fields.

### Baseline review


| Field | Current condition |
| --- | --- |
| Remote service | Telnet is still enabled although SSH is available. |
| Direct root login | Direct SSH login as root is allowed. |
| SSH authentication | Password login is still enabled alongside tested keys. |
| Web service identity | Application runs as root. |
| Session cookie transport | Cookie lacks a transport restriction. |
| Session cookie script access | Page JavaScript can read the session cookie. |
| Session cookie cross-site policy | No SameSite attribute is set. |
| Configuration control | Production settings can drift with no comparison to an approved baseline. |

### T01


Remote service: select the appropriate setting.

- o1: Disable Telnet and use the approved SSH service

- o2: Retain Telnet but restrict it to the administrator subnet

- o3: Retain Telnet with longer administrator passwords

- o4: Retain Telnet as a fallback whenever SSH is unavailable

### T02


Direct root SSH login: select the setting.

- o1: Use named accounts with controlled elevation; deny direct root login

- o2: Permit direct root login with a regularly rotated password

- o3: Permit direct root login only from the management subnet

- o4: Permit direct root login using administrator public keys

### T03


SSH authentication: choose the setting consistent with the established key-only operations plan.

- o1: Require individual SSH keys and disable password authentication

- o2: Allow individual keys or passwords as interchangeable login methods

- o3: Require individual passwords and disable public-key authentication

- o4: Use one shared SSH private key for all administrators

### T04


Web service identity: select the minimum required permission design.

- o1: Run under an administrator employee account with application access

- o2: Run as root but restrict which network clients can connect

- o3: Use a non-root identity with configuration-read and upload-write access

- o4: Use a non-root identity with write access to all application code

### T05


Session cookie transport flag: select the setting that restricts transmission to secure transport.

- o1: Path=/

- o2: HttpOnly

- o3: SameSite=Strict

- o4: Secure

### T06


Session cookie script-access flag: select the setting that prevents ordinary page JavaScript from reading it.

- o1: SameSite=Strict

- o2: Secure

- o3: Max-Age=300

- o4: HttpOnly

### T07


Choose the explicit SameSite policy that supports the required incoming top-level links while limiting cross-site requests.

- o1: Lax

- o2: Leave SameSite unset and use the browser default

- o3: None

- o4: Strict

### T08


Configuration control: select the best ongoing validation.

- o1: Review change tickets without comparing actual deployed settings

- o2: Check installed package versions without checking configuration values

- o3: Review server availability metrics and error-rate dashboards

- o4: Compare deployed settings with the approved versioned baseline

References: https://www.rfc-editor.org/rfc/rfc6265.html, https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie

## SEC-PBQ-014 — Repair identity lifecycle and privilege assignments


An access review finds eight tasks that must be completed. Apply the role definitions and business rules below. Select the least-privilege action that satisfies each person's current job. Routine service operations must remain available; do not solve an individual identity problem by disabling the entire application.

### Roles and business rules


| Role | Permissions |
| --- | --- |
| Observer | Read device status and logs |
| Operator | Observer permissions plus restart assigned devices |
| Administrator | Operator permissions plus change security policies and manage accounts |

New technician Alex needs to read logs and restart assigned devices. Morgan moved from device support to finance and no longer needs device-control access. Sam left employment today. Priya needs one approved 30-minute administrator session tomorrow. Purchase requests require approval by a different person than the requester. The unattended report service reads only its report dataset. Shared technician accounts are prohibited. A staff member reports a lost hardware authentication key; a verified recovery process is available.

### T01


Alex: assign the narrowest role that meets the job requirements.

- o1: Observer

- o2: Administrator

- o3: Operator

- o4: No device-control role

### T02


Morgan: choose the correct handling of the previous device-support role.

- o1: Retain the Operator role until the next annual review

- o2: Remove the unneeded device-control role during the move

- o3: Add finance access while retaining the previous support role

- o4: Disable the whole identity despite the new finance assignment

### T03


Sam: choose the immediate offboarding action.

- o1: Schedule access removal after the next periodic access review

- o2: Rotate the password while leaving issued access tokens valid

- o3: Disable sign-in and revoke active sessions and credentials

- o4: Block new interactive logins but leave active sessions and tokens

### T04


Priya: choose the best privileged-access arrangement.

- o1: Provide a shared administrator credential for the task

- o2: Grant standing administrator rights with daily log review

- o3: Grant the role for the whole shift and remove it manually later

- o4: Use approved 30-minute JIT elevation with expiry and logging

### T05


Purchases: choose the access rule that implements the stated separation of duties.

- o1: Prevent the requester from approving the same request

- o2: Require MFA whenever a user approves a request

- o3: Limit the monetary value that any requester can approve

- o4: Log approvals and review requester self-approvals afterward

### T06


Report service: choose the best identity and permission assignment.

- o1: Use a dedicated service identity with read, write, and delete access

- o2: Use a dedicated service identity limited to required dataset reads

- o3: Use an employee identity with access to the required report dataset

- o4: Use a shared service identity that can read every department dataset

### T07


Shared technician login: choose the corrective action.

- o1: Rotate the shared password more often and increase its length

- o2: Keep the shared login but record password-vault checkouts

- o3: Replace the shared login with named accounts and approved roles

- o4: Keep the shared login but limit it to management-network sources

### T08


Lost hardware authentication key: choose the next action after verifying the report under the recovery process.

- o1: Allow temporary password-only access without addressing the lost key

- o2: Enroll an additional key while leaving the lost key registered

- o3: Reset the account password while keeping the lost key registered

- o4: Revoke the lost key and enroll a replacement through verified recovery

References: 

## SEC-PBQ-015 — Build the vulnerability remediation queue


You have one maintenance team and must build a remediation queue. The organization uses this priority ladder: (1) reachable production flaws with confirmed exploitation in the wild; (2) other Internet-reachable production flaws; (3) internal production flaws; (4) isolated lab findings. Within a tier, higher impact wins. The four queued flaws are all verified applicable; do not rank by CVSS alone. A separate banner-only finding needs validation.

### Verified queue


| ID | System | CVSS | Reachability and evidence |
| --- | --- | --- | --- |
| V-41 | Edge gateway | 8.1 | Internet reachable; confirmed exploitation in the wild; vulnerable optional diagnostics endpoint is enabled |
| V-42 | Customer portal | 9.8 | Internet reachable; no confirmed exploitation known to the team |
| V-43 | Internal file server | 9.8 | Internal production network only; no confirmed exploitation known to the team |
| V-44 | Training VM | 9.8 | Isolated lab with synthetic data; no production route |

For V-41, the vendor provides an approved temporary workaround that disables only the vulnerable optional diagnostics endpoint. Its permanent patch will be available during the emergency window later today.

### Additional records


A scanner flags WEB-OLD only from its version banner. The operating-system vendor may have backported the fix without changing that upstream banner. The signed package release and vendor advisory have not yet been compared.

Every deferred production item requires a named risk owner, documented compensating controls, an expiry/review date, and approval. Successful remediation requires security verification and a representative business-function check.

### T01


Order all four verified findings from highest to lowest priority using the stated ladder.

- o1: V-41: edge gateway

- o2: V-43: internal file server

- o3: V-42: customer portal

- o4: V-44: training VM

### T02


V-41: choose the best temporary step while the emergency patch is prepared.

- o1: Increase endpoint logging while retaining its existing exposure

- o2: Add a detection-only network rule for suspicious endpoint requests

- o3: Require MFA for administrator logins while leaving the endpoint enabled

- o4: Apply and verify the approved optional-endpoint workaround

### T03


V-42: choose the appropriate patch deployment preparation.

- o1: Approve production release based only on the package signature

- o2: Scan for the flaw again but omit rollback preparation

- o3: Test the patch and rollback on a representative system before release

- o4: Reuse an unrelated server recovery plan without validating it

### T04


WEB-OLD: choose the next validation step.

- o1: Repeat a banner-only scan using another scanner product

- o2: Close the finding because a scheduled patch job ran recently

- o3: Compare the installed package release with the vendor backport advisory

- o4: Confirm vulnerability solely from the upstream version banner

### T05


After patching V-41, choose the strongest focused security verification.

- o1: Confirm that the patch installer returned a success status

- o2: Confirm that the patch ticket was moved to its closed state

- o3: Confirm that the externally displayed version string changed

- o4: Verify the running fixed component and safely retest the affected condition

### T06


Choose the complete exception record required for a deferred production flaw.

- o1: Patch release date, installer checksum, platform, and restart plan

- o2: Business reason, system owner, purchase date, and support contract

- o3: Asset name, CVSS score, scanner report, and ticket identifier

- o4: Risk owner, compensating controls, review date, and approval

### T07


Select the additional check needed before declaring a production patch fully successful.

- o1: Exercise representative business functions after the security checks

- o2: Confirm that the asset inventory contains the updated package version

- o3: Confirm the vulnerability dashboard no longer lists the finding

- o4: Check only that the operating system recorded a successful startup

### T08


Which statement explains why CVSS alone is insufficient for this remediation queue?

- o1: The severity number already incorporates local asset business priorities

- o2: All Internet-facing systems have the same business impact by definition

- o3: Local priority also depends on exploitation, exposure, and production context

- o4: A scanner detection by itself establishes exploitation in the wild

References: 

## SEC-PBQ-016 — Correlate a suspicious sign-in and outbound transfer


Review the static logs below. All clocks are synchronized. Endpoint and proxy inventory reliably map 192.0.2.17 to FIELD-17 for the entire period. Timestamps marked -04:00 are four hours behind UTC. Security has confirmed that the new remote session was unauthorized. The destination invoice-drop.example is unapproved, but the transfer contents have not yet been inspected. Preserve this distinction when selecting conclusions.

### Normalized log excerpts


```text
L1 proxy 2026-10-03T09:00:00-04:00 host=FIELD-17 src=192.0.2.17 user=mlee
   method=GET url=https://benefits-review.example/login status=200
L2 idp   2026-10-03T13:02:00Z user=mlee src=203.0.113.64 result=MFA_DENIED
L3 idp   2026-10-03T13:03:00Z user=mlee src=203.0.113.64 result=SUCCESS session=K884
L4 edr   2026-10-03T09:05:00-04:00 host=FIELD-17 user=mlee
   action=archive_created file=work-cache.zip parent=unapproved_process
L5 proxy 2026-10-03T13:06:00Z host=FIELD-17 src=192.0.2.17
   method=POST dst=203.0.113.77 host_header=invoice-drop.example bytes_sent=4200000 status=200
```

The metadata records bytes and destination, not a decoded upload body. Session K884 remains active when the analyst begins review.

### T01


Select the endpoint associated with the archive and transfer.

- o1: FIELD-71

- o2: FIELD-17

- o3: No endpoint can be identified from these records

- o4: The identity-provider server

### T02


Select the account associated with the confirmed unauthorized session.

- o1: The records contain no account name

- o2: invoice-service

- o3: mlee

- o4: administrator

### T03


Convert the timestamp of L1 to UTC.

- o1: 13:00 UTC

- o2: 05:00 UTC

- o3: 09:00 UTC

- o4: 17:00 UTC

### T04


Place L1 through L5 in chronological order after time normalization.

- o1: L4: archive created

- o2: L5: outbound POST

- o3: L2: MFA denied

- o4: L3: unauthorized sign-in succeeds

- o5: L1: login-page request

### T05


Choose the immediate account-containment action for the confirmed unauthorized access.

- o1: Reduce new-session lifetimes without revoking session K884

- o2: Require an additional factor at the next future sign-in only

- o3: Reset the password but preserve all currently issued sessions

- o4: Revoke session K884 and secure the affected account

### T06


Select the destination that should be investigated for the observed upload.

- o1: invoice-drop.example

- o2: 203.0.113.64

- o3: benefits-review.example

- o4: 192.0.2.17

### T07


Choose the strongest conclusion supported by the transfer metadata alone.

- o1: The log records 4,200,000 outbound bytes but not their data classification

- o2: The HTTP status proves the remote application permanently stored the data

- o3: The byte count identifies the amount returned by the destination server

- o4: The POST proves the complete work-cache.zip archive was uploaded

### T08


Select TWO follow-up evidence sources that best help determine what was uploaded. (Select TWO.)

- o1: Preserved archive contents and endpoint file-access records

- o2: Identity-provider records for account authentication attempts

- o3: DNS resolver records for the upload destination hostname

- o4: Available content-aware DLP or approved upload-inspection records

- o5: Network-flow summaries with source, destination, and byte totals

References: 

## SEC-PBQ-017 — Complete the active-incident response board


Incident command asks you to complete the response board. The local playbook authorizes EDR isolation of ordinary workstations and revocation of confirmed compromised sessions. These actions do not require a building-wide shutdown. Evidence handling should keep a system powered when it can be safely isolated and volatile evidence is needed. External incident statements are issued by the designated communications lead after legal and incident-command review.

### Validated incident observations


| System | Observation | Validation |
| --- | --- | --- |
| WS-21 | An unapproved remote process is reading credential material and using session S-51. | Security confirmed active unauthorized behavior. |
| WS-22 | Administrative software installed at 10:00. | Matches approved change CHG-88 and expected signature. |
| WS-23 | Failed sign-in after the user mistyped a password. | One failure, followed by normal verified activity. |

WS-21 is a standard office workstation. It is powered on, EDR is connected, and the forensic analyst needs volatile-memory evidence.

### Local workflow dependencies


For this exercise, the incident board uses five milestones. Triage validates the event before containment begins. The eradication milestone follows containment and evidence preservation. Recovery follows removal of the root cause and validation of a trusted state. The final review occurs after stable service restoration. Activities may overlap in real incidents, but order these milestone cards according to this specified workflow.

### T01


Select the system with confirmed active compromise.

- o1: WS-21

- o2: WS-22

- o3: All three are confirmed compromised

- o4: WS-23

### T02


WS-21: choose the immediate authorized host-containment action.

- o1: Log off the interactive user while leaving the workstation connected

- o2: Finish full disk acquisition before making any containment change

- o3: Block only the Internet destination while retaining other connectivity

- o4: Isolate WS-21 through EDR while preserving its powered state

### T03


Session S-51: select the appropriate account-containment step.

- o1: Add MFA to future logins while preserving the current session

- o2: Revoke S-51 and secure the associated compromised identity

- o3: Reset the password without invalidating currently issued sessions

- o4: Reduce the default lifetime of sessions issued in the future

### T04


After safe network isolation, select the appropriate handling for needed volatile evidence.

- o1: Collect a disk image, shut down, and defer memory acquisition

- o2: Acquire volatile evidence through the authorized procedure before shutdown

- o3: Disconnect power now and collect only persistent storage later

- o4: Boot from forensic media before attempting to capture running memory

### T05


Order the five milestone cards using the local workflow dependencies.

- o1: Contain confirmed compromise

- o2: Recover trusted service

- o3: Post-incident review

- o4: Eradicate the cause after evidence preservation

- o5: Validate and triage the event

### T06


Select the strongest condition for reconnecting the recovered workstation.

- o1: The system starts and its normal startup event is recorded

- o2: The cause is fixed and trusted recovery passes security and business checks

- o3: No endpoint alert appeared during a brief observation interval

- o4: The operating system is rebuilt with the original vulnerable configuration

### T07


Select who should issue an external incident statement under the stated policy.

- o1: The supplier account manager responsible for the affected product

- o2: The on-call analyst who first validated the alert

- o3: The help-desk manager who owns the user support ticket

- o4: The designated communications lead after the required review

### T08


Choose the most useful review deliverable after stable recovery.

- o1: Record restoration costs and asset counts without assigning corrective work

- o2: Record alert volume and ticket closure times without assessing response gaps

- o3: Update the incident severity rating without reviewing the underlying causes

- o4: Record the cause, response gaps, and improvements with accountable owners

References: 

## SEC-PBQ-018 — Complete an evidence preservation worksheet


A workstation has already been safely isolated. An authorized forensic analyst is collecting evidence under the organization's procedure. It requires volatile memory acquisition before shutdown, preserved originals, working copies for analysis, integrity verification after transfer, and a complete transfer log. A legal hold applies to the incident records. The displayed hashes are synthetic SHA-256 values, not actual case evidence.

### Evidence register


| Item | Description | SHA-256 |
| --- | --- | --- |
| IMG-01 | Original disk image | a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1 |
| COPY-A | First analysis copy | a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1 |
| COPY-B | Newly transferred copy | b1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1 |

Both copy hashes were calculated after transfer, using the same algorithm. No authorized modification to the images is expected.

### Transfer log entry


```text
Item: IMG-01
Released by: Analyst Rivera
Received by: [blank]
Transfer time: 2026-10-03T15:20:00Z
Purpose: move sealed media to evidence storage
Location: Evidence cabinet E-4
Release acknowledgement: recorded
Receipt acknowledgement: [blank]
```

The incident logs include both UTC and explicit local-offset timestamps. The normal retention schedule would delete the oldest logs tomorrow, but the legal hold covers those records.

### T01


Before shutdown, select the collection step required by the procedure.

- o1: Shut down first and image persistent storage from forensic media

- o2: Restart into a clean environment before attempting memory acquisition

- o3: Export application logs, shut down, and omit volatile collection

- o4: Acquire volatile memory using the authorized procedure

### T02


Select the appropriate handling of the original disk image during analysis.

- o1: Analyze the transferred copy before completing its integrity check

- o2: Retain only the working copy after the first analysis completes

- o3: Preserve the original and analyze an integrity-verified working copy

- o4: Mount the original read-write so tools can place their output beside it

### T03


Select the copy that passes the displayed integrity comparison with IMG-01.

- o1: COPY-A

- o2: COPY-B

- o3: Both copies

- o4: Neither copy

### T04


Assess COPY-B against IMG-01 and select the appropriate handling.

- o1: Preserve both records, investigate differences, and reacquire as needed

- o2: Replace the original baseline hash with the transferred-copy hash

- o3: Begin analysis and reconcile copy integrity after the findings are written

- o4: Accept the copy if its byte size matches the original image

### T05


Select TWO missing transfer-log elements needed to complete this handoff. (Select TWO.)

- o1: Identity of the receiving custodian

- o2: The stated purpose of this transfer

- o3: The date and time of this transfer

- o4: The destination evidence-storage location

- o5: Receiving custodian acknowledgement

### T06


Legal hold: choose the correct handling of the covered records scheduled for deletion.

- o1: Keep a printed timeline and delete the underlying covered log files

- o2: Apply the ordinary retention deletion schedule to all old records

- o3: Keep a de-identified summary and delete the covered original records

- o4: Suspend deletion and preserve records covered by the active hold

### T07


Timeline: choose the best treatment of timestamps from different offsets.

- o1: Apply the collection-server time zone to every source record

- o2: Order records by likely attack stages instead of timestamp evidence

- o3: Remove offsets and sort records by the displayed clock time

- o4: Preserve original timestamps and normalize copies for comparison

### T08


What does a matching SHA-256 comparison establish for the working copy in this exercise?

- o1: Every custody transfer has been properly documented

- o2: The original file creator has been reliably identified

- o3: The original file contains no malicious code

- o4: The compared copy has no content difference detected by that hash check

References: 

## SEC-PBQ-019 — Complete mobile-device and asset disposition tickets


Process the eight asset-management fields below under the stated organizational policies. BYOD devices use a managed work profile that separates employer data from personal data. Corporate devices may be remotely locked or wiped after approval. Sanitization decisions must consider the actual storage technology and verifiable protection history; a quick format is not sufficient evidence of sanitization.

### Ticket queue


| Ticket | Facts and policy |
| --- | --- |
| M1 | A contractor leaves. Their personally owned phone contains a managed work profile. Policy permits removing corporate data and access, not personal photos. |
| M2 | A corporate laptop is reported lost. It is online in device management. The authorized responder has approval for immediate remote lock while location and next steps are assessed. |
| M3 | An encrypted corporate SSD is being reused internally. All sensitive data was encrypted before storage; unique keys and every escrow copy can be destroyed. The device supports an approved, verifiable cryptographic erase. |
| M4 | A failed SSD with Restricted data cannot execute or verify sanitization, and encryption history is unknown. Policy requires destruction through an approved provider. |
| M5 | A retired laptop is covered by an active evidence hold. |
| M6 | A new laptop has arrived. The inventory needs a unique hardware identifier, responsible owner, assigned user, and location. |
| M7 | A disposal vendor returns a certificate that omits all media serial numbers. The shipment contained 20 SSDs. |
| M8 | An endpoint appears in discovery, but its owner and approved use are unknown. No compromise is yet confirmed. |

### T01


M1: choose the appropriate BYOD offboarding action.

- o1: Remove the corporate app shortcuts while retaining their data

- o2: Reset the account password while retaining the corporate work profile

- o3: Revoke corporate access and remove the managed work profile

- o4: Issue a full-device wipe through the mobile-management console

### T02


M2: select the immediate device-management action already authorized.

- o1: Revoke cloud sessions but leave the device local lock state unchanged

- o2: Complete the next inventory reconciliation before sending the lock

- o3: Issue the approved remote lock and verify its reported result

- o4: Run a compliance scan without sending the approved lock action

### T03


M3: select the appropriate approved sanitization method under the given prerequisites.

- o1: Quick-format the existing filesystem and reuse its encryption key

- o2: Overwrite only logical blocks without validating the SSD purge method

- o3: Perform approved cryptographic erase and verify all key-copy destruction

- o4: Reinstall the operating system without verifying data sanitization

### T04


M4: choose the disposition required by policy.

- o1: Return it to service after repair without verifying prior data removal

- o2: Use approved physical destruction with tracked custody and verification

- o3: Send it through standard recycling without media-specific sanitization

- o4: Use the degaussing process approved for magnetic backup tapes

### T05


M5: choose the correct disposition while the hold remains active.

- o1: Copy selected user documents and release the device for reuse

- o2: Record a hash and sanitize the held device immediately

- o3: Preserve the device and covered data under the active hold

- o4: Retain an unverified backup and reimage the original device

### T06


M6: select the best record for uniquely identifying the physical device.

- o1: The current DHCP-assigned network address

- o2: The current primary network-interface address

- o3: The current operating-system hostname

- o4: Manufacturer serial number linked to the asset record

### T07


M7: select the next action before closing the disposal ticket.

- o1: Accept the shipping count without matching individual assets

- o2: Reconcile each shipped serial number with itemized destruction evidence

- o3: Close the ticket because the certificate confirms a total of 20 items

- o4: Accept the vendor general certification instead of shipment-specific proof

### T08


M8: choose the best next asset-management step.

- o1: Treat a valid DHCP lease as sufficient evidence of device approval

- o2: Remove it from the asset register because no owner is currently recorded

- o3: Enroll it under the subnet default owner without checking its purpose

- o4: Establish ownership and approved use, assess posture, and apply admission policy

References: 

## SEC-PBQ-020 — Configure a controlled response-automation playbook


The SOC is enabling a playbook that creates incident tickets and can add confirmed malicious destinations to a firewall blocklist. Human approval is required when a proposed change affects more than three destinations or could disable accounts. Incoming threat-feed descriptions are untrusted data. The playbook must use scoped credentials, preserve a rollback point, avoid duplicate tickets, and stop safely when a write fails. Complete the configuration fields.

### Pilot results


| Pilot issue | Observed behavior |
| --- | --- |
| P1 | A feed description includes text asking the automation to bypass approvals. |
| P2 | One feed entry alone immediately blocks a destination without internal corroboration. |
| P3 | A proposed action would add 400 destinations and disable 12 accounts. |
| P4 | The playbook uses a shared global administrator credential stored in source code. |
| P5 | It changes rules without saving the previous approved configuration. |
| P6 | Repeated delivery of the same event creates 30 identical tickets. |
| P7 | A partial firewall write fails, but the playbook reports success and continues. |
| P8 | Operators cannot tell which event produced a change or whether the change worked. |

### T01


P1: choose the handling of the feed description.

- o1: Allow a signed feed description to override local approval requirements

- o2: Treat feed descriptions as data governed by the local approval policy

- o3: Allow urgent feed wording to reduce the required approval level

- o4: Interpret feed descriptions as instructions that can alter the playbook

### T02


P2: choose the improved automatic-block trigger.

- o1: Trigger after repeated deliveries of the same uncorroborated feed item

- o2: Trigger whenever a destination appears once in the external feed

- o3: Trigger from the feed severity label without local activity context

- o4: Require the configured confidence threshold and internal corroboration

### T03


P3: select the required decision path for this large proposed action.

- o1: Divide the proposal into small API calls to stay below the threshold

- o2: Reuse an earlier approval for a different single-destination change

- o3: Pause the proposed change and obtain the required human approval

- o4: Apply the batch after a successful syntax-only dry run

### T04


P4: choose the best credential design.

- o1: Use a shared administrator identity kept in a rotating password vault

- o2: Use a named analyst administrator identity for all unattended executions

- o3: Use a global administrator credential in an encrypted configuration file

- o4: Use a scoped workload identity with protected or short-lived credentials

### T05


P5: choose the required pre-change action.

- o1: Capture and identify the current approved configuration for rollback

- o2: Test the rules in a lab without capturing the production rollback state

- o3: Verify API connectivity without preserving the current rule state

- o4: Export only the proposed new rules before applying them

### T06


P6: choose the mechanism that prevents duplicate processing of the same event.

- o1: Delay retries without checking whether the event was already processed

- o2: Assign a fresh event identifier to every delivery retry

- o3: Deduplicate solely by source address without distinguishing incidents

- o4: Use a stable event key and consult the persisted processing result

### T07


P7: choose the required failure behavior.

- o1: Retry the whole batch without checking which writes already succeeded

- o2: Continue dependent steps after skipping the failed write

- o3: Treat any successful API call as success for the complete run

- o4: Stop changes, use the approved recovery path, and alert an operator

### T08


P8: select the logging and validation design.

- o1: Record final configuration snapshots without linking actors or events

- o2: Record HTTP status codes without verifying the resulting control state

- o3: Record event identifiers and timing without recording state changes

- o4: Record event, actor, action, before/after state, and verification result

References: 

## SEC-PBQ-021 — Evaluate the mail-authentication results


Complete the mail-gateway review. Every message below displays From: billing@accounts.example. For this exercise, strict alignment requires an authenticated domain to equal accounts.example exactly. DMARC passes if at least one of these is true: SPF passes with an aligned MAIL FROM domain, or DKIM passes with an aligned d= domain. The published policy requests quarantine for DMARC failures, and this simulated receiver honors that request without local exceptions. Passing authentication does not approve a payment or guarantee harmless content.

### Gateway results


| Message | SPF result | MAIL FROM domain | DKIM result | DKIM d= domain |
| --- | --- | --- | --- | --- |
| M1 | pass | mailer.example | pass | accounts.example |
| M2 | pass | accounts.example | fail | accounts.example |
| M3 | pass | attacker.example | none | none |
| M4 | fail | accounts.example | fail | accounts.example |

An independently verified investigation later finds that M2 came from a compromised legitimate billing account and requests a fraudulent bank-account change.

### T01


M1: choose the DMARC result.

- o1: DMARC fail

- o2: DMARC pass

### T02


M2: choose the DMARC result.

- o1: DMARC pass

- o2: DMARC fail

### T03


M3: choose the DMARC result.

- o1: DMARC pass

- o2: DMARC fail

### T04


M4: choose the DMARC result.

- o1: DMARC fail

- o2: DMARC pass

### T05


Choose the simulated receiver disposition for M3 under the stated policy.

- o1: Deliver to the normal inbox

- o2: Monitor and report without changing delivery

- o3: Reject the message during receipt

- o4: Quarantine under the published policy

### T06


What does a valid DKIM signature primarily provide?

- o1: Confidentiality through encryption of the complete message

- o2: Evaluation of alignment with the visible From domain

- o3: Verification of the signing domain and integrity of signed message parts

- o4: Authorization of the sending IP for the MAIL FROM domain

### T07


M2: given the investigation findings, choose the appropriate handling of the bank-change request.

- o1: Use the mail-authentication checks as sufficient payment authorization

- o2: Ask for confirmation through the existing compromised email thread

- o3: Use independent payment verification and respond to the account compromise

- o4: Request a revised invoice through the same mailbox as verification

### T08


What does SPF primarily check for the MAIL FROM identity in this exercise?

- o1: Whether the sending source is authorized by the MAIL FROM domain policy

- o2: Whether the transport session encrypts traffic between mail servers

- o3: Whether signed message portions match a domain digital signature

- o4: Whether visible From aligns with an authenticated domain identifier

References: 

## SEC-PBQ-022 — Complete the quantitative risk worksheet


Complete a simplified annual risk analysis for a file-processing service. Use only the supplied assumptions; no discounting, inflation, tax effects, multiple-loss correlation, or insurance deductibles apply. Values are study estimates, not predictions. Enter dollar answers as numbers without a currency symbol. Evaluate the proposed control against both the risk limit and the budget.

### Analysis inputs


| Variable | Value |
| --- | --- |
| Asset value (AV) | $200,000 |
| Exposure factor (EF) per incident | 25% |
| Current annualized rate of occurrence (ARO) | 0.4 incidents/year |
| Expected ARO after the control | 0.1 incidents/year |
| EF after the control | Still 25% |
| Recurring annual control cost | $10,000 |
| Maximum acceptable residual annualized loss | $6,000 |
| Maximum annual control budget | $12,000 |

Use SLE = AV × EF; ALE = SLE × ARO. Gross annual risk reduction is current ALE minus residual ALE. Net estimated annual benefit is gross annual risk reduction minus annual control cost. The decision rule is to implement a control if it meets both stated limits and produces a positive net estimated annual benefit.

### T01


Calculate single loss expectancy (SLE), in dollars.

### T02


Calculate the current annualized loss expectancy (ALE), in dollars per year.

### T03


Calculate residual ALE after the control, in dollars per year.

### T04


Calculate the gross estimated annual risk reduction, in dollars per year.

### T05


Calculate net estimated annual benefit after control cost, in dollars per year.

### T06


Apply the stated decision rule.

- o1: Approve: both limits are met and net estimated annual benefit is positive

- o2: Defer: benefit is positive but recurring cost exceeds the budget limit

- o3: Defer: both limits are met but net estimated annual benefit is negative

- o4: Defer: cost fits the budget but residual loss exceeds the risk limit

### T07


Classify the proposed control that reduces incident frequency while keeping the service.

- o1: Risk mitigation

- o2: Risk transfer

- o3: Risk acceptance

- o4: Risk avoidance

### T08


An alternative would buy insurance that pays specified covered losses while the service continues. Classify that treatment.

- o1: Risk acceptance

- o2: Risk transfer

- o3: Risk mitigation

- o4: Risk avoidance

References: 

## SEC-PBQ-023 — Build the supplier approval and contract packet


A company is selecting a hosted document-processing supplier. Mandatory requirements are: processing and storage in approved Region R, an independent control report covering the offered service and current review period, and a contractual right to obtain additional audit evidence. Choose the lowest-cost supplier that satisfies all mandatory requirements. Costs and supplier records are fictional. Marketing claims do not substitute for the required report.

### Supplier comparison


| Supplier | Annual cost | Region | Assurance evidence | Audit evidence right |
| --- | --- | --- | --- | --- |
| Harbor | $14,000 | Region R | Marketing brochure only | Yes |
| Meridian | $18,000 | Region R | Independent report covers this service and the current review period; findings supplied for review | Yes |
| Summit | $12,000 | Region S only | Independent report covers this service and current review period | No |

Selection remains subject to review and resolution of material report findings. The existence of a report does not guarantee security.

### Contract and governance needs


The packet needs a document defining measurable availability and support response commitments, a document defining this implementation's deliverables and milestones, and a confidentiality agreement for exchanged business information. One evaluator owns a significant financial interest in Harbor. After onboarding, the company needs continued evidence of relevant controls and material service changes. On termination it must revoke access, retrieve required data, and verify agreed retention/deletion handling.

### T01


Choose the lowest-cost supplier that satisfies all mandatory conditions in the comparison.

- o1: Meridian

- o2: Summit

- o3: Harbor

- o4: No supplier satisfies the listed conditions

### T02


Choose the most important next assurance review for the selected supplier.

- o1: Compare support commitments and price without assessing the control findings

- o2: Review service scope, period, findings, and customer-responsibility assumptions

- o3: Review a general security certification without the service control report

- o4: Check the report date and cover page without reviewing its findings

### T03


Handle the evaluator financial interest.

- o1: Allow the evaluator to complete final scoring before addressing the conflict

- o2: Disclose the conflict and apply recusal or independent review

- o3: Adjust scoring privately without disclosing the financial interest

- o4: Disclose the interest only to the supplier being evaluated

### T04


Choose the document for measurable availability and support response commitments.

- o1: Memorandum of understanding (MOU)

- o2: Service-level agreement (SLA)

- o3: Non-disclosure agreement (NDA)

- o4: Statement of work (SOW)

### T05


Choose the document for this implementation's deliverables and milestones.

- o1: Service-level agreement (SLA)

- o2: Non-disclosure agreement (NDA)

- o3: Statement of work (SOW)

- o4: Memorandum of understanding (MOU)

### T06


Choose the document for protecting exchanged confidential business information.

- o1: Statement of work (SOW)

- o2: Service-level agreement (SLA)

- o3: Memorandum of understanding (MOU)

- o4: Non-disclosure agreement (NDA)

### T07


Choose the most useful ongoing supplier-monitoring practice.

- o1: Review security evidence only after a publicly reported vendor breach

- o2: Monitor availability and billing without reviewing security-related changes

- o3: Review relevant controls, material changes, incidents, and unresolved findings

- o4: Retain the initial report until the full contract reaches its end date

### T08


Choose the complete termination action set.

- o1: Revoke access, retrieve required data, and verify agreed retention or deletion

- o2: Revoke credentials but leave data-return and retention decisions unresolved

- o3: Export required data while leaving integration credentials active

- o4: Request immediate deletion before checking retention and retrieval needs

References: 

## SEC-PBQ-024 — Complete the data-governance decision record


A retailer chooses why and how customer support records are used. A hosting company processes those records only under the retailer's documented instructions. Internally, the support director approves the business classification and access requirements, while IT administers the storage and applies approved permissions. Use these described responsibilities to complete the role map and the policy decisions. This is a fictional policy exercise, not a jurisdiction-specific legal question.

### Documents and retention rules


| Record | Content |
| --- | --- |
| DOC-A | Mandatory technical baseline: managed laptops must use the approved full-disk encryption configuration. |
| DOC-B | Step-by-step instructions for enabling the configuration and recording verification. |

Support tickets are retained for 36 months unless an active hold applies. Ticket X is 40 months old, is not covered by a hold, and has no other retention obligation. Ticket Y is 40 months old and is covered by an active hold. Deletion must use the approved lifecycle process.

A new appointment reminder needs only a contact address and an appointment time. The proposed form also collects a national identifier and full birth date, but neither additional field is needed for the service or another approved purpose.

### T01


Assign the retailer privacy role for determining the purposes and means of this processing.

- o1: Data processor

- o2: Data subject

- o3: Independent data auditor

- o4: Data controller

### T02


Assign the hosting company privacy role for processing only under documented instructions.

- o1: Data processor

- o2: Data subject

- o3: Data controller

- o4: Independent data auditor

### T03


Assign the support director role for business classification and access decisions.

- o1: Data subject

- o2: Independent auditor

- o3: Data custodian

- o4: Data owner

### T04


Assign IT the role for administering storage and applying approved permissions.

- o1: Data subject

- o2: Data owner

- o3: Independent auditor

- o4: Data custodian

### T05


Classify DOC-A as the most specific document type.

- o1: Procedure

- o2: Guideline

- o3: Standard

- o4: Policy

### T06


Classify DOC-B as the most specific document type.

- o1: Guideline

- o2: Standard

- o3: Procedure

- o4: Policy

### T07


Choose the correct disposition for Ticket X and Ticket Y.

- o1: Delete both under the ordinary retention schedule

- o2: Delete X under the lifecycle process and preserve Y under its hold

- o3: Preserve X under ordinary retention and delete Y after hashing it

- o4: Preserve both indefinitely under a general preference to retain data

### T08


Choose the appropriate appointment-reminder form design.

- o1: Add full birth date for possible future identity checks not yet approved

- o2: Collect all proposed fields because they can be encrypted in storage

- o3: Add a national identifier to simplify matching duplicate reminder requests

- o4: Collect only the contact address and appointment time required for reminders

References: 

## SEC-PBQ-025 — Review awareness results and authorize the follow-up assessment


An approved awareness exercise uses synthetic phishing messages. Each of 200 employees receives exactly one message; every count below represents distinct employees. Use the supplied denominators and select appropriate follow-up actions. The purpose is to improve reporting and response, not to punish people for reporting mistakes.

### Exercise metrics


| Measure | Baseline exercise | Current exercise |
| --- | --- | --- |
| Delivered messages | 200 | 200 |
| Employees who clicked | 40 | 20 |
| Employees who reported the message | 50 | 70 |
| Employees who reported before any click | 40 | 60 |

For this exercise, click rate = clickers / delivered. Reporting rate = reporters / delivered. Safe-first reporting rate = reporters before a click / delivered. Use percentages, not fractions, in numeric answers.

Role review shows field technicians missed the warning signs in QR-code sign-in requests more often than other groups. The approved reporting workflow is a mail-client Report Suspicious button that preserves message metadata for the SOC.

### Assessment scope


The follow-up penetration-test authorization permits only staging-app.example during the approved window using the listed test accounts. Production, employee personal devices, and third-party services are excluded. An assessor proposes extending the test to production immediately without a written scope change. The control-assessment team also needs evidence that the reporting button routes messages correctly, not just a policy saying that it should.

### T01


Calculate the current click rate as a percentage.

### T02


Calculate the current reporting rate as a percentage.

### T03


Calculate the current safe-first reporting rate as a percentage.

### T04


Choose the most appropriate targeted learning intervention.

- o1: Concentrate on password-composition drills for all departments

- o2: Collect a policy acknowledgement without practicing QR-request decisions

- o3: Practice QR sign-in verification with the field-technician group

- o4: Repeat a general annual awareness presentation without adapting its examples

### T05


Choose the employee response that follows the approved workflow.

- o1: Use Report Suspicious to preserve message metadata for the SOC

- o2: Paste the message body into a ticket without the original metadata

- o3: Forward an inline copy of the message to a colleague for an opinion

- o4: Send a screenshot to the help desk without preserving the message

### T06


Choose the appropriate response to the proposed production test.

- o1: Remain within scope and obtain a written change before production testing

- o2: Use the staging authorization for production because the owner is the same

- o3: Begin low-volume production tests and document the scope change afterward

- o4: Rely on informal developer agreement without updating the test authorization

### T07


Choose the strongest focused evidence that the reporting control operates effectively.

- o1: Collect staff recollections without checking submissions or stored evidence

- o2: Inspect the documented reporting policy without exercising the control

- o3: Inspect button configuration without checking the resulting SOC record

- o4: Test a submission and verify the resulting SOC metadata and routing

### T08


Choose the conclusion supported by the comparison.

- o1: The higher report count establishes a rise in real production attacks

- o2: Observed clicking decreased and reporting increased; continued measurement is needed

- o3: The comparison isolates training as the sole cause of the observed change

- o4: The results establish lasting resistance to other phishing techniques

References: 