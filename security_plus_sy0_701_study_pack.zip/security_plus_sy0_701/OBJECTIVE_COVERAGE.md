# Objective coverage

The quiz bank follows the five domain percentages in the [official SY0-701 blueprint](https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6). All 28 numbered objectives are represented. Counts within a domain are editorial allocations; CompTIA does not publish these sub-objective weights. PBQs often cover more than one objective and are counted separately.

| Domain | Name | Exam weight | Questions | Single-answer | Multi-select |
| --- | --- | ---: | ---: | ---: | ---: |
| 1 | General Security Concepts | 12% | 36 | 32 | 4 |
| 2 | Threats, Vulnerabilities, and Mitigations | 22% | 66 | 59 | 7 |
| 3 | Security Architecture | 18% | 54 | 49 | 5 |
| 4 | Security Operations | 28% | 84 | 76 | 8 |
| 5 | Security Program Management and Oversight | 20% | 60 | 54 | 6 |
| Total | | 100% | 300 | 270 | 30 |

## Objective detail

| Objective | Focus (paraphrased) | Quiz count | Quiz IDs | PBQs touching objective |
| --- | --- | ---: | --- | --- |
| 1.1 | Security control categories and functions | 8 | SEC-Q001–SEC-Q008 | SEC-PBQ-001 |
| 1.2 | Fundamental security concepts | 10 | SEC-Q009–SEC-Q018 | SEC-PBQ-001, SEC-PBQ-014 |
| 1.3 | Secure change management | 6 | SEC-Q019–SEC-Q024 | SEC-PBQ-002, SEC-PBQ-015 |
| 1.4 | Cryptography and public key infrastructure | 12 | SEC-Q025–SEC-Q036 | SEC-PBQ-002, SEC-PBQ-009 |
| 2.1 | Threat actors and motivations | 8 | SEC-Q037–SEC-Q044 | SEC-PBQ-006 |
| 2.2 | Attack vectors and surfaces | 14 | SEC-Q045–SEC-Q058 | SEC-PBQ-006, SEC-PBQ-021 |
| 2.3 | Vulnerability types | 16 | SEC-Q059–SEC-Q074 | SEC-PBQ-005 |
| 2.4 | Indicators of malicious activity | 18 | SEC-Q075–SEC-Q092 | SEC-PBQ-003, SEC-PBQ-004 |
| 2.5 | Mitigation methods | 10 | SEC-Q093–SEC-Q102 | SEC-PBQ-003, SEC-PBQ-004, SEC-PBQ-005, SEC-PBQ-006, SEC-PBQ-007, SEC-PBQ-015 |
| 3.1 | Architecture models and security implications | 12 | SEC-Q103–SEC-Q114 | SEC-PBQ-008, SEC-PBQ-011 |
| 3.2 | Secure enterprise infrastructure | 16 | SEC-Q115–SEC-Q130 | SEC-PBQ-007, SEC-PBQ-011 |
| 3.3 | Data protection strategies | 12 | SEC-Q131–SEC-Q142 | SEC-PBQ-008, SEC-PBQ-009, SEC-PBQ-024 |
| 3.4 | Resilience and recovery design | 14 | SEC-Q143–SEC-Q156 | SEC-PBQ-010, SEC-PBQ-011 |
| 4.1 | Resource hardening | 11 | SEC-Q157–SEC-Q167 | SEC-PBQ-005, SEC-PBQ-012, SEC-PBQ-013, SEC-PBQ-019 |
| 4.2 | Asset lifecycle management | 7 | SEC-Q168–SEC-Q174 | SEC-PBQ-019 |
| 4.3 | Vulnerability management | 11 | SEC-Q175–SEC-Q185 | SEC-PBQ-015 |
| 4.4 | Monitoring and alerting | 9 | SEC-Q186–SEC-Q194 | SEC-PBQ-016, SEC-PBQ-017, SEC-PBQ-020 |
| 4.5 | Enterprise security capabilities | 12 | SEC-Q195–SEC-Q206 | SEC-PBQ-007, SEC-PBQ-009, SEC-PBQ-012, SEC-PBQ-013, SEC-PBQ-021 |
| 4.6 | Identity and access implementation | 12 | SEC-Q207–SEC-Q218 | SEC-PBQ-008, SEC-PBQ-012, SEC-PBQ-013, SEC-PBQ-014, SEC-PBQ-019, SEC-PBQ-020 |
| 4.7 | Automation and orchestration | 6 | SEC-Q219–SEC-Q224 | SEC-PBQ-020 |
| 4.8 | Incident response | 10 | SEC-Q225–SEC-Q234 | SEC-PBQ-004, SEC-PBQ-016, SEC-PBQ-017, SEC-PBQ-018 |
| 4.9 | Investigation data sources | 6 | SEC-Q235–SEC-Q240 | SEC-PBQ-003, SEC-PBQ-004, SEC-PBQ-016, SEC-PBQ-017, SEC-PBQ-018 |
| 5.1 | Security governance | 10 | SEC-Q241–SEC-Q250 | SEC-PBQ-014, SEC-PBQ-023, SEC-PBQ-024 |
| 5.2 | Risk management | 14 | SEC-Q251–SEC-Q264 | SEC-PBQ-010, SEC-PBQ-022, SEC-PBQ-025 |
| 5.3 | Third-party risk | 10 | SEC-Q265–SEC-Q274 | SEC-PBQ-023 |
| 5.4 | Compliance and privacy | 8 | SEC-Q275–SEC-Q282 | SEC-PBQ-024 |
| 5.5 | Audits and assessments | 8 | SEC-Q283–SEC-Q290 | SEC-PBQ-023, SEC-PBQ-025 |
| 5.6 | Security awareness | 10 | SEC-Q291–SEC-Q300 | SEC-PBQ-006, SEC-PBQ-021, SEC-PBQ-025 |

## Difficulty labels

Foundational questions focus on recognizing or applying one core concept. Intermediate questions combine a practical scenario with competing choices. Advanced questions require closer reading, calculations, or competing constraints. These are editorial study labels, not a measured prediction of real-exam item difficulty.
