# Security+ study questions — v1.0.0

Unofficial study material; verify uncertain points against trusted sources.

## SEC-Q001

A workstation automatically refuses to run programs that are not on an approved application list. Which classification BEST describes this control's implementation and primary function?

- A. Technical and preventive
- B. Managerial and directive
- C. Operational and detective
- D. Physical and corrective

Answer: A

Control category describes how the control is implemented, while control function describes what it accomplishes. The application allowlist is a technical mechanism because software enforces it. Its primary function is preventive because unapproved code is stopped before it executes. A related written policy could have a different category and function.

Study tip: Identify the implementation and the purpose separately when a question asks for both category and function.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Software enforces the restriction, making the category technical; refusing execution stops the unwanted action, making the primary function preventive.

B: A policy requiring approved software would be managerial and directive. The question describes the automated mechanism enforcing that policy.

C: Operational controls involve people performing procedures, and detective controls identify events. This software actively blocks execution rather than merely reporting it.

D: Physical controls protect facilities or tangible assets, while corrective controls address damage or restore conditions. Neither describes an application execution restriction.

## SEC-Q002

A company publishes an approved policy instructing employees to report missing laptops immediately to the service desk. Considering the instruction itself, which control function is MOST directly represented?

- A. Directive
- B. Compensating
- C. Detective
- D. Corrective

Answer: A

The defining feature is that the approved policy directs employee behavior. Reporting may later trigger detection, containment, or recovery activities, but those downstream actions are separate controls. Classify the specific mechanism named in the question instead of assigning every function that the overall incident process might serve.

Study tip: Words such as required, must, and instructed often indicate a directive function when the control is a policy.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Directive controls prescribe required behavior. The policy tells employees what action to take when a device is missing.

B: Compensating controls substitute for an unavailable required safeguard. The scenario does not identify any unavailable control that this policy replaces.

C: Detective controls identify or reveal events. This policy establishes reporting expectations but does not itself detect that a laptop is missing.

D: Corrective controls repair conditions or restore services after an event. The reporting instruction does not itself recover or repair the laptop.

## SEC-Q003

Every morning, a facilities employee manually compares the previous night's server-room entry records with the approved maintenance schedule and investigates exceptions. Which control category BEST describes the employee's review activity, as distinct from the electronic badge system?

- A. Managerial
- B. Operational
- C. Technical
- D. Physical

Answer: B

A control can depend on several supporting mechanisms without inheriting every one of their categories. Electronic access logs support this review, and the protected resource is a physical room, but a person carries out the stated control. The review is therefore operational; its primary function is also detective.

Study tip: Classify the activity explicitly named in the stem, not the resource it protects or the tools it uses.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Management might establish the access policy or approve the review requirement. Performing the recurring review is an operational activity.

B: Operational controls are carried out through people and procedures. The employee's recurring review is a human process for identifying unexpected access.

C: The badge reader and logging software are technical mechanisms, but the question specifically isolates the employee's manual review of their output.

D: Locks, doors, and barriers are physical controls. Reviewing recorded access remains an operational process even though it concerns a physical room.

## SEC-Q004

An unauthorized configuration change disables a branch office's secure remote-access service. After the unauthorized session is terminated, an administrator restores the last verified configuration and confirms that the approved service works again. What is the PRIMARY function of the restoration?

- A. Directive
- B. Deterrent
- C. Detective
- D. Corrective

Answer: D

Corrective controls address the consequences of a security event and help restore an acceptable operating state. The suspicious session has already been stopped, so the question focuses on repairing the service configuration. Validation is included to establish that the repair restored the intended secure behavior.

Study tip: When the action repairs damage or restores an approved state, consider the corrective function.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A procedure ordering administrators to restore approved configurations would be directive. Executing the restoration is the corrective action described here.

B: Deterrent controls discourage attempted misconduct. Restoring a configuration addresses an incident that has already occurred rather than influencing an attacker's initial choice.

C: Detection identified the unauthorized change earlier. Applying the verified configuration fixes its effects rather than merely revealing that it happened.

D: Restoring the verified configuration repairs the unwanted change and returns the service to its intended condition after the event.

## SEC-Q005

Policy requires an application to perform native multifactor authentication. A legacy application cannot support it until replacement next quarter. An approved exception requires an MFA access broker, individual accounts, blocked direct connections, and monitored sessions. Relative to the unmet native-MFA requirement, what role does this alternative arrangement serve?

- A. Directive control
- B. Corrective control
- C. Detective control
- D. Compensating control

Answer: D

A compensating control provides an approved alternative when the original requirement cannot presently be implemented. Its adequacy depends on addressing the relevant risk, including ways to bypass it. The broker performs authentication while direct paths are blocked. Individual safeguards can also have preventive or detective functions without changing the arrangement's compensating role.

Study tip: Compensating describes a control's relationship to an unmet requirement; it can also perform preventive or detective functions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The exception includes instructions, but actual technical safeguards enforce the alternate access path. It is more than a statement of required behavior.

B: No compromise or damaged state is being repaired. The arrangement reduces ongoing access risk while the application lacks a required capability.

C: Session monitoring is detective, but the arrangement also enforces MFA and prevents direct access. Detection alone does not describe its substitution role.

D: The approved alternative addresses the security objective of an unavailable required safeguard. Blocking bypass paths helps make the substitute meaningful.

## SEC-Q006

A warehouse installs prominent signs stating that unauthorized entry is prosecuted and the area is monitored. The security manager says the purpose of the signs is to discourage people from attempting entry. Which function BEST matches that purpose?

- A. Detective
- B. Compensating
- C. Corrective
- D. Deterrent

Answer: D

The signs are intended to make an intruder reconsider the attempt, which is deterrence. They do not physically stop entry or independently detect it. The surrounding security system may include barriers and cameras, but the stem deliberately asks about the stated purpose of the signs themselves.

Study tip: A warning can deter an action even when it cannot physically prevent that action.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A camera or sensor could detect entry, but a warning sign does not itself observe or record an event.

B: A compensating control replaces an unavailable required safeguard. The scenario identifies discouragement as the goal and describes no substituted requirement.

C: Corrective controls restore acceptable conditions after a problem. Posting a warning does not repair damage caused by a previous intrusion.

D: The signs seek to influence behavior by communicating consequences and visibility. Their stated purpose is to discourage the attempted action.

## SEC-Q007

A security team needs controls that primarily reveal suspicious activity for analyst review, without automatically blocking it or restoring systems. Which TWO implementations BEST meet that need? (Select TWO.)

- A. A recovery job that restores a verified configuration after damage
- B. A file-integrity monitor that alerts when protected files change
- C. A login banner warning that misuse may lead to disciplinary action
- D. A firewall rule that denies unapproved inbound connections
- E. A passive network sensor that generates intrusion alerts

Answer: B|E

Both the passive network sensor and alert-only file-integrity monitor produce evidence of potentially unwanted activity. Their stated operating modes make detection their primary function. The firewall prevents connections, the recovery job corrects damage, and the warning banner deters behavior. Classify the actual implementation rather than every capability a product could possess.

Study tip: Passive observation and alert-only operation are strong clues for a detective function.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Restoring the verified configuration is corrective. The job repairs a condition after detection rather than primarily revealing suspicious activity.

B: The monitor identifies changes and produces evidence for review. In the stated alert-only mode, it neither blocks writes nor restores files.

C: The warning primarily deters misuse by describing consequences. It does not independently discover an unauthorized action or produce an event alert.

D: Denying connections is primarily preventive because it stops the traffic. Logging denied traffic can add detection, but that is not the stated implementation.

E: The passive sensor observes traffic and reports suspicious patterns. It detects potential activity without sitting in the forwarding path to block packets.

## SEC-Q008

Executives conduct a quarterly security-risk review, set risk-treatment priorities, and approve funding for required safeguards. Which security-control category BEST describes this governance activity?

- A. Technical
- B. Physical
- C. Managerial
- D. Operational

Answer: C

Risk oversight and resource approval are managerial controls because they establish the organization's security direction. The people attending do not make every human activity operational; purpose matters. A technician following an approved procedure performs an operational activity, while executives selecting risk priorities perform a managerial one.

Study tip: Look for oversight, policy direction, and risk decisions when distinguishing managerial controls from routine operational work.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Technical controls enforce or monitor security through technology. The review may fund such tools, but the review itself is a management process.

B: Physical controls include tangible barriers and facility protections. A risk-funding decision is governance even when some funding supports physical safeguards.

C: Managerial controls establish direction, oversight, and risk decisions. Executives are deciding priorities and resources rather than operating individual protective mechanisms.

D: Operational controls focus on executing security procedures. This meeting sets organizational direction and authorizes treatment rather than carrying out routine safeguard operations.

## SEC-Q009

A compromised integration account changes approved payment amounts in a database. Investigators confirm unauthorized changes, while the payment service remains responsive. Which security objective was MOST directly violated by changing the stored amounts?

- A. Availability
- B. Integrity
- C. Non-repudiation
- D. Confidentiality

Answer: B

Unauthorized modification is the central integrity failure. A real incident could affect several security objectives, but each requires supporting facts. Continued service responsiveness does not repair corrupted data, and access to an account does not by itself establish that records were disclosed. Select the objective tied to the demonstrated action.

Study tip: Map disclosure to confidentiality, unauthorized alteration to integrity, and service disruption to availability.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Availability concerns timely, reliable access to services and information. The service remains responsive, so disruption is not the demonstrated consequence.

B: Integrity concerns the accuracy and trustworthiness of information. Unauthorized changes to approved payment values directly undermine the correctness of those records.

C: Non-repudiation supports evidence that an entity performed an action. The question asks about unauthorized data modification, not a dispute over recorded approval.

D: Confidentiality concerns unauthorized disclosure. The specific act being classified is changing payment values, and the scenario does not establish a disclosure.

## SEC-Q010

A service desk application contains accurate data and has no unauthorized readers, but staff cannot reach it whenever its single internet connection fails. Adding a second independent connection MOST directly improves which security objective?

- A. Integrity
- B. Availability
- C. Confidentiality
- D. Non-repudiation

Answer: B

The identified failure is loss of access, so availability is the objective directly addressed. Independence matters because two connections sharing the same failing component could fail together. Redundancy supports continuity, but it does not inherently authenticate users, prevent data changes, or make information confidential.

Study tip: Redundancy addresses availability most effectively when the redundant paths avoid a shared failure point.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Integrity protects information from improper changes. The described records are already accurate, and adding connectivity does not validate or protect their contents.

B: An independent connection can preserve access when the first link fails. The control addresses interruption of service rather than disclosure or modification.

C: Confidentiality limits unauthorized disclosure. A redundant connection does not inherently restrict who can read data or encrypt the transmitted information.

D: Non-repudiation supports proof of actions or origin. Additional network connectivity does not establish evidence that a particular person approved a transaction.

## SEC-Q011

A technician successfully signs in to a support portal with a password and security key. The portal then refuses the technician's request to edit payroll because the assigned role permits only ticket management. Which process made the payroll-access decision?

- A. Authorization
- B. Federation
- C. Authentication
- D. Accounting

Answer: A

Authentication answers who the technician is; authorization determines what that identity is allowed to do. The credentials have already been accepted, and the role check limits payroll access. Accounting may record both events. Separating these functions helps identify whether a failure concerns identity verification, permissions, or evidence of activity.

Study tip: A valid login followed by a permission decision points to authorization.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Authorization determines which actions an authenticated identity may perform. The portal checks the technician's permissions before allowing changes to payroll.

B: Federation allows identity information to be trusted across systems. It does not itself explain the application-specific permission decision described here.

C: Authentication established the technician's identity during sign-in. A successful identity check does not automatically grant permission to access every application function.

D: Accounting records actions and resource use for accountability. An audit record of the denial would document the decision rather than make it.

## SEC-Q012

Network administrators already authenticate with individual accounts and receive role-appropriate permissions. An auditor now requires records showing who issued each configuration command, when it ran, and whether it succeeded. Which AAA function must be strengthened?

- A. Single sign-on
- B. Authorization
- C. Accounting
- D. Authentication

Answer: C

Accounting provides the audit trail for actions taken after access is granted. Individual accounts help connect activity to an identity, but that connection is only useful if the relevant commands and outcomes are actually recorded. Protecting and retaining those records also matters because incomplete or alterable evidence weakens accountability.

Study tip: Questions asking who did what, when, and with what result usually point to accounting or audit logging.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Single sign-on reduces repeated authentication across services. It is not the AAA function responsible for recording administrative commands and their outcomes.

B: Authorization controls permitted actions and is already role appropriate. The missing capability is evidence of performed actions, not another permission decision.

C: Accounting records identity-linked actions, timestamps, and outcomes. These records provide the activity trail the auditor needs to reconstruct administrative changes.

D: Authentication verifies identity and is already present. Improving the sign-in check alone would not retain command-by-command records of subsequent activity.

## SEC-Q013

A supplier later denies approving an electronic order. The buyer retains the exact order and a valid digital signature linked to the supplier's verified identity; the signing private key was under the supplier's sole control. Which objective does this evidence MOST directly support when resolving the denial?

- A. Availability
- B. Authorization
- C. Confidentiality
- D. Non-repudiation

Answer: D

Non-repudiation concerns evidence that can support attribution of an action when its originator later denies it. Digital signatures can support this objective when identity binding, key control, and evidence handling are sound. The signature is not an absolute guarantee against every dispute, especially if the signing key was compromised.

Study tip: A signature supports non-repudiation only as strongly as its identity binding, private-key protection, and retained evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Availability concerns dependable access to resources. Retaining signing evidence addresses an authorship dispute rather than service uptime or continuity.

B: Authorization establishes what an identity may do. The issue here is evidence of an approval already given, not whether access should be granted.

C: A signature does not conceal the order's contents. Confidentiality would require a separate protection such as encryption and appropriate access controls.

D: A verifiable signature associated with a controlled private key supports evidence of approval. It helps counter a later denial of the signing action.

## SEC-Q014

A company documents its current security safeguards, compares them with a defined target baseline, and produces a list of missing capabilities and incomplete processes. Which activity is it performing?

- A. Business impact analysis
- B. Vulnerability exploitation
- C. Threat attribution
- D. Gap analysis

Answer: D

The defining structure is current state, target state, and the differences between them. A gap analysis can inform risk treatment and implementation planning, but it does not itself prove exploitability or calculate the business consequences of every outage. The target must be explicit enough for the differences to be meaningful.

Study tip: A comparison between existing safeguards and a desired baseline is the central pattern of a gap analysis.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: A business impact analysis evaluates the consequences of disruption and recovery priorities. It is not primarily a current-versus-target control comparison.

B: Exploitation attempts to demonstrate that a weakness can be used. This activity compares documented capabilities without describing an attack attempt.

C: Threat attribution assesses who is responsible for malicious activity. No incident or suspected actor is being investigated in the described comparison.

D: Gap analysis compares the current condition with a desired target. Its output identifies differences that must be addressed to reach that target.

## SEC-Q015

In a Zero Trust design, one component evaluates identity, device-health signals, resource sensitivity, and policy rules to make the ultimate grant-or-deny decision. Other components establish the access path and enforce that decision. Which component performs the decision-making role described?

- A. Policy engine
- B. Subject
- C. Policy administrator
- D. Policy enforcement point

Answer: A

The policy engine makes the access decision using policy and available context. The policy administrator translates that decision into access-path actions, and the policy enforcement point carries out the resulting control over access. These are logical roles, so an implementation may combine components without erasing the distinction between deciding and enforcing.

Study tip: For Zero Trust roles, distinguish deciding access, administering the path, and enforcing the decision.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final

A: The policy engine evaluates policy and contextual inputs to make the access decision. It belongs to the logical policy decision function.

B: The subject is the user or system requesting resource access. It supplies relevant context but does not decide its own authorization.

C: The policy administrator implements the engine's decision by establishing or terminating the access path. It does not replace the engine's ultimate decision role.

D: The enforcement point permits, monitors, or terminates access according to decisions. Enforcing a decision is distinct from evaluating inputs to make it.

## SEC-Q016

An employee connects from a managed office network, signs in successfully, and opens a sensitive application. Later, endpoint telemetry reports a serious device compromise. Which TWO design choices BEST implement Zero Trust principles for this situation? (Select TWO.)

- A. Use the new device-risk signal to reassess access and enforce any resulting restriction
- B. Keep the original permission unchanged until sign-out despite the new compromise alert
- C. Allow all internal applications once the user passes the initial network sign-in
- D. Evaluate access to the requested resource without treating office-network location as sufficient trust
- E. Treat a managed subnet address as a substitute for checking the requesting identity

Answer: A|D

Zero Trust evaluates resource access explicitly and avoids implicit trust based only on network location or prior authentication. Device posture and other signals can inform reassessment during access. The appropriate resulting action depends on policy, but ignoring the compromise signal or granting blanket internal access conflicts with the principles in the scenario.

Study tip: An internal IP address and an earlier successful login do not establish continuing trust in every resource request.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final

A: Changing context can change an access decision. Reassessing the session allows the system to respond when a previously acceptable device becomes risky.

B: Ignoring relevant new risk information defeats adaptive access decisions. A successful earlier check does not guarantee that a session remains acceptable.

C: An initial sign-in does not justify unrestricted access across resources. Broad network-based trust ignores application-specific policy and changing device conditions.

D: Zero Trust does not grant implicit trust solely because a device is on an internal network. Resource access still needs policy-based evaluation.

E: Network location supplies context but does not establish identity. A compromised device can remain on the same managed subnet while its risk changes.

## SEC-Q017

Employees use badges to enter a restricted laboratory, but visitors sometimes follow closely through the same open door. The facility needs a control that checks an individual's authorization and limits passage between interlocked doors to one admitted person at a time. Which option BEST fits?

- A. A passive infrared motion sensor inside the hallway
- B. Additional lighting along the outside walkway
- C. Vehicle-resistant bollards outside the entrance
- D. An access control vestibule with occupancy detection

Answer: D

The weakness is unauthorized following through a valid admission, commonly called tailgating. A vestibule can combine identity checks, interlocked doors, and occupancy detection to constrain passage. Bollards address vehicles, lighting improves visibility, and motion sensors detect movement; none alone supplies the individual admission control required here.

Study tip: Match the physical control to the actual path of entry: vehicles, perimeter movement, or individual pedestrian admission.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A motion sensor can report movement in its coverage area. It does not by itself determine identity or control passage between interlocked doors.

B: Lighting improves visibility and may discourage misconduct. It does not create controlled individual passage or enforce the badge holder's admission boundary.

C: Bollards resist vehicle access or impact. They do not validate pedestrian authorization or prevent one person from following another through an open door.

D: A properly designed vestibule controls movement between doors and can detect multiple occupants. It directly addresses following another person through a single admission.

## SEC-Q018

An analyst places a fake API credential in a location where authorized software never uses it. The credential grants no production access, but attempts to use it generate a high-priority alert. What is this credential BEST described as?

- A. A honeynet
- B. A honeytoken
- C. A honeyfile
- D. A production service account

Answer: B

The credential is a honeytoken because the valuable signal is its unexpected use. Removing legitimate dependencies on the token reduces ambiguity when an alert fires. Deception can help expose activity, but the token must remain a decoy; granting it production privileges would introduce unnecessary risk instead of improving the signal.

Study tip: A planted credential or identifier is a honeytoken; a decoy document is a honeyfile, and decoy systems form a honeypot or honeynet.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A honeynet is a network of decoy systems intended to attract or study activity. The scenario describes one planted credential, not a network.

B: A honeytoken is decoy information or an identifier whose unexpected use can reveal suspicious activity. This fake credential is the monitored lure.

C: A honeyfile is a decoy file monitored for access or misuse. Here the alert is specifically tied to using a credential value.

D: A production service account performs authorized application tasks and holds needed permissions. This credential has no legitimate workflow or production access.

## SEC-Q019

A proposed gateway change removes a deprecated encryption protocol. The gateway passed its own tests, but an older inventory application is listed as a dependency and has not been tested. What should the change owner do NEXT before production approval?

- A. Approve the production change and use support tickets to discover incompatible clients afterward
- B. Assess the dependent application's impact and test its compatibility with the proposed configuration
- C. Use the gateway's passing tests as sufficient evidence for every dependent application
- D. Leave the deprecated protocol enabled indefinitely without recording a treatment decision

Answer: B

Change testing should reflect the systems and workflows affected by the change, not just the component being edited. The inventory application's dependency is already known, making compatibility a concrete unresolved risk. Testing informs a safe rollout, necessary application updates, or an explicitly managed temporary exception rather than guessing from gateway health alone.

Study tip: A passing component test does not prove that its dependent business services will still work.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: Post-change complaints are not an adequate substitute for evaluating a known dependency. The compatibility uncertainty can be investigated before an avoidable outage.

B: Impact analysis must include dependent services. Testing the inventory application can reveal whether removing the protocol breaks a required business function.

C: A gateway can operate correctly while a client fails to connect. Component success does not establish compatibility across an application dependency.

D: A compatibility concern needs an evaluated treatment and owner. Indefinite untracked exposure avoids neither the security risk nor the change-management responsibility.

## SEC-Q020

A deployment changes an application's database format so the old application cannot read it. The database resides on a separate server, and production writes will be paused during the change. The proposed backout plan saves only the old application executable. What is the MOST important improvement before approval?

- A. Test a coordinated restore of the compatible application and database state from protected pre-change copies
- B. Reduce the DNS cache lifetime so users reach the restored executable more quickly
- C. Retain the migration's success log and restart the old executable if validation fails
- D. Take an application-server snapshot and rely on it to reverse the separate database migration

Answer: A

A usable backout plan covers the full state needed for a compatible service, including data and dependencies. Saving an executable is insufficient when a database migration prevents it from running. The planned write pause helps preserve a coherent recovery point; testing should still confirm the restoration steps, validation criteria, and time required.

Study tip: Backout requires compatible data and dependencies, not merely possession of the previous software version.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Backout must restore mutually compatible components. Testing the application and database together establishes whether the previous service can actually be recovered.

B: DNS timing can influence routing changes, but it does not solve application-database incompatibility. Reaching the old executable sooner would not restore service.

C: A successful migration log does not reverse the schema change. Restarting an incompatible application cannot recreate the required prior database state.

D: The application snapshot does not include the separately hosted database. Restoring it alone leaves the old executable facing the incompatible migrated data format.

## SEC-Q021

A critical exposed service requires an urgent security change. The organization's policy defines an on-call emergency approver and allows immediate implementation after that approval, followed by documented review. The next routine change meeting is tomorrow. Which action BEST follows the established process?

- A. Wait for the routine meeting because urgent changes cannot use a different approval route
- B. Use emergency approval, record the change, implement and validate it, then complete the required review
- C. Make the change immediately and seek the emergency approver only if users report problems
- D. Obtain emergency approval but omit the change record and review if validation succeeds

Answer: B

Emergency change management adapts the approval path to time-sensitive conditions while preserving the controls specified by policy. Here, the on-call approver is explicitly authorized to permit immediate implementation. The correct response follows that path and retains the required record, operational validation, and subsequent review instead of inventing a different process.

Study tip: Use the emergency process stated in the scenario; urgency does not automatically remove its approval or documentation requirements.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The stated policy explicitly allows emergency approval. Waiting solely for the routine meeting ignores the authorized path designed for this situation.

B: The policy already provides an authorized expedited path. Following it addresses urgency while retaining approval, traceability, validation, and subsequent oversight.

C: The policy requires emergency approval before implementation. Success or lack of complaints does not substitute for that defined authorization step.

D: The emergency path still requires documentation and review. A successful result does not remove the need for traceability or learning from the change.

## SEC-Q022

A change will make a database unavailable from 02:00 to 02:20. The proposed maintenance window ends at 02:30, but a payroll job that requires that database begins at 02:10. Testing shows the payroll job fails rather than retrying. What must be resolved before the window is approved?

- A. Suppress payroll failure alerts during the window so monitoring does not interrupt the change
- B. Coordinate the database outage and payroll schedule with the service owners and validate the revised plan
- C. Approve the window because the database should recover before the window's final minute
- D. Leave payroll unchanged because successful database restart automatically reruns every dependent job

Answer: B

A maintenance window is not automatically safe because a technical change fits inside it. Dependencies and business schedules must also fit. The payroll job overlaps a known outage and lacks automatic retry, so the change owner needs an agreed scheduling or recovery arrangement and validation with the relevant service owners.

Study tip: Check what runs during the outage, not only whether the technical task finishes before the window ends.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Suppressing an alert does not prevent the failed job or its business impact. The schedule conflict requires an operational solution.

B: The dependent job overlaps the outage and is known to fail. Owner coordination and a validated schedule address that demonstrated business impact.

C: Finishing inside the window does not protect jobs scheduled during the outage. Payroll begins before the database is expected to return.

D: Testing explicitly shows that this job does not retry. Database recovery alone cannot be assumed to restart failed application workflows.

## SEC-Q023

An agent upgrade moves its approved telemetry destination from 198.51.100.20 to 198.51.100.30 on TCP 443. The current egress allowlist permits only the old address. Release testing also confirms that the collector must be upgraded before the agents. The change must preserve narrowly restricted egress. Which TWO additions are required in the rollout plan? (Select TWO.)

- A. Replace destination restrictions with unrestricted outbound access for the fleet throughout deployment
- B. Upgrade and validate the collector before deploying the dependent agent version
- C. Keep the old egress rule unchanged because the destination still uses TCP 443
- D. Upgrade all agents first and retain the old collector until the next routine maintenance cycle
- E. Add the approved new destination to the controlled egress rule at the appropriate rollout stage

Answer: B|E

The rollout has two independent dependencies: network policy must allow the approved new endpoint, and the collector version must precede agent deployment. Keeping TCP 443 does not bypass an address-specific rule. A coordinated, narrowly scoped change addresses both conditions without discarding the egress control or ignoring the tested upgrade order.

Study tip: Read release dependencies and allowlist fields literally; an unchanged port does not imply an unchanged permitted destination.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Broad outbound access violates the stated narrow-egress requirement. The known address and port allow a specific change instead of removing the boundary.

B: Testing establishes a required upgrade order. Validating the collector first ensures the new agents have a compatible receiving service.

C: The rule restricts destination address as well as port. Retaining the port does not make traffic to a different address permitted.

D: This reverses the tested dependency order. The new agents require the upgraded collector, so delaying that prerequisite introduces a known compatibility failure.

E: The new address is otherwise blocked. A targeted rule change enables the documented destination while preserving the required restriction on outbound connectivity.

## SEC-Q024

After a firewall migration, administrators must identify the exact approved configuration deployed at each site and compare it with prior revisions. The logical network diagrams must also reflect the deployed topology. Which closeout practice BEST satisfies both needs?

- A. Record the software version in inventory without preserving site configuration or diagram changes
- B. Overwrite the previous configuration file and keep the old network diagram until the annual review
- C. Version the deployed configurations and updated diagrams, linking their revisions to the approved change record
- D. Keep only screenshots of successful traffic tests and delete superseded configuration revisions

Answer: C

Change closeout should leave an accurate representation of what was deployed and enough history to understand how it differs from earlier states. Version control preserves revisions, updated diagrams explain topology, and links to the change record connect the artifacts to approval and implementation. Successful testing complements these records but does not replace them.

Study tip: Deployment evidence, configuration history, and current diagrams answer different operational questions and should remain connected.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Software version alone does not show rule differences or topology. Sites running the same release may still have substantially different configurations.

B: Overwriting destroys revision context, while an outdated diagram misrepresents the deployed topology. Neither supports accurate immediate comparison and operational understanding.

C: Versioned artifacts preserve change history, and record links connect approved revisions to deployment. Updated diagrams document the topology administrators will actually support.

D: Traffic tests are useful validation evidence but do not preserve complete configurations or historical differences. Deleting revisions defeats the required traceability.

## SEC-Q025

A backup service must encrypt several terabytes efficiently. Its components already have a securely established secret key. Which cryptographic approach is MOST appropriate for protecting the bulk backup contents?

- A. Public-key encryption applied directly to the entire multi-terabyte archive
- B. A digital signature attached to the otherwise unencrypted archive
- C. Authenticated symmetric encryption with the established secret key
- D. A cryptographic hash stored alongside the otherwise unencrypted archive

Answer: C

Symmetric encryption is suited to large data volumes once the parties have securely established a secret key. Many systems combine asymmetric mechanisms for key establishment with symmetric protection for bulk data. Hashes and signatures serve different purposes and do not, by themselves, provide confidentiality for the backup contents.

Study tip: Think symmetric encryption for bulk data, with asymmetric mechanisms often helping establish or protect the symmetric key.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Public-key operations are generally used for key establishment or small values rather than direct bulk encryption. Symmetric encryption better fits this workload.

B: A digital signature can support authenticity and integrity but does not hide archive contents. It cannot meet the stated encryption requirement alone.

C: Symmetric encryption efficiently protects large data volumes. An authenticated mode also detects unauthorized ciphertext changes when used correctly with its required parameters.

D: Hashing creates a digest for comparison rather than concealing data. Storing a digest does not make the original backup contents confidential.

## SEC-Q026

A sender uses a hybrid encryption system that supports public-key wrapping of a symmetric transfer key. The recipient's public encryption key has been authenticated. Which action lets the sender protect that transfer key so the recipient can recover it with the matching private key?

- A. Wrap the transfer key with the recipient's authenticated public encryption key
- B. Sign the transfer key with the sender's signing key and send it in plaintext
- C. Wrap the transfer key with the sender's own public encryption key
- D. Send only a hash of the transfer key for the recipient to reverse

Answer: A

For a public-key encryption or wrapping scheme, the sender uses the intended recipient's authenticated public key, and the recipient uses its corresponding private key for recovery. The key pair's owner matters. Signing proves something about origin and integrity, while hashing does not provide a reversible key-delivery mechanism.

Study tip: For confidentiality to a recipient, identify the recipient's encryption key pair before choosing which key performs each operation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: The recipient's public encryption key protects a value that the matching recipient private key can recover. Authenticating the public key prevents substitution.

B: A signature authenticates the signed value but does not conceal it. Sending the transfer key in plaintext would defeat the desired confidentiality.

C: That operation would require the sender's matching private key for recovery. The recipient's private key would not decrypt a value protected for the sender.

D: A cryptographic hash is not designed to be reversed to recover its input. The recipient needs the actual transfer key to decrypt the data.

## SEC-Q027

An attacker can replace both a software download and the SHA-256 value displayed beside it on a compromised mirror. Administrators already possess the vendor's signing public key from a separately trusted source. Which verification BEST detects a substituted package under these conditions?

- A. Verify the vendor's signed release manifest with the trusted key, then match the package to its signed digest
- B. Validate an HMAC using a secret key included openly with the download on the mirror
- C. Encrypt the package locally immediately after downloading it from the mirror
- D. Compute SHA-256 and compare it only with the digest shown on the same compromised mirror

Answer: A

A bare hash only helps when the expected digest is trustworthy. The compromised mirror can replace both file and digest, but it should not be able to forge a vendor signature without the private signing key. Verifying a manifest with an independently trusted public key authenticates the digest used to check the package.

Study tip: Ask how the expected hash or verification key became trustworthy; a matching hash alone does not authenticate an attacker-controlled download.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: The signature authenticates the manifest independently of the mirror. Matching the package digest to that authenticated manifest exposes an unauthorized replacement.

B: HMAC security depends on a secret known only to authorized parties. A publicly supplied key lets an attacker generate a valid tag.

C: Local encryption may protect the stored copy from disclosure, but it does not establish whether the downloaded bytes came from the legitimate vendor.

D: An attacker controlling both values can publish a matching digest for malicious software. An unauthenticated hash comparison does not establish the vendor's origin.

## SEC-Q028

A password database currently stores a single fast hash of each password, and users with identical passwords have identical stored values. The team wants to resist precomputed attacks and increase the cost of each offline guess. Which design BEST addresses both goals?

- A. Use one fixed salt for the whole database and keep the same single fast hash operation
- B. Add unique salts but remove computational work factors to maximize password-checking speed
- C. Use a suitable password-hashing scheme with a unique random salt and a tuned work factor for each stored verifier
- D. Encrypt every password reversibly with one application-wide key stored beside the database

Answer: C

Salting and key stretching solve related but different problems. Unique salts prevent identical passwords from predictably sharing a verifier and reduce the value of reusable precomputed tables. A suitable password-hashing scheme adds a tunable cost to each guess. Salts can be stored with the verifier; their role is uniqueness, not secrecy.

Study tip: Salt makes password work less reusable; a work factor makes each individual guess more expensive.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html

A: A shared salt preserves equality for identical passwords and enables work to be reused across accounts. A single fast hash also keeps guesses inexpensive.

B: Unique salts address precomputation and equality, but removing intentional cost makes offline guesses cheaper. The question requires both salt separation and increased guessing cost.

C: Unique salts separate otherwise identical passwords and undermine reusable precomputation. The password-hashing work factor increases the computation required for each offline guess.

D: Reversible encryption is not password hashing, and exposure of the colocated key can reveal every password. It does not provide the requested per-guess cost.

## SEC-Q029

A payment workflow replaces each sensitive account number with a random surrogate value before passing data to support systems. An isolated, access-controlled service retains the mapping and can recover the original number for authorized processing. Which technique is described?

- A. One-way hashing
- B. Steganography
- C. Tokenization
- D. Display masking

Answer: C

The distinguishing feature is a substitute value linked to the original through a controlled token service. Support systems can use the surrogate without routinely handling the sensitive account number. The token service remains sensitive because authorized recovery depends on it. Masking, hashing, and steganography solve different data-handling problems.

Study tip: A recoverable surrogate maintained by a protected mapping service points to tokenization.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: A cryptographic hash is designed to resist recovery of its input. The described workflow deliberately retrieves original values through a maintained mapping.

B: Steganography hides the presence of information inside another medium. Replacing account numbers with mapped surrogates is not concealment inside an image or other carrier.

C: Tokenization substitutes a surrogate for sensitive data while a protected mapping or service supports authorized recovery. Downstream systems can operate on the token.

D: Masking hides part or all of a displayed value, such as showing only the last four digits. It does not describe the separate surrogate-mapping service.

## SEC-Q030

A laptop must protect its disk-unlock key in platform hardware and release it only when configured boot measurements meet the required policy. Which component is MOST directly associated with this platform-bound key protection?

- A. A network-attached hardware security module
- B. An application secure enclave
- C. A centralized key management service
- D. Trusted Platform Module

Answer: D

A TPM supplies hardware-backed platform security functions, including protecting keys and supporting decisions based on measured boot state. Disk encryption performs the data protection, while the TPM helps protect and condition use of the unlock material. HSMs, key management services, and secure enclaves have related cryptographic roles but are not the platform component described here.

Study tip: Hardware protection tied to a device's boot measurements is a strong TPM clue.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final|https://learn.microsoft.com/en-us/windows/security/hardware-security/tpm/trusted-platform-module-overview

A: An HSM protects cryptographic operations for authorized clients. The scenario specifically calls for the laptop's own platform-bound key protection and measured-boot integration.

B: A secure enclave isolates application computations and secrets. The question instead describes platform boot measurements controlling disk-key release, a characteristic TPM use case.

C: A key management service manages key lifecycle and access policies. It does not itself provide the laptop's local hardware measurement and sealing functions.

D: A TPM provides platform cryptographic functions and can bind key use to measured platform state. It commonly supports protected disk-unlock operations.

## SEC-Q031

A certificate authority needs a dedicated, tamper-resistant cryptographic appliance that generates and uses signing keys internally. Several authorized issuance services must request signatures without receiving the private-key material. Which solution BEST fits that role?

- A. A hardware security module serving the issuance services
- B. A public repository containing the authority's root certificate
- C. A TPM on each certificate applicant's personal laptop
- D. A password-protected private-key file shared among issuance servers

Answer: A

An HSM is purpose-built for protected cryptographic key operations. Services can be authorized to request signatures while key material remains inside the hardware boundary. The module does not eliminate the need to control those requests: an attacker able to invoke unauthorized signing could still misuse the key without exporting it.

Study tip: Keeping a key non-exportable protects its material, but access to operations using that key still requires authorization.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: An HSM is designed to protect cryptographic keys and perform authorized operations inside a controlled hardware boundary, including certificate-authority signing workloads.

B: A root certificate distributes public trust information. It neither protects the private signing key nor performs controlled signing operations for issuance services.

C: Applicant TPMs can protect those devices' own keys. They do not provide the certificate authority's centralized signing appliance for authorized issuance services.

D: A shared file distributes the private-key material to servers and lacks the dedicated hardware boundary. Password protection does not meet the no-key-distribution requirement.

## SEC-Q032

A company must retain readable copies of encrypted project archives even if the employee who created them loses the data-decryption key. Which approach BEST provides controlled recovery without placing usable decryption material beside the ordinary archive files?

- A. Keep only the public encryption certificate and destroy all corresponding recovery material
- B. Use protected key escrow with an authorized recovery process and verified recovery testing
- C. Digitally sign each archive and use the signature as a replacement decryption key
- D. Retain only a one-way hash of each lost decryption key

Answer: B

Key escrow can preserve the ability to decrypt retained business data when an ordinary key holder loses access. Its value depends on protecting the escrowed material, authorizing recovery, and verifying that the process actually works. Hashes, signatures, and public encryption certificates cannot reconstruct missing private or symmetric decryption secrets.

Study tip: Recovering encrypted data requires recoverable decryption material; a hash or signature is not a backup key.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: A public encryption key does not replace its corresponding private decryption key. Destroying all recovery material can make retained ciphertext permanently unreadable.

B: Protected escrow preserves recoverable key material under controlled access. An authorized process and testing help ensure recovery works without making the archives broadly readable.

C: A signature supports integrity and origin verification. It does not contain a substitute secret that can unlock data encrypted with another key.

D: A one-way hash cannot recreate the original key for decryption. It may help compare candidate values but is not recoverable key storage.

## SEC-Q033

A TLS server certificate contains exactly one DNS subject alternative name: *.branch.example. Assume all other certificate checks pass and TLS certificate DNS-ID wildcard matching under RFC 9525 is used. Which TWO requested hostnames match that name? (Select TWO.)

- A. vpn.branch.example
- B. files.branch.example
- C. admin.ops.branch.example
- D. vpn.branch.example.other.example
- E. branch.example

Answer: A|B

A standard certificate DNS wildcard occupies the complete left-most label and matches exactly one label. Therefore, vpn.branch.example and files.branch.example match. The bare domain, a deeper descendant, and a name with an additional suffix do not. Name matching is only one certificate check; the scenario explicitly assumes the other checks succeed.

Study tip: Count labels and compare the entire suffix; a wildcard does not cover the bare domain or arbitrary nesting.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html|https://www.rfc-editor.org/rfc/rfc9525.html

A: The hostname has exactly one label, vpn, before branch.example. That single left-most label is the portion matched by the wildcard.

B: The hostname places one label, files, before the required suffix. A wildcard in that position can match this single label.

C: Two labels appear before branch.example. A standard TLS DNS wildcard matches one label rather than multiple levels of the domain hierarchy.

D: The hostname ends in other.example, not the certificate's required branch.example suffix. Containing the expected text earlier in a name does not establish a match.

E: The bare domain lacks a label for the wildcard to match. It would need its own subject alternative name in the certificate.

## SEC-Q034

A client needs a signed status response about one certificate, identified by its issuer and serial number, rather than downloading the issuer's full list of revoked certificates. Which mechanism is designed for this request?

- A. Online Certificate Status Protocol
- B. Key escrow
- C. Certificate revocation list
- D. Certificate signing request

Answer: A

OCSP is designed to provide certificate status through a request-and-response exchange, whereas a CRL distributes a revocation list. Neither mechanism replaces the other parts of certificate validation, such as trust-chain, validity-period, and hostname checks. A status response must also be appropriately authenticated and sufficiently fresh for the application's policy.

Study tip: Individual certificate status requests suggest OCSP; downloading an issuer's revocation list suggests a CRL.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: OCSP supports requests for certificate status and signed responses from an authorized responder. It can check a certificate without downloading a full CRL.

B: Key escrow retains protected key material for authorized recovery. It does not provide signed status responses about whether certificates have been revoked.

C: A CRL is an issuer-signed list of revoked certificates distributed for checking. The stem specifically asks for an individual status-response mechanism instead.

D: A CSR requests certificate issuance for a public key and associated identity information. It is not a query about an existing certificate's revocation status.

## SEC-Q035

An administrator generates a new key pair on a web server and must request a certificate from the organization's CA. Which statement correctly describes a normal certificate signing request and handling of the server's private key?

- A. Treat the CSR as an already trusted server certificate because the applicant signed it
- B. Send the server's private key to the CA because the CA must use it to sign the certificate
- C. Submit the public key and requested identity information in a signed CSR while protecting the private key locally
- D. Place the private key in the certificate so connecting clients can validate the server's identity

Answer: C

The applicant keeps the private key protected and submits a signed request containing the public key and requested certificate information. The CA validates the request according to its issuance process and signs the resulting certificate with its own key. A correctly signed request establishes key possession but does not independently establish trusted identity approval.

Study tip: The server protects its private key; the CA uses the CA's own private key to sign the server certificate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: The request's signature proves control of a key, not that a trusted CA approved the requested identity. A CSR is not the issued certificate.

B: The CA signs the issued certificate with the CA's own signing key. It does not need the applicant's private key to do so.

C: A CSR contains public-key and request information and is signed using the corresponding private key. Issuance does not require sending that private key.

D: Certificates contain public keys and identity assertions, not the corresponding private keys. Publishing a server's private key would expose its cryptographic identity.

## SEC-Q036

A laptop uses correctly configured full-disk encryption. While an employee is signed in and the disk is unlocked, malicious software running with the employee's file permissions reads and uploads documents. Why did full-disk encryption NOT prevent these reads?

- A. Enabling TLS for web browsing would prevent local malware from reading files in the active session
- B. Full-disk encryption protects filenames but leaves the contents of ordinary documents unencrypted
- C. Successful file reads prove the encryption algorithm's key length was too short
- D. The unlocked system transparently decrypts permitted file reads, so malware using those permissions can obtain plaintext

Answer: D

Full-disk encryption protects stored data on a powered-off device when the attacker cannot obtain its decryption keys. It is not a substitute for controlling processes in a signed-in, unlocked session. Here, malware uses an allowed file-access path through the running system, so plaintext is returned without the attacker having to break the encryption.

Study tip: Always identify the data state and key availability: encryption at rest does not stop every read by an already authorized session.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: TLS protects transport connections. It does not stop a local process from using the employee's existing file permissions to read decrypted data.

B: Full-disk encryption encrypts the relevant stored volume contents. The failure described concerns access after unlocking, not an inherent exclusion of document contents.

C: The malware did not need to break the cipher. It accessed data through an unlocked session and existing permissions, regardless of the algorithm's strength.

D: Full-disk encryption primarily protects stored data when decryption access is unavailable. An active session can legitimately decrypt files for processes with sufficient access.

## SEC-Q037

A research company discovers a campaign that quietly collected proprietary satellite designs for 18 months. The attackers used substantial custom tooling and showed no interest in payments or public attention. Which actor and motivation BEST fit the available evidence?

- A. An organized crime group pursuing immediate extortion
- B. An unskilled attacker pursuing entertainment
- C. A hacktivist pursuing public awareness
- D. A nation-state pursuing espionage

Answer: D

The best fit combines the actor's apparent resources with the objective of collecting strategically valuable information. Long duration and silence support espionage more strongly than extortion or publicity. These are analytical indicators, not proof that a particular government directed the campaign.

Study tip: Match both the actor's capabilities and the stated motivation; sophistication alone does not prove attribution.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: Criminal groups can steal research, but the stated absence of payment demands and focus on strategic collection better support espionage.

B: Custom tooling and long-term covert access indicate capabilities and sustained objectives beyond the opportunistic behavior described by this alternative.

C: Hacktivism commonly serves ideological publicity or disruption; this campaign emphasizes quiet intelligence collection rather than an observable public message.

D: Sustained, well-resourced collection of strategically useful research is consistent with nation-state espionage, although these indicators alone cannot establish attribution.

## SEC-Q038

A group defaces a transportation company's public website with a political statement and claims responsibility to attract attention to its cause. Which threat actor category BEST matches this behavior?

- A. Ethical researcher
- B. Hacktivist
- C. Organized crime group
- D. Shadow IT user

Answer: B

Hacktivists use technical activity to advance political, social, or philosophical beliefs. The clearest clue is the public statement explaining the purpose of the defacement. Classification follows the demonstrated motivation, rather than the particular tool or the technical complexity of the attack.

Study tip: A stated political or social cause is a stronger hacktivism clue than a specific attack technique.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Defacing a production website for publicity exceeds the authorized testing and coordinated reporting expected of an ethical researcher.

B: The public political message and claimed responsibility indicate an ideological objective, which is characteristic of hacktivist activity.

C: Organized crime generally seeks financial benefit; the scenario provides a political publicity goal rather than a revenue-generating activity.

D: Shadow IT concerns technology used outside organizational approval and oversight, not the politically motivated defacement of another organization's website.

## SEC-Q039

An attacker steals customer records, threatens to publish them unless paid, and directs the victim to a negotiation portal used in several unrelated incidents. Which motivation is MOST directly demonstrated?

- A. Financial gain through blackmail
- B. Ethical improvement through responsible disclosure
- C. Political change through public protest
- D. Service disruption for entertainment

Answer: A

Data theft identifies an action, while the payment demand identifies the motivation. This incident demonstrates financial gain through blackmail. Reuse of a negotiation service may support an organized operation, but the question can be answered without attributing the activity to a particular criminal organization.

Study tip: Separate what the attacker did from why the attacker did it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The demand for payment in exchange for withholding stolen records directly demonstrates financially motivated blackmail, regardless of the attacker's identity.

B: Threatening to publish customer records unless paid is coercive extortion and differs from reporting a vulnerability through an authorized process.

C: No political demand or ideological message appears; the attacker requests money as the condition for withholding the stolen information.

D: The described leverage is disclosure of stolen data, while the desired outcome is payment rather than an outage for amusement.

## SEC-Q040

A database administrator learns that a promotion was denied. Using an account still authorized for maintenance, the administrator deliberately deletes production records to punish management. Which classification BEST describes the actor and motivation?

- A. External attacker motivated by espionage
- B. Unintentional insider caused by inadequate training
- C. Malicious insider motivated by revenge
- D. Hacktivist motivated by a public cause

Answer: C

An insider threat can involve authorized access used for unauthorized purposes. The administrator does not need to bypass authentication to cause a security incident. Deliberate damage following a personal grievance makes malicious insider activity motivated by revenge the most specific classification.

Study tip: Valid credentials establish access; they do not make every action performed with that access authorized.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The actor is an employee using existing authorized access, and the observed objective is destruction rather than covert intelligence collection.

B: An accidental maintenance mistake could indicate training problems, but the scenario explicitly states deliberate deletion intended to punish management.

C: The administrator abuses legitimate organizational access to cause intentional harm in response to a grievance, demonstrating insider revenge.

D: The stated grievance is personal retaliation, with no evidence of a public political or social cause behind the action.

## SEC-Q041

A sales team subscribes to an unapproved file-sharing service using personal accounts and uploads customer proposals to simplify collaboration. The security team has no inventory or access controls for the service. Which risk category is MOST directly illustrated?

- A. Approved third-party data processing
- B. Shadow IT
- C. Confirmed malicious insider exfiltration
- D. Authorized risk acceptance

Answer: B

Shadow IT includes services and devices introduced without the required organizational approval or management. Malicious intent is not required. Personal accounts and missing inventory make ownership, access revocation, retention, and incident response harder, even when the employees only want to collaborate more easily.

Study tip: Shadow IT is defined by missing governance and visibility, not by malicious employee intent.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The service has not received the required organizational approval or oversight, so its business usefulness does not establish an approved processing relationship.

B: The employees introduced technology outside organizational approval and oversight, creating unmanaged data storage and access despite their productive intent.

C: The activity creates a data exposure concern, but the stated collaboration purpose does not establish that employees deliberately intend to steal information.

D: Risk acceptance requires an appropriate accountable decision, while the security team is unaware of the service and its exposures.

## SEC-Q042

An attacker runs a publicly available scanning script against many unrelated systems using its default settings. When it fails, the attacker cannot modify the script or explain the vulnerability it attempts to use. Which actor attribute is BEST supported?

- A. Internal access because default tool settings were used
- B. Nation-state sponsorship because the script targets vulnerabilities
- C. Low technical capability despite access to automated tools
- D. High technical capability because many systems were scanned

Answer: C

The evidence supports an unskilled attacker who depends on existing tools. Automated activity can be widespread without reflecting deep expertise. Evaluate the operator's ability to develop, adapt, and understand techniques separately from the volume of requests that an available tool generates.

Study tip: Attack volume measures activity; it does not directly measure attacker sophistication.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Tool settings do not reveal whether the attacker is an employee or has trusted access within the target organization.

B: Public scripts are available to many actors, so their use does not establish government support, funding, or strategic direction.

C: Dependence on unchanged public tooling and inability to adapt it indicate limited personal capability, even when automation produces substantial activity.

D: Automated tools can reach many systems with little expertise; activity volume does not demonstrate the operator's understanding or skill.

## SEC-Q043

A threat assessment must distinguish observed actor attributes from unsupported attribution. Analysts confirm a custom exploit chain and a year of coordinated infrastructure replacement across several campaigns. Which TWO conclusions are BEST supported by these observations? (Select TWO.)

- A. The actor must have an account inside the victim organization
- B. The actor's primary objective must be financial gain
- C. The actor has sustained operational resources
- D. The actor demonstrates substantial technical capability
- E. The actor must be employed by a foreign government

Answer: C|D

Threat analysis should separate attributes demonstrated by evidence from identity or intent that remains uncertain. Custom exploitation and sustained infrastructure support conclusions about capability and resources. They do not independently prove nationality, insider access, or financial motivation, each of which requires additional evidence.

Study tip: Do not turn evidence of resources into certainty about sponsorship or motivation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: Custom tools and external infrastructure do not prove employee status or possession of an internal account at the victim.

B: The evidence describes capability and persistence, not a payment demand, resale activity, or another direct indicator of financial motivation.

C: Repeated coordinated infrastructure replacement over a year demonstrates continued access to operational resources, even without identifying their funding source.

D: A confirmed custom exploit chain supports technical capability, although investigators should still consider whether the actor developed or acquired it.

E: Capability and resources can also belong to criminal or commercial groups; the observations do not establish a government employer.

## SEC-Q044

A researcher tests only systems listed in an organization's approved assessment scope, avoids accessing customer records, and privately reports a reproducible weakness through the agreed channel. Which motivation BEST matches the described behavior?

- A. Revenge through service disruption
- B. Espionage through covert data collection
- C. Ethical improvement of security
- D. Blackmail through threatened disclosure

Answer: C

Ethical motivation is supported by the researcher's authorization, scope compliance, harm reduction, and agreed reporting behavior. Merely finding a vulnerability would not establish authorization. In this scenario, the explicit assessment agreement provides the key distinction between approved security work and unauthorized activity.

Study tip: Authorization and scope are concrete evidence of legitimate testing; good intentions alone are insufficient.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: The researcher respects operational boundaries and minimizes harm, whereas revenge would require evidence of a retaliatory objective or damaging intent.

B: Avoiding customer records and reporting the weakness to the owner conflict with the covert intelligence collection described by this option.

C: Following explicit scope and reporting rules while minimizing impact supports a legitimate effort to improve the organization's security posture.

D: The scenario contains no coercive threat or payment demand; the researcher uses the reporting process agreed upon with the organization.

## SEC-Q045

An attacker controls a supplier's real email account and joins an existing invoice conversation. The attacker asks accounts payable to send this month's payment to a replacement bank account. No link or attachment is included. Which attack is MOST likely?

- A. Business email compromise
- B. A watering-hole attack
- C. A password-spraying attack
- D. A malicious attachment exploit

Answer: A

Business email compromise often relies on trust, timing, and normal payment workflows. A message can be fraudulent even when it comes from a genuine supplier account and contains no malware. Independently verifying bank-detail changes through an established contact process addresses the specific deception.

Study tip: A genuine sender account and an existing email thread do not establish that a payment change is legitimate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The attacker abuses a trusted business mailbox and ongoing financial conversation to redirect payment, which is characteristic of business email compromise.

B: A watering-hole attack compromises a site frequented by intended victims; this incident manipulates an existing business email conversation instead.

C: Password spraying attempts a small set of passwords across accounts; the scenario describes abuse of an already compromised mailbox.

D: The message contains no attachment, and the desired action is a fraudulent payment change rather than execution of an attached file.

## SEC-Q046

A caller claims to be from the service desk and asks an employee to read out a one-time authentication code to prevent an account suspension. Which attack vector is being used?

- A. DNS cache poisoning
- B. Smishing
- C. Vishing
- D. Typosquatting

Answer: C

The delivery channel makes this vishing: a fraudulent voice call. The service-desk identity is impersonation, and the threatened suspension adds urgency. These techniques can overlap within one attack, but the question asks for the vector used to deliver the request.

Study tip: When asked for a phishing vector, identify the delivery channel before the persuasion tactic.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: DNS cache poisoning corrupts name-resolution information, whereas this attacker directly persuades an employee to reveal an authentication code.

B: Smishing uses SMS or similar text messages as the delivery channel, while the described interaction takes place in a voice call.

C: Vishing uses voice communication to deceive a person into disclosing information or performing an action, as this impersonating caller attempts.

D: Typosquatting relies on a misleading domain name resembling a legitimate one; no domain-name confusion is described in this call.

## SEC-Q047

An employee receives an SMS claiming that a work package cannot be delivered until a small fee is paid through the included link. The linked page imitates the courier and requests card details. Which term MOST specifically identifies the delivery method?

- A. Removable-media attack
- B. Vishing
- C. Smishing
- D. Watering hole

Answer: C

Smishing is phishing delivered through SMS. The courier branding and small payment request support the deception, but they do not change the delivery classification. A single event can combine a message-based vector with brand impersonation and a credential or payment collection page.

Study tip: Classify the requested layer: SMS is the vector, while brand impersonation is a deception technique.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: A removable-media attack uses physical storage or a similar connected device, neither of which appears in the delivery scenario.

B: Vishing requires a voice-based interaction; this employee receives a text message and a link rather than a fraudulent call.

C: The fraudulent request arrives by SMS, making smishing the specific delivery method even though the linked page also impersonates a brand.

D: A watering hole involves compromising a site the target normally visits, not directly sending a fraudulent link through SMS.

## SEC-Q048

Attackers compromise a small industry standards website that engineers at a target company visit each week. They modify the site to direct selected visitors to malicious content. What BEST describes this targeting method?

- A. Watering-hole attack
- B. Password spraying
- C. Typosquatting
- D. Business email compromise

Answer: A

A watering-hole attack turns a trusted or familiar destination into an entry point. The attacker chooses the website because the target population commonly visits it. The engineers need not mistype a URL or receive a direct message for the malicious content to reach them.

Study tip: A compromised site chosen because the target group regularly visits it is a watering-hole clue.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The attackers compromise a location the intended victims already frequent, using their normal browsing habits to deliver malicious content.

B: Password spraying targets authentication with repeated password guesses across users, while this technique delivers content through a compromised website.

C: The engineers visit the correct established website, rather than a newly registered domain relying on a spelling mistake or confusion.

D: Business email compromise abuses business messaging and trust, often for fraud; the described attack uses a routinely visited external website.

## SEC-Q049

An attacker registers payrol.example to catch users who intend to visit payroll.example. The imitation site asks users to sign in with their work credentials. Which technique is MOST directly illustrated by the domain choice?

- A. A watering-hole compromise
- B. Typosquatting
- C. DNS cache poisoning
- D. Domain transfer hijacking

Answer: B

Typosquatting exploits mistakes in entering or reading domain names. Here, the missing letter distinguishes the attacker's separate domain from the legitimate destination. The credential request adds a phishing component, but the specific domain-selection technique is typosquatting rather than altered DNS resolution.

Study tip: A similar registered name points to typosquatting; an incorrect answer for the correct name points to DNS manipulation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: The legitimate destination has not been compromised; the attacker operates another domain intended to capture mistyped visits from users.

B: The attacker uses a domain that differs by a likely typing mistake, attempting to receive traffic intended for the legitimate site.

C: No incorrect resolver entry is described; users reach a separate domain whose spelling closely resembles the intended payroll domain.

D: The attacker registers a different name rather than taking control of the registration or ownership of the legitimate domain.

## SEC-Q050

A visitor carries a fake inspection order and claims a water leak requires immediate access to the wiring closet. The invented emergency explains why the visitor supposedly needs to bypass normal escort procedures. Which social engineering technique does this fabricated story BEST illustrate?

- A. Typosquatting
- B. Watering-hole targeting
- C. Credential stuffing
- D. Pretexting

Answer: D

Pretexting creates a scenario that makes an unusual request appear reasonable. The fake order, claimed role, and water-leak emergency reinforce that scenario. Independent verification and established escort procedures would test the story before the visitor receives access to sensitive equipment.

Study tip: The invented reason that legitimizes an unusual request is the pretext.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Typosquatting relies on misleading domain spelling, whereas this attempt uses a fabricated physical emergency and a claimed inspection role.

B: Watering-hole targeting compromises a frequently visited destination; the visitor instead creates a false explanation for direct access to a restricted area.

C: Credential stuffing reuses stolen account and password pairs against authentication services, not a story designed to persuade an employee.

D: The attacker constructs a believable situation to justify the requested access, using the invented inspection and emergency as the pretext.

## SEC-Q051

A technician finds an unknown USB device labeled 'Staff salary review' beside a store workstation. What is the BEST way to handle the device while avoiding the attack vector it may present?

- A. Connect it briefly and inspect only its filenames
- B. Connect it after disconnecting the workstation from Wi-Fi
- C. Ask a coworker to open it using a personal laptop
- D. Follow the security reporting procedure without connecting it to a production device

Answer: D

Unknown removable devices can provide a physical entry point into trusted systems. A tempting label encourages someone to connect the device voluntarily. The appropriate response is the organization's reporting and controlled-analysis procedure, rather than experimenting on a production or personal computer.

Study tip: An unknown USB device is a device-level risk, not merely a collection of files.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A device may present functions beyond storage or trigger vulnerable processing, so limiting intended file access does not make connection safe.

B: Removing one network connection does not prevent local compromise, credential theft, destructive behavior, or later spread when connectivity is restored.

C: Moving the risk to a personal device does not provide a controlled analysis environment or follow the organization's incident reporting process.

D: Reporting preserves the opportunity for controlled analysis and avoids exposing a trusted workstation to unknown storage or other USB device behavior.

## SEC-Q052

A support portal accepts only image uploads. A specially malformed image causes the server's outdated thumbnail library to execute unintended instructions when generating a preview. Which statement BEST identifies the overlooked attack surface?

- A. The failure proves that an employee enabled document macros
- B. The image-processing component still parses attacker-controlled input
- C. The image restriction prevents executable behavior inside the server
- D. The only exposed surface is the uploader's web browser

Answer: B

Data formats can become attack vectors when software processes them unsafely. The upload restriction narrows acceptable formats but does not establish that all accepted content is harmless. The key boundary is attacker-controlled image data reaching a vulnerable server-side parser during preview generation.

Study tip: A nonexecutable file can exploit the program that interprets it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: The reported behavior occurs in the server's thumbnail library, without a document, a macro engine, or an employee enabling active content.

B: Restricting uploads to images does not remove the parser attack surface; the thumbnail library must still interpret potentially malformed content.

C: An image need not be a normal executable file to exploit a defect in the software that parses its contents.

D: The server generates the thumbnail using its own vulnerable component, so exposure exists beyond the browser that submitted the file.

## SEC-Q053

Several unrelated companies receive unauthorized administrative commands through the same managed service provider's remote management platform. Investigators find that the provider's management account was compromised. Which common attack vector connects the victims?

- A. Independent malicious insiders at every customer
- B. Typosquatting against the customers' public websites
- C. Separate removable-media infections at each site
- D. A trusted service-provider supply chain

Answer: D

A supply chain attack can exploit a service relationship rather than a physical shipment or software package. The provider already has trusted administrative pathways into several customers. Compromise of that shared access can therefore create a common route into otherwise unrelated organizations.

Study tip: Supply chain exposure includes trusted service-provider access as well as products and software updates.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The common compromised provider account explains the coordinated activity without requiring an unrelated malicious employee within each customer organization.

B: Misleading domain registrations do not explain administrative commands delivered through an already trusted remote management account at the provider.

C: Commands arrive through an identified management platform, while no removable devices or separate local infection events are described.

D: The compromised provider's shared management access reaches multiple customers, making the trusted service relationship the connecting attack vector.

## SEC-Q054

A newly installed camera has an Internet-reachable management interface and still uses the administrator password printed in the public setup guide. Which TWO changes MOST directly remove the demonstrated remote entry conditions? (Select TWO.)

- A. Enable login alerts without changing the existing access configuration
- B. Require HTTPS while retaining the current password and Internet exposure
- C. Restrict management access to authorized internal administration paths
- D. Move management to an unusual port while retaining unrestricted Internet access
- E. Replace the default administrator password with a unique secret

Answer: C|E

The scenario identifies two independent conditions: external reachability and a known administrative credential. Restricting management paths reduces who can connect, while replacing the default password strengthens authentication. Address both conditions instead of assuming either a network boundary or a password alone resolves the exposure.

Study tip: Separate service exposure from authentication weakness when selecting multiple controls.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Alerts can improve detection but do not remove external reachability or prevent a successful login using the documented default password.

B: HTTPS protects management traffic in transit but still allows an external party who knows the default credential to authenticate normally.

C: Limiting management reachability removes unnecessary direct Internet exposure while preserving a controlled way for authorized administrators to manage the camera.

D: Changing the port may reduce casual discovery, but the management service remains externally reachable and protected by a publicly known credential.

E: A unique secret removes the publicly known authentication value that an external party could otherwise use to enter the management interface.

## SEC-Q055

An Internet-facing web server legitimately provides HTTPS. A recent firewall change also exposed its database administration service to all source addresses, although only an internal management host needs it. Which change BEST reduces the unnecessary attack surface?

- A. Retain public administration access and increase log retention
- B. Publish the database port in the operations documentation
- C. Change the public HTTPS port to an uncommon number
- D. Permit database administration only from the approved management host

Answer: D

An open port is an entry opportunity when the exposed service is reachable by parties that do not need it. A source-specific restriction matches the stated business requirement. The public HTTPS service should remain available while administrative access is limited to the approved management path.

Study tip: Reduce reachability to the minimum required source, destination, and service combination.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Longer log retention supports investigation after activity occurs but leaves the avoidable management interface exposed to untrusted source addresses.

B: Documentation can support management but does not enforce a boundary or prevent arbitrary external clients from reaching the administration service.

C: Changing the website's port does not address the exposed database administration service and would unnecessarily alter the legitimate public application.

D: Restricting the administration service to its documented source removes unnecessary external reachability while preserving the legitimate management requirement.

## SEC-Q056

A kiosk uses wired Ethernet only. Its Wi-Fi interface still automatically joins an old open network name, and its unused Bluetooth interface remains enabled. Which TWO actions MOST directly remove these unnecessary wireless attack surfaces? (Select TWO.)

- A. Hide the kiosk from Bluetooth discovery while leaving its radio active
- B. Disable the unused Bluetooth interface
- C. Disable the unused Wi-Fi interface and remove its automatic connection profile
- D. Enable switch port security on the kiosk's wired Ethernet connection
- E. Update the Wi-Fi driver while keeping automatic open-network connections enabled

Answer: B|C

The kiosk has no wireless business requirement, so removing the unused interfaces directly reduces its attack surface. Clearing the automatic profile also prevents an unnecessary future connection if Wi-Fi is enabled again. Driver maintenance and reduced discoverability leave the radios enabled, while wired port security addresses a different interface.

Study tip: An unused interface can still expose a system when it remains enabled.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Reducing discoverability does not remove the enabled Bluetooth interface or its protocol exposure as completely as disabling the unneeded radio.

B: Turning off an unneeded radio removes its active wireless exposure without disrupting the kiosk's stated wired-only business function.

C: Disabling unused Wi-Fi and removing the saved profile prevents the kiosk from unnecessarily connecting through a matching untrusted wireless network.

D: Wired port security can restrict devices using that switch connection, but it does not control the kiosk's independent wireless interfaces.

E: Driver maintenance can fix known software flaws but leaves the unnecessary radio and the automatic connection to an untrusted network in place.

## SEC-Q057

An adversary knowingly publishes fabricated reports claiming a company's products are contaminated, hoping customers will cancel orders. Which term BEST describes the deliberate use of false information in this campaign?

- A. A cryptographic collision
- B. Misinformation shared in good faith
- C. Disinformation
- D. A software supply chain compromise

Answer: C

The key distinction is intent. False information deliberately created or distributed to deceive is disinformation. Incorrect claims can also spread through people who believe them, but the scenario explicitly identifies an adversary who knows the reports are fabricated and seeks to manipulate purchasing decisions.

Study tip: Look for evidence that the creator or distributor knows the information is false.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: A collision concerns distinct inputs producing the same hash value, not an adversary knowingly spreading fabricated statements to influence customers.

B: Good-faith misinformation involves sharing incorrect information without the described deliberate fabrication and intent to manipulate the audience's behavior.

C: The adversary knowingly creates and distributes false claims to influence behavior, making deliberate deception the defining feature of disinformation.

D: The campaign manipulates public information, with no compromised software supplier, build pipeline, update package, or trusted distribution channel described.

## SEC-Q058

A vendor advertises a browser-only support portal as agentless. A branch still accesses it with an unsupported browser containing known rendering vulnerabilities. Which assessment is MOST accurate?

- A. HTTPS automatically compensates for the browser's rendering flaws
- B. Agentless access removes software attack surfaces from the endpoint
- C. Only the vendor's servers need patching for a browser-only application
- D. The browser remains a vulnerable client component despite the absence of a vendor agent

Answer: D

Agentless operation avoids installing a particular vendor agent, but it does not mean no client software exists. The unsupported browser remains an application attack surface. Secure deployment therefore requires maintaining the browser and underlying endpoint, in addition to evaluating the portal's server-side protections.

Study tip: Agentless is a deployment characteristic, not a guarantee that client-side vulnerabilities disappear.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: HTTPS protects the connection but does not repair unsafe processing of content after the browser receives and interprets it.

B: The endpoint still runs a browser, operating system, and related components, so removing a dedicated agent does not eliminate client software exposure.

C: Both server-side services and client software can contain vulnerabilities; browser-only access does not shift all endpoint maintenance to the vendor.

D: Agentless describes the vendor deployment approach, but users still depend on a browser whose vulnerable rendering components can process untrusted content.

## SEC-Q059

A legacy service reserves 128 bytes for a name but copies the entire supplied value without checking its length. A longer value overwrites adjacent memory and crashes the process. Which vulnerability BEST explains the result?

- A. SQL injection
- B. A cryptographic downgrade
- C. Buffer overflow
- D. A time-of-check/time-of-use race

Answer: C

The flaw is an unchecked write beyond the allocated memory boundary. The observed crash establishes a memory-safety problem and availability impact. It does not by itself prove arbitrary code execution, which would require additional evidence about how the overwritten memory can be used.

Study tip: An overflow-related crash demonstrates corruption; do not assume it automatically proves code execution.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: SQL injection changes a database command through unsafe input handling; this failure involves an unchecked memory copy rather than database query construction.

B: A downgrade causes weaker security settings to be selected, while this process crashes because supplied data exceeds a fixed-size buffer.

C: Copying more data than the allocated buffer can hold overwrites adjacent memory, which is the defining condition of a buffer overflow.

D: A race requires security-relevant state to change between operations; the scenario describes a deterministic length-check failure during a memory copy.

## SEC-Q060

A privileged service verifies that a requested file path points to an approved temporary file. Before the service opens that path, another process replaces it with a link to a protected file. The service then writes to the protected file. Which vulnerability is present?

- A. A time-of-check/time-of-use race condition
- B. A buffer overflow caused by a long pathname
- C. A reflected cross-site scripting vulnerability
- D. A hash collision in file-integrity monitoring

Answer: A

The service checks one state and later acts after that state has changed. This is a time-of-check/time-of-use race. A secure design must bind validation to the actual object used, using suitable atomic operations and object handling rather than trusting that a pathname remains unchanged.

Study tip: If something changes between validation and use, inspect the gap between those two operations.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: The object referenced by the path changes after validation but before the privileged operation, invalidating the service's earlier security decision.

B: No oversized data or memory corruption is described; the failure depends on a path referring to a different object between operations.

C: Reflected scripting involves unsafe web output interpreted by a browser, whereas this defect crosses a filesystem authorization boundary inside a service.

D: The scenario does not compare file digests; it describes changed filesystem state between a validation step and a later write.

## SEC-Q061

Endpoint telemetry shows an unauthorized process writing executable bytes into a trusted process's memory and causing that trusted process to run them. The trusted executable's file on disk remains unchanged. Which technique BEST matches the evidence?

- A. Memory injection
- B. A malicious replacement of the trusted executable on disk
- C. SQL injection against a database connection
- D. A normal application update verified by file integrity

Answer: A

Memory injection lets attacker-controlled code execute within another process. The unchanged file on disk does not establish that the running process is trustworthy. The important evidence is the cross-process memory modification followed by execution, which requires runtime visibility beyond file-integrity checks.

Study tip: A trusted executable on disk can still host untrusted code in its running process.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The attacker places code inside another process's address space and executes it there, without needing to modify that process's executable file.

B: The trusted file remains unchanged, while the evidence directly locates the unauthorized code placement and execution within process memory.

C: SQL injection changes database query behavior; the observed cross-process memory write and execution concern operating-system processes instead of SQL statements.

D: An unchanged executable does not explain or authorize another process injecting executable bytes and triggering execution inside the trusted process.

## SEC-Q062

A vendor's build pipeline is compromised before release. Customers receive an update through the normal channel with a valid vendor signature, but the update contains unauthorized data-collection code. Which conclusion is MOST accurate?

- A. The incident can only be an on-path modification during download
- B. The customers must have disabled signature verification
- C. A valid signature proves the update contains no malicious behavior
- D. The trusted software supply chain produced a malicious signed artifact

Answer: D

Code signing helps verify that an artifact corresponds to a signing identity and has not changed since signing. It does not prove the build inputs or pipeline were trustworthy. A supply chain compromise before signing can therefore produce a malicious artifact that passes normal signature checks.

Study tip: Integrity since signing does not establish integrity before signing.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/|https://csrc.nist.gov/pubs/sp/800/218/final

A: The compromise occurs in the build pipeline before distribution, while unauthorized changes after signing would normally invalidate a correctly verified signature.

B: The scenario explicitly gives a valid vendor signature; successful verification can still accept an update that was compromised before signing.

C: A signature supports origin and integrity checks relative to the signing key, not an assurance that the signed software is harmless.

D: A compromised build can place malicious code into an artifact before legitimate signing, so signature validity does not guarantee benign content.

## SEC-Q063

A web application builds a customer search query by concatenating text entered into a search field directly into SQL. Testing confirms that specially structured input changes the query's meaning. Which change BEST addresses the root cause?

- A. Increase the database account's permissions to prevent query errors
- B. Remove database error messages from the response
- C. Use a parameterized query with the search value bound as data
- D. Encrypt the web connection while retaining query concatenation

Answer: C

SQL injection occurs when untrusted input becomes part of a database command's structure. For the search value described, parameter binding keeps the SQL structure separate from the value. Error suppression and encryption are supplementary controls that do not repair the unsafe query construction.

Study tip: For a user-supplied SQL value, choose code/data separation over hiding errors or encrypting transport.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html

A: Additional permissions increase potential impact and do not separate untrusted search text from SQL syntax in the constructed database command.

B: Suppressing detailed errors can reduce information disclosure, but the application still executes a query whose structure attacker-controlled input can alter.

C: Binding the value separately from the SQL structure prevents that value from becoming executable query syntax in the intended search statement.

D: Transport encryption protects data on the connection but leaves the server's unsafe construction of SQL commands unchanged after input arrives.

## SEC-Q064

A customer submits a support comment containing script markup. The application saves the comment and later inserts it into an analyst's browser page without safe output handling. The script runs when the analyst opens the ticket. Which vulnerability is present?

- A. Reflected cross-site scripting without stored content
- B. SQL injection executed by the database
- C. A buffer overflow in the browser's network stack
- D. Stored cross-site scripting

Answer: D

Stored XSS persists attacker-controlled content and exposes later viewers when the application renders it unsafely. The important boundary is data becoming executable browser content. Context-appropriate output encoding, or safe sanitization where limited HTML is intended, addresses that rendering behavior rather than merely scanning the stored text.

Study tip: Saved input that executes when someone later views it points to stored XSS.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/

A: The malicious comment is saved and displayed in a later request, rather than being immediately echoed from the current request.

B: The observed execution occurs in the analyst's browser after rendering a comment; no change to database query syntax is demonstrated.

C: The browser interprets unsafely inserted script markup as active content, with no evidence of overwritten memory or malformed network handling.

D: Attacker-controlled markup persists in the application and later executes in another user's browser when the stored comment is displayed.

## SEC-Q065

A search page inserts the current URL's search term into its HTML response without encoding. An attacker sends a crafted link, and script executes when a user opens it. The application does not save the search term. Which classification is BEST?

- A. Reflected cross-site scripting
- B. Directory traversal
- C. A database resource-reuse vulnerability
- D. Stored cross-site scripting

Answer: A

Reflected XSS involves request input being returned unsafely in the immediate response. The malicious link supplies that input, and the browser executes the resulting content under the page's context. The absence of persistence distinguishes this scenario from a stored comment or profile-field attack.

Study tip: Immediate unsafe reflection of request input is different from saved content displayed in a later visit.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/

A: The current request supplies content that the server immediately returns unsafely, causing script execution without storing the malicious input.

B: Directory traversal accesses paths outside an intended directory; this incident changes browser interpretation of HTML rather than file path resolution.

C: Resource reuse exposes remnants from a previously assigned resource, whereas this response directly includes the current request's untrusted search term.

D: Stored scripting requires persisted attacker-controlled content to be displayed later; the scenario explicitly says the search term is not saved.

## SEC-Q066

A network appliance has current management software, but its embedded boot firmware contains a known flaw that can persist below the operating system. Which remediation MOST directly addresses the vulnerable component?

- A. Rotate management credentials and restrict access without changing the firmware
- B. Reinstall the management application without changing firmware
- C. Install the vendor's authenticated firmware update using the approved maintenance process
- D. Restore the appliance's operating-system configuration from an approved backup

Answer: C

Hardware platforms contain software components below their main operating systems. Those components have their own vulnerabilities and update processes. Updating a management application does not establish that firmware is current; remediation must match the specific affected component and follow its authenticated update procedure.

Study tip: Patch the layer containing the flaw; an operating-system or application update may not include firmware.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Access restrictions can reduce exposure but do not remove the defect in the firmware, which remains a separate component requiring remediation.

B: Replacing management software leaves the separate vulnerable firmware unchanged, even if the application installation is clean and fully up to date.

C: The vulnerability resides in firmware, so applying the appropriate verified firmware fix addresses the affected component through a controlled maintenance process.

D: Restoring operating-system settings does not replace the vulnerable boot firmware, so the identified lower-layer defect remains unless the firmware itself is corrected.

## SEC-Q067

A scanner appliance still performs its business function, but the manufacturer has ended security support and will provide no future fixes. What is the MOST significant security implication of continuing to use it?

- A. The device is guaranteed to be compromised immediately
- B. Its existing vulnerabilities become harmless when support ends
- C. Network encryption will supply the missing firmware fixes
- D. Newly discovered weaknesses may remain unpatched by the manufacturer

Answer: D

An end-of-life device can remain operational while losing a critical maintenance path. That creates growing uncertainty about future vulnerabilities and available fixes. The organization should evaluate replacement and interim controls based on exposure and business requirements, rather than equating continued functionality with continued security support.

Study tip: Still working and still supported are separate properties of an asset.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: End of support increases risk but does not establish that exploitation has occurred or that every deployment is immediately reachable.

B: A support deadline does not change vulnerable code or prevent attackers from exploiting weaknesses that remain present in the appliance.

C: Encryption can protect certain communications but does not replace the manufacturer's ability to correct vulnerabilities in the device's software or firmware.

D: End of security support removes the expected source of vendor fixes, allowing newly discovered defects to remain exposed unless other actions reduce risk.

## SEC-Q068

Code running inside a guest virtual machine exploits a hypervisor defect and gains execution on the physical host. The guest had no authorized host-management access. Which vulnerability category BEST describes the boundary failure?

- A. Resource reuse exposing an old virtual disk
- B. Lateral movement between guests through ordinary network access
- C. Virtual machine escape
- D. Privilege escalation confined to the guest operating system

Answer: C

Virtualization depends on isolation between guest workloads and the host. A VM escape breaches that boundary, potentially exposing other workloads or host control. The scenario distinguishes escape from ordinary guest compromise by explicitly showing unauthorized execution on the host through a hypervisor defect.

Study tip: Guest compromise becomes VM escape when the attacker crosses into the host's security boundary.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Resource reuse concerns residual information from previously assigned resources, rather than active code crossing from a guest into the host.

B: Guest-to-guest network movement follows a different path; this incident exploits the hypervisor to gain execution on the host itself.

C: The code crosses the intended guest-to-host isolation boundary by exploiting the virtualization layer, which is the defining feature of VM escape.

D: Guest-only escalation changes permissions within the virtual machine, while the scenario explicitly shows code crossing into the physical host's execution context.

## SEC-Q069

A cloud tenant receives a newly assigned virtual disk and can recover fragments of another tenant's deleted customer records. The new tenant has no credentials for the former tenant and did not escape its virtual machine. Which weakness BEST explains the exposure?

- A. Credential stuffing against the former tenant
- B. A virtual machine escape into the hypervisor
- C. A TLS downgrade during the disk attachment
- D. Inadequate sanitization before resource reuse

Answer: D

Resource reuse can expose a previous user's information when storage or memory is reassigned without appropriate clearing or protection. The new tenant is authorized to use the resource but should not inherit its former contents. This is a data-isolation failure, not evidence of a guest-to-host escape.

Study tip: Distinguish crossing a live isolation boundary from receiving uncleared remnants in an assigned resource.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/88/r2/final

A: No former-tenant credentials are used; access comes from the new allocation of storage containing data left behind by its previous owner.

B: The tenant reads remnants from its assigned disk without crossing into the host, and the scenario explicitly excludes a VM escape.

C: Negotiating weaker transport security does not explain old records remaining readable on storage legitimately assigned to a new tenant.

D: Residual data remains in storage reassigned to a different tenant, indicating that the provider failed to sanitize or otherwise protect reused capacity.

## SEC-Q070

An employee can download a confidential object from a cloud storage service while signed out because its policy grants anonymous read access. The object is encrypted at rest, and the service decrypts it for permitted requests. What is the PRIMARY weakness?

- A. A hypervisor escape from another tenant
- B. A failure of the encryption algorithm
- C. An overly permissive access policy
- D. An inadequate password length for the employee

Answer: C

Encryption at rest protects stored data against particular forms of access, but the service still supplies readable data to requests that its policy allows. Here the problem is authorization misconfiguration: anonymous users receive permission they should not have. Correct the object or service access policy.

Study tip: Encryption does not compensate for a service deliberately returning data to an overly broad authorized audience.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/|https://aws.amazon.com/compliance/shared-responsibility-model/

A: The object is retrieved through the normal storage interface under its configured policy, without evidence of crossing a virtualization boundary.

B: No cryptographic break is necessary because the service intentionally decrypts the object for requests its access policy mistakenly permits.

C: The policy treats anonymous requests as authorized, allowing the storage service to return plaintext despite correctly applying encryption at rest.

D: The download succeeds without authentication, so changing the employee's password would not remove the policy's anonymous access permission.

## SEC-Q071

A desktop application encrypts local customer exports with the same secret key embedded in every distributed installer. An analyst extracts that key from one copy and decrypts an export from another installation. Which design weakness MOST directly enabled this result?

- A. A shared hardcoded encryption key exposed to application recipients
- B. Insufficient transport encryption when opening the local export
- C. A collision between two unrelated ciphertext files
- D. The use of encryption instead of a file checksum

Answer: A

The demonstrated failure is key management, not a break of the underlying encryption algorithm. Embedding a shared secret in every distributed client makes that secret recoverable by recipients and reusable against other installations. Proper key separation and protection must match who is allowed to decrypt each export.

Study tip: Strong cryptography cannot preserve confidentiality when unauthorized parties obtain the decryption key.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final|https://owasp.org/Top10/2025/

A: Anyone who extracts the embedded shared key can apply it across installations, defeating the intended separation between different customers' encrypted exports.

B: The scenario involves local files and a recovered encryption key, so network transport encryption would not prevent the demonstrated decryption.

C: The analyst decrypts using the actual key; no identical hash values or cryptographic collision is needed to explain the exposure.

D: A checksum detects certain changes but provides no confidentiality; replacing encryption with a checksum would not protect the exported customer information.

## SEC-Q072

An employee first removes manufacturer-imposed privilege restrictions from a phone's operating system. The employee then installs a work-themed application obtained directly from an unknown website instead of an approved application store. Which TWO practices are described? (Select TWO.)

- A. Sanitizing the phone before reassignment
- B. Sideloading an application
- C. Jailbreaking or rooting the device
- D. Applying a manufacturer-signed security patch
- E. Enrolling the phone in centralized device management

Answer: B|C

The scenario describes two separate actions. Jailbreaking or rooting changes platform restrictions, while sideloading changes the application installation source. They can occur together but are not synonyms; some platforms permit sideloading without elevated privileges. Each can introduce risks depending on the device policy and software involved.

Study tip: Platform privilege changes and application-source changes describe different mobile risks.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Sanitization removes or renders prior data inaccessible for reuse, while the described actions alter privileges and add an unapproved application.

B: Installing an application from a source outside the approved store describes sideloading, independent of whether the device was previously modified.

C: Removing operating-system restrictions to obtain elevated control describes jailbreaking or rooting, depending on the platform and its terminology.

D: The employee bypasses platform restrictions and uses an unknown application source, rather than installing a described authenticated update from the manufacturer.

E: No organizational enrollment or policy management is described; the employee instead removes restrictions and installs software outside the approved channel.

## SEC-Q073

Investigators observe active exploitation of a software flaw that was previously unknown to the vendor. The vendor confirms the discovery and has no fix available yet. Which description BEST fits the flaw at the time of discovery?

- A. A zero-day vulnerability
- B. A known vulnerability with an available but uninstalled patch
- C. A scanner false positive without a real security defect
- D. An approved deviation from a documented configuration baseline

Answer: A

The defining clues are that the vulnerability was previously unknown to the vendor and exploitation occurred before a fix was available. A zero-day label does not determine the eventual severity by itself. Exposure and demonstrated impact still matter when choosing interim controls and remediation priorities.

Study tip: A vulnerability is not a zero-day merely because your organization has not installed an available patch.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://github.com/cisagov/kev-data

A: The previously unknown vulnerability is already being exploited before the vendor has had an opportunity to provide a corrective update.

B: An uninstalled available fix would indicate a patch-management gap, but the vendor was previously unaware and has no corrective update yet.

C: Observed exploitation and vendor confirmation establish a real flaw, rather than an unsupported vulnerability alert caused by a scanner's detection logic.

D: The scenario describes a newly discovered software defect, not an organization's authorized decision to operate with a known configuration difference.

## SEC-Q074

A web service starts automatically with full operating-system privileges. Its administrator-owned service configuration is writable by ordinary local users, allowing them to replace the executable path before the next restart. Which TWO conditions combine to create the demonstrated privilege-escalation risk? (Select TWO.)

- A. The service executes the configured program with full operating-system privileges
- B. The service configuration has an administrator listed as its owner
- C. The service configuration is stored on a local disk
- D. Excessive write permissions on a privileged service's configuration
- E. The web service uses an automatic startup schedule

Answer: A|D

The exploit path combines control by a lower-privileged user with execution by a higher-privileged service. Administrator ownership alone does not prevent writes if permissions are too broad. Restricting configuration changes and reducing service privileges address the actual conditions, while automatic startup and local storage are incidental.

Study tip: Find the low-privilege write that feeds a high-privilege action.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://attack.mitre.org/tactics/enterprise/

A: The high-privilege execution context turns control of the startup program into elevated execution, completing the security boundary crossing.

B: Administrative ownership is not itself the flaw; the dangerous condition is that the permissions still allow ordinary users to modify the content.

C: Local storage is normal for service configuration and does not create escalation when ownership, permissions, and service privileges are appropriately controlled.

D: Ordinary users can change the configuration trusted at service startup, allowing lower-privileged input to control what a privileged component executes.

E: Automatic startup can trigger execution but is not inherently unsafe; the risk comes from combining untrusted configuration writes with privileged execution.

## SEC-Q075

Many files on a department share become unreadable, their extensions change, and a new text file demands payment for a decryption key. Which malware category is MOST strongly indicated?

- A. A passive packet sniffer
- B. Bloatware
- C. Ransomware
- D. A keylogger

Answer: C

The strongest evidence is the combination of file inaccessibility, apparent encryption, and an extortion message. These clues point to ransomware rather than general resource consumption or surveillance. The payment demand does not establish that the attacker can or will successfully restore the data.

Study tip: Look for the combined impact and demand; a changed extension alone is not enough to classify malware.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: Passive traffic capture observes network communication rather than changing stored files into an unreadable state and requesting payment for recovery.

B: Unnecessary preinstalled software may consume resources, but it does not account for the coordinated encryption and ransom message described here.

C: The combination of inaccessible encrypted files and a demand for payment to recover them is characteristic of encryption-based ransomware.

D: Keyloggers capture input such as keystrokes; that behavior alone does not explain widespread file encryption and an extortion demand.

## SEC-Q076

A compromised workstation scans neighboring systems, exploits an exposed service, and causes each newly infected system to repeat the process. No user opens an attachment or runs an infected document on the additional systems. Which malware type BEST matches this propagation?

- A. A nonpropagating logic bomb
- B. A passive spyware extension
- C. Worm
- D. A file virus requiring infected host execution

Answer: C

A worm's defining feature is autonomous propagation. The initial entry method can differ, but the later systems become infected through automatic exploitation and repeat the behavior. The question asks about propagation, so the answer follows that evidence rather than any unknown initial delivery mechanism.

Study tip: Classify malware propagation separately from its original delivery method or eventual payload.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: A logic bomb executes when a condition is met, but the defining evidence here is repeated automatic infection of other systems.

B: Passive spyware collects information; the described behavior actively exploits remote services and reproduces across the network without additional user actions.

C: The malware propagates between systems automatically through network services, without needing a user to execute an infected host file on each destination.

D: A traditional file virus propagates by infecting host files that execute, while the described spread occurs directly through exposed network services.

## SEC-Q077

An employee installs a program advertised as a PDF conversion utility. It performs basic conversion but secretly adds unauthorized remote access. Investigators find no self-replication. Which malware classification BEST describes its deceptive delivery?

- A. Trojan
- B. A boot-sector virus
- C. A cryptographic downgrade tool
- D. Worm

Answer: A

A Trojan disguises malicious behavior within software that appears legitimate or useful. It can provide the advertised feature and still be malicious. The unauthorized remote access is the payload, while the deceptive conversion utility explains why the employee chose to install it.

Study tip: Useful functionality does not rule out a Trojan; deception concerns the hidden behavior.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The program presents a useful function while concealing malicious behavior, matching a Trojan's deceptive appearance as legitimate or desirable software.

B: No boot-sector infection or replication through boot media is described; the evidence concerns malicious functionality hidden in a conversion utility.

C: The reported behavior adds unauthorized remote access rather than manipulating protocol negotiation to force the use of weaker cryptographic settings.

D: Worm classification depends on autonomous propagation, while the scenario specifically identifies installation of a deceptive program without observed self-replication.

## SEC-Q078

A former employee left unauthorized code that checks whether the employee's account is disabled. Once that condition becomes true, the code deletes project files. Until then, it remains inactive. Which malware behavior is MOST specifically demonstrated?

- A. A benign scheduled data-retention task
- B. A worm spreading through vulnerable services
- C. A logic bomb triggered by a condition
- D. A keylogger capturing authentication input

Answer: C

Logic bombs use a condition to control when malicious behavior occurs. The condition can be a date, event, or state change such as an account being disabled. A scheduled action is not inherently malicious; the unauthorized destructive purpose is explicit in this scenario.

Study tip: Identify both the trigger condition and the unauthorized action it releases.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The code is unauthorized and tied to a former employee's account state, not an approved retention schedule for the project data.

B: No automatic propagation to other systems is described; the important behavior is destructive code waiting for a predetermined account-state condition.

C: The malicious action is deliberately deferred until a specific condition becomes true, which is the defining behavior of a logic bomb.

D: The code checks account status and deletes files, without evidence that it records keystrokes or captures users' authentication input.

## SEC-Q079

A host's normal administration tools report no suspicious process or driver. A trusted offline examination finds an unauthorized kernel component that intercepts system queries to hide its associated files and process. Which malware category BEST fits this concealment?

- A. Rootkit
- B. A simple advertising toolbar
- C. A reflected denial-of-service attack
- D. A standalone file-encrypting ransomware payload

Answer: A

A rootkit can alter the system's view of itself, making ordinary host tools unreliable for discovering the hidden components. The trusted offline examination provides an independent comparison. The defining evidence is deliberate concealment through a privileged component, rather than simply running with administrative permissions.

Study tip: Disagreement between compromised host tools and trusted external examination can reveal deliberate hiding.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The unauthorized component manipulates system visibility to conceal artifacts and activity, a characteristic purpose of a rootkit operating at a privileged layer.

B: An unwanted toolbar may affect browsing but does not explain a kernel component altering operating-system queries to hide files and processes.

C: Reflected denial of service uses intermediaries to direct traffic at a victim, rather than modifying the host's kernel reporting mechanisms.

D: The evidence centers on privileged concealment, not inaccessible encrypted files or a demand for payment to restore data access.

## SEC-Q080

Security staff recover a second RFID badge containing the same static credential identifier as an employee's badge. Both badges open the same doors, and the employee still possesses the original. Which physical attack is MOST directly demonstrated?

- A. Tailgating behind an authorized employee
- B. Physical brute force against the door
- C. Environmental damage to the badge reader
- D. RFID cloning

Answer: D

RFID cloning duplicates credential information so another device can present the same identity. The original badge can remain in the employee's possession, unlike ordinary theft. A reader that relies only on the copied static identifier cannot distinguish these two badges from that identifier alone.

Study tip: The continued presence of the original credential does not rule out a usable copy.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: Tailgating relies on following someone through an access point, while the second badge independently causes the reader to authorize access.

B: The doors accept a copied electronic credential; the scenario does not describe breaking a lock or forcing an entry barrier.

C: The reader continues accepting a duplicated identifier as designed; there is no evidence of flooding, heat, power damage, or another environmental cause.

D: Duplicating the credential identifier onto another usable badge demonstrates cloning, allowing the copy to be accepted as the original identity.

## SEC-Q081

An investigation confirms that an attacker tried one common password against 600 different employee accounts, paused, and then tried a second common password across the same accounts. Which password attack BEST matches this pattern?

- A. Credential stuffing using unique breached account-password pairs
- B. Password spraying
- C. Focused brute force against one account
- D. An offline collision attack against file hashes

Answer: B

Password spraying emphasizes breadth: one or a few candidate passwords are tried across many users. Pausing can reduce the rate of attempts seen by each account's lockout mechanism. The distinguishing evidence is the distribution of guesses, not simply the presence of failed logins.

Study tip: Few passwords across many accounts indicates spraying; many passwords against one account indicates focused guessing.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/|https://pages.nist.gov/800-63-4/sp800-63b.html

A: Credential stuffing replays previously obtained credential pairs, whereas this campaign uses the same small set of guesses across many different accounts.

B: The attacker spreads a small number of common guesses across many accounts, rather than exhausting many candidate passwords against one identity.

C: Focused brute force applies many guesses to a particular account; the defining pattern here is a few guesses distributed broadly.

D: The attacker attempts online account authentication, not the generation of different file contents that produce the same cryptographic hash.

## SEC-Q082

Authentication monitoring shows thousands of different password guesses directed at a single service account during a short period. Investigators find no evidence that the guesses came from previously breached credential pairs. Which attack is MOST likely?

- A. A successful session-token replay
- B. Focused online password brute force
- C. Credential stuffing from a known breached list
- D. Password spraying across the directory

Answer: B

This pattern shows a concentrated attempt to discover one account's password by repeatedly trying candidates online. It differs from spraying by the number of identities targeted and from credential stuffing by the use of guesses rather than known breached pairs. Rate controls can reduce the attack opportunity.

Study tip: Use both the number of accounts and the origin of the candidate credentials to classify password attacks.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/|https://pages.nist.gov/800-63-4/sp800-63b.html

A: Token replay reuses a captured session credential, whereas the monitoring shows repeated password checks rather than an accepted existing session token.

B: Numerous candidate passwords are being tested against one account through its authentication service, matching a focused online brute-force attempt.

C: The evidence supports generated guesses against one account and explicitly lacks a source of previously breached account-password pairs for replay.

D: Spraying distributes a small number of guesses across many accounts, while this activity concentrates thousands of different guesses on one identity.

## SEC-Q083

Attackers obtain username-password pairs from an unrelated breached shopping site and automatically submit each intact pair to a company's employee portal. Some employees reused the same credentials. Which attack BEST describes the portal activity?

- A. A cryptographic collision in the portal's certificate
- B. Credential stuffing using replayed breached credential pairs
- C. An offline brute-force attack against local password hashes
- D. Password spraying with a common password list

Answer: B

Credential stuffing is a form of credential replay that takes advantage of password reuse between services. The source and pairing of the credentials distinguish it from spraying. A complex password reused across services can still be vulnerable when one of those services exposes the complete credential.

Study tip: Previously breached username-password pairs are the distinguishing clue for credential stuffing.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/|https://pages.nist.gov/800-63-4/sp800-63b.html

A: The successful logins result from credential reuse, without any evidence that the attacker forged a certificate or found matching hash outputs.

B: The attackers reuse complete credentials obtained from another service, testing whether password reuse allows those same pairs to authenticate at the portal.

C: The activity occurs through the company's live authentication interface with recovered plaintext credential pairs, not through local computation against password hashes.

D: Spraying applies common guesses across accounts, while these attackers submit specific username-password pairs already associated with users in a breach.

## SEC-Q084

Users relying on one recursive resolver receive 192.0.2.70 for portal.example. The unchanged authoritative zone and trusted independent resolvers return the approved address, 198.51.100.21. Investigators confirm an unauthorized entry in the affected resolver's cache. Which attack BEST fits?

- A. DNS cache poisoning
- B. A denial of service caused by a full browser cache
- C. Typosquatting against a similar domain
- D. An authorized authoritative DNS migration

Answer: A

DNS cache poisoning corrupts a resolver's cached mapping and can redirect users who enter a legitimate domain correctly. Comparing the affected resolver with authoritative information helps localize the problem. Here the confirmed unauthorized cache entry distinguishes poisoning from ordinary propagation delay or a legitimate DNS update.

Study tip: Validate the correct hostname and compare resolver answers before assuming a lookalike domain caused the redirect.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: An unauthorized cached answer causes the correct domain name to resolve to the wrong address for clients using the affected resolver.

B: The confirmed false record resides in the recursive DNS resolver, and clients receive an incorrect destination rather than failing because of browser storage.

C: Users requested the correct portal.example name; the problem is the returned address, not a spelling change leading to a different registered domain.

D: The authoritative zone remains unchanged and independent resolvers return the approved address, contradicting the explanation of an intended authoritative migration.

## SEC-Q085

Near a branch lobby, a newly detected access point advertises the corporate wireless network's exact name. It is not connected to approved infrastructure and presents a fake company sign-in page to connecting employees. Which attack is MOST likely?

- A. A reflected DNS amplification attack
- B. RFID badge cloning
- C. An evil twin impersonating the corporate wireless network
- D. An approved roaming extension of the wireless deployment

Answer: C

An evil twin copies the identity of a wireless network users expect to trust. The matching network name alone does not establish ownership or authenticity. The unauthorized infrastructure and fraudulent sign-in page provide stronger evidence than signal strength or a familiar SSID.

Study tip: An SSID is a network name, not proof that the access point belongs to its claimed organization.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: No large DNS responses or spoofed traffic reflection are described; the attacker attracts local wireless clients through network impersonation.

B: The scenario concerns a wireless access point and employee network sign-in, not a copied proximity badge accepted by a physical reader.

C: The unauthorized access point copies a trusted network identity and uses that resemblance to direct employees to a fraudulent authentication page.

D: The access point is absent from approved infrastructure and presents a fake sign-in page, which contradicts normal authorized roaming behavior.

## SEC-Q086

A workstation's gateway IP remains correct, but its ARP cache suddenly maps that IP to an unknown laptop's MAC address. Packet capture confirms the laptop sent false ARP replies and forwards the workstation's traffic onward. Which attack is MOST strongly indicated?

- A. A password spray against the wireless controller
- B. An on-path attack using ARP spoofing
- C. A normal gateway failover approved by network operations
- D. DNS poisoning of the gateway hostname

Answer: B

ARP associates an IPv4 address with a link-layer address on the local network. False replies can cause a victim to send traffic to an attacker who then forwards it, creating an on-path position. This evidence establishes redirection but does not alone prove that properly protected TLS content was decrypted.

Study tip: A changed IP-to-MAC mapping concerns ARP; distinguish traffic interception from successful decryption.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: No password attempts are described; the observed behavior manipulates local network addressing so the laptop receives traffic intended for the gateway.

B: False local address-resolution information redirects gateway-bound frames through the laptop, which forwards them and places itself on the communication path.

C: The capture identifies false replies from an unknown laptop, providing evidence of unauthorized redirection rather than an approved gateway transition.

D: The gateway IP is unchanged; the manipulated mapping is between that IP and a local hardware address, which belongs to ARP.

## SEC-Q087

A victim receives large unsolicited UDP responses from many public servers. Investigation at a responding server shows small requests with the victim's spoofed source address; each response is much larger than its request. Which attack combines the two demonstrated mechanisms?

- A. A reflected attack with no amplification
- B. A credential replay attack against the UDP servers
- C. A reflected and amplified denial-of-service attack
- D. A direct denial-of-service flood without intermediaries

Answer: C

Reflection describes third-party systems replying to a spoofed victim address. Amplification describes a response being larger than the request that caused it. These mechanisms can occur together but are distinct; the scenario supplies evidence for both and shows how they produce unsolicited traffic at the victim.

Study tip: Intermediaries indicate reflection; a larger response-to-request ratio indicates amplification.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The responses are explicitly much larger than the triggering requests, demonstrating amplification in addition to reflection through third-party servers.

B: The mechanism uses source-address spoofing and response volume, not reuse of an authentication credential to establish an authorized session.

C: The spoofed victim address redirects replies through third-party servers, while larger responses than requests amplify the volume delivered to the victim.

D: The traffic reaches the victim through responding public servers, so intermediaries are central to the observed attack rather than absent.

## SEC-Q088

A client and server both support a modern secure protocol version. Investigators confirm that an attacker interferes with negotiation until a compatibility mechanism retries using a weaker legacy version that the server still permits. Which attack is being performed?

- A. A hash collision attack
- B. A downgrade attack
- C. A password-spraying campaign
- D. An authorized certificate renewal

Answer: B

A downgrade attack causes participants to use weaker security than they could otherwise support. The problem here is an exploitable fallback path coupled with server permission for the legacy option. Correctly disabling obsolete alternatives and enforcing secure negotiation prevents that specific path to weaker protection.

Study tip: Supporting a strong protocol is insufficient when an attacker can force an accepted weaker alternative.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: A collision concerns different inputs sharing a digest; the evidence instead shows manipulation of the protocol version selected for a connection.

B: The attacker deliberately drives negotiation away from a supported stronger option toward an allowed weaker version, exploiting the compatibility fallback behavior.

C: No account-password guesses occur; the attack targets security negotiation between communicating systems rather than repeated attempts at user authentication.

D: Certificate renewal replaces or extends an identity credential, while the attacker changes negotiated security strength through repeated forced fallback.

## SEC-Q089

In a controlled test, researchers freely construct two different documents that produce exactly the same digest under a weak hash algorithm. No specific original document or target digest was imposed before they began. Which property has MOST directly failed?

- A. Second-preimage resistance for a fixed original document
- B. Collision resistance
- C. Preimage resistance for a specified digest
- D. Confidentiality of encrypted document contents

Answer: B

Collision resistance concerns the difficulty of finding any two different inputs with the same digest. Preimage and second-preimage problems impose a target digest or a fixed original input. The scenario explicitly removes those constraints, making a collision the demonstrated cryptographic weakness.

Study tip: Ask what the attacker must match: any pair, a specified digest, or a specified original input.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: A second-preimage attack starts from a particular existing input, whereas the researchers were allowed to construct both documents freely.

B: Finding any two distinct inputs with the same hash output demonstrates failure of collision resistance, matching the researchers' freedom to choose both documents.

C: A preimage attack begins with a target digest and finds an input for it; no target digest was supplied in this test.

D: The test compares hash outputs and does not involve decrypting data; ordinary hashing does not provide confidentiality for document contents.

## SEC-Q090

An analyst reviews a user account against its established baseline. Source locations are accurately mapped, and no approved VPN explains location differences. Which THREE observations warrant investigation as possible attack indicators? (Select THREE.)

- A. The approved backup job runs during its established nightly window
- B. The user's managed workstation renews its certificate on the approved schedule
- C. The audit stream stops after a privilege change while host heartbeats continue
- D. A documented patch changes the expected version of an approved application
- E. Simultaneous sessions from unfamiliar devices in two distant cities
- F. Successful logins from New York and Tokyo four minutes apart

Answer: C|E|F

Impossible travel, unfamiliar concurrent sessions, and a selective logging gap are indicators to correlate and investigate. None individually proves an attack, and legitimate explanations must still be checked. The other observations fit approved baseline activity, which provides context for separating suspicious deviations from expected operations.

Study tip: Treat anomalies as evidence to validate, and compare them with known authorized activity.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The job matches an authorized recurring activity and its normal time, providing no stated deviation or corroborating sign of malicious behavior.

B: The renewal occurs through an expected managed process at the established time, with no reported anomaly in its identity or authorization.

C: Selective loss of audit data following a sensitive change may indicate logging interference and deserves investigation rather than being treated as a confirmed host outage.

D: The version change matches a documented maintenance action, so the supplied facts explain it without indicating an unauthorized modification.

E: Concurrent unfamiliar sessions across the suspicious locations add evidence of possible unauthorized account use, although concurrency alone is not conclusive.

F: The geographic distance and short interval indicate impossible travel under the stated location assumptions, making account compromise a reasonable hypothesis to investigate.

## SEC-Q091

A report-download request contains parent-directory references in its filename parameter. The server resolves the path outside the approved report folder and returns a protected configuration file. Which application attack is MOST directly demonstrated?

- A. A cryptographic birthday attack
- B. SQL injection
- C. Directory traversal
- D. Cross-site scripting

Answer: C

Directory traversal lets path input select a location outside the application's intended boundary. The decisive evidence is not simply suspicious path syntax but the confirmed resolution and successful return of a protected file. Safe file selection must enforce the permitted location after appropriate path handling.

Study tip: Distinguish a suspicious traversal attempt from a confirmed boundary escape and file disclosure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/

A: A birthday attack seeks hash collisions more efficiently, while this request exploits unchecked path components to retrieve an unauthorized server file.

B: The attacker manipulates file path resolution rather than SQL syntax, and the evidence identifies a filesystem boundary failure rather than a database query.

C: The supplied path escapes the permitted report directory and accesses a file elsewhere, which directly demonstrates traversal of the intended filesystem boundary.

D: No script execution in a browser is shown; the demonstrated impact is unauthorized server-side access to a file outside the approved directory.

## SEC-Q092

A standard user exploits a local helper program and obtains a process running with operating-system administrator privileges. No administrator intentionally grants the additional rights. Which attack BEST describes the resulting change?

- A. An authorized role assignment
- B. A denial-of-service attack with no privilege change
- C. Horizontal access to another standard user's data
- D. Vertical privilege escalation

Answer: D

Privilege escalation increases what an attacker can do after obtaining an initial position. Moving from a standard user to administrator is vertical escalation because it crosses permission levels. The helper's legitimate presence does not authorize abuse of its execution context to gain additional rights.

Study tip: Identify the permission level before and after the action to recognize vertical escalation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/

A: The additional privileges result from exploiting a helper program, and the scenario explicitly excludes an intentional administrative grant of those rights.

B: The defining outcome is a newly privileged process, not merely loss of availability without any change in the attacker's effective permissions.

C: Horizontal access concerns resources of peers at the same privilege level, while this process gains administrator privileges beyond the user's original level.

D: The user moves from a lower permission level to a higher one by exploiting a defect, crossing an intended privilege boundary.

## SEC-Q093

A store's camera VLAN and point-of-sale VLAN currently allow unrestricted traffic between them. Cameras only need to communicate with a designated recording server. Which change BEST limits the impact of a compromised camera while preserving that requirement?

- A. Move cameras to a new VLAN while preserving unrestricted inter-VLAN routing
- B. Enforce inter-VLAN rules that permit the recording flow and deny unnecessary camera access
- C. Increase camera password length without changing the inter-VLAN access policy
- D. Encrypt camera-to-recorder video while retaining unrestricted inter-VLAN routing

Answer: B

Segmentation becomes an effective mitigation when traffic rules enforce the intended separation. Merely placing devices in different VLANs does not help if routing permits everything. Allow the camera-to-recorder flow and restrict unnecessary access, particularly to systems whose business function requires a separate trust boundary.

Study tip: A VLAN provides separation structure; traffic policy determines which connections can cross it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A separate VLAN does not achieve the intended access restriction when its routing policy still permits unnecessary connections to the payment systems.

B: Rules based on required communication restrict the camera network's reach, reducing lateral movement opportunities while retaining the approved video-recording function.

C: Stronger credentials can reduce one compromise path, but the question assumes a camera is compromised and asks how to constrain its subsequent reach.

D: Video encryption protects the recording flow but does not restrict what other destinations an already compromised camera can attempt to reach.

## SEC-Q094

Auditors need to open and download finalized reports from a shared folder, but they must not alter or delete them. Which permission assignment BEST satisfies the requirement?

- A. Grant the auditor group modification rights so members can download copies
- B. Grant the auditor group write-only access through a drop-box folder
- C. Grant the auditor group full control only during the scheduled audit
- D. Grant the auditor group read access and withhold modification permissions

Answer: D

Least privilege grants the permissions required for the task and withholds unnecessary capabilities. The auditors need read access, including normal file retrieval, but no modification authority. Limiting when an excessive permission applies does not make its scope appropriate; both the granted actions and access duration should match the job.

Study tip: Translate the required task into permissions before choosing a role or access level.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Downloading requires reading the source file, not permission to modify or delete it; modification rights exceed the auditors' stated tasks.

B: Write-only access supports submitting files rather than reading existing reports, so it does not provide the auditors' required viewing and download capabilities.

C: A time limit reduces duration but still grants unnecessary modification and permission-management capabilities throughout the audit period when only read access is needed.

D: Read access supports the required viewing and download tasks while withholding write and delete capabilities that the auditors do not need.

## SEC-Q095

A kiosk runs a small, stable set of approved applications. Administrators want unapproved executables blocked even when those files have not previously been classified as malicious. Which control BEST matches that requirement?

- A. Full-disk encryption with no execution restrictions
- B. A denylist containing only previously identified malicious file hashes
- C. Longer retention for software installation logs
- D. Application allowlisting with a managed approved-software policy

Answer: D

Application allowlisting is well suited to a stable, limited software inventory. It enforces approval rather than trying to recognize every possible malicious file. The policy still needs controlled maintenance so legitimate updates work and overly broad rules do not create unintended execution paths.

Study tip: An allowlist asks whether software is approved; a denylist asks whether it is already prohibited.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Disk encryption protects stored data in relevant circumstances but does not decide which programs an authenticated running system is allowed to execute.

B: A known-malicious denylist can miss new or changed executables, while the requirement is to block anything outside the approved application set.

C: Installation records support investigation and accountability, but retaining them longer does not enforce a rule preventing unapproved executable files from running.

D: An allowlist permits explicitly approved software and blocks other executables without depending on a prior determination that each blocked file is malicious.

## SEC-Q096

A workstation is actively contacting a confirmed command-and-control destination. The approved response plan calls for immediate network containment while preserving the running system for investigation. Which action BEST fits the plan?

- A. Revoke the employee's browser session while leaving workstation network access unchanged
- B. Use endpoint isolation to block ordinary network traffic while retaining the approved response channel
- C. Block the destination's domain in DNS while leaving established connections active
- D. Erase and reinstall the workstation before collecting evidence

Answer: B

Isolation reduces the system's communication opportunities while supporting the stated need to preserve evidence. The question supplies an approved plan, so no universal incident-order assumption is necessary. A controlled response channel can allow investigation without restoring the workstation's ordinary access to other systems.

Study tip: Match containment to the stated evidence-preservation and response requirements.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Revoking a user session can address account misuse but does not necessarily stop malware's independent command-and-control channel or contain the endpoint's network access.

B: Endpoint isolation can interrupt attacker communication and lateral movement while leaving the powered-on system accessible through a controlled investigation channel.

C: A DNS block alone need not terminate existing connections or prevent direct-IP communication, and it does not isolate the workstation from neighboring systems.

D: Immediate rebuilding destroys the running state that the plan explicitly requires preserving and combines eradication with an unneeded loss of evidence.

## SEC-Q097

A vendor provides a verified update that fixes a vulnerability in a required server service. Compatibility testing has passed and the emergency change is approved. Which action MOST directly removes the known software defect?

- A. Restrict service access to approved subnets without updating its executable
- B. Add an intrusion-prevention signature while retaining the existing service version
- C. Rebuild the server using a clean copy of the same vulnerable package
- D. Install the corrective update and verify the affected component's version and behavior

Answer: D

Patching directly corrects the known defect when a suitable fix exists. The scenario resolves testing and approval prerequisites, making installation and validation the appropriate next action. Other controls may reduce exposure or improve detection, but they do not substitute for changing the vulnerable component itself.

Study tip: Distinguish removing a defect from reducing its exposure or detecting attempts to exploit it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://github.com/cisagov/kev-data

A: Network restrictions reduce exposure to potential attackers but do not correct the software flaw for clients still permitted to reach the service.

B: An effective signature may block particular exploit attempts, but it is a compensating measure that leaves the defective service code installed.

C: A clean installation can remove unwanted modifications, but reinstalling the same affected package reproduces the known software defect rather than fixing it.

D: Applying the vendor's fix changes the vulnerable code, and verification checks that the intended component was actually updated and remains functional.

## SEC-Q098

A powered-off laptop is stolen. Its storage uses properly configured full-disk encryption, and the thief does not possess the recovery material or a means to unlock it. Which risk is this control primarily intended to reduce?

- A. Physical loss of the laptop itself
- B. Unauthorized disclosure from reading the stored data
- C. Accidental deletion by an authorized application
- D. Every malware action during an unlocked user session

Answer: B

Full-disk encryption mainly protects confidentiality when storage is unavailable in decrypted form to the attacker. The powered-off state and absence of unlock material define that protection here. It does not replace controls for physical theft, malware in an active session, or accidental deletion.

Study tip: Identify the data state and key access before deciding what encryption protects.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Encryption changes how readable the stored data is, but it cannot prevent the physical device from being stolen or recover the hardware.

B: Full-disk encryption protects the confidentiality of data at rest when an unauthorized person cannot obtain the key or unlock the protected storage.

C: Applications with access to an unlocked volume can still delete files; backup and permission controls address that risk more directly.

D: An unlocked system can access decrypted data, so full-disk encryption alone does not stop malicious activity that runs with effective access.

## SEC-Q099

Administrators repeatedly find that an unauthorized troubleshooting change has re-enabled an insecure service on branch workstations. A reviewed baseline requires the service disabled. Which control BEST provides consistent correction of this drift across the fleet?

- A. Document manual correction steps without deploying a fleet enforcement mechanism
- B. Run weekly assessments that report deviations without changing device settings
- C. Take daily workstation snapshots without comparing their settings to the baseline
- D. Centrally enforce the reviewed baseline and automatically remediate unapproved deviations

Answer: D

Configuration enforcement keeps deployed systems aligned with an approved state and identifies departures from it. Central management is particularly useful when the same drift appears across many branches. Legitimate exceptions should be reviewed explicitly instead of allowing recurring unauthorized local changes to silently become the baseline.

Study tip: Detection finds configuration drift; enforcement restores or prevents deviations from the approved state.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Instructions can help technicians respond, but documentation alone does not consistently detect and correct recurring deviations across the managed workstation fleet.

B: Reporting detects configuration drift, but the settings remain incorrect until another process acts, so assessment alone does not provide the requested consistent correction.

C: Snapshots support recovery but may preserve the unauthorized configuration; they do not determine or enforce whether the insecure service should be disabled.

D: Central policy enforcement compares actual settings with the approved configuration and restores the required service state consistently across managed devices.

## SEC-Q100

A server review finds unchanged factory credentials, active services with no business use, and installed remote-support software that the organization does not need. Which THREE actions MOST directly harden the server against these findings? (Select THREE.)

- A. Disable unnecessary services and their listening ports
- B. Rename the default administrator account but retain its factory password
- C. Move unused services to unusual ports and leave them running
- D. Replace factory credentials with unique managed credentials
- E. Keep the remote-support software installed and extend its log retention
- F. Remove the unneeded remote-support software

Answer: A|D|F

Hardening reduces unnecessary functionality and corrects insecure defaults. Each selected action maps directly to a stated finding: known credentials, unused services, and unneeded support software. Renaming, moving ports, or collecting more logs can leave the underlying exposure intact and do not fulfill these removal requirements.

Study tip: Map each hardening action to a specific unnecessary capability or insecure default.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Disabling services without a business requirement reduces reachable functionality and removes avoidable entry points into the server's operating environment.

B: A name change does not adequately address the known default secret and leaves the required credential replacement unfinished despite a cosmetic alteration.

C: Changing port numbers can obscure casual discovery but retains the unnecessary services and their vulnerabilities instead of removing the identified exposure.

D: Replacing documented default credentials removes an easily obtainable authentication value and creates an accountable credential appropriate to the managed server.

E: Longer retention improves historical visibility but does not remove the unneeded remote-access functionality identified as an avoidable part of the attack surface.

F: Uninstalling software that provides no required function removes its code, management features, and potential vulnerabilities from the server's active attack surface.

## SEC-Q101

A replacement system has been validated, required records have been migrated and verified, and an unsupported appliance is approved for retirement. Which action BEST completes the security mitigation associated with decommissioning it?

- A. Power it off and delete its inventory entry while leaving device credentials valid
- B. Leave it connected with its old administrator account as an undocumented spare
- C. Remove its access paths and credentials, sanitize storage appropriately, and update the inventory
- D. Perform a factory reset without verifying data removal or revoking linked credentials

Answer: C

Decommissioning removes an asset from operational use and closes the associated access and data risks. The scenario confirms that the replacement and migration are ready, so retirement can proceed. Sanitization must suit the media and intended disposition, and the inventory should preserve an accurate record of retirement.

Study tip: Retiring a device includes its data and trust relationships, not only unplugging or deleting its inventory entry.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/88/r2/final

A: Powering off removes immediate connectivity, but valid credentials and an erased asset record leave incomplete trust revocation and poor accountability for retirement.

B: An undocumented connected spare preserves the unsupported attack surface and active credentials instead of completing the approved retirement of the appliance.

C: Decommissioning should end the asset's connectivity and trust relationships, protect remaining data, and record its retired status so it is no longer unmanaged exposure.

D: A factory reset may be part of a process, but unverified sanitization and still-valid external credentials do not complete the required data and access controls.

## SEC-Q102

A server must accept traffic to a required application. Security wants a host control that can detect and block exploit behavior within the running application, even when the connection uses the allowed port. Which control BEST meets this requirement?

- A. Host-based intrusion prevention configured for the application
- B. Full-disk encryption for the server's stored files
- C. A port-only firewall rule that allows the required application port
- D. A passive log archive with no response capability

Answer: A

Host-based intrusion prevention adds enforcement close to the running application. A connection's allowed destination port does not establish that its content or resulting process behavior is safe. Effective prevention depends on the control's capabilities and configuration, and it complements rather than replaces patching and appropriate network policy.

Study tip: Choose a control that observes and blocks the behavior at the layer where the attack occurs.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A suitable host-based prevention control can inspect local behavior and block recognized exploit activity beyond the network port's basic allow decision.

B: Encryption at rest protects stored data in relevant situations but does not inspect or block an exploit against a currently running application.

C: A basic port allow rule permits the application's traffic but cannot by itself distinguish an exploit within that permitted application's runtime behavior.

D: Archiving records can preserve evidence of events, but a passive archive does not provide the requested capability to block exploit behavior.

## SEC-Q103

A retailer rents virtual machines from an infrastructure as a service provider. Its contract assigns physical facilities and the hypervisor to the provider, while the retailer manages each guest operating system and application. Which security task is the retailer responsible for?

- A. Install security updates in the guest operating systems
- B. Replace failed drives in the provider's storage arrays
- C. Patch the hypervisor running the virtual machines
- D. Manage access badges for the provider's data center

Answer: A

Shared responsibility follows the service model and the actual agreement. Here, the provider secures the physical infrastructure and hypervisor, while the retailer secures the guest operating systems, applications, and their configurations. Moving a workload to IaaS does not transfer customer-controlled operating system maintenance to the provider.

Study tip: Separate the host infrastructure from the guest operating system before assigning cloud responsibilities.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://aws.amazon.com/compliance/shared-responsibility-model/

A: The agreement places guest operating systems under customer management. Patching those systems remains the retailer's responsibility even though the provider maintains the underlying infrastructure.

B: Replacing physical storage hardware belongs to the infrastructure provider under this agreement. The customer manages virtual resources rather than servicing the provider's equipment.

C: The contract explicitly assigns hypervisor management to the provider. This boundary differs from the guest operating systems that the retailer controls.

D: Physical facility access is a provider responsibility in this scenario. Customer tenant permissions do not grant responsibility for securing the provider's buildings.

## SEC-Q104

A company subscribes to a hosted payroll application. The software as a service contract makes the provider responsible for the application code, operating systems, and infrastructure. Which action remains the company's responsibility?

- A. Deploy patches to the application's operating system
- B. Replace the application's web framework libraries
- C. Review which employees can export payroll records
- D. Apply firmware updates to the provider's network switches

Answer: C

The SaaS provider manages the product and hosting stack, but the customer still controls its users, data, and available tenant settings. Reviewing payroll export privileges addresses a business authorization decision that the provider cannot make on the customer's behalf. Always use the contract's explicit allocation when assessing responsibilities.

Study tip: Managed software still requires customer decisions about identities, permissions, and sensitive data.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://aws.amazon.com/compliance/shared-responsibility-model/

A: The provider operates and patches the application operating systems under the stated SaaS contract. The customer does not manage those system images.

B: Maintaining application code and its dependencies is assigned to the SaaS provider. The company instead controls its use and configuration of the service.

C: The customer decides who should access its data and configures tenant permissions. Provider maintenance does not determine the company's legitimate business access requirements.

D: Provider network hardware lies within the infrastructure responsibilities transferred by this agreement. Tenant administrators generally cannot maintain that equipment.

## SEC-Q105

A serverless function creates thumbnails from newly uploaded images. The provider maintains the underlying operating system and runtime. The function's execution role can delete every object in every company storage bucket. Which change BEST limits the impact if the function is compromised?

- A. Reduce the function's maximum concurrent invocations to one
- B. Increase the function's timeout so operations complete without retries
- C. Place the function in a private subnet without changing its execution role
- D. Restrict the execution role to required actions on the input and thumbnail locations

Answer: D

Serverless architecture transfers infrastructure maintenance but does not eliminate application authorization responsibilities. The function should receive only the actions and resource paths required for its job. Network placement, concurrency limits, and timeouts may serve other purposes, but they do not correct the overprivileged execution role described here.

Study tip: Serverless removes server management tasks, not the need to scope application identities.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://aws.amazon.com/compliance/shared-responsibility-model/|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Concurrency limits can constrain resource use and cost, but a single invocation retaining excessive permissions could still delete unrelated company objects.

B: A longer timeout changes execution behavior rather than permissions. It could leave a compromised invocation running longer while preserving the same destructive access.

C: A private subnet changes network exposure, but permitted storage access can remain available. It does not remove excessive authorization from the execution identity.

D: A narrowly scoped execution role limits the resources and operations available to compromised function code. Thumbnail processing does not require company-wide deletion privileges.

## SEC-Q106

Administrators manually create cloud networks, and several new deployments accidentally expose management ports to the internet. The company wants repeatable deployments with security checks before resources are created. Which approach BEST meets this goal?

- A. Maintain screenshots of each network after administrators finish configuring it
- B. Schedule annual vulnerability scans of the deployed networks
- C. Use version-controlled infrastructure templates with automated policy checks before deployment
- D. Give all administrators the same unrestricted cloud account for consistency

Answer: C

Version-controlled infrastructure as code enables peer review, reproducible provisioning, and automated rules that reject unsafe configurations. Templates still require secure defaults and controlled deployment permissions. Detecting later drift is useful, but the immediate requirement is to prevent an insecure network definition from reaching the provisioning step.

Study tip: Choose a deployment control when the requirement is to reject errors before provisioning.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/218/final

A: Screenshots document a point in time but do not enforce settings or prevent errors. Manual deployment can still create exposed management services.

B: Periodic scans may discover exposure after deployment, but annual checks do not provide the requested preventive validation or repeatable provisioning.

C: Infrastructure as code makes intended configuration reviewable and repeatable. Automated checks can reject public management access before the templates create resources.

D: A shared unrestricted account weakens accountability and least privilege. Consistent credentials do not make infrastructure configuration repeatable or ensure secure network policies.

## SEC-Q107

A public order API calls an inventory service, which calls a pricing service. All three currently share one database administrator credential. The architect wants a compromise of the public API to provide only the access needed for order processing. Which design BEST meets that requirement?

- A. Encrypt every connection while keeping the shared administrator credential
- B. Assign each service its own identity and authorize only the required service calls and data operations
- C. Move all three services into one private subnet while retaining the shared credential
- D. Place a load balancer before the API and retain unrestricted database access

Answer: B

Microservices create multiple trust boundaries, so each service needs an identity and authorization appropriate to its function. A shared administrator credential collapses those boundaries. Service-specific credentials and narrowly allowed operations reduce the scope of compromise; encryption and private networking complement these controls but cannot substitute for them.

Study tip: A service boundary provides little containment when every service shares unrestricted credentials.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Transport encryption protects communication from interception, but an authenticated attacker holding the shared credential would retain excessive authorization across services.

B: Distinct identities support service-specific authorization. Restricting calls and database operations prevents compromise of one service from automatically inheriting every service's administrative privileges.

C: A private subnet reduces direct exposure but does not limit what compromised API code can do with the shared database administrator credential.

D: A load balancer distributes requests and can improve availability. It does not reduce the database privileges available to a compromised API service.

## SEC-Q108

An architect compares ordinary Linux containers with full virtual machines. Which statement describes a security-relevant difference?

- A. Containers eliminate dependency vulnerabilities, while virtual machines require dependency updates
- B. Containers require a separate physical server for each application, while virtual machines share hardware
- C. Containers automatically encrypt application memory, while virtual machines cannot protect memory
- D. Containers typically share the host kernel, while virtual machines ordinarily run separate guest kernels

Answer: D

The key difference is the isolation layer. Conventional containers separate processes using host operating system mechanisms while sharing the kernel; full virtual machines run their own guest operating systems under a hypervisor. Neither model is immune to escape vulnerabilities, and container images still need updates and hardening.

Study tip: A shared kernel creates a different trust boundary from a separate guest operating system.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/190/final

A: Container images can contain vulnerable libraries and applications. Both containers and virtual machines require lifecycle maintenance and appropriate vulnerability management.

B: Containers commonly share the same host and physical hardware. Requiring a dedicated physical server is not a defining property of containerization.

C: Ordinary containerization does not automatically encrypt application memory. Memory protection capabilities depend on the platform and configuration rather than this simple deployment distinction.

D: Conventional containers use operating system isolation around a shared kernel. Virtual machines provide guest operating systems separated by a hypervisor, creating different isolation boundaries.

## SEC-Q109

A research laboratory disconnects its analysis network from all wired and wireless external networks. Staff must still import approved instrument updates using removable drives. Which statement BEST describes the resulting architecture?

- A. It is air-gapped, so software from removable drives cannot compromise its hosts
- B. It is logically segmented, so ordinary internet routing remains available through a firewall
- C. It is air-gapped, but removable media remains a path for introducing malicious content
- D. It is a public cloud network because external updates are imported periodically

Answer: C

An air gap removes direct network connectivity to other environments. It does not make imported data, software, or removable devices trustworthy. The laboratory must account for controlled transfer procedures, media inspection, and endpoint protections because those transfer mechanisms remain part of the attack surface.

Study tip: Physical network isolation does not remove threats carried across the boundary on storage devices.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: An air gap restricts network paths, not local execution of malicious files. Removable media can introduce harmful software or exploit vulnerable applications.

B: Logical segmentation separates traffic on connected infrastructure. The scenario instead removes all external network connections, so ordinary internet routing is unavailable.

C: Removing network connectivity creates physical isolation from external networks. Approved media transfers still cross the trust boundary and require appropriate inspection and handling.

D: Importing updates does not define a cloud architecture. The laboratory's disconnected local network remains physically isolated regardless of its software distribution method.

## SEC-Q110

A software-defined network uses a central controller to push forwarding policies to many switches. Which component is MOST critical to protect against unauthorized changes that could reroute traffic across the entire network?

- A. The read-only dashboard used to display historical link utilization
- B. The controller's management interface and privileged identities
- C. The certificate trust store used only by employee web browsers
- D. The packet buffers on one branch switch's data-plane interfaces

Answer: B

In SDN, the control plane programs network behavior while the data plane forwards traffic. Centralizing control simplifies management but creates a high-impact administrative target. Strong management isolation, authentication, authorization, and monitoring are therefore essential around the controller and the identities permitted to modify network policy.

Study tip: Identify the component that can change many enforcement points at once.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Historical telemetry may be sensitive, but read-only utilization access does not normally authorize the forwarding changes described in the scenario.

B: The controller directs forwarding behavior across the managed fabric. Unauthorized control-plane access could change policies for many switches and compromise multiple network segments.

C: Browser trust settings affect validation of website identities. They are not the management authority that controls forwarding policy across the software-defined network.

D: Local packet buffers affect forwarding on that device, but they do not hold the centralized authority that programs policies across the entire SDN fabric.

## SEC-Q111

A manufacturing controller uses an unsupported operating system. Replacing it requires a planned production shutdown, and untested active scans have previously interrupted operations. Which TWO measures BEST reduce security risk during the approved replacement period? (Select TWO.)

- A. Run aggressive vulnerability scans against the controller every hour
- B. Rely on port translation while leaving broad access from the business network
- C. Monitor a copy of its traffic with a passive sensor
- D. Isolate the controller in a restricted zone that permits only documented operational communications
- E. Install unrelated desktop security software without compatibility testing

Answer: C|D

An unsupported industrial controller may need compensating controls until replacement is feasible. Restricted connectivity limits exposure, and passive traffic monitoring supplies visibility without the disruptive probing already observed. Neither measure patches the underlying weakness, so the replacement plan and operationally validated access requirements remain necessary.

Study tip: For fragile industrial systems, weigh operational availability when choosing how to inspect and contain exposure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: The scenario states that active scanning has interrupted operations. Repeating intrusive probes increases availability risk without resolving the controller's inability to receive supported updates.

B: Port translation does not provide the required isolation from internal threats. Broad business-network access leaves the unsupported controller reachable through unnecessary paths.

C: Passive monitoring can reveal suspicious communications without sending scan probes to the fragile controller. Sensor placement and alerting should reflect the industrial environment.

D: Segmentation reduces reachable attack paths while preserving required control traffic. Rules should be validated with operational owners to avoid disrupting essential industrial functions.

E: Untested software may interfere with controller timing or stability. Operational constraints require validated compensating controls and a planned replacement rather than arbitrary software changes.

## SEC-Q112

An embedded controller must issue a protective command within 5 milliseconds under every supported workload. A proposed security agent occasionally pauses processing for 12 milliseconds during inspection. What is the MOST important architecture concern to resolve before deployment?

- A. Whether the controller can retain twice as many historical log files
- B. Whether the agent can meet the real-time deadline under worst-case load
- C. Whether the agent can inspect encrypted application payloads without additional configuration
- D. Whether average daily processor utilization remains below 50 percent

Answer: B

Real-time operating environments require predictable timing. A control that performs well on average can still be unsuitable if its worst-case delay exceeds a critical deadline. The organization must validate compatible security mechanisms and deployment options with engineering and operational owners before accepting the proposed agent.

Study tip: Real-time suitability depends on worst-case timing, not average resource utilization.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: Additional log retention may improve investigation, but it does not establish that the proposed inspection avoids unacceptable real-time processing delays.

B: A real-time system must satisfy its timing requirements, not just average performance targets. A 12-millisecond pause can violate the stated protective command deadline.

C: Inspection visibility is relevant to security coverage, but it does not resolve the demonstrated timing violation. The real-time deadline must still be satisfied.

D: Low average utilization does not prove deadline compliance. A brief worst-case processing pause can still violate a strict five-millisecond response requirement.

## SEC-Q113

A company keeps its design database on premises and moves its customer portal to the cloud. Staff use separate local and cloud identities, and terminated employees have sometimes retained cloud access. Which architecture improvement MOST directly addresses this gap?

- A. Replicate the design database into a second cloud region
- B. Use a coordinated identity lifecycle that revokes access across both environments
- C. Replace the portal's public certificate with one using a longer validity period
- D. Add more bandwidth between the data center and cloud provider

Answer: B

Hybrid architecture introduces boundaries between systems that may have different administration and identity processes. The observed failure is incomplete offboarding, so the design should coordinate account lifecycle events and verify revocation across both environments. Connectivity upgrades and extra replicas do not resolve this access control inconsistency.

Study tip: Choose the control that addresses the observed boundary failure, not a general cloud improvement.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Replication supports availability and recovery. It does not correct inconsistent identity lifecycle management between on-premises and cloud systems.

B: Coordinated provisioning and deprovisioning applies employment changes to local and cloud identities. It directly addresses accounts that remain active after termination.

C: Certificate validity affects server identity operations, not user offboarding. A longer-lived certificate would not deactivate stale accounts or remove their permissions.

D: Additional bandwidth may improve responsiveness, but it does not propagate employment changes or revoke access held by former staff.

## SEC-Q114

A fleet of remote sites loses WAN connectivity several times each month. Each site must continue evaluating local sensor readings and raising local alarms during an outage. Which architecture BEST supports that requirement?

- A. Send every sensor reading to a central cloud function before generating an alarm
- B. Disable local processing and retain a larger queue of unread sensor messages
- C. Reduce sensor collection frequency until the cloud service becomes reachable
- D. Process the time-sensitive sensor rules locally and synchronize records when connectivity returns

Answer: D

Decentralized or edge processing supports local responsiveness and continuity when a central service is unreachable. The design can still synchronize results after connectivity returns. Its tradeoffs include maintaining distributed devices and policies, but those costs are justified by the explicit requirement for local decisions during WAN outages.

Study tip: When the network can fail, keep time-critical decisions near the device that must act.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: A central-only decision path depends on WAN connectivity. During the described outages, readings cannot reach the service in time to generate required local alarms.

B: Queueing can preserve messages for later analysis, but it does not evaluate readings or produce local alarms while connectivity is unavailable.

C: Lower collection frequency does not remove the WAN dependency. It may also reduce visibility during precisely the outages when local decision-making is required.

D: Local processing removes WAN availability from the immediate decision path. Later synchronization preserves centralized records while each site continues its required alarm function.

## SEC-Q115

A public website uses a web tier, an application tier, and a database tier. Internet clients need HTTPS to the web tier; the web tier needs one application port; only the application tier needs database access. Which design BEST limits access if a web server is compromised?

- A. Publish the database port through the perimeter firewall for easier health checks
- B. Isolate only the application tier while allowing unrestricted traffic between the web and database tiers
- C. Place all tiers on one flat network and encrypt the public HTTPS connection
- D. Place the tiers in separate security zones and allow only the documented flows between them

Answer: D

Security zones make the required trust boundaries enforceable. Internet traffic should reach only the web service, web servers should reach only necessary application services, and database access should be limited to the application tier. This reduces the reachable attack surface after a web-tier compromise without claiming to prevent every application-level attack.

Study tip: Translate each required business flow into the smallest permitted connection between zones.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Publishing the database adds unnecessary exposure and bypasses the application tier. Monitoring convenience does not justify giving internet clients a direct database path.

B: Separating the application tier alone leaves a direct web-to-database path. That fails to enforce the stated requirement that only the application tier needs database access.

C: HTTPS protects client traffic, but a flat internal network leaves the compromised web server with broader reachability to application and database services.

D: Separate zones with explicit allowed flows restrict lateral movement. A compromised web server would not automatically obtain a direct network path to the database.

## SEC-Q116

A firewall first permits traffic belonging to an established allowed connection. It then evaluates NEW connections using the first matching rule:
1. ALLOW 192.0.2.10 -> 198.51.100.20, TCP destination port 5432
2. DENY 198.51.100.20 -> 192.0.2.10, ANY
3. DENY ANY -> ANY, ANY
Assume symmetric routing and no other controls. What happens when 192.0.2.10 opens a TCP session to 198.51.100.20:5432?

- A. The initial packet is allowed, but every reply is denied by the second rule
- B. The session and its return traffic are allowed, but an unrelated new connection in the reverse direction is denied
- C. The session allows the database host to initiate any future connection to the application host
- D. The session is denied because the final deny overrides all earlier matching rules

Answer: B

The connection begins with a new packet that matches the permitted application-to-database flow. The firewall then recognizes return packets as part of that established session. The reverse-direction deny still blocks unrelated new sessions. This answer depends on the explicit state-first evaluation and symmetric routing supplied in the question.

Study tip: Distinguish response traffic inside an allowed session from a separately initiated connection.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: The question explicitly evaluates established connection state before new-connection rules. Replies belonging to the permitted session do not undergo that reverse-direction deny evaluation.

B: The initial connection matches the explicit allow, and the stated connection-state check permits its replies. An independent reverse connection instead matches the deny rule.

C: State tracking permits traffic belonging to the established session. It does not create unrestricted authorization for unrelated new connections initiated by the database host.

D: The new-connection rules use first-match processing. The first rule allows this session, so the final deny does not override the earlier match.

## SEC-Q117

An analyst connects a sensor to a switch mirror port. It receives copies of traffic and raises alerts, but it is not in the forwarding path and does not send reset packets or enforcement commands. Which role BEST describes this deployment?

- A. An inline intrusion prevention system
- B. A stateful filtering firewall
- C. An active vulnerability scanner
- D. A passive intrusion detection system

Answer: D

Placement and behavior both matter. This sensor sees a copy of traffic and can report suspicious activity, but the original packets continue along the normal path. Calling it an IDS describes that detection role; it would need a separate, explicitly configured enforcement mechanism to stop traffic.

Study tip: A mirror-port sensor observes the traffic copy; the original flow does not pass through it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: An inline IPS processes traffic in the forwarding path and can enforce blocking decisions. This sensor receives copies and has no stated prevention mechanism.

B: A stateful firewall enforces connection policy for traffic passing through it. Receiving mirrored copies without enforcement does not provide that filtering role.

C: An active scanner sends probes to assess target behavior or weaknesses. The sensor described only observes existing traffic and does not initiate testing.

D: A passive IDS observes copied traffic and generates alerts. The stated deployment has no inline position or active mechanism for blocking the original traffic.

## SEC-Q118

A company requires every remote administrative connection to a sensitive database to pass inspection. Management explicitly accepts temporary loss of remote administration if the inline inspection device fails. Which failure mode satisfies this requirement?

- A. Passive monitoring, allowing all traffic while recording a copy when possible
- B. Fail-closed, preventing traffic from bypassing the failed inspection control
- C. Automatic bypass routing, directing sessions around the failed inspection device
- D. Fail-open, allowing traffic to continue without inspection during the failure

Answer: B

Fail-closed is appropriate because the requirement explicitly favors maintaining the inspection boundary over remote administrative availability. Fail-open would preserve connectivity while allowing uninspected traffic. The choice is a business and architecture tradeoff; redundancy may reduce outages, but it does not change which failure mode meets this requirement.

Study tip: Use the stated availability-versus-enforcement priority to choose the failure mode.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Passive monitoring does not enforce passage through inspection or block failed inspection paths. It cannot satisfy the specified requirement on its own.

B: Fail-closed blocks the protected flow when the control cannot operate. That preserves the inspection requirement at the accepted cost of temporary remote administrative unavailability.

C: A bypass route preserves connectivity by avoiding the failed control. It would permit uninspected administration, contrary to the explicitly accepted availability tradeoff.

D: Fail-open favors connectivity, but it permits uninspected access when the device fails. That conflicts with the explicit requirement for this administrative path.

## SEC-Q119

A company wants wired switch ports to admit managed laptops to the production network only after successful device-certificate authentication. The company already operates a trusted certificate infrastructure and an authentication server. Which solution BEST meets this requirement?

- A. A shared password entered into a captive portal after network access is granted
- B. Static production VLAN assignment based only on the physical switch port
- C. 802.1X using EAP-TLS with certificate validation and the authentication server.
- D. A MAC address allowlist maintained on each switch port

Answer: C

802.1X provides port-based network access control, with EAP carrying the chosen authentication method. EAP-TLS uses certificates and fits the company's existing infrastructure. The design still requires correct certificate trust and authentication-server configuration; a copied MAC address or possession of a shared password is not equivalent.

Study tip: Match the network admission mechanism with the requested authentication method.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A shared portal password does not authenticate the laptop's device certificate before production network admission. It also weakens accountability across participating users or devices.

B: Static assignment treats the connection location as sufficient for admission. It does not validate the identity or certificate of whichever device occupies the port.

C: 802.1X controls network admission at the access port, and EAP-TLS supports certificate-based authentication. Correct trust configuration enables the required managed-device admission decision.

D: MAC allowlisting recognizes addresses rather than proving possession of a trusted device certificate. An address can be copied, so it does not meet this authentication requirement.

## SEC-Q120

Administrators must manage servers in a restricted network. Policy prohibits direct administrative connections from user workstations and requires a controlled point for recording sessions. Which design BEST supports these requirements?

- A. Permit management traffic only through a hardened jump server with individual authentication and session recording
- B. Use a client VPN that permits direct workstation management and records only tunnel connection times
- C. Expose each server's remote desktop service through a different public port
- D. Give administrators the same local account on every server and allow unrestricted access

Answer: A

A hardened jump server concentrates administrative access at a controlled boundary where authentication, authorization, and recording can be applied. Network rules must enforce use of that path; merely deploying a jump server while leaving direct management ports reachable would not meet the requirement.

Study tip: A jump server becomes an enforced control only when direct management paths are restricted.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A jump server provides a controlled administrative entry point. Restricting destination management access to that server makes individual authentication and session recording enforceable.

B: The VPN authenticates entry and protects transport, but direct workstation management violates policy. Tunnel connection timestamps also do not provide the required administrative session recording.

C: Changing public port numbers does not establish a controlled administrative gateway. It expands direct exposure and does not ensure centralized session recording.

D: Shared local accounts weaken accountability, and unrestricted direct access bypasses the required controlled point. They do not provide reliable individual session attribution.

## SEC-Q121

A company wants employee web requests to pass through one service that applies destination policies and records outbound browsing activity. Which component MOST directly provides this function?

- A. A reverse proxy placed before the company's public website
- B. A forward proxy used by the employee clients
- C. A passive network tap connected only to an archive recorder
- D. A DNS resolver configured to log employee hostname lookups

Answer: B

A forward proxy acts on behalf of clients reaching external services, so it fits centralized outbound web policy and logging. A reverse proxy acts on behalf of hosted servers. The architecture must also address direct outbound paths; an optional proxy that users can bypass cannot enforce a universal browsing policy.

Study tip: Forward proxies serve outbound clients; reverse proxies front incoming requests to hosted services.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A reverse proxy primarily represents servers to incoming clients. Protecting the company's website does not automatically intermediate employee browsing to unrelated external destinations.

B: A forward proxy intermediates client requests to external destinations. It can centralize outbound access policy and logging when client and network configuration enforce its use.

C: A passive tap supplies visibility into copied traffic but does not intermediate requests or enforce destination decisions on outbound browsing sessions.

D: DNS logs reveal queried names, but a resolver does not intermediate the subsequent web requests. Name resolution alone cannot provide the requested request-level policy point.

## SEC-Q122

A security team needs a control that examines HTTP request paths, headers, and bodies for web attacks before requests reach a public application. Which control is MOST directly suited to this role?

- A. A firewall limited to source addresses and TCP destination ports
- B. A VPN concentrator limited to authenticating remote users and terminating tunnels
- C. A web application firewall
- D. A switch enforcing maximum learned MAC addresses per access port

Answer: C

The required inspection occurs at the HTTP application layer, which is the WAF's focus. Lower-layer filtering is useful for limiting reachability but does not satisfy content inspection by itself. A WAF can reduce exposure to suspicious requests while secure application code and vulnerability remediation remain necessary.

Study tip: Look for HTTP content inspection when choosing between a WAF and a basic port filter.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A basic network and transport-layer filter can restrict hosts and ports, but its stated capabilities do not inspect HTTP paths, headers, or request bodies.

B: The stated VPN function provides authenticated encrypted remote connectivity. It does not, by itself, inspect decrypted web requests using application attack rules.

C: A WAF evaluates application-layer HTTP content and can apply rules for suspicious web requests. It is designed to protect the web application's request boundary.

D: Switch port security limits address use on local network connections. It does not inspect web request content for application-specific attacks.

## SEC-Q123

Employees may use an approved collaboration application over TCP 443, but an unapproved file-sharing application using the same port must be blocked. The organization has an approved traffic-inspection design that provides the required visibility. Which control BEST fits this requirement?

- A. An application-aware next-generation firewall policy
- B. A NAT rule that translates all client addresses to one public address
- C. A source-port rule that permits all client ephemeral ports
- D. A destination-port rule that denies every connection using TCP 443

Answer: A

The key requirement is to distinguish applications that use the same transport port. An application-aware control can do this when its identification capabilities and traffic visibility support those applications. Blocking TCP 443 would disrupt legitimate use, while NAT or source-port rules do not classify the application.

Study tip: Ports identify transport endpoints; several different applications can share the same port.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Application-aware inspection can distinguish supported application traffic beyond its transport port. With the required visibility provided, policy can permit one application and deny the other.

B: Address translation changes network addressing but does not determine which application a flow represents. It cannot enforce the requested application-specific policy by itself.

C: Client source ports do not identify the approved application reliably. Permitting ephemeral ports would leave both applications available under the stated conditions.

D: Blocking the shared port would also block the approved collaboration application. Port-only rules cannot make the requested distinction between applications on the same port.

## SEC-Q124

Two branch offices must exchange database traffic over the public internet. The design must authenticate the gateways, protect traffic confidentiality in transit, and allow only the required database flow between the branches. Which TWO controls together meet these requirements? (Select TWO.)

- A. Static routes over the internet without an encrypted tunnel
- B. DNSSEC signatures for the branches' public domain records
- C. A correctly configured IPsec site-to-site tunnel with authenticated gateways and encryption
- D. Address translation that hides both branches behind public addresses
- E. Firewall policies that permit the required database endpoints and port while denying other interbranch flows

Answer: C|E

The tunnel supplies authenticated, confidential transport across the public network. Firewall rules supply the separate authorization decision about which traffic is permitted between sites. These functions complement each other: encrypting a broad connection does not make unrestricted internal reachability appropriate.

Study tip: Secure transport and permitted traffic scope are separate architecture decisions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Static routing can direct packets but does not provide confidentiality or authenticate the remote gateway. It cannot satisfy the untrusted-network protection requirement.

B: DNSSEC validates supported DNS data, not the confidentiality of database traffic. It also does not enforce the required interbranch database-only access policy.

C: An authenticated, encrypted IPsec tunnel protects branch traffic crossing the untrusted internet. Gateway authentication helps establish that the tunnel connects the intended peers.

D: NAT changes address presentation and may support connectivity, but it does not encrypt the data or authenticate the other gateway.

E: Explicit flow restrictions apply least privilege to traffic using the connection. Tunnel encryption alone does not decide which internal systems should communicate.

## SEC-Q125

A browser establishes TLS to a load balancer, which forwards requests to the application using HTTP over a shared internal network. Policy requires confidentiality on every network hop carrying customer data. Which change MOST directly closes the remaining gap?

- A. Enable HTTP Strict Transport Security on the public website while keeping backend HTTP
- B. Encrypt the application's storage volume while leaving the backend hop as HTTP
- C. Add more backend servers while retaining HTTP on all internal connections
- D. Use TLS from the load balancer to the application and validate the application's certificate

Answer: D

TLS terminates at the load balancer, so its protection does not automatically continue to the backend. The application connection requires its own correctly validated TLS session, or an equivalent approved encrypted transport. Internal network placement alone does not satisfy the explicit requirement for confidentiality on every hop.

Study tip: Follow the complete data path; encryption ends wherever the TLS connection terminates.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: HSTS directs supporting browsers to use HTTPS for the public website. It does not encrypt the separate load-balancer-to-application connection.

B: Volume encryption protects stored data, not data crossing the internal network. It does not satisfy the explicit requirement for every network hop.

C: Additional servers may improve capacity, but each plaintext backend connection retains the same confidentiality gap. Scaling does not provide transport encryption.

D: The backend hop currently carries plaintext. Re-encrypting that connection and validating the backend identity protects data in transit across the shared internal network.

## SEC-Q126

An organization wants distributed staff and branches to use an integrated architecture combining wide-area connectivity with cloud-delivered access and security services. Which term BEST describes this approach?

- A. Secure access service edge (SASE)
- B. A remote-access VPN concentrator operating by itself
- C. A cloud access security broker operating by itself
- D. A standalone software-defined WAN deployment

Answer: A

SASE integrates wide-area networking and cloud-delivered security for distributed access. Implementations vary. A VPN concentrator supplies a tunnel endpoint; a CASB governs cloud-service access; standalone SD-WAN addresses WAN connectivity. None alone provides the integrated SASE architecture.

Study tip: Look for the combination of distributed networking and cloud-delivered security services.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: SASE combines networking and cloud-delivered security capabilities for distributed users and sites. It aligns with the requested integrated connectivity and access architecture.

B: A VPN concentrator terminates remote-access tunnels. That capability alone does not describe the broader integration of wide-area connectivity and cloud-delivered security services.

C: A CASB focuses on visibility and policy for cloud service use. It does not by itself supply the full wide-area connectivity architecture described.

D: SD-WAN supplies centrally managed WAN connectivity and path selection. A standalone deployment does not necessarily provide the integrated cloud-delivered security services specified.

## SEC-Q127

A branch has two internet circuits from different carriers. It needs to move application traffic to the healthier path as latency and loss change, while applying consistent centrally managed connectivity policy. Which capability MOST directly addresses this requirement?

- A. Software-defined WAN with policy-based path selection
- B. A static default route pointing permanently to the first carrier
- C. Round-robin DNS records for the company's public website
- D. An SDN controller limited to the data center's internal switching fabric

Answer: A

SD-WAN separates centrally managed policy from the underlying WAN links and can select paths based on conditions and application needs. Multiple circuits provide options, but dynamic path selection requires a mechanism to use them effectively. Encryption and access controls must still be specified; path selection alone is not a security guarantee.

Study tip: Multiple circuits provide redundancy; path-aware policy determines how traffic uses them.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6

A: SD-WAN can use measured link conditions and centrally defined policies to choose application paths. It fits dynamic use of multiple branch WAN connections.

B: A fixed default route does not adapt application paths to changing latency or loss. It leaves the second link unused unless separate mechanisms intervene.

C: DNS distribution can influence which service address clients resolve. It does not measure branch circuit performance and select outbound paths for the branch applications.

D: An internal-fabric controller manages that data center's forwarding policies. Its stated scope does not provide path selection for the branch's separate carrier connections.

## SEC-Q128

A load balancer sends users to three application servers. One server still accepts TCP connections but returns errors for every login because its application process is unhealthy. Which health check BEST detects this failure before sending additional users to that server?

- A. Send an ICMP echo request to verify the server's network interface responds
- B. Request a dedicated application health endpoint that verifies required login-service dependencies
- C. Check that the server's TCP port accepts a connection
- D. Check whether the server's DNS record still resolves

Answer: B

A useful health check measures the function whose availability matters. Here, the network stack and TCP listener remain operational, so lower-layer checks produce misleading healthy results. An application-level endpoint that safely checks the required dependencies gives the load balancer evidence to remove the unhealthy backend.

Study tip: A successful network connection does not prove the application can complete its business function.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: ICMP reachability proves only limited network responsiveness. The host can answer pings while the application and its login dependencies remain unusable.

B: An application-level check can detect failures beyond basic port availability. A carefully designed endpoint should verify the dependencies needed for the user-facing function.

C: The scenario explicitly states that TCP connections succeed. A transport-only check would continue marking the failed application as healthy.

D: Name resolution confirms a naming entry is available. It does not show that the application behind the address can successfully process login requests.

## SEC-Q129

A branch replaces separate firewall, VPN, and web-filter devices with one unified threat management appliance. All branch internet access and remote access now depend on that appliance. Which architecture issue should the team address MOST directly?

- A. The concentration of several critical functions into one failure and resource-capacity point
- B. The need to use identical permissions for local users and remote VPN users
- C. The requirement to remove every host firewall because the appliance performs multiple functions
- D. The inability to apply access control policies when filtering and VPN run on the same device

Answer: A

Combining functions introduces a common dependency: one hardware, software, power, or resource-capacity failure can affect multiple protections and connectivity services. The architecture should assess capacity with inspection enabled and plan appropriate redundancy or recovery. Consolidation can be useful, but it does not remove the need to manage concentrated failure risk.

Study tip: Consolidation simplifies management while increasing the number of services affected by one appliance failure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Consolidation can simplify administration, but failure or resource exhaustion of the shared appliance can disrupt several services together. Resilience and capacity must account for that concentration.

B: Using one appliance does not require identical authorization for different access contexts. Separate rules can still enforce distinct local and remote permissions.

C: Consolidating perimeter controls does not make host firewalls incompatible or unnecessary. Endpoint enforcement can still provide useful protection beyond the appliance's boundary.

D: UTM appliances are designed to combine such functions. Co-location does not inherently prevent access policy enforcement, although configuration and capacity require attention.

## SEC-Q130

A perimeter firewall correctly filters public application traffic, but its administrative interface is reachable from the guest wireless network. Guests have no business reason to administer infrastructure. Which change MOST directly reduces this unnecessary attack surface?

- A. Increase the number of public application ports inspected by the firewall
- B. Restrict management access to an administrative zone and approved management identities
- C. Collect more detailed utilization telemetry from the firewall's public traffic interfaces
- D. Require stronger administrator passwords while leaving the management interface reachable from guests

Answer: B

Data-plane filtering and management-plane exposure are different concerns. A firewall can enforce public traffic policy correctly while its own administrative service remains unnecessarily reachable. Restricting that service to an approved administrative path reduces exposure, and strong identity controls protect the privileges available through that path.

Study tip: Protect the security device's own management interface as well as the traffic it filters.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Improving application traffic inspection does not close guest access to the firewall's own administrative service. The management exposure is a separate path.

B: Management-plane isolation removes an unnecessary path from an untrusted network to a privileged interface. Identity controls then restrict who can administer through the permitted path.

C: Traffic utilization telemetry helps capacity monitoring, but it does not restrict guest reachability to the firewall's privileged administrative service.

D: Stronger passwords can improve authentication, but they leave the unnecessary network path available. Management-plane restrictions more directly reduce the exposed attack surface.

## SEC-Q131

A shipping partner needs only monthly delivery totals by region for capacity planning. The source dataset also contains customer names, street addresses, phone numbers, and account identifiers. Which sharing approach BEST limits unnecessary disclosure while meeting the partner's stated need?

- A. Tokenize account identifiers while including names and addresses in the detailed customer records
- B. Mask phone numbers while retaining customer names, street addresses, and account identifiers
- C. Encrypt the complete customer dataset and provide the partner with its decryption key
- D. Send a regional summary containing only the required totals and no customer-level identifiers

Answer: D

Data protection includes limiting what information a recipient receives. Here, the partner needs regional totals rather than customer records, so a summary meets the business requirement with less exposure. Encryption, masking, and tokenization can be useful, but their configuration must address all unnecessary sensitive fields rather than merely changing one aspect of the full dataset.

Study tip: Match the released data to the recipient's business need before choosing transport protection.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Tokenizing one identifier leaves names, addresses, and detailed records available. The partner's required regional totals do not justify releasing those extra fields.

B: Masking one field leaves other identifying details exposed even though the partner does not need them. Partial concealment does not meet the stated information need.

C: Encryption protects delivery or storage, but the authorized recipient receives the key and can read every customer record. It does not reduce unnecessary disclosure.

D: An aggregated regional summary supplies the business data the partner needs while excluding unnecessary personal records. Reducing the released data limits avoidable disclosure.

## SEC-Q132

A payroll application sends employee records to an authorized remote client over an untrusted network. Which control MOST directly protects the records against reading and modification while they travel between those endpoints?

- A. Digitally sign the transmitted records without encrypting their contents
- B. Full-disk encryption on the application server
- C. Correctly configured TLS with server-certificate validation
- D. Restrict filesystem access to downloaded records on the authorized client's device

Answer: C

The records are in transit between endpoints, making a secure transport such as properly validated TLS the direct control. Storage encryption protects a different state. TLS also does not decide whether the client is authorized to read a particular employee record; the application must separately enforce that business permission.

Study tip: Transport security protects the communication path; application permissions govern which records a client may receive.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: A properly verified signature can support integrity and origin assurance, but it does not conceal plaintext records from observers along the network path.

B: Full-disk encryption protects stored server data. Once the application reads the records and sends them, transport protection is still required.

C: TLS provides encrypted, integrity-protected transport and enables validation of the intended server. It directly addresses interception or modification along the network path.

D: Local permissions can protect stored copies on the receiving endpoint. They do not encrypt or integrity-protect records as they cross the untrusted network.

## SEC-Q133

A cloud application already encrypts its disks and network connections. Its threat model also requires reducing a platform operator's ability to inspect sensitive plaintext while computation occurs. The chosen platform supports attested hardware isolation. Which additional capability is MOST relevant?

- A. A larger encryption key for the existing storage volume only
- B. A suitable hardware-backed trusted execution environment for the sensitive computation
- C. A duplicate encrypted backup stored in a second region
- D. A longer TLS session lifetime for client connections

Answer: B

Data in use is processed in an execution environment, where ordinary storage and transport encryption do not by themselves protect plaintext from every privileged actor. A suitable attested hardware-backed trusted execution environment addresses this part of the threat model. Its precise guarantees and limitations still depend on the implementation and configuration.

Study tip: Encrypting disks and connections does not automatically protect plaintext while an application is processing it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://learn.microsoft.com/en-us/azure/confidential-computing/overview

A: Stronger storage encryption does not directly protect plaintext after the running application decrypts it for computation. The identified gap concerns data in use.

B: A supported trusted execution environment is designed to isolate computation and data in use from specified privileged actors. Its protection depends on the platform's defined threat model.

C: An additional encrypted backup can improve recovery and stored-data protection. It does not address inspection of plaintext during the current application's execution.

D: TLS session lifetime affects transport operation. It does not isolate the application's plaintext working memory from the platform operator described.

## SEC-Q134

A company's approved data-handling policy requires a restricted dataset and every retained copy of it to remain within Country A. A cloud service offers a primary region in Country A and automatic global resilience features. Which detail is MOST important to verify before using the service?

- A. Whether the provider's corporate headquarters is located in Country A
- B. Whether the provider requires multifactor authentication for support staff
- C. The locations used for replicas, backups, snapshots, and logs that contain the restricted data
- D. Whether the primary database uses encryption while allowing unrestricted global replication

Answer: C

Data location requirements must be traced through the complete data lifecycle. A correctly located primary instance is insufficient if replicas, backups, snapshots, or data-bearing logs are retained elsewhere. This question supplies the organization's policy; encryption or a provider's billing arrangements do not override that specific restriction.

Study tip: Trace every copy of the data when a requirement applies to where information is retained.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Corporate headquarters does not establish where the service retains customer data. Providers can operate infrastructure and create copies in multiple other countries.

B: Support authentication is an important access control, but it does not demonstrate that the restricted dataset and every retained copy remain in Country A.

C: The requirement covers every retained copy, not only the primary database. Automated resilience and logging features can create additional copies with separate location settings.

D: Encryption protects confidentiality but does not satisfy the explicit location requirement. Encrypted copies outside Country A would still conflict with the stated policy.

## SEC-Q135

A company's classification policy defines Restricted data as proprietary formulas and Public data as approved marketing material. An analyst combines an unreleased proprietary formula with a public product brochure in one report. What classification should the report receive until the content is separated or formally reclassified?

- A. Public, provided the report is saved in a compressed archive
- B. Public, because part of the report has already been approved for publication
- C. Restricted, because the report contains information requiring that level of protection
- D. Unclassified until the report has been emailed outside the company

Answer: C

Classification follows the sensitivity and handling requirements of the information in the report. The supplied policy clearly identifies the formula as Restricted, so the combined document needs that protection until the content is separated or an authorized reclassification occurs. Public content does not dilute the sensitivity of protected content.

Study tip: Combining public and protected information does not lower the protected information's classification.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Compression changes representation or size rather than sensitivity. It does not reclassify the proprietary formula or authorize its disclosure.

B: Public approval applies to the brochure's content, not the unreleased formula. A mixed report still exposes the protected information it contains.

C: The report contains a proprietary formula explicitly classified as Restricted. Combining it with public material does not remove the formula's handling requirements.

D: Sensitivity exists before external distribution. Waiting for disclosure would delay the handling protections already required by the explicit policy.

## SEC-Q136

A finance system replaces account numbers in analytics records with randomly assigned surrogate values and keeps the original-to-surrogate mapping in a restricted vault. Separately, its support screen displays only the final four digits of each account number. Which TWO techniques are described? (Select TWO.)

- A. Steganography for storing the original account numbers in the vault
- B. Full-disk encryption for the last-four-digit support display
- C. Data masking for the support display
- D. Tokenization for the analytics records
- E. Cryptographic hashing for the recoverable analytics mapping

Answer: C|D

Tokenization replaces a sensitive value with a surrogate while a protected mechanism maintains the authorized relationship to the original. Masking limits what a viewer sees, such as showing only final digits. These techniques serve different purposes, and their protection still depends on access controls around the raw values and any mapping.

Study tip: Surrogate plus protected mapping suggests tokenization; partial concealment of a displayed value suggests masking.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Steganography conceals the existence of information within another medium. Storing original values behind restricted vault access does not describe that technique.

B: Full-disk encryption protects stored blocks, not which digits an authorized application displays. Selective concealment in the interface is a different control.

C: Displaying only selected digits obscures the rest of the sensitive value in that view. This is masking rather than replacing the entire value with a vault-backed token.

D: The surrogate replaces a sensitive value, with a protected mapping used when authorized recovery is needed. That arrangement describes tokenization.

E: A cryptographic hash is computed from the input and is not reversed through an original-value lookup by design. The scenario explicitly uses assigned surrogates and a vault.

## SEC-Q137

An administrator has a trusted SHA-256 digest for an archived configuration file. Before restoring it, the administrator calculates the file's current digest and compares the two. What property does this comparison primarily check?

- A. Availability of the server that will receive the restored file
- B. Integrity of the file relative to the trusted reference
- C. Non-repudiation of every administrator who previously handled the file
- D. Confidentiality of the file from anyone holding a copy

Answer: B

A cryptographic digest is useful for checking whether content matches a trusted reference. Trust in the reference is essential: if an attacker can replace both the file and the expected digest, a simple match provides little assurance against that attacker. The operation checks integrity rather than confidentiality or individual attribution.

Study tip: A hash comparison is only as meaningful as the trusted reference used for comparison.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A digest comparison does not measure the server's operational state or capacity. The target can remain unavailable even when the file is unchanged.

B: Matching a trusted cryptographic digest provides evidence that the file matches the reference content. The comparison is aimed at detecting modification, not hiding the file.

C: An unkeyed digest alone does not identify who created or handled a file. It does not provide individual attribution equivalent to a verified digital signature.

D: Hash comparison does not encrypt or conceal the file. A person with readable access to the file can still view its contents.

## SEC-Q138

A company stores payroll records and public catalog data on separate servers, but both are reachable from every employee and guest network. Only payroll staff and one payroll application need network access to the payroll server. Which change BEST reduces unnecessary exposure of the payroll data service?

- A. Place the payroll service in a restricted segment and permit only approved payroll access paths
- B. Require TLS for payroll connections while leaving the service reachable from every network
- C. Encrypt the payroll server's disks while leaving all current network paths open
- D. Use different DNS suffixes for payroll and catalog servers without changing connectivity

Answer: A

Separating files or servers is not equivalent to enforcing network separation. The payroll service should be reachable only through approved paths, with application permissions still controlling access to particular records. This layered design reduces unnecessary network exposure while preserving the access required by payroll users and services.

Study tip: Physical or logical separation matters only when access rules enforce the intended boundary.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Segmentation limits which networks and systems can reach the sensitive service. Explicitly permitting required payroll paths reduces exposure without blocking authorized business functions.

B: TLS secures the connection in transit but does not reduce which networks can reach the service. Unnecessary exposure remains despite encrypted communication.

C: Disk encryption protects stored data against some access paths, but it does not remove unnecessary network reachability to the running payroll service.

D: Different DNS naming conventions distinguish systems but do not enforce network separation. The same employee and guest networks could still reach the payroll service.

## SEC-Q139

A developer places a production API secret in browser-delivered code, renames the variables, and Base64-encodes the value. The developer claims the secret is now protected from users who receive the code. Which architecture response is BEST?

- A. Deliver the page only over TLS so the embedded secret cannot be intercepted in transit
- B. Apply Base64 encoding to the embedded secret a second time
- C. Rename the variable that holds the embedded secret after every deployment
- D. Move the secret to a controlled server-side component and authorize browser requests to that component

Answer: D

Obfuscation changes how information appears, but it does not create a trustworthy secret boundary when the recipient must receive and use the value. TLS protects transport, not secrecy from the browser's own user. A controlled server-side component should retain the production secret and enforce authorization for the operations it exposes.

Study tip: A secret delivered to an untrusted client should be treated as accessible to that client.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: TLS protects delivery against network observers but does not hide delivered content from the legitimate endpoint receiving it. The browser user can still inspect the secret.

B: Base64 is reversible encoding, not encryption. Applying it repeatedly does not provide a secret key or meaningful confidentiality against the code recipient.

C: Variable renaming is obfuscation that may slow casual inspection. It does not prevent a recipient from recovering or observing a value the browser must use.

D: Code and values delivered to a user's browser are accessible to that user. Server-side secret handling creates a meaningful boundary when requests are also properly authorized.

## SEC-Q140

An application grants access only when a request's public source IP is geolocated to an approved country. The control does not use device location or other signals. Which situation MOST directly illustrates a limitation of this geographic restriction?

- A. A user changes the browser's display language while keeping the same public source address
- B. A user clears browser cookies while keeping the same public source address
- C. A user changes the workstation's time zone while keeping the same public source address
- D. A user in another country connects through a VPN exit server located in the approved country

Answer: D

IP-based geolocation describes the apparent origin of the network request, which can be a proxy or VPN exit. It can contribute a geographic policy signal, but it is not conclusive evidence of the user's physical location.

Study tip: Separate the apparent network origin from the user's physical location and the data's storage location.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The described control uses public source IP geolocation, not interface language. A language change alone does not change the value used for the decision.

B: Cookie state is not the location signal used by this control. Clearing cookies alone does not change the public address evaluated by IP geolocation.

C: The stated decision does not inspect the workstation time zone. Changing it alone would not alter the public address's geolocation result.

D: The application sees the VPN exit's public address, not necessarily the user's physical location. IP geolocation therefore cannot reliably establish that physical location alone.

## SEC-Q141

A customer portal encrypts its database at rest and uses TLS. A logged-in customer can nevertheless retrieve another customer's invoice by requesting its record identifier. Which change MOST directly addresses the demonstrated data exposure?

- A. Require a fresh multifactor login for each customer session while retaining the invoice lookup behavior
- B. Replace sequential invoice identifiers with longer unpredictable values but leave authorization unchanged
- C. Rotate the database's storage encryption key more frequently
- D. Enforce server-side authorization for the requested invoice using the authenticated customer's permitted records

Answer: D

Encryption protects data in particular states, but the application legitimately decrypts and returns records to users. The defect is which user receives which record. Authorization must therefore be checked on the server for the requested object, based on the authenticated customer's rights, rather than relying on transport or storage encryption.

Study tip: Encrypted data can still be disclosed when the application authorizes the wrong recipient.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Stronger authentication confirms the requesting customer's identity. It does not authorize that customer to receive another customer's invoice or correct the missing record-level check.

B: Unpredictable identifiers can make guessing harder, but a leaked or otherwise obtained identifier would still expose the record. Server-side authorization is the direct correction.

C: The application is authorized to decrypt records during normal operation. More frequent key rotation does not prevent it from returning the wrong customer's plaintext invoice.

D: The application is returning a record to an unauthorized customer. Checking access to each requested invoice addresses that authorization failure at the decision point.

## SEC-Q142

A restricted engineering design is exported from a readable document into a proprietary binary format used by manufacturing software. The export preserves the same design information. What should happen to its data classification?

- A. Retain the applicable classification because sensitivity follows the information, not its readability
- B. Downgrade it to Public because a text editor cannot display the design
- C. Downgrade it because reading it requires a separately licensed software tool
- D. Classify it according to the filename extension rather than the design it contains

Answer: A

Data can be human-readable or machine-readable while retaining the same sensitivity. Binary encoding may make casual inspection harder, but it does not change the protected design or authorize disclosure. Classification, permissions, and other handling requirements should follow the information into its new representation.

Study tip: Encoding and format conversion do not automatically change an information asset's classification.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The binary export still contains the protected engineering design. A format conversion does not change the information's business sensitivity or authorized handling requirements.

B: Human readability is not a reliable confidentiality control. Appropriate software can interpret the binary file, and its sensitive content remains present.

C: Requiring particular software may limit casual viewing but is not an information classification decision. Authorized or unauthorized holders of that software can still interpret the design.

D: A filename extension describes an apparent format, not the sensitivity of its contents. Renaming the export must not change its required protection.

## SEC-Q143

A service has a recovery point objective of 15 minutes and a recovery time objective of 60 minutes. At 10:00, an incident destroys the active data. The newest recoverable data is from 09:40, and the service resumes normal operation at 10:45. Which assessment is correct?

- A. The recovery point objective is met, but the recovery time objective is missed
- B. Both recovery objectives are met because the service returns within one hour
- C. The recovery time objective is met, but the recovery point objective is missed
- D. Both recovery objectives are missed because the recovery process takes more than 15 minutes

Answer: C

RPO measures the tolerable gap between recoverable data and the disruption: 10:00 minus 09:40 equals 20 minutes, so the 15-minute target is missed. RTO measures acceptable service interruption: 10:45 minus 10:00 equals 45 minutes, within the 60-minute target. The two objectives assess different outcomes.

Study tip: Use the backup timestamp for RPO and the return-to-service timestamp for RTO.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: This reverses the results. Forty-five minutes is within the 60-minute RTO, while the 20-minute recoverable-data gap exceeds the 15-minute RPO.

B: Meeting the downtime target does not establish acceptable data loss. The 20-minute gap between the recovery point and incident exceeds the 15-minute RPO.

C: Recovery takes 45 minutes, within the 60-minute target. The recovered data is 20 minutes older than the incident, exceeding the 15-minute data-loss target.

D: Fifteen minutes is the data-loss tolerance, not the downtime limit. Recovery completes in 45 minutes, which is within the separate 60-minute RTO.

## SEC-Q144

A transaction service's recovery time objective requires normal user transactions within 60 minutes of an outage. An exercise records: outage at 13:00, replacement servers powered on at 13:25, application started at 13:45, and successful normal transactions at 14:10. Which result should be reported?

- A. A 70-minute recovery time, missing the objective by 10 minutes
- B. A 25-minute recovery time, meeting the objective when servers power on
- C. A 45-minute recovery time, meeting the objective when the application starts
- D. A 10-minute recovery time, measured only from the target deadline to successful transactions

Answer: A

Recovery must be measured against the business capability defined in the objective. The system is not recovered merely because hardware boots or an application process starts. Normal transactions resume at 14:10, seventy minutes after the outage, so the exercise misses the stated RTO by ten minutes.

Study tip: Measure recovery at the required business outcome, not an earlier technical milestone.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: The objective explicitly requires normal user transactions. That capability returns 70 minutes after the outage, so the 60-minute recovery target is missed.

B: Powered-on servers are an intermediate recovery step. They do not satisfy the defined requirement to process normal user transactions.

C: A started application is not necessarily a functioning business service. The exercise does not demonstrate successful normal transactions until 14:10.

D: The ten minutes represents how far recovery exceeds the target, not the total outage. Recovery time begins at the stated outage time.

## SEC-Q145

A company pays for an alternate facility with operational systems, current replicated data, and tested procedures for rapid service activation. Which recovery-site category BEST fits this description?

- A. Cold site
- B. Warm site
- C. Hot site
- D. Unprovisioned reciprocal office space

Answer: C

Hot sites provide a high level of pre-established recovery capability, including prepared systems and sufficiently current data. Warm and cold sites require progressively more activation work. Actual recovery performance still depends on capacity, dependencies, and testing, so the label alone does not guarantee that a particular RTO will be met.

Study tip: Compare how much equipment, configuration, and data preparation remains before the site can operate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: A cold site typically provides space and supporting facilities while requiring substantial equipment and system preparation. It does not match the stated ready-to-activate capability.

B: A warm site generally has partial infrastructure or equipment prepared but requires additional configuration or data restoration. The described operational readiness is more extensive.

C: A hot site maintains operational capability and current data for rapid recovery. The scenario includes both prepared systems and tested activation procedures.

D: Available office space alone does not provide operational systems or current replicated data. It would require substantial preparation before supporting the described service recovery.

## SEC-Q146

An employee accidentally deletes an important directory. The deletion is immediately replicated to a second storage system, and the disks in both systems remain healthy. Which capability would MOST directly enable recovery of the deleted directory?

- A. A retained independent backup or version from before the deletion
- B. More parity disks in the existing storage arrays
- C. An additional synchronous replica that immediately copies every deletion
- D. A larger write cache on both storage systems

Answer: A

Replication and disk redundancy primarily protect availability against certain system or hardware failures. They can faithfully propagate unwanted changes, including deletions. Recovering earlier content requires an available version or backup from before the event, with retention and access controls appropriate to the organization's risks.

Study tip: A healthy replica can contain the same unwanted change as the original.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: A retained earlier recovery point preserves content no longer present in the current replicas. It addresses logical deletion rather than physical disk failure.

B: Parity protects against specified disk failures, but the deletion is a valid logical operation propagated across healthy disks. Parity does not restore the previous directory state.

C: Another current-state replica would reproduce the same deletion. It increases copies of the latest state without necessarily preserving an earlier recoverable version.

D: A larger cache can affect performance but does not establish retained historical versions. It does not reliably preserve the deleted directory for recovery.

## SEC-Q147

Four stateless web servers are available behind one service address. The organization wants incoming requests distributed among healthy servers to increase usable capacity. Which capability MOST directly performs that function?

- A. Active-passive failover with only one server handling requests
- B. Scheduled snapshots of each server's storage volumes
- C. Synchronous data replication among the servers
- D. Load balancing

Answer: D

Load balancing directs traffic across available application instances and can improve both capacity use and availability. Failover clustering focuses on coordinated service continuity when a member fails, although real architectures can combine these capabilities. The question specifically asks for distributing concurrent requests among stateless web servers.

Study tip: Request distribution points to load balancing; coordinated service takeover points to failover clustering.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Active-passive failover can support service continuity by activating a standby. It does not use the four servers concurrently to distribute the live request load.

B: Snapshots create recovery points for stored state. They do not distribute client traffic or make simultaneous use of application processing capacity.

C: Replication keeps specified data copies coordinated. It does not by itself decide which application server should receive each incoming request.

D: A load balancer distributes incoming requests among suitable backends, often considering health and capacity. This matches the requirement to use several stateless servers concurrently.

## SEC-Q148

An application must sustain 2,100 requests per second after any one processing node fails. Each node can safely handle 750 requests per second, and traffic distributes evenly with no other bottleneck. What is the MINIMUM total number of nodes required?

- A. Five nodes
- B. Four nodes
- C. Three nodes
- D. Two nodes

Answer: B

First calculate the number of surviving nodes: 2,100 divided by 750 is 2.8, so three operational nodes are necessary. Add one node to tolerate the specified single failure, giving four total. Capacity planning must consider the degraded condition rather than relying only on healthy-state aggregate throughput.

Study tip: Calculate required surviving capacity first, then add the capacity lost in the failure scenario.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Five nodes would provide enough capacity after a failure, but they are not the minimum. Four already satisfy the 2,100-request requirement under the given assumptions.

B: After one failure, three nodes remain with a combined safe capacity of 2,250 requests per second. That exceeds the required 2,100 requests per second.

C: One failure would leave two nodes, supporting only 1,500 requests per second. That falls short of the required degraded-state capacity.

D: One failure would leave just one node and 750 requests per second of safe capacity. This is well below the application's stated demand.

## SEC-Q149

A company's primary and recovery data centers use different vendors but sit in the same floodplain and depend on the same regional power infrastructure. Which change MOST directly reduces the chance that one regional disaster disables both?

- A. Select a recovery location with sufficiently independent geographic and infrastructure risks, then validate recovery performance
- B. Use a different operating system at the recovery site while retaining the same geographic dependencies
- C. Renegotiate the recovery vendor's support response time while keeping both locations
- D. Increase replication frequency between the existing facilities

Answer: A

Different vendors do not necessarily mean independent failure risks. Geographic dispersion should account for actual hazards and shared supporting infrastructure, not merely provider names. The organization must balance independence with connectivity, latency, data location requirements, and the ability to meet recovery objectives.

Study tip: Check shared hazards and dependencies rather than assuming different vendors mean independent sites.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Geographic and infrastructure independence reduces shared exposure to regional hazards. Recovery testing confirms that the more independent location still supports required business recovery objectives.

B: Platform diversity can reduce exposure to some shared software failures. It does not remove the common floodplain or regional power dependency.

C: Faster support may help some incidents, but it does not remove the shared floodplain and power dependencies that can disable both facilities together.

D: More frequent replication can reduce the recoverable-data gap, but it does not make either facility available when a shared disaster disables both.

## SEC-Q150

A virtualization cluster keeps hourly snapshots on the same storage array that holds every production virtual disk. The snapshots restore deleted files successfully during routine tests. Which remaining scenario MOST clearly demonstrates why these snapshots alone are insufficient as the entire backup strategy?

- A. A user deletes a file that existed in a retained snapshot before the deletion
- B. A storage-array failure destroys both the production disks and all snapshots on that array
- C. A virtual machine needs additional CPU while its storage remains available
- D. An administrator needs to compare two versions still retained in healthy snapshots

Answer: B

Snapshots can be useful recovery points, but their protection depends on where they are stored and which failures they survive. Keeping every snapshot on the production array leaves a shared failure boundary. A complete strategy should include recoverable copies independent of that array and validate their restoration.

Study tip: A recovery point is useful only if it survives the failure it is intended to address.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: The scenario states that retained snapshots successfully recover this type of deletion. This event does not demonstrate their remaining common-storage limitation.

B: Snapshots on the same array share its failure boundary. A destructive array-wide event can remove both the live data and the retained recovery points.

C: A CPU capacity need is separate from the recoverability of data on the array. It does not demonstrate loss of both production and snapshot copies.

D: Healthy retained snapshots may support this comparison. The task does not inherently expose the shared-array disaster risk identified in the question.

## SEC-Q151

A continuity exercise finds that the alternate application environment is healthy, but no remote employee has the training or authority to activate it. The exercise also finds that its administrators cannot sign in when the primary identity service is unavailable. Which TWO improvements MOST directly address these findings? (Select TWO.)

- A. Increase application server memory without changing staffing or authentication
- B. Move recovery instructions into the primary identity service's protected portal only
- C. Provide a tested, tightly controlled emergency authentication path that does not depend on the failed primary identity service
- D. Train authorized remote responders and document their recovery responsibilities
- E. Shorten the backup compression cycle without changing administrator access

Answer: C|D

Continuity planning includes people and dependencies, not just running infrastructure. The alternate environment cannot deliver recovery without authorized, capable responders and a usable administrative access path. Emergency access should be independent enough to survive the specified failure while remaining controlled, monitored, and tested.

Study tip: Test who can perform recovery and how they authenticate when normal services are unavailable.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: The application environment is already healthy. Additional memory does not provide trained responders or enable sign-in when the primary identity service fails.

B: Making instructions depend exclusively on the failed service adds another recovery obstacle. Responders need appropriately protected access to instructions during the outage.

C: An independent emergency access path addresses the authentication dependency. Its credentials and use still require protection, accountability, and periodic testing.

D: The exercise exposes a personnel and authority gap. Prepared responders with documented responsibilities can carry out the recovery actions when the usual local staff are unavailable.

E: Backup processing efficiency does not resolve the identified personnel and authentication barriers. Recoverable data cannot be used if authorized responders cannot activate the environment.

## SEC-Q152

During a recovery exercise, a company processes the same test workload at its alternate site and primary site, compares the results, and leaves production users on the primary service. Which testing method BEST describes this exercise?

- A. A tabletop exercise
- B. A documentation-only recovery-plan review
- C. A full production failover
- D. Parallel processing

Answer: D

Parallel processing exercises alternate capabilities while the primary continues to operate, allowing results to be compared. It provides more technical evidence than a discussion-only exercise but does not prove every aspect of production cutover. A separate failover test may be needed to validate switching dependencies and user traffic.

Study tip: Processing in both environments without moving production users indicates a parallel exercise.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: A tabletop exercise primarily walks participants through decisions and procedures through discussion. Here, the alternate environment actually processes the workload.

B: Reviewing documents does not execute matching workloads in both environments. The scenario includes an operational comparison beyond checking written instructions.

C: A full failover moves the production service to the alternate environment. The scenario explicitly keeps production users on the primary service.

D: Both environments execute the workload concurrently for comparison while the primary remains in service. This tests alternate processing without moving production users.

## SEC-Q153

A facility's generator can support the critical server room for many hours, but it needs 45 seconds after a utility outage before supplying stable power. Servers currently shut down during that gap. Which addition MOST directly addresses the problem?

- A. A properly sized UPS that bridges the interruption until generator power is stable
- B. A surge-protected power strip without energy storage
- C. A larger generator fuel tank with no interim power source
- D. An automatic transfer switch without an interim stored-energy source

Answer: A

UPS systems and generators serve complementary roles. A suitably sized UPS supplies immediate power through a short interruption, while the generator supports a longer outage after startup. The complete design must account for the critical equipment load and supporting dependencies such as networking and necessary environmental systems.

Study tip: Use a UPS for the immediate gap and a generator for sustained power after startup.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: A UPS supplies immediate short-term power during the generator's startup interval. Sizing must account for the critical load and the required bridging time.

B: Surge protection addresses voltage spikes but does not provide sustained backup power. It cannot bridge an interruption lasting 45 seconds.

C: More fuel extends generator runtime after it starts. It does not supply electricity during the 45-second interval before stable generator power is available.

D: A transfer switch selects an available power source, but it cannot supply energy while both utility power and stable generator output are unavailable.

## SEC-Q154

A service runs in two cloud providers and can move traffic between them. Both deployments require one external identity provider for user authentication. During an identity-provider outage, both applications remain healthy but users cannot sign in. What is the MOST important resilience lesson?

- A. The second cloud provider automatically guarantees user authentication during an identity outage
- B. Cloud diversity does not remove shared service dependencies that can disable the business function
- C. Different virtual-machine operating systems would necessarily eliminate this authentication outage
- D. Adding load balancers to both application deployments would restore normal sign-in

Answer: B

Multi-cloud hosting can reduce exposure to some provider failures, but the useful unit of recovery is the complete business service. Shared identity, DNS, keys, data services, and operational dependencies can still create common failure points. Continuity planning should map and test these dependencies rather than assuming hosting diversity guarantees availability.

Study tip: Trace the dependencies needed for a user to complete the business task across every alternate environment.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: A separate hosting provider does not automatically replace the shared identity service. Authentication continuity must be designed and tested explicitly.

B: Both deployments depend on the same authentication service. That common dependency can prevent business use despite healthy, separately hosted application infrastructure.

C: Operating system diversity addresses some platform-specific failures, but both applications would still rely on the unavailable external authentication service.

D: More load balancers can improve traffic distribution but do not restore the shared identity provider. Users still require that unavailable authentication dependency.

## SEC-Q155

A database has a valid midnight full backup and a complete protected transaction-log sequence through 10:10. An accidental destructive transaction committed at 10:07. The database supports point-in-time recovery, and the team needs the state immediately before that transaction. Which recovery approach BEST meets the requirement?

- A. Restore only the midnight full backup and discard all transaction logs
- B. Promote a synchronous replica that has already applied the destructive transaction
- C. Restore the full backup and replay every available transaction through 10:10
- D. Restore the full backup and replay the required logs only to a point before the destructive transaction

Answer: D

A full backup provides the baseline, and the protected log sequence supplies subsequent changes. Point-in-time recovery applies only the changes needed to reach the chosen pre-incident state. The target must exclude the destructive commit; restoring the latest replicated state or replaying all logs would preserve the unwanted action.

Study tip: Journaling enables selective recovery only when the baseline, required log sequence, and stopping point are available.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: The full backup alone loses legitimate changes between midnight and the target time. Available transaction logs allow a much closer recovery point under the stated capabilities.

B: The replica contains the same committed deletion or modification. Promoting it changes the serving system but does not return the data to the required earlier state.

C: Replaying the entire available sequence would include the destructive 10:07 transaction. The recovered database would reproduce the unwanted change.

D: Point-in-time recovery combines a baseline backup with ordered transaction history. Stopping before the destructive commit recovers later legitimate work without reapplying that transaction.

## SEC-Q156

A company must recover encrypted backups even if a disaster destroys its primary site and an attacker has compromised production administrator accounts. Which THREE design measures together BEST address these combined risks? (Select THREE.)

- A. Store the only backup copy on a different disk in the same physical server
- B. Retain a tested offsite backup copy with offline or appropriately enforced immutable protection
- C. Maintain protected, recoverable backup-decryption material that remains accessible during the site and identity outage
- D. Keep the only decryption key on the primary site's production administrator workstation
- E. Use an additional online replica that production administrators can freely overwrite and delete
- F. Separate backup administration from production privileges and restrict destructive backup operations

Answer: B|C|F

Recovery must preserve both the data and the ability to use it. The design therefore needs an independently retained offsite copy, protection against compromised production privileges, and recoverable decryption material that survives the outage. Testing should verify the complete recovery path, including access to keys and procedures.

Study tip: Protect recovery copies, their administration, and their decryption keys from the same common failure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: A different local disk still shares the site's destruction risk and much of the server's administrative access. It does not provide offsite independence.

B: An offsite copy survives loss of the primary site, while offline or immutable protection can resist deletion through compromised production access paths.

C: Encrypted backups are usable only if authorized responders can recover the required keys. Key protection and availability must survive the same disaster as the backup copies.

D: Losing the primary site or its administrator workstation can make every encrypted copy unusable. This creates a critical single dependency for recovery.

E: An administrator-controlled replica remains exposed to the compromised privileges. It does not provide the independent retained recovery capability needed for the combined risks.

F: Independent backup privileges reduce the chance that a compromised production administrator can destroy recovery copies. Access separation must be enforced rather than merely documented.

## SEC-Q157

A retailer deployed a hardened workstation image six months ago. A configuration audit now finds unauthorized services on several terminals. Which action BEST restores consistent protection as the fleet changes?

- A. Enforce the approved baseline and continuously check for configuration drift
- B. Add the newly discovered services to the approved baseline automatically
- C. Reinstall the original image once and suspend configuration scanning
- D. Replace configuration checks with a monthly bandwidth utilization report

Answer: A

A secure baseline describes the approved configuration and must remain current as systems evolve. Applying it and checking for drift address both existing deviations and future changes. Investigate exceptions and update the baseline through change control rather than treating every observed configuration as acceptable.

Study tip: A baseline is a maintained standard, not merely an installation image.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Baseline enforcement restores required settings, while recurring drift checks identify later departures introduced by software, administrators, or users.

B: Automatically accepting deviations normalizes unauthorized changes; baseline changes require assessment, testing, and approval before broad deployment across systems.

C: Reimaging may restore an initial state, but stopping configuration checks leaves later changes undetected and the baseline potentially outdated.

D: Bandwidth reports help capacity and traffic analysis but do not establish whether workstation settings and installed services meet requirements.

## SEC-Q158

Employees use personally owned phones for corporate email. The organization must remove business data when an employee leaves while preserving personal photos. Which solution BEST fits this requirement?

- A. Require a full factory reset during every offboarding event
- B. Allow access from any phone that uses a personal screen lock
- C. Store corporate email in an unmanaged personal backup account
- D. Manage a separate work container and perform a selective wipe

Answer: D

Mobile management can apply policy to a work profile or managed application container. Selective wipe removes corporate content without requiring erasure of the entire personally owned device. This depends on deploying compatible management controls before the data is accessed; a personal screen lock alone does not provide that separation.

Study tip: Match the management scope to ownership and the data that must be removed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A factory reset removes personal data along with business data, conflicting with the explicitly stated requirement to preserve personal photos.

B: A screen lock helps protect local access but does not provide organizational control over business data during employee offboarding.

C: Unmanaged backups can retain business data beyond organizational control, making effective offboarding and selective removal substantially more difficult.

D: A managed work container separates business applications and data, allowing targeted removal while preserving personal content outside the container.

## SEC-Q159

A warehouse is adding wireless access points. Metal shelving creates dead zones, and the team wants to limit unnecessary signal leakage outside the building. What should guide access point placement and transmit-power settings?

- A. A floor plan that assumes equal signal strength in every aisle
- B. A list of assigned wired switch port numbers
- C. A policy requiring identical maximum power on every access point
- D. An onsite wireless survey with coverage and interference heat maps

Answer: D

Radio signals interact with building materials, obstacles, and neighboring transmitters. A wireless survey and heat maps reveal those conditions so the team can place access points and tune power deliberately. Coverage design supports security, but reducing signal leakage does not replace strong wireless authentication and encryption.

Study tip: Use measured radio conditions for placement; encryption still protects reachable wireless traffic.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A floor plan helps planning, but assuming uniform propagation ignores attenuation and interference from the warehouse's actual shelving and radio environment.

B: Switch port assignments document cabling and connectivity, but they do not show wireless propagation, interference, or coverage beyond building boundaries.

C: Maximum power can increase unwanted coverage and interference; appropriate power should follow measured conditions and the required coverage design.

D: A site survey measures the actual radio environment, supporting placement and power decisions that account for shelving, interference, and boundaries.

## SEC-Q160

A company is replacing a shared wireless password. Managed laptops already have device certificates and trust the corporate RADIUS server certificate. The company requires individual device revocation and resistance to credential collection by rogue access points. Which configuration BEST meets these needs?

- A. WPA3-Personal with one complex password shared by all employees
- B. An open wireless network with a captive portal using employee passwords
- C. WPA3-Enterprise with clients configured to trust any authentication-server certificate
- D. WPA3-Enterprise with EAP-TLS and enforced authentication-server certificate validation

Answer: D

EAP-TLS lets the company authenticate managed devices with certificates rather than a fleet-wide password. Clients must validate the RADIUS server certificate against the expected trust and identity settings. This combination supports individual certificate lifecycle actions and makes an imitation access point less useful for collecting reusable employee credentials.

Study tip: Enterprise wireless security depends on the EAP method and server validation, not just the WPA label.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: A shared personal-mode credential does not provide individual device certificate revocation and must be redistributed when shared access is changed.

B: A captive portal does not provide the requested certificate-based wireless authentication and can expose users to deceptive portal collection attempts.

C: Disabling server certificate validation removes an important check against rogue authentication infrastructure despite using an enterprise wireless security mode.

D: EAP-TLS uses individual certificates and validates the authentication server, supporting device-specific revocation and reducing exposure to rogue authentication endpoints.

## SEC-Q161

A production controller cannot be patched until a vendor-approved maintenance window next month. Unplanned downtime could damage equipment. Which immediate measure BEST reduces exposure while respecting that constraint?

- A. Enable unrestricted remote administration so the vendor can connect quickly
- B. Turn off controller event collection until the patch is available
- C. Restrict controller communications to required peers and monitor the approved paths
- D. Install the workstation security agent directly on the controller without testing

Answer: C

Industrial hardening must account for safety, availability, and vendor support. Restricting access to required systems is a compensating measure while the patch is tested and scheduled. It does not remove the underlying flaw, so monitoring and a tracked remediation plan remain necessary during the temporary exception.

Study tip: For operational technology, reduce exposure without casually disrupting safety or timing requirements.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/82/r3/final

A: Broad administrative reachability increases exposure and provides no compensating protection for the controller while its vulnerability remains unpatched.

B: Disabling event collection reduces visibility during the period of elevated risk and does not address the vulnerable communication paths.

C: Allowing only necessary communications limits exposure while monitoring supports detection, without introducing an untested controller change during production.

D: An untested agent could disrupt controller timing or compatibility, creating the operational hazard that the maintenance constraint is intended to prevent.

## SEC-Q162

An HTTPS-only portal stores its session identifier in a cookie. The developer wants browsers to avoid sending that cookie over plaintext HTTP and to prevent ordinary page scripts from reading it. Which attributes directly address both goals?

- A. Domain and Path
- B. Expires and Max-Age
- C. Secure and HttpOnly
- D. SameSite and Priority

Answer: C

The Secure attribute controls the transport over which a cookie is sent, and HttpOnly restricts direct script access to it. These address the two specified requirements. They do not repair an XSS flaw itself or stop every action a malicious script might perform through a logged-in browser.

Study tip: Secure concerns transport; HttpOnly concerns script access; SameSite concerns cross-site requests.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: Domain and Path limit cookie scope across hosts and URL paths, but they do not supply transport protection or script-access restrictions.

B: Expiration attributes control how long a cookie persists, but they do not require encrypted transport or prevent scripts from reading it.

C: Secure restricts cookie transmission to secure connections, while HttpOnly blocks access through ordinary client-side scripting interfaces such as document.cookie.

D: SameSite influences cross-site cookie inclusion and Priority influences eviction behavior; neither pair directly provides both requested Secure and HttpOnly protections.

## SEC-Q163

A technician downloads a firmware update and verifies its digital signature using the vendor's trusted signing certificate. What does a successful verification MOST directly establish?

- A. The package matches what the signing key holder signed and has not been modified
- B. The package contents are concealed from people who download it
- C. The firmware contains no exploitable implementation defects
- D. The firmware will operate correctly on every hardware revision

Answer: A

A valid signature connects the package's integrity to possession of the trusted signing key. The trust decision also depends on the certificate and signing-key controls. It does not demonstrate that the software is bug-free, compatible with every device, or encrypted against disclosure.

Study tip: A valid software signature establishes origin and integrity, not the absence of vulnerabilities.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final|https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final

A: Signature verification authenticates the signed content against a trusted signing identity and detects changes to the content after signing.

B: Digital signatures provide authenticity and integrity checks rather than confidentiality; a signed package can remain fully readable to others.

C: A valid signature does not analyze source code or runtime behavior; legitimately signed firmware can still contain vulnerabilities.

D: Compatibility depends on the supported hardware and release requirements, which signature verification does not evaluate merely by authenticating the package.

## SEC-Q164

A development team wants to detect dangerous function calls and insecure data flows before its application is built or started. Which technique BEST addresses this stage of development?

- A. Perform dynamic testing against the production application only
- B. Monitor the production firewall for unusually large responses
- C. Apply a digital signature to the application release archive
- D. Run static application security analysis against the source code

Answer: D

Static analysis examines source or other nonrunning program representations, making it useful in early development and continuous integration. Findings still need validation because analysis can report false positives or miss runtime-dependent issues. Dynamic analysis complements it after an executable application and suitable test environment exist.

Study tip: Static analysis inspects code; dynamic analysis exercises a running application.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: Dynamic testing evaluates a running application and therefore does not meet the request to analyze code before building or starting it.

B: Firewall monitoring examines deployed traffic patterns and cannot directly inspect predeployment source-code calls or internal data-flow relationships.

C: Signing helps recipients verify release origin and integrity but does not inspect the source for insecure constructs or data flows.

D: Static analysis examines code without executing the application, allowing detection of risky constructs and potential data-flow problems early in development.

## SEC-Q165

An inventory application checks that quantity is an integer from 1 through 100 in browser JavaScript. A tester bypasses the page and submits quantity=-500 directly to the API, which accepts it. What is the BEST correction?

- A. Add the same validation to a second browser event handler
- B. Rename the browser's quantity field to make it less predictable
- C. Enforce the allowed type and range at the server-side API boundary
- D. Use HTTPS while leaving the server-side acceptance rules unchanged

Answer: C

The server must validate untrusted input even when the interface already performs the same check. Browser controls are useful for immediate feedback but can be bypassed by direct HTTP requests. The corrective control should enforce the quantity's permitted type and range where the application accepts the request.

Study tip: Client validation improves usability; server validation enforces the rule.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://owasp.org/Top10/2025/|https://csrc.nist.gov/pubs/sp/800/218/final

A: Additional client-side checks can improve usability but remain bypassable when a caller sends requests directly to the API.

B: Changing a field name does not enforce a trust boundary; a caller can still inspect requests and send an invalid value.

C: Server-side validation checks requests regardless of client behavior and directly prevents values outside the application's permitted type and range.

D: HTTPS protects data in transit but does not make a client-supplied quantity trustworthy or enforce the application's numeric limits.

## SEC-Q166

A facilities team deploys network cameras that need only an internal recording server and an approved time server. Their web administration interfaces are currently reachable from employee Wi-Fi. Which design BEST reduces the cameras' management exposure?

- A. Place cameras in a restricted segment and allow administration only from the management network
- B. Block the recording server while permitting all other camera network destinations
- C. Allow camera administration from any internal subnet because it is not internet-facing
- D. Keep the cameras on employee Wi-Fi and change only their visible device names

Answer: A

The required data paths and administrative paths should be explicitly limited. A camera segment can allow recording and time synchronization while a separate management policy permits authorized administrators. Being inside the organization is insufficient justification for unrestricted access, particularly for embedded devices with limited local security controls.

Study tip: Separate required device traffic from privileged management access.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Segmentation separates camera services from general users, while management-source restrictions limit which systems can reach their administrative interfaces.

B: This interrupts the required business function while preserving unnecessary connectivity and management exposure from other systems on the network.

C: Internal reachability still exposes administrative services to compromised or unauthorized internal hosts and does not implement the requested restriction.

D: Renaming devices provides little access control; employees and compromised endpoints would retain the same reachability to the management interfaces.

## SEC-Q167

A company issues phones that permit limited personal use. Before business email is enabled, IT must ensure a stolen locked phone protects local data and that outdated devices cannot synchronize. Which TWO controls directly meet these requirements? (Select TWO.)

- A. Enforce an operating-system compliance rule before allowing email access
- B. Allow unmanaged mail clients to bypass enrollment checks
- C. Publish the phone's Bluetooth name in the employee directory
- D. Disable all organizational inventory records for issued phones
- E. Require device encryption and a managed screen-lock policy

Answer: A|E

Local protection and access eligibility are different requirements. Encryption with a managed lock helps protect data on a stolen device, while a compliance-based access policy can prevent an outdated phone from synchronizing. The mobile management system must be integrated with the email access path so unmanaged clients cannot bypass the checks.

Study tip: Pair protection of data already on a device with conditions for future access.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A compliance rule can deny synchronization to devices below the approved operating-system level, linking business access to the required patch posture.

B: Bypassing enrollment creates a route around the very device posture conditions that are supposed to control business email access.

C: Bluetooth naming can help identify a device but does not protect stored business data or enforce an operating-system requirement.

D: Removing inventory information weakens accountability and lifecycle management without improving local data protection or enforcement of supported operating-system levels.

E: Encryption and a required lock protect locally stored business data when a phone is lost, subject to the platform's supported controls.

## SEC-Q168

Two network appliance models meet a branch office's performance needs. One costs less but receives security updates for only another year; the office expects to use it for five years. Which procurement consideration MOST directly addresses the resulting security concern?

- A. Evaluate the supported security-update lifecycle against the planned service life
- B. Choose the model with the smallest initial purchase price
- C. Delay consideration of vendor support until the appliance stops functioning
- D. Select the model with the greatest number of unused physical ports

Answer: A

Security requirements belong in procurement, before unsupported dependencies enter the environment. Comparing support commitments with planned service life exposes lifecycle risk and informs total cost. The cheaper device might still be selected through an informed decision, but purchase price alone cannot establish suitability for five years of protected operation.

Study tip: An asset's useful hardware life can exceed its supported security life.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A support period shorter than the deployment period creates foreseeable unpatched exposure and replacement obligations during the asset's planned use.

B: Initial price ignores later replacement or compensating-control costs and does not address continued vulnerability remediation throughout the intended deployment.

C: A working appliance can lose security support long before hardware failure, leaving vulnerabilities without vendor fixes during normal operation.

D: Spare ports may support expansion, but they do not resolve the identified mismatch between security-update support and expected service life.

## SEC-Q169

A new document repository has no assigned party responsible for approving its classification and acceptable business use. Which asset-management assignment MOST directly closes this accountability gap?

- A. Assign a business owner for the repository and its information
- B. Assign a procurement coordinator to reconcile the repository's software invoices
- C. Assign an internal auditor to evaluate compliance with existing control requirements
- D. Assign a technical custodian to apply protection settings chosen by another party

Answer: A

Asset records need more than technical identifiers. A designated business owner provides accountability for decisions such as classification and approved use, while custodians and administrators can implement those requirements. Clear ownership also provides a decision point when access, retention, or lifecycle questions arise.

Study tip: Ownership establishes accountability; administration implements the owner's requirements.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An owner is accountable for business decisions about the asset, including classification, authorized use, and appropriate protection requirements.

B: Procurement reconciliation supports financial and licensing records but does not assign accountability for the repository's information classification and acceptable business use.

C: An auditor independently evaluates compliance and evidence; that review role does not establish the business ownership needed to make classification and use decisions.

D: A custodian can implement and maintain controls, but this assignment alone does not identify the party accountable for choosing classification and business use.

## SEC-Q170

Network discovery detects a previously unknown print server. It is absent from the asset inventory but is actively serving a department. What is the BEST initial asset-management response?

- A. Automatically give it the same trust level as the domain controllers
- B. Identify its owner and purpose, assess its state, and reconcile the inventory
- C. Delete the discovery result because it lacks an existing asset identifier
- D. Mark it compliant because users are successfully printing through it

Answer: B

Discovery and inventory maintenance work together. Finding a device does not prove it is malicious or approved, so the team should establish ownership, purpose, authorization, and security state. Reconciliation then brings the actual environment into accountable records and enables appropriate follow-up without assuming that functionality demonstrates compliance.

Study tip: Discovery shows what exists; reconciliation establishes whether the records and authorization match.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An unidentified departmental device has no established need for privileged trust, and assigning it would increase exposure before accountability is established.

B: Verification establishes whether the device is authorized and what it does, allowing accurate ownership, classification, and lifecycle records to be created.

C: Missing inventory data is the condition requiring investigation; discarding the discovery preserves the gap and leaves the device unaccounted for.

D: Successful operation says nothing about authorization, security posture, or support status and cannot replace verification of the newly discovered asset.

## SEC-Q171

An organization will reuse solid-state drives containing confidential records. The drives support a vendor-documented sanitize operation, and policy permits reuse after verified sanitization. Which approach BEST satisfies the requirement?

- A. Rename the drives and perform a quick format without validation
- B. Run a magnetic degausser over each drive before reconnecting it
- C. Use the approved device sanitize method, verify completion, and record the result
- D. Delete visible files and empty the operating system's recycle bin

Answer: C

Use the approved SSD sanitization method. Verification checks that the operation completed successfully; validation is the authorized decision that its result provides the confidentiality assurance required for reuse. Record the process result and validation decision. Deletion, quick formatting, and magnetic degaussing are not equivalent SSD sanitization methods; follow the exception or destruction process when assurance is insufficient.

Study tip: Choose sanitization by the medium and verify the result; deletion is not proof of erasure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/88/r2/final

A: Changing labels and quick formatting do not establish removal of recoverable data, especially across an SSD's controller-managed storage areas.

B: Degaussing targets magnetic storage; solid-state drives store data electronically, so this process is not suitable evidence of SSD sanitization.

C: An appropriate device-level method addresses the medium's characteristics, while verification and records establish that the required sanitization process completed.

D: File deletion commonly removes references rather than all underlying data and does not establish that confidential records are unrecoverable.

## SEC-Q172

A disposal vendor returns a certificate stating that 40 retired drives were destroyed. The asset manager needs evidence that the organization's specific drives were included. Which information is MOST useful?

- A. Drive serial numbers linked to destruction records and the retirement inventory
- B. An invoice listing a disposal charge for a batch of 40 drives
- C. The vendor's general certification describing its overall disposal management system
- D. A copy of the vendor's standard destruction procedure with no asset identifiers

Answer: A

A count alone cannot tie a destruction claim to individual assets. Serial numbers or equivalent unique identifiers should connect retirement records, custody transfers, and the vendor's destruction evidence. This enables the asset manager to find missing or mismatched items and close the lifecycle records with supportable evidence.

Study tip: Disposal evidence should trace back to the exact assets in the inventory.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/88/r2/final

A: Unique identifiers connect the destruction event to the exact assets being retired, supporting reconciliation and evidence that specific media were processed.

B: A matching quantity supports billing reconciliation but does not identify the exact drives destroyed or show that the correct serial-numbered assets were included.

C: A vendor certification supports due diligence about its processes but does not connect this particular destruction event to the organization's individual drives.

D: A procedure describes how destruction should occur; without specific identifiers and execution records, it does not establish which organizational drives were actually processed.

## SEC-Q173

A department wants to retire a database server. Some records still fall within the organization's approved retention period. There is no legal hold, and the application can export the records. What should happen before the server's storage is sanitized?

- A. Preserve required records in an approved archive and verify they remain retrievable
- B. Keep the unsupported server online indefinitely with unrestricted access
- C. Copy only the database application installer and destroy all data files
- D. Erase the records because retirement automatically ends their retention period

Answer: A

The asset lifecycle and information lifecycle are related but not identical. The organization can retire hardware while preserving records for their required duration in a controlled archive. Successful export and retrieval checks should precede sanitization so that decommissioning does not accidentally eliminate information the organization still needs to retain.

Study tip: Retire the server only after required data has a verified, approved destination.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/88/r2/final

A: Archiving and retrieval verification meet the continuing retention obligation while allowing the old server and its storage to be retired.

B: Indefinite operation creates unnecessary exposure and does not follow a controlled archive and retirement process for records with a defined retention period.

C: An installer cannot replace the retained records, so preserving only software would not maintain the information required by the retention policy.

D: The obligation applies to the information, not the hardware; retiring a server does not by itself authorize premature destruction of retained records.

## SEC-Q174

Discovery finds several software packages that are absent from the approved application inventory. The security team wants to establish accountable lifecycle management before deciding whether to retain them. Which TWO actions BEST support that goal? (Select TWO.)

- A. Treat any application without a scanner finding as automatically approved
- B. Remove the package names from discovery reports until renewal time
- C. Grant local administrator rights to all users of the discovered software
- D. Record each package's version, deployment locations, and responsible owner
- E. Determine each package's business purpose and vendor support status

Answer: D|E

Useful software inventory records connect the package to its versions, deployments, owners, purposes, and support lifecycle. Those details support a reasoned authorization and remediation decision. Merely passing a scan is insufficient because inventory accountability also concerns who needs the software and whether it can be maintained securely.

Study tip: Software inventory needs context that supports decisions, not just a list of names.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A clean scan does not establish ownership, business need, licensing, or support status and cannot substitute for application authorization.

B: Suppressing discovery hides the inventory gap and prevents timely assessment of the applications' legitimacy, exposure, and ongoing support requirements.

C: Broad privilege grants increase user capabilities without establishing the software's lifecycle records, approved purpose, or vendor-supported security maintenance.

D: Version, location, and ownership data make software trackable and identify who can justify its use and coordinate necessary lifecycle actions.

E: Purpose supports authorization decisions, while support status identifies whether security fixes remain available during continued use of the package.

## SEC-Q175

An external scan identifies reachable services on a server but cannot determine whether local patches and security settings are installed. Which authorized scanning change MOST directly improves that visibility?

- A. Use a credentialed scan with an appropriately scoped assessment account
- B. Increase the server's internet bandwidth before running the same scan
- C. Run a public DNS lookup for the server's hostname each hour
- D. Remove every service banner while leaving the scan unauthenticated

Answer: A

Credentialed scans can examine patch and configuration state through an authorized account or equivalent authenticated mechanism. The account needs only the access required by the assessment method and should be protected accordingly. External and authenticated scans remain complementary because they reveal different views of the system's exposure.

Study tip: Authenticated scanning adds local visibility; it does not replace the external attack-surface view.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Authenticated assessment can inspect permitted local configuration and patch information that an unauthenticated network scan may not expose.

B: More bandwidth can affect scan speed but does not grant access to local configuration or patch information hidden from unauthenticated checks.

C: DNS resolution provides naming information and does not reveal whether local patches or host security settings meet assessment requirements.

D: Suppressing banners may reduce information disclosure, but it further limits remote identification rather than providing authenticated local inspection.

## SEC-Q176

A software team wants an alert when an open-source library used in its application becomes associated with a newly disclosed vulnerability. Which activity BEST addresses this need?

- A. Exercise the application's login page once before each major release
- B. Monitor the application's dependency inventory against vulnerability information
- C. Verify the digital signature on each previously approved application release
- D. Run source analysis only on code written by the company's own developers

Answer: B

Dependency or software composition monitoring compares the components an application uses with published vulnerability information. Accurate component names and versions are necessary, and a match still requires assessment of affected versions, usage, and available fixes. This complements source review and testing because a new disclosure can affect unchanged application code.

Study tip: New vulnerability information can change risk even when your own code has not changed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/218/final

A: A dynamic login test may find reachable application problems but does not continuously match the complete dependency inventory to newly published vulnerability information.

B: Package monitoring links known dependency names and versions to newly published vulnerability records, enabling review of affected application components.

C: A signature verifies signed release integrity and origin; it does not alert when a legitimate component later receives a new vulnerability disclosure.

D: Source analysis can find implementation weaknesses in reviewed code, but limiting it to internally written code does not monitor newly disclosed third-party dependency issues.

## SEC-Q177

Two validated findings await remediation. Finding A has a higher severity score on an isolated lab system with no sensitive data. Finding B affects an internet-facing production gateway, is being exploited in the wild, and provides a path to business systems. Which is the BEST priority?

- A. Prioritize finding A solely because its severity score is numerically higher
- B. Close finding B because the lab finding was discovered first
- C. Prioritize finding B using exploitation, exposure, and business impact
- D. Remediate neither finding until both have identical severity scores

Answer: C

Remediation priority combines technical severity with exposure, threat activity, asset importance, and organizational consequences. Finding B has an active exploitation context and a reachable path to important systems, so it deserves immediate attention. The lab issue still needs a tracked response; lower immediate priority does not mean the finding is irrelevant.

Study tip: Severity informs priority; exposure, exploitation, and business impact complete the decision.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://github.com/cisagov/kev-data|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://www.first.org/cvss/v4.0/specification-document

A: A severity score is useful input but omits key organizational context; ignoring exposure and active exploitation can misallocate urgent remediation effort.

B: Discovery order does not determine current risk; the stated exploitation and gateway exposure remain relevant regardless of which issue was reported earlier.

C: Known exploitation on an exposed production gateway creates a stronger immediate business risk than the score alone describes for the isolated lab issue.

D: Equal scores are not required for a risk decision, and delaying validated findings leaves the production exposure unnecessarily available to attackers.

## SEC-Q178

A scanner flags a server from its version banner. The vendor documents a security fix backported to that release, and the installed package revision matches the fixed vendor build. What is the BEST next step before closing the finding as a false positive?

- A. Validate the relevant fix and scanner detection basis, then document supporting evidence
- B. Assume the scanner is correct because automated findings need no confirmation
- C. Uninstall the patch so the version banner matches the scanner's expectation
- D. Close every finding on servers with the same operating system name

Answer: A

A version string is an indicator, not conclusive proof of vulnerability. Vendors may backport fixes without changing the upstream version displayed in banners. Confirm the installed revision and the advisory's applicability, examine the scanner logic, and retain evidence for the conclusion. Adjust detection or exceptions narrowly so unrelated findings remain visible.

Study tip: Confirm the vulnerable condition; a version banner can be incomplete evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Checking the actual patched condition against the detection method establishes whether the banner-based finding applies and supports a defensible closure.

B: Banner-based detection can miss vendor backports, so automated output must be assessed against relevant package and vulnerability evidence.

C: Removing a security fix weakens the server and changes a reporting discrepancy into a potentially real vulnerability rather than resolving the evidence.

D: A verified backport for one installed build does not establish the patch state or applicability of all findings on other systems.

## SEC-Q179

A scanner reports no issues on an application. A subsequent authorized test confirms that an ordinary user can retrieve another user's private invoice. How should the missed scanner result be classified?

- A. A false positive
- B. An accepted risk
- C. A true negative
- D. A false negative

Answer: D

A false negative occurs when a detection method fails to identify a condition that is actually present. The authorized invoice test supplies the missing confirmation. This also illustrates why a clean automated scan is not proof of security, particularly for application authorization logic that requires user and object relationships to evaluate.

Study tip: Positive and negative describe the tool's result; true and false describe whether it matches reality.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: A false positive would report a vulnerability that is not actually present; the scenario confirms a real issue was missed.

B: Risk acceptance requires an informed authorized decision about a known risk; it is not the classification for a detection system missing an issue.

C: A true negative means no issue is reported and no issue exists; the demonstrated unauthorized invoice retrieval contradicts that condition.

D: The vulnerable condition exists but the scanner did not report it, which is the defining relationship for a false negative.

## SEC-Q180

Administrators deploy a patch to 200 servers. The deployment console says the installation job completed, but some updates require a restart. What provides the BEST evidence that the original vulnerability is remediated?

- A. Verify active patch state and rescan affected servers after required restarts
- B. Treat a completed installation job as sufficient despite pending restarts
- C. Close the finding when the patch file reaches the deployment share
- D. Replace the original scanner report with the patch purchase receipt

Answer: A

Remediation validation checks the resulting state rather than relying solely on the action taken. Confirm the patch is active, complete required restarts through the approved process, and rescan or perform equivalent verification. This can identify failed installations, missed targets, and running components that still use the vulnerable code.

Study tip: Deployment success and effective remediation are different checkpoints.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Active-state checks and rescanning confirm that the intended fix is actually effective rather than merely downloaded or reported as installed.

B: Some fixes are inactive until restart, so installation completion alone may leave the running system vulnerable despite the successful job status.

C: Placing a package on a share does not demonstrate installation, activation, or removal of the vulnerable condition on any target server.

D: A purchase or entitlement record establishes access to software, not whether the patch changed the security state of the affected servers.

## SEC-Q181

A critical business application cannot accept a tested security patch until its vendor fixes a compatibility problem. The risk owner approves temporary continued operation. Which documentation BEST supports responsible handling of the exception?

- A. Record the owner, justification, compensating controls, review date, and remediation condition
- B. Delete the vulnerability from all tracking systems until the vendor contacts IT
- C. Mark the patch as installed because the risk owner approved the delay
- D. Leave a permanent unassigned note that the application is business critical

Answer: A

An approved exception is a managed decision to operate with residual risk under stated conditions. It should identify responsibility, rationale, interim protection, and a review or expiration trigger. The vulnerability remains open or tracked as an exception until verified remediation or another approved disposition actually changes its status.

Study tip: An exception needs accountability and a review trigger; approval does not install a fix.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: These details make the exception accountable, describe how exposure is limited, and establish when continued acceptance must be reconsidered.

B: Removing the record hides an unresolved condition and leaves no reliable owner, review schedule, or basis for confirming eventual remediation.

C: Approval to tolerate residual risk does not change the technical patch state, so reporting the patch as installed would be inaccurate.

D: Business importance explains a constraint but does not establish accountable acceptance, compensating protection, or a time to revisit the unresolved issue.

## SEC-Q182

An industry sharing group reports exploitation of a specific remote-access appliance release. What should the vulnerability team do FIRST to determine whether this advisory requires action in its own environment?

- A. Assume no exposure because the advisory came from outside the company
- B. Block every IP address owned by the appliance manufacturer's customers
- C. Replace all employee passwords before checking whether the appliance is deployed
- D. Compare the affected products and versions with its asset inventory

Answer: D

Threat information becomes actionable when related to the organization's assets and deployment context. Matching the product and affected releases against inventory establishes initial relevance. The team can then confirm applicability, assess exposure and evidence of exploitation, and implement the appropriate remediation or incident response rather than treating every advisory identically.

Study tip: Connect intelligence to your assets before deciding the response.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://github.com/cisagov/kev-data|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: External intelligence can describe vulnerabilities in deployed products; its relevance depends on evidence and asset matching, not merely where it originated.

B: Broad blocking is not grounded in the advisory's affected assets or evidence and could disrupt unrelated legitimate communication without addressing local exposure.

C: Password resets may be appropriate in some incidents, but they do not establish whether this product-specific vulnerability affects the organization.

D: Inventory matching establishes whether the organization operates potentially affected components, which is necessary before assigning a targeted vulnerability response.

## SEC-Q183

A vulnerability scan reports several possible paths into a test environment. Management wants to know whether an authorized tester can actually combine weaknesses to reach a designated business objective within agreed boundaries. Which activity BEST answers that question?

- A. A new unauthenticated scan with all verification checks disabled
- B. A software license reconciliation based only on purchase records
- C. A scoped penetration test with explicit rules of engagement
- D. An annual survey asking users whether systems seem secure

Answer: C

A penetration test evaluates whether identified or discovered weaknesses can produce meaningful access or impact within an authorized scope. It complements a vulnerability scan, which primarily identifies possible weaknesses. Clear objectives and rules of engagement define what may be tested and how evidence should be obtained without exceeding the agreed boundaries.

Study tip: Scanning identifies possible weaknesses; penetration testing can validate their practical impact.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Reducing verification does not establish exploitability or chained business impact and would provide less confirmation of the original potential findings.

B: License reconciliation addresses entitlement and inventory accuracy, but it does not demonstrate whether technical weaknesses can be combined to reach the objective.

C: Penetration testing can validate exploitability and chained impact under agreed authorization, objectives, and limits rather than stopping at potential findings.

D: User perceptions can inform awareness planning, but they do not test the stated technical attack paths or demonstrate access to the objective.

## SEC-Q184

An analyst sees a vulnerability record with both a CVE identifier and a CVSS score. Which interpretation is correct?

- A. CVE identifies the vulnerability record; CVSS expresses technical severity using defined metrics
- B. CVE gives the business loss estimate; CVSS names the affected vendor
- C. CVE assigns the incident owner; CVSS establishes the organization's risk acceptance
- D. CVE proves exploitation occurred locally; CVSS confirms the installed patch version

Answer: A

CVE provides a consistent identifier for a vulnerability record so different tools and organizations can refer to the same issue. CVSS provides a structured expression of technical severity. Neither alone establishes local compromise, remediation status, or business priority, which require additional evidence about the organization's environment.

Study tip: An identifier tells you which issue; a severity score helps describe its technical characteristics.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://www.first.org/cvss/v4.0/specification-document|https://www.cve.org/Resources/Media/Archives/OldWebsite/about/faqs.html

A: A CVE identifier provides a shared reference to a vulnerability record, while CVSS describes severity through a standardized scoring framework.

B: CVE is an identifier rather than a financial estimate, and CVSS is a scoring system rather than a vendor naming scheme.

C: Incident ownership and risk acceptance are organizational decisions; they are not assigned automatically by vulnerability identifiers or technical severity scores.

D: Neither a vulnerability identifier nor a severity score is evidence of local exploitation or verification that a specific system is patched.

## SEC-Q185

An unpatched application has a temporary exception. The approved compensating control permits access only from a dedicated administration subnet. The firewall rule was deployed. Which TWO checks BEST validate that the control works as intended? (Select TWO.)

- A. Use the number of firewall interfaces as proof of network isolation
- B. Close the underlying vulnerability because one network rule was created
- C. Test from a disallowed subnet and verify the service is blocked with supporting logs
- D. Test that an authorized administration host can still reach the required service
- E. Check only that the firewall rule has a descriptive name

Answer: C|D

Validation should demonstrate both the required permitted behavior and the prohibited behavior. Testing only one side can miss an overly broad rule or an accidental outage. Logs provide supporting evidence of enforcement. Because this is a compensating measure, the application vulnerability and its temporary exception still require review and eventual disposition.

Study tip: Test both allowed and denied paths when verifying an access restriction.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Interface count does not establish effective access restrictions and cannot substitute for examining and testing the permitted and blocked communication paths.

B: A compensating control limits exposure but does not remove the application flaw; the unresolved vulnerability must remain accurately tracked.

C: A negative-path test and logs demonstrate that the restricted source cannot reach the service, directly validating the intended exposure reduction.

D: An authorized-path test confirms the compensating control preserves the specific operational access allowed by the exception rather than simply breaking the service.

E: A meaningful name aids administration but does not prove that rule order, source matching, routing, and service restrictions produce the intended behavior.

## SEC-Q186

A security team wants one rule to connect a VPN login, an endpoint process event, and a privileged directory change involving the same user. Which platform is BEST suited to collect and correlate these events?

- A. A security information and event management platform
- B. An asset inventory system recording host owners and installed application names
- C. A vulnerability scanner assessing patch levels during a weekly maintenance window
- D. A standalone network intrusion sensor receiving traffic from one switch

Answer: A

A SIEM collects events from multiple systems and relates them using common fields such as users, hosts, and timestamps. It can therefore identify activity that appears ordinary in one log but significant in combination. Useful results depend on reliable ingestion, consistent field handling, and appropriately tuned correlation rules.

Study tip: Cross-source event correlation is a central SIEM use case.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A SIEM centralizes events from multiple sources and applies correlation logic to identify related activity across systems and accounts.

B: An inventory supplies valuable context but does not by itself correlate time-ordered VPN logins, process execution, and privileged directory changes into a security event.

C: A scanner identifies possible configuration or software weaknesses, rather than correlating this sequence of operational events from the three distinct systems.

D: A network sensor can detect traffic patterns at its observation point but does not inherently ingest endpoint process and directory audit events for this correlation.

## SEC-Q187

An approved vulnerability scanner repeatedly triggers reconnaissance alerts during its scheduled assessment. The team has verified the source address, scan window, and target scope. How should it BEST reduce this noise while preserving detection of unexpected scans?

- A. Disable the reconnaissance detection rule across the whole organization
- B. Trust all traffic from the scanner subnet regardless of source or destination
- C. Raise the threshold until no reconnaissance alerts occur during normal operation
- D. Apply a narrow exception for the verified scanner, schedule, and approved targets

Answer: D

Alert tuning should reflect the verified reason an event is expected. Limiting the exception by source, window, and target retains coverage for deviations from the authorized scan. The exception should also be reviewed when the scanner or schedule changes; broad suppression sacrifices detection beyond the known benign activity.

Study tip: Suppress the verified pattern, not the entire behavior category.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Global suppression would remove visibility into unauthorized scans as well as the known assessment, exceeding the verified reason for the noise.

B: Subnet-wide trust is broader than the verified scanner and assessment scope, allowing unrelated activity to escape the intended monitoring.

C: A very high threshold can conceal slower unauthorized scanning and does not make use of the specific context already verified by analysts.

D: A scoped exception suppresses expected activity while keeping alerts for other sources, times, and targets that could indicate unauthorized scanning.

## SEC-Q188

A managed switch sends an unsolicited notification to the monitoring system immediately when an interface changes state. Which monitoring mechanism is this?

- A. A scheduled SNMP polling request
- B. A DNS zone transfer
- C. A vulnerability scanner's authenticated audit
- D. An SNMP trap

Answer: D

A trap is a device-generated SNMP notification sent when an event occurs. Polling instead has the manager periodically request values. Both can support monitoring, but the unsolicited event direction distinguishes this case. The monitoring design should also consider reliable receipt, filtering, and secure SNMP configuration.

Study tip: Ask who initiates the message: the device sends a trap; the manager initiates polling.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Polling starts with a manager request for device information; this scenario explicitly describes an unsolicited notification initiated by the switch.

B: A zone transfer distributes DNS record information between servers and does not report a switch interface-state event to a monitoring manager.

C: An authenticated audit queries configuration or vulnerability information; it is not the event-driven switch notification described in this scenario.

D: An SNMP trap is a device-initiated notification about an event, so the manager does not have to request that specific update first.

## SEC-Q189

A network team must identify which internal host sent the most data to an external destination overnight. It has flow records with source, destination, time, and byte counts, but no packet payloads. What can it determine MOST directly?

- A. The largest observed transfer by source and destination during that period
- B. The plaintext password used inside an encrypted application session
- C. The exact confidential document text contained in the transfer
- D. The specific keystrokes entered into the sending application

Answer: A

Flow records are useful for identifying communication patterns and transfer volume without storing full packets. They can direct investigators toward a host and time window, but they do not establish the exact contents of a transfer. Additional endpoint, application, or appropriately available packet evidence is needed to investigate content.

Study tip: Flow telemetry describes who communicated, when, and how much; it is not packet content.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Flow metadata includes endpoints, timestamps, and volume, allowing the team to aggregate transfers and identify the largest observed conversation.

B: Flow summaries do not decrypt application sessions and cannot disclose plaintext credentials merely from addresses, timestamps, ports, and byte counts.

C: Byte counts and connection metadata do not contain the application payload, so they cannot reveal the actual text of transferred documents.

D: Flow records summarize network communication rather than user input and do not capture the endpoint's keystrokes or application interaction history.

## SEC-Q190

A vendor-managed appliance does not allow third-party software installation. It can export syslog and supports authenticated management queries. Which monitoring approach BEST fits these limitations?

- A. Classify the appliance as unmonitorable and discard its exported logs
- B. Install an endpoint agent by replacing the appliance operating system
- C. Use agentless collection of its supported logs and management telemetry
- D. Monitor only nearby workstations and assume their events describe the appliance

Answer: C

Agentless collection is appropriate when an agent cannot be installed but supported telemetry is available. Syslog and authenticated queries can expose events and state while respecting vendor constraints. The team should document visibility limits because remote interfaces may not provide the same process-level detail as a full endpoint agent.

Study tip: Choose collection methods the target supports, and document what they cannot observe.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The appliance explicitly offers logs and authenticated telemetry, so abandoning monitoring ignores available sources of security and operational visibility.

B: Replacing the operating system exceeds the stated support constraint and can break the appliance instead of using its available monitoring interfaces.

C: Agentless monitoring uses the appliance's supported interfaces, providing available visibility without installing software that violates its management constraints.

D: Workstation events may provide indirect context but do not replace the appliance's own supported logs and management-state information.

## SEC-Q191

An organization wants repeatable automated checks against a published configuration benchmark using standardized, machine-readable security content. Which capability BEST supports that goal?

- A. A manual administrator attestation that each system follows the benchmark
- B. A SCAP-compatible assessment tool using the relevant benchmark content
- C. A vulnerability feed containing product names and newly disclosed flaw descriptions
- D. A SIEM rule that counts successful and failed login events

Answer: B

Security benchmarks specify expected configurations, and SCAP-compatible tooling can automate applicable checks using standardized content. The organization still needs to choose an appropriate benchmark and manage justified exceptions. Automated results provide evidence of assessed settings, rather than a universal guarantee that every security requirement is satisfied.

Study tip: A benchmark states the settings; assessment tooling checks actual systems against them.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Attestation can supplement assurance, but it does not meet the requirement for repeatable automated evaluation using standardized machine-readable security assessment content.

B: SCAP supports standardized security configuration assessment content, enabling tools to evaluate applicable settings consistently against defined benchmark checks.

C: A vulnerability feed informs risk assessment but does not by itself execute machine-readable configuration benchmark checks against the organization's deployed systems.

D: Login correlation can reveal authentication patterns but does not provide the requested standardized assessment of actual configuration settings against machine-readable benchmark content.

## SEC-Q192

Security logs must remain available for later investigations after leaving the fast SIEM search tier. Which archival design BEST preserves their evidentiary value while reducing storage cost?

- A. Export logs to a shared folder where every employee can edit them
- B. Use access-controlled archival storage with retention enforcement and integrity verification
- C. Delete raw logs immediately after an alert dashboard is generated
- D. Retain only a screenshot of the SIEM's total daily event count

Answer: B

Archiving moves older logs to a suitable retention tier without discarding their investigative value. Access restrictions, retention controls, and integrity verification help preserve dependable evidence. The team should also verify retrieval and maintain needed parsing context so archived data remains usable when an incident is discovered long after it occurred.

Study tip: An archive must preserve useful, trustworthy records, not merely a summary count.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Broad write access exposes historical records to alteration or deletion and undermines confidence that retrieved logs reflect the original events.

B: Controlled storage, enforced retention, and integrity checks preserve retrievable records while reducing the ability to alter or prematurely delete archived evidence.

C: Dashboards summarize selected information and cannot reliably replace the detailed underlying records needed when a later investigation asks different questions.

D: An aggregate screenshot omits underlying event details needed for timelines, identity correlation, and investigation of specific actions after the fact.

## SEC-Q193

A dashboard suddenly shows zero authentication failures across 500 servers. At the same time, the log collector's input count falls to zero and agents report delivery errors. Which interpretation is MOST defensible?

- A. The organization has conclusively eliminated password-based attacks
- B. All 500 servers simultaneously changed their authentication policies successfully
- C. Authentication monitoring has a collection gap, so the quiet dashboard is not evidence of improvement
- D. The failure count proves that every account is currently disabled

Answer: C

Monitoring depends on a functioning telemetry pipeline. When collection stops, zero alerts or failures may describe missing data rather than safer systems. The team should investigate transport, collector health, and backlog while maintaining visibility through available alternate sources. Data-quality signals are necessary to interpret security dashboards correctly.

Study tip: No events can mean no visibility; monitor the monitoring pipeline.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A drop in collected data prevents that conclusion; the dashboard can appear quiet because events are missing rather than because attacks stopped.

B: No policy-change evidence is provided, and agent delivery errors directly support a collection issue rather than successful coordinated policy changes.

C: The collector and agent symptoms indicate missing telemetry, making the absence of dashboard failures unreliable as a measure of actual authentication activity.

D: Disabled-account status requires account-state evidence; zero incoming events and delivery errors do not establish that all accounts have been disabled.

## SEC-Q194

An antivirus alert quarantined a suspicious executable on a workstation. The incident ticket will be closed only after the team validates the automated response. Which TWO checks BEST support closure? (Select TWO.)

- A. Close the ticket as soon as the dashboard displays the word quarantine
- B. Confirm the quarantine action succeeded on the affected endpoint
- C. Review relevant endpoint activity for continued execution or related detections
- D. Use the absence of further help desk complaints as proof that the system is clean
- E. Add the executable to the organization-wide allowlist before validation

Answer: B|C

Automated containment needs confirmation at the affected system. Verifying the quarantine and reviewing related behavior helps distinguish a completed response from a failed action or a broader compromise. The scope of follow-up should reflect the evidence and incident criteria; a single successful file action does not establish that every related risk has been resolved.

Study tip: Validate the response result and check for related activity before closing an alert.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A dashboard label alone may represent a requested action and does not establish endpoint success or resolution of related malicious activity.

B: Successful endpoint quarantine verifies that the reported response actually restricted the detected file rather than merely creating an alert or pending command.

C: Follow-up activity checks help identify persistence, additional artifacts, or continued execution that would make file quarantine insufficient for closing the case.

D: Users may not observe malicious background activity, so a lack of complaints cannot confirm quarantine completion or exclude continued execution and related detections.

E: Allowlisting the suspect file reverses protection without confirming it is benign and can permit the same activity on other systems.

## SEC-Q195

A firewall uses the FIRST matching rule. Its rules are: 1) allow TCP from any source to 192.0.2.20 port 22; 2) deny TCP from any source to 192.0.2.20 port 22; 3) deny all. The requirement is to permit SSH only from 198.51.100.10. Which change BEST meets it?

- A. Change rule 2 to permit all TCP destinations from any source
- B. Add a new deny rule below rule 3 without changing rule 1
- C. Move the existing deny-all rule to the top without adding an exception
- D. Restrict rule 1's source to 198.51.100.10 and retain rule 2

Answer: D

First-match processing means an earlier broad allow prevents later rules from restricting that traffic. Making the initial permission specific to the authorized source lets all other SSH attempts reach the deny. The rule set must be tested for both the allowed administrator and denied sources after the approved change.

Study tip: Read firewall rules in their stated processing order before evaluating later restrictions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: This creates an additional broad permission and leaves the original any-source SSH access intact rather than restricting it to the administrator.

B: The broad allow still matches all SSH traffic first, so a later deny cannot correct the exposure under first-match evaluation.

C: A first-position deny-all blocks the authorized administrator as well, failing the requirement to preserve SSH access from the specific source.

D: The specific source is allowed first, while other SSH sources fall through to the deny rule under the stated first-match behavior.

## SEC-Q196

An application transmits directory credentials through unencrypted LDAP. The team must protect the connection and authenticate the directory server. Which change BEST meets both goals?

- A. Move plaintext LDAP to an unusual TCP port without enabling TLS
- B. Encode the LDAP password with Base64 before sending it over plaintext
- C. Encrypt the application backup while leaving directory traffic unchanged
- D. Configure LDAP over validated TLS using a supported secure connection method

Answer: D

Secure protocol use requires the actual protected transport and appropriate certificate validation. An application can use a supported LDAP TLS method, such as LDAPS or correctly required StartTLS, with server identity checks. Merely selecting a different port or encoding a password does not provide encrypted, authenticated communication.

Study tip: A secure port number is not enough; verify TLS and certificate validation are actually in use.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: Changing a port may alter discoverability but does not encrypt credentials or authenticate the server carrying the directory exchange.

B: Base64 is reversible encoding rather than transport encryption and does not provide authenticated protection against interception or server impersonation.

C: Backup encryption protects stored copies but leaves the live LDAP credential exchange exposed on its unchanged unencrypted connection.

D: TLS provides encrypted transport and server authentication when the application validates the directory server's certificate and expected identity correctly.

## SEC-Q197

A network security device is inline and configured to drop packets that match a known exploit signature. Which capability is being used?

- A. Offline forensic disk imaging
- B. Asset classification based on data ownership
- C. Signature-based intrusion prevention
- D. Passive intrusion detection without response integration

Answer: C

The device both inspects a known pattern and takes an inline blocking action, which describes signature-based intrusion prevention. A signature can be effective for recognized patterns but needs maintenance and tuning. Its presence does not imply detection of every variation or unknown attack against the protected service.

Study tip: IDS observes and alerts; an inline IPS can enforce a blocking decision.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: Disk imaging acquires storage evidence for analysis and is unrelated to a network appliance dropping traffic during live communication.

B: Classification assigns protection needs and accountability to assets or information; it does not describe inline packet blocking based on exploit signatures.

C: An inline IPS can compare traffic with known patterns and block matching packets, combining detection with an active prevention action.

D: A passive IDS can alert on matching traffic but cannot directly drop packets passing through a separate production path without another enforcement mechanism.

## SEC-Q198

A company uses a headquarters web proxy to block prohibited content categories. Remote laptops browse directly through home networks without a corporate tunnel, bypassing that proxy. Which change BEST extends category filtering to those laptops?

- A. Replace the office printer firewall rule with a web browsing rule
- B. Add more category rules only to the unreachable headquarters proxy
- C. Deploy a managed endpoint web-filtering agent or enforced cloud filtering path
- D. Change the headquarters proxy's hostname without updating client routing

Answer: C

A filtering policy works only where traffic reaches an enforcement point. Remote devices need a managed agent or an enforced route to an appropriate filtering service. Central policy administration may remain the same, but coverage must include off-network use and prevent straightforward bypass of the chosen enforcement mechanism.

Study tip: Follow the traffic path; a control cannot filter traffic that bypasses it.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A printer rule at the office does not control the offsite laptops' direct home-network traffic and cannot supply the missing enforcement path.

B: Additional rules have no effect on traffic that does not pass through the proxy, so the remote browsing gap remains.

C: An endpoint or enforced cloud path can apply web policy while devices are offsite, addressing the routing gap that bypasses headquarters.

D: Renaming the proxy does not cause offsite browsing traffic to traverse it or introduce another enforcement point on remote laptops.

## SEC-Q199

A Linux service has ordinary filesystem permission to read a configuration file, but access fails. The audit log reports an SELinux denial involving an incorrect file label. What is the BEST corrective approach?

- A. Disable SELinux enforcement permanently on every server in the environment
- B. Verify and restore the intended label and narrowly correct policy if needed
- C. Change the service's log rotation interval and leave the label unchanged
- D. Give every user full filesystem permissions on the affected directory

Answer: B

SELinux can deny access even when ordinary Unix permissions permit it. The audit message and incorrect label identify the relevant policy layer. Restoring the intended context, or making a reviewed narrow policy adjustment when required, fixes the specific problem while preserving the broader mandatory access protections.

Study tip: When normal permissions look correct, examine the mandatory access-control context and denial evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Environment-wide disablement removes protection far beyond the affected label problem and is not a targeted correction for the reported denial.

B: SELinux evaluates mandatory policy beyond ordinary permissions; correcting the intended label or narrow policy addresses the cause without broadly removing enforcement.

C: Log rotation timing does not correct the file's SELinux context or the mandatory access decision that is denying the service.

D: Broader discretionary permissions do not resolve a mandatory SELinux label denial and unnecessarily expose the directory to other local users.

## SEC-Q200

Assume a valid applicable DMARC policy has been discovered. An inbound message shows From: billing@retail.example. Its DKIM signature passes for attacker.example, and SPF passes for an attacker.example envelope sender. Neither domain aligns with retail.example. What should a standards-compliant DMARC evaluation conclude?

- A. DMARC fails only when both SPF and DKIM cryptographic signatures are invalid
- B. DMARC passes because successful SPF and DKIM results compensate for missing alignment
- C. DMARC passes whenever any domain supplies a valid DKIM signature
- D. DMARC fails because neither passing authentication result aligns with the visible From domain

Answer: D

SPF and DKIM can authenticate domains that differ from the address a recipient sees. DMARC addresses that gap by requiring alignment between the visible From domain and at least one passing SPF or DKIM identity. This message has neither. The receiver's disposition additionally depends on applicable policy and receiver handling.

Study tip: A passing SPF or DKIM result must align with the visible From domain for DMARC.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://www.rfc-editor.org/rfc/rfc9989.html|https://www.rfc-editor.org/rfc/rfc7208.html|https://www.rfc-editor.org/rfc/rfc6376.html

A: SPF is not a message-signature mechanism, and DMARC can fail despite passing authentication when neither authenticated domain aligns with the visible From domain.

B: Combining two unrelated authenticated identities does not replace alignment; at least one passing mechanism must authenticate a domain aligned with the visible From domain.

C: A valid signature for an unrelated domain can be present on spoofed mail; DMARC adds alignment with the visible From domain.

D: DMARC requires a passing SPF or DKIM result aligned with the visible From domain; authentication of an unrelated domain does not satisfy alignment.

## SEC-Q201

A domain owner wants receiving mail servers to check whether the connecting outbound mail server is authorized to send for the envelope sender's domain. Which mechanism MOST directly supplies that authorization information?

- A. Domain-based Message Authentication, Reporting, and Conformance
- B. Sender Policy Framework
- C. A DNS mail exchanger record
- D. DomainKeys Identified Mail

Answer: B

SPF lets a receiving server check the connecting sender against the authorization policy associated with the envelope sender's domain. DKIM instead authenticates a signature applied to message content. SPF alone does not guarantee the visible From address is genuine, which is why alignment-based controls such as DMARC matter.

Study tip: SPF checks the sending infrastructure; DKIM checks a message signature.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://www.rfc-editor.org/rfc/rfc7208.html|https://www.rfc-editor.org/rfc/rfc7489.html|https://www.rfc-editor.org/rfc/rfc6376.html

A: DMARC evaluates alignment with the visible From domain and communicates policy, while the underlying list of authorized sending infrastructure is provided through SPF.

B: SPF publishes authorized sending infrastructure for a domain so receivers can compare the connecting sender against the envelope sender's domain policy.

C: An MX record identifies servers that receive mail for a domain; it does not define which connecting outbound servers are authorized for SPF evaluation.

D: DKIM verifies a domain's cryptographic signature over selected message content; it does not primarily list the connecting servers authorized for an envelope domain.

## SEC-Q202

A web server's approved configuration file changes outside any maintenance window. The security team wants an alert when protected file content or attributes differ from an approved baseline. Which control BEST fits?

- A. A periodic vulnerability scan that inventories service versions
- B. File integrity monitoring
- C. A backup job that copies the current configuration file without comparison
- D. A network intrusion signature inspecting inbound HTTP requests

Answer: B

File integrity monitoring detects changes to selected files or attributes compared with a known approved state. An alert requires context because legitimate maintenance can also change files. Linking findings to change records helps the team distinguish expected updates from unauthorized modifications while retaining evidence of what changed.

Study tip: Integrity monitoring detects a change; investigation determines whether that change was authorized.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Version scanning can identify known software vulnerabilities but does not necessarily compare the protected configuration file's contents or attributes against its approved baseline.

B: File integrity monitoring compares protected files or attributes against a trusted baseline and can alert on unexpected changes outside approved activity.

C: A backup can preserve a copy but, without baseline comparison and alerting, does not itself detect or report that the protected file changed unexpectedly.

D: A network signature can detect matching traffic patterns but does not directly monitor whether a local configuration file changed outside authorized maintenance.

## SEC-Q203

A company must block copying documents labeled Confidential onto removable USB storage while permitting approved public documents. Which endpoint control BEST implements this requirement?

- A. A network DLP sensor that observes only traffic leaving the internet gateway
- B. Full-disk encryption on the laptop without a removable-media policy
- C. A rule that blocks every removable-storage device regardless of document classification
- D. A DLP policy that evaluates document classification and the removable-media destination

Answer: D

The rule depends on both what the data is and where it is going. Endpoint DLP can inspect a classification label or other content criteria and enforce restrictions for removable storage. A blanket USB ban would not meet the stated need to allow approved public documents, while network-only controls miss the local transfer.

Study tip: DLP decisions combine sensitive data identification with the action or destination.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A gateway sensor can inspect traffic that crosses its network path, but a local USB copy bypasses that path and requires endpoint enforcement.

B: Encryption protects the laptop's stored data from offline access but does not distinguish authorized public copies from prohibited Confidential transfers by a logged-in user.

C: A blanket device block prevents the required approved public-document transfers as well, so it does not implement the requested classification-based selective control.

D: Content- or label-aware DLP can combine the data classification with the destination, enforcing selective restrictions while allowing permitted public transfers.

## SEC-Q204

A laptop successfully authenticates at a wired access port but lacks required security updates. Policy requires it to reach patch services while preventing access to production applications. What should NAC do?

- A. Disconnect every device on the switch regardless of its compliance status
- B. Place the laptop in a remediation network with access only to approved update services
- C. Grant full production access because successful authentication proves patch compliance
- D. Give the laptop the same unrestricted access as the network management servers

Answer: B

NAC can make access decisions using both identity and device posture. The user or device may authenticate correctly while failing a required health check. A restricted remediation path lets the laptop obtain updates without receiving production access, after which compliance can be reassessed before broader connectivity is granted.

Study tip: Authentication and device compliance are separate inputs to network access.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A switch-wide disconnection disrupts compliant devices and is broader than the targeted posture problem identified on the single laptop.

B: A remediation network limits production exposure while retaining the connectivity needed to bring the authenticated but noncompliant device into policy compliance.

C: Authentication establishes identity, not device health; the missing updates remain relevant to the network's separate authorization and posture requirements.

D: Elevated network access does not remediate missing patches and conflicts with the explicit requirement to prevent access to production applications.

## SEC-Q205

A behavior-analytics system alerts when an accountant downloads far more records than usual. The accountant is using valid credentials. What is the MOST appropriate interpretation?

- A. The unusual behavior warrants investigation even though authentication succeeded
- B. The anomaly should be treated as an approved baseline change before contacting the owner
- C. The download is authorized solely because the credentials were accepted
- D. The alert conclusively proves the accountant deliberately stole information

Answer: A

A valid login does not establish that subsequent behavior is appropriate. User behavior analytics highlights unusual activity relative to a baseline, but the alert needs investigation of work context, access history, and other evidence. The same signal could arise from legitimate work, a compromised account, or intentional misuse.

Study tip: An anomaly is a lead; establish context before assigning cause or intent.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Behavior analytics identifies deviations from expected activity, which may reflect compromise, misuse, or legitimate work that needs contextual verification.

B: Automatically accepting the new pattern skips validation of its business purpose and could normalize compromised-account activity or misuse into the expected baseline.

C: Successful authentication identifies an account session but does not establish that every action is legitimate, necessary, or performed by the intended person.

D: An anomaly is an investigative lead, not proof of intent; legitimate assignments and account compromise can produce similar volume changes.

## SEC-Q206

An attacker used a valid account to launch a suspicious process and send data to a newly observed domain. The team wants endpoint process visibility and correlation with email and identity alerts. Which TWO capabilities BEST meet these goals? (Select TWO.)

- A. EDR telemetry showing process ancestry, file activity, and response actions
- B. XDR correlation across endpoint, identity, and email security telemetry
- C. A vulnerability scanner that reports the endpoint's missing software patches
- D. A centralized password manager without endpoint or security-telemetry integrations
- E. A perimeter flow exporter that records addresses, ports, and byte counts

Answer: A|B

EDR supplies endpoint-specific investigation detail such as process relationships and file activity. XDR can connect endpoint evidence with supported identity, email, and other security sources. The value depends on actual integrations and telemetry quality; product names alone do not guarantee every source is covered or every attack is detected.

Study tip: EDR focuses on endpoint behavior; XDR extends correlation across supported security domains.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: EDR provides detailed endpoint behavior and investigation capabilities, allowing analysts to examine the suspicious process and take supported endpoint response actions.

B: XDR can relate signals across supported security layers, connecting the endpoint behavior with identity and email context in a broader investigation.

C: Patch assessment can identify exploitable weaknesses, but it does not provide the requested runtime process ancestry or integrated email and identity alert correlation.

D: A password manager protects stored credentials, but without telemetry integrations it does not provide the required process investigation or cross-domain detection correlation.

E: Flow metadata helps track communication volume and endpoints but does not include process ancestry or inherently correlate endpoint, email, and identity security alerts.

## SEC-Q207

An employee transferred from payroll to inventory management. The new role was assigned, but payroll permissions remain. Which action BEST addresses the access problem?

- A. Keep both roles permanently because the employee once required each one
- B. Replace the employee's password while preserving every permission assignment
- C. Have the appropriate owners review access and remove permissions no longer justified by the new role
- D. Disable audit logging for payroll actions performed by transferred employees

Answer: C

Provisioning a new role is only part of a transfer. Access owners should attest that retained permissions match current duties and remove obsolete grants. This prevents privilege creep while allowing documented exceptions for genuine transitional needs. Authentication changes alone do not correct excessive authorization.

Study tip: A mover needs both new access and removal of access that no longer has a business reason.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Historical need does not establish current authorization; retaining obsolete access creates privilege accumulation inconsistent with the employee's new responsibilities.

B: Changing a password affects authentication credentials, not authorization scope, so the unnecessary payroll permissions would remain available after the reset.

C: A role change should trigger access review and revocation of obsolete grants, preventing privilege accumulation while preserving current authorized duties.

D: Suppressing audit records reduces accountability and does not remove the obsolete access that the role transition left behind.

## SEC-Q208

A research portal permits access only when the user is assigned to the project, the document's classification is permitted for that user, the device is compliant, and the request occurs during approved hours. Which access-control model BEST describes this policy?

- A. Attribute-based access control
- B. Role-based access control using only a single job-title group
- C. Discretionary access control based only on the file owner's choices
- D. An unrestricted access model after initial authentication

Answer: A

ABAC can combine attributes from several sources to evaluate a request, including subject membership, resource classification, device posture, and time. Roles may be one useful attribute, but a single role assignment does not express every stated condition. The distinguishing feature is the contextual policy decision using these attributes together.

Study tip: When several subject, resource, and environment conditions combine, consider ABAC.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/207/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: ABAC evaluates attributes of the subject, resource, device, and environment together, matching the project's membership, classification, compliance, and time conditions.

B: A job-title role alone does not capture the stated document, device, project, and time conditions that jointly determine authorization.

C: The policy describes centrally evaluated contextual attributes rather than relying only on an individual file owner's permission grants.

D: The portal explicitly checks multiple authorization conditions for access, so it is not granting unrestricted access merely because the user authenticated.

## SEC-Q209

A classified system compares each user's clearance with file labels. Ordinary file owners cannot override the centrally enforced classification policy. Which access-control model is being used?

- A. Mandatory access control
- B. Discretionary access control
- C. Rule-based access control determined only by source network and time
- D. Role-based access control using job-function group membership

Answer: A

Mandatory access control applies a centrally enforced policy that ordinary owners cannot override, often using security labels and user clearances. This differs from discretionary control, where an owner can grant permissions within the system's rules. The labels and non-discretionary enforcement are the key clues in this scenario.

Study tip: A resource owner's inability to override classification rules points to mandatory control.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: MAC enforces centrally defined security labels and clearances, preventing ordinary owners from overriding the classification-based access rules.

B: DAC allows resource owners to determine permissions within system limits, unlike the centrally enforced labels that ordinary owners cannot override here.

C: Source and schedule rules control access using network or time conditions, whereas the scenario explicitly relies on centrally enforced security labels and clearances.

D: RBAC grants access through assigned organizational roles; the central comparison of security labels and clearances, without owner override, identifies mandatory control here.

## SEC-Q210

A collaboration system lets a document's owner choose which coworkers may read or edit that document. No central classification label determines these grants. Which access-control model is MOST directly illustrated?

- A. Mandatory access control based on classification labels
- B. Discretionary access control
- C. Role-based access control determined exclusively by centrally assigned job roles
- D. Attribute-based control evaluating device compliance and request location

Answer: B

The owner's discretion over which coworkers receive read or edit rights is the defining feature of discretionary access control. The system can still impose broad limits, but the individual grants are controlled by the owner. Identity proofing and authentication are separate from the permission-assignment model used here.

Study tip: Identify who decides access: the owner, a central policy, a role, or evaluated attributes.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: MAC relies on centrally enforced policy that ordinary owners cannot override; the scenario explicitly places these decisions with the document owner.

B: DAC permits the resource owner to make access decisions for the resource, matching the owner's ability to choose readers and editors.

C: RBAC bases permissions on roles administered for organizational functions, whereas this scenario gives document owners discretion to choose particular readers and editors.

D: ABAC uses policy conditions across attributes to decide access; the scenario instead emphasizes the document owner's individual permission grants without those contextual conditions.

## SEC-Q211

Which login method uses TWO different authentication factor categories?

- A. A memorized password plus a memorized personal identification number
- B. Two passwords entered into different fields on the same login page
- C. A fingerprint scan plus a facial biometric scan
- D. A memorized password plus a code generated by an assigned hardware token

Answer: D

Multifactor authentication requires distinct factor categories, rather than simply multiple prompts. A password is a knowledge factor, and a code from an assigned hardware token demonstrates possession. Two passwords or two biometric comparisons may provide additional checks, but they do not satisfy the specific requirement for two different categories.

Study tip: Count factor categories, not the number of fields or prompts.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html

A: Both secrets are knowledge factors; requiring two values from the same factor category does not make the process multifactor authentication.

B: Both values are knowledge factors despite being separate secrets or fields, so the method does not combine different authentication factor categories.

C: Both checks use biometric characteristics, so they remain within the something-you-are category rather than establishing two distinct factor categories.

D: The password is something the user knows, while the assigned token demonstrates possession, combining knowledge and possession factor categories.

## SEC-Q212

Employees have been tricked into entering passwords and time-based one-time codes into imitation login pages. The organization wants an authentication method cryptographically tied to the legitimate service's identity. Which option BEST addresses this attack?

- A. Use properly deployed FIDO2/WebAuthn security keys or passkeys
- B. Replace six-digit one-time codes with eight-digit one-time codes
- C. Deliver the same type of one-time code through text messages instead of an app
- D. Require a second password known only to the user

Answer: A

Phishing-resistant authentication uses protocol properties that make a response unsuitable for an imitation service. Properly implemented FIDO2/WebAuthn credentials are bound to the relying party identity rather than relying on users to recognize every deceptive page. Enrollment, recovery, and session security still need protection so weaker paths do not undermine the deployment.

Study tip: Phishing resistance comes from binding authentication to the legitimate service, not merely adding another typed secret.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html

A: WebAuthn credentials are bound to the relying party's identity, reducing the ability of an imitation domain to obtain a usable authentication response.

B: Longer codes can change guessing resistance but still allow a user to relay a valid code through a phishing page during its acceptance window.

C: Changing the delivery channel does not prevent a user from relaying a valid code to an imitation login page during its acceptance window.

D: A phishing page can request both passwords, so adding another knowledge secret does not cryptographically bind the authentication to the legitimate service.

## SEC-Q213

A company wants its identity provider to authenticate employees for a SaaS application. The application will trust signed assertions from that provider, and employees should not maintain a separate application password. Which solution BEST matches this design?

- A. Configure SAML federation between the identity provider and the SaaS service
- B. Allow the SaaS application to query an unauthenticated employee directory
- C. Synchronize separate local application passwords through an overnight export
- D. Configure only OAuth access tokens for a background integration account

Answer: A

In SAML federation, the identity provider authenticates the user and issues an assertion that the SaaS service validates under an established trust relationship. This can deliver single sign-on without giving the SaaS provider each employee's directory password. Access rights and application sessions still require their own lifecycle and authorization controls.

Study tip: Federation establishes trust between identity domains; SSO is the resulting user experience.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: SAML federation allows a service provider to trust signed identity assertions from an identity provider, supporting centralized authentication and single sign-on.

B: A directory lookup can retrieve attributes but does not prove that the employee authenticated or establish the required trust in signed identity-provider assertions.

C: Password copying creates a second credential store and synchronization dependency, rather than allowing the SaaS application to validate authentication assertions from the identity provider.

D: OAuth tokens authorize client access to resources, but this option does not implement the specified signed user-authentication assertions and employee single sign-on trust.

## SEC-Q214

A calendar application needs permission to read a user's contacts from another service. The user should approve limited access without revealing the account password to the calendar application. Which mechanism BEST fits?

- A. A SAML login assertion without any contacts-service authorization grant
- B. A client certificate that identifies the calendar application but grants no user permissions
- C. OAuth authorization with a narrowly scoped access token
- D. A password manager that autofills the user's account password into the calendar application

Answer: C

OAuth addresses delegated authorization: a user or other authorized party grants a client limited access represented by a token. Scopes can restrict the permitted operation, such as reading contacts. OAuth alone should not be treated as a complete user-authentication protocol; an authentication layer such as OpenID Connect serves that separate purpose.

Study tip: OAuth answers what a client may access; it is not by itself proof of user identity.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A login assertion can communicate authentication, but by itself it does not establish the client's scoped authorization to call the user's contacts API.

B: Application identity alone does not establish the user's delegation or the permitted contacts operations; the service still needs a scoped authorization decision.

C: OAuth supports delegated authorization through scoped tokens, allowing the application to obtain approved access without receiving the user's account password.

D: Autofill still gives the application the reusable account secret, which conflicts with the requirement to delegate limited access without revealing that password.

## SEC-Q215

A terminated contractor's directory account is disabled, but a SaaS application continues accepting an existing session token. The offboarding requirement is to end current access promptly. Which additional action BEST closes this gap?

- A. Revoke the application's active sessions and relevant tokens through its supported controls
- B. Remove the contractor's display name from the employee directory only
- C. Wait for the contractor to attempt a fresh directory login
- D. Reset the application's public DNS record while leaving tokens valid

Answer: A

Disabling an identity account can stop new authentication without immediately ending sessions already issued by another service. Offboarding therefore needs application-aware revocation of sessions, access grants, and tokens where supported. The process should verify that access actually ended and account for services with delayed synchronization or independent local credentials.

Study tip: Disablement blocks new authentication; existing sessions may need separate revocation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Session and token revocation targets already-established access that may survive directory disablement until the application rechecks identity or the token expires.

B: Changing directory presentation does not invalidate application sessions or tokens and therefore does not stop the contractor's remaining authenticated access.

C: A fresh login would be denied, but the existing application token can remain usable in the meantime, violating the prompt-access termination requirement.

D: DNS changes are not an access-revocation mechanism and could disrupt other users without invalidating the contractor's active application credentials.

## SEC-Q216

An employee reused one strong password on several unrelated services, and one service suffered a credential breach. Which change BEST reduces the chance that a future breach of one service compromises the others?

- A. Rotate the same shared password monthly across all of the services
- B. Use a protected password manager to generate and store unique passwords for each service
- C. Use the same password but select different usernames at each service
- D. Add the same extra character to the reused password on every service

Answer: B

Password uniqueness limits the consequences of one site's credential exposure. A protected password manager helps create and retain distinct secrets without requiring the user to memorize each one. The vault itself must be secured, and MFA should protect accounts where supported; a strong reused password still creates a cross-service dependency.

Study tip: Password strength and password uniqueness solve different problems.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html

A: Regularly rotating a reused value preserves the shared dependency; exposure of the currently valid password can still compromise the other accounts using it.

B: Unique passwords prevent one service's exposed secret from being reused directly elsewhere, while a managed vault makes maintaining those distinct secrets practical.

C: Different usernames may complicate matching slightly, but reused passwords still create linked risk and do not reliably isolate a service's credential breach.

D: Uniformly changing a shared secret preserves cross-service reuse, so exposure of the new value can still affect all accounts using it.

## SEC-Q217

Support technicians occasionally need administrator rights for an approved repair. The company wants those rights to expire after the task instead of remaining available every day. Which implementation BEST meets the requirement?

- A. Give every technician a copy of an untracked shared administrator password
- B. Hide the administrator group from the normal management console
- C. Make all technicians permanent members of the highest privilege group
- D. Use privileged access management to grant approved, time-limited elevation

Answer: D

Privileged access management can issue a task-specific elevation for a defined duration after approval. This reduces standing privilege and can associate actions with the individual technician. The design should ensure permissions actually expire and log the request and use; hiding privileges or sharing a password does not supply equivalent control.

Study tip: Just-in-time access limits when privilege exists; least privilege limits what it permits.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An untracked shared credential undermines accountability and remains reusable unless separately changed, rather than providing automatically expiring individual elevation.

B: Hiding a group changes visibility, not the actual privileges or their duration, so it cannot enforce time-limited access for repairs.

C: Standing membership leaves administrative power available beyond each repair and directly conflicts with the requirement for privileges to expire.

D: Just-in-time elevation provides privileges only for the authorized task window, reducing persistent administrative access while retaining accountability for approved repairs.

## SEC-Q218

A caller says a company phone was lost and requests replacement of the account's MFA factor. The caller knows the employee's public name and job title. Policy allows recovery through established identity verification and requires retiring a lost authenticator. Which TWO actions should the help desk take? (Select TWO.)

- A. Keep the lost authenticator valid indefinitely as a convenience for the user
- B. Complete approved identity verification using independently established evidence or channels
- C. Approve the reset based only on the caller's knowledge of the employee's job title
- D. Send the reset link to any new email address supplied during the same call
- E. After verification, bind the replacement factor and invalidate the lost authenticator

Answer: B|E

Account recovery can become a bypass around strong normal authentication. The help desk should use the approved verification procedure rather than public facts or newly supplied contact details. Once the legitimate user is verified, controlled enrollment of a replacement and invalidation of the lost authenticator restore access without leaving the reported lost factor usable.

Study tip: Protect recovery as carefully as normal login; public knowledge is weak identity evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://pages.nist.gov/800-63-4/sp800-63b.html|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Retaining a factor reported lost leaves an avoidable authentication route active and conflicts with the policy requiring retirement of that authenticator.

B: Recovery must verify the claimant through trusted evidence or channels already established by policy, rather than accepting easily obtained public biographical details.

C: Public organizational information is easily learned by an impersonator and does not provide sufficient verification for changing a high-impact authentication factor.

D: An unverified destination supplied by the claimant can route account recovery to an attacker and bypass the established identity-verification process.

E: Controlled rebinding restores legitimate access while invalidating the lost factor reduces the chance that possession of the missing device enables later authentication.

## SEC-Q219

An alert triggers a workflow that retrieves threat context, checks asset ownership, creates a ticket, and sends the incident to the correct queue through several product APIs. What is this workflow MOST directly demonstrating?

- A. Security orchestration
- B. A configuration benchmark assessment limited to one server
- C. A standalone automation that performs one local file-hash calculation
- D. Log aggregation without response workflow integration

Answer: A

Orchestration connects tools so a security workflow can carry information and actions across them. Individual lookups or ticket operations may be automated, while orchestration coordinates their sequence and dependencies. Reliable integration still needs error handling, consistent identifiers, and appropriate credentials so a failure does not silently interrupt the process.

Study tip: Automation performs a task; orchestration coordinates related tasks across tools.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Orchestration coordinates actions across multiple tools and APIs, turning separate enrichment, ownership, ticketing, and routing tasks into one connected workflow.

B: A single-host benchmark assessment evaluates settings, whereas this workflow coordinates several security and business tools to enrich and route an incoming alert.

C: One local automated action does not demonstrate the cross-tool coordination present in the described enrichment, asset lookup, ticketing, and queue-routing workflow.

D: Aggregation collects records, but the scenario goes further by coordinating lookups, ticket creation, and routing actions through several connected product APIs.

## SEC-Q220

An identity-provisioning job may receive the same approved onboarding event more than once because of retries. A duplicate event must not create extra accounts or duplicate group grants. Which property should the workflow have?

- A. Digital signing of the provisioning script without state reconciliation
- B. Idempotent processing keyed to a stable event or identity identifier
- C. Encrypting event messages in transit without identifying repeated requests
- D. Rate limiting without checking whether the requested account already exists

Answer: B

Retries are normal in distributed integrations, so workflows should safely tolerate repeated events. Idempotent provisioning uses stable identifiers and checks or reconciles desired state instead of blindly creating new resources each time. This improves reliability while avoiding security problems such as orphaned duplicate accounts and untracked access grants.

Study tip: A safe retry should produce the intended state, not multiply its side effects.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Code signing supports script authenticity and integrity, but an authentic script can still create duplicate resources unless its processing handles repeated events correctly.

B: Idempotent handling makes repeated processing converge on the intended state, preventing retries from creating duplicate accounts or repeating unintended side effects.

C: Transport encryption protects event confidentiality and integrity but does not determine whether repeated delivery should create a new account or reuse existing state.

D: Rate limiting controls operation frequency but does not make repeated events safe; duplicate accounts can still be created when retries are eventually processed.

## SEC-Q221

A ticket-enrichment script needs read access to asset records and permission to add notes to incident tickets. What is the BEST authorization design for its API credentials?

- A. Disable authentication on both APIs because the script runs automatically
- B. Use a shared human administrator account with unrestricted control of both systems
- C. Embed a privileged employee's reusable password in a publicly readable script
- D. Use a dedicated service identity limited to those required read and ticket-update operations

Answer: D

Automation needs its own accountable identity and only the permissions required for the workflow. A dedicated service identity can read asset context and update tickets without receiving unrelated deletion or administration rights. Credential storage, rotation, and logging should support the same narrow role so the integration does not become a broad access path.

Study tip: Scope an automation identity to its actual API actions, not the operator's full privileges.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Automation still requires authenticated, authorized access; removing API authentication exposes the same operations to other callers without adequate control.

B: A shared administrative account grants far more capability than the script requires and weakens attribution of its automated actions.

C: Exposing a privileged reusable credential creates unnecessary access risk and does not implement controlled authorization for the script's limited operations.

D: A scoped service identity supports the script's specific duties and limits the impact if its credentials or execution environment are compromised.

## SEC-Q222

A cloud template is used to create test servers automatically. A policy forbids exposing administrative ports to the internet. Which guardrail BEST prevents noncompliant deployments at scale?

- A. Review only the server's billing label after deployment has completed
- B. Validate the template's network rules in the deployment pipeline and reject prohibited exposure
- C. Add an internet-wide administrative rule to avoid failed deployment jobs
- D. Email the policy once and allow any template configuration to deploy

Answer: B

A provisioning guardrail translates a security requirement into an enforceable check at the point of resource creation. Validating network rules and rejecting prohibited internet exposure prevents repeated unsafe deployments from a reusable template. Testing approved exceptions and monitoring deployed state still matter because later changes could introduce drift.

Study tip: Put a repeatable policy check where the unsafe resource would be created.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A billing label does not describe effective network access and a postdeployment label review cannot prevent the prohibited exposure from being created.

B: An automated policy check blocks disallowed administrative exposure before deployment, applying the same rule consistently to every use of the template.

C: Broad administrative exposure directly violates the stated policy and trades away the required protection merely to simplify deployment.

D: A one-time message does not enforce the rule during automated provisioning and relies on every later author remembering and applying it correctly.

## SEC-Q223

An automation service normally creates incident tickets from alerts. During a ticketing API outage, its current script silently discards failed requests. Which improvement BEST protects response continuity?

- A. Mark every failed ticket request as successfully completed
- B. Queue failed work for controlled retries and alert operators when delivery remains unsuccessful
- C. Increase API permissions to administrator without changing error handling
- D. Remove source alert identifiers from all retry attempts

Answer: B

Automation can become a response bottleneck if integration failures silently lose work. Queuing, controlled retries, and operator notification preserve continuity and make failure observable. Stable identifiers help recovery avoid duplicate cases. The workflow should distinguish temporary outages from permanent errors so it does not retry indefinitely without a meaningful escalation.

Study tip: Automated work needs an observable failure path, not just a successful path.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Reporting success hides missing cases and leaves responders unaware that alerts did not reach the incident workflow during the outage.

B: A durable queue preserves unprocessed work, while bounded retries and failure notifications keep outages visible and support later recovery of missed ticket creation.

C: Broader permissions do not fix service unavailability or silent data loss and unnecessarily increase the impact of compromised automation credentials.

D: Discarding correlation identifiers complicates deduplication and traceability, making it harder to recover failed work without creating duplicate or disconnected cases.

## SEC-Q224

A proposed playbook will isolate endpoints when a new detection rule fires. The rule has not been evaluated against normal production activity, and isolation can interrupt customer service. Which TWO safeguards BEST support a controlled rollout? (Select TWO.)

- A. Suppress records of automated isolation to reduce the number of audit events
- B. Enable automatic isolation on every endpoint before collecting any test results
- C. Use scoped deployment, human approval for uncertain cases, and an authorized release procedure
- D. Run an observation-only pilot and review representative matches before enabling isolation
- E. Give the playbook authority to wipe disks whenever an isolation command fails

Answer: C|D

Disruptive automation should be introduced with evidence that its triggers are reliable and its effects are controlled. Observation-only evaluation reveals expected behavior, while scope, approvals, and release procedures limit business impact. These safeguards permit useful automation without assuming that a new rule is ready for unrestricted enforcement.

Study tip: Validate the trigger and control the effect before scaling disruptive automation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Removing action records weakens accountability and troubleshooting, making it harder to understand or reverse incorrect response decisions during rollout.

B: Organization-wide enforcement of an unvalidated rule exposes customer operations to avoidable false-positive disruptions without evidence that the criteria are reliable.

C: Scope and approval constrain disruptive actions, while a release procedure supports recovery when an isolation is inappropriate or the investigation permits reconnection.

D: A pilot reveals likely false positives and scope problems without immediately disrupting endpoints, providing evidence for tuning the detection and response criteria.

E: Escalating a failed isolation to destructive wiping is disproportionate to the described detection and substantially increases operational and evidence-preservation risk.

## SEC-Q225

A company realizes its incident contact list and response playbooks are available only through the same identity service that might be disabled during a compromise. Which preparation measure BEST addresses this dependency?

- A. Store the only backup copy behind the same unavailable identity provider
- B. Wait until an incident occurs before identifying response decision makers
- C. Maintain protected, current response materials and an approved alternate communication path
- D. Let any employee disable production systems without a defined response role

Answer: C

Preparation includes establishing authority, accessible procedures, and communication methods that survive plausible failures. A protected alternate path lets responders work when primary identity or messaging systems are compromised or unavailable. Access to these materials must still be controlled, and their contents need periodic review so the backup process remains usable.

Study tip: A response plan must remain reachable when the systems it protects are unavailable.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: A backup with the identical authentication dependency may be inaccessible during the same incident and does not provide operational independence.

B: Unassigned authority delays coordination under pressure and does not resolve the identified dependency on the potentially unavailable identity service.

C: Accessible response materials and an alternate communication path allow authorized responders to coordinate when the primary identity or collaboration service is unavailable.

D: Unrestricted authority can cause avoidable disruption and does not establish a controlled alternate means of accessing plans and coordinating incident response.

## SEC-Q226

A suspicious workstation is already isolated from the network, and no active local destruction is observed. The authorized forensic examiner needs evidence of running processes and memory-resident connections. Which action BEST preserves that evidence before further analysis?

- A. Reinstall the operating system before recording the current system state
- B. Power off immediately and inspect only the disk image later
- C. Acquire memory with an approved live-response method before powering off the system
- D. Run a disk cleanup utility to remove temporary files before collection

Answer: C

RAM is volatile, so powering off can eliminate process and connection information needed for this investigation. The scenario establishes isolation, no observed ongoing destruction, and an authorized examiner, making controlled live acquisition the appropriate choice. Acquisition actions and their effects should be documented because live collection itself changes the running system.

Study tip: Volatile evidence decisions depend on containment, ongoing harm, and authorized collection capability.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Reinstallation alters or destroys relevant evidence and prevents the examiner from preserving the running state required for this investigation.

B: A shutdown loses volatile memory state, so a later disk image cannot reliably recover all of the running-process and connection evidence requested.

C: Memory acquisition can preserve volatile process and connection information that would otherwise be lost during shutdown, given the stated containment and authorization conditions.

D: Cleanup changes evidence without addressing the requested volatile acquisition and may remove useful artifacts before the authorized examination is complete.

## SEC-Q227

Confirmed ransomware on a noncritical workstation is attempting to spread to peers over the network. The incident plan authorizes immediate endpoint isolation. Which action BEST limits further network spread while retaining the system's volatile state?

- A. Use the approved isolation control to restrict network connectivity while leaving power on
- B. Reconnect the workstation to a broader network to capture more peer infections
- C. Wait for the full forensic report before limiting the workstation's connectivity
- D. Erase the workstation's disk before notifying the incident response team

Answer: A

The immediate goal is to stop network propagation from a confirmed compromised workstation under an established response authority. Approved network isolation can limit spread while leaving volatile state available for subsequent decisions. Responders must still assess any continuing local harm, collect appropriate evidence, and plan eradication and recovery based on the incident context.

Study tip: For confirmed active spread, use the authorized containment action that fits the stated operational and evidence needs.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Network isolation limits peer communication without immediately discarding volatile memory, matching the authorized containment objective and the explicitly stated preservation requirement.

B: Expanding connectivity increases the opportunity for spread and conflicts with the immediate containment objective for the confirmed ransomware host.

C: Delaying the authorized containment leaves an actively spreading host connected and increases the risk to peers while the investigation proceeds.

D: Immediate erasure destroys evidence and does not preserve volatile state; it is not the authorized network containment action described in the plan.

## SEC-Q228

Responders have isolated a compromised server and collected required evidence. They identify an attacker-created scheduled task that reinstalls malware and the exploited service configuration that allowed entry. Which action is MOST directly part of eradication?

- A. Move the server into a quarantine network without changing its contents
- B. Notify executives that the investigation remains open
- C. Schedule a lessons-learned meeting without changing the compromised server
- D. Remove the malicious persistence and correct the exploited configuration

Answer: D

Eradication removes the attacker mechanism and addresses identified causes of compromise after appropriate evidence and containment decisions. Here, removing the scheduled task stops the known reinstall path, while correcting the service configuration addresses entry. Additional scoping may be necessary to confirm there are no related persistence mechanisms before recovery proceeds.

Study tip: Containment limits reach; eradication removes attacker presence and addresses the identified cause.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Network quarantine is containment; it limits communication but does not remove the scheduled task or correct the service configuration.

B: Status communication supports incident coordination but does not itself eliminate the malware persistence or the identified technical entry condition.

C: A review can improve future response, but scheduling it does not remove the current attacker mechanism or repair the exploited configuration.

D: Eradication addresses attacker presence and the condition enabling compromise, preventing the known persistence mechanism and entry weakness from remaining in place.

## SEC-Q229

An incident team has removed known persistence and corrected the entry vulnerability. It plans to restore an affected business server from a backup believed to predate compromise. Which action BEST supports safe recovery?

- A. Restore the backup directly to production without checking its integrity or date
- B. Re-enable the previously exploited configuration to match the old backup exactly
- C. Validate the backup and restored system, then return service in stages with heightened monitoring
- D. Disable endpoint monitoring permanently to prevent alerts during restoration

Answer: C

Recovery should restore a trustworthy, functional service rather than merely a running machine. A backup's date is useful but does not alone prove it is clean, so validate the source and restored system. Staged return and heightened monitoring provide opportunities to identify residual compromise, missed dependencies, or operational problems before full normal service resumes.

Study tip: A backup that restores successfully still needs security and business-function validation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: An unverified backup may contain corruption or attacker artifacts, and immediate production use provides little opportunity to detect those problems before exposure.

B: Restoring the entry weakness recreates the known compromise path and defeats the corrective action taken before returning the service to operation.

C: Validation checks that the recovery source and restored state are suitable, while staged restoration and monitoring help detect unresolved compromise or operational failures.

D: Disabling monitoring removes visibility when recurrence or residual compromise needs attention and does not improve confidence in the restored system.

## SEC-Q230

A completed incident review shows that several teams assumed another team would revoke compromised tokens, causing a long delay. Which outcome would BEST turn that lesson into an operational improvement?

- A. Record that communication should improve without assigning any follow-up work
- B. Delete the timeline because it shows that the response was delayed
- C. Reduce log retention so future reviews contain fewer token-related events
- D. Assign token-revocation ownership, update the playbook, and exercise the revised process

Answer: D

Lessons learned should lead to assigned and verifiable improvements. The root problem here is an ambiguous responsibility boundary, so clarifying ownership and testing the updated playbook directly address it. A report alone does not change operations; follow-up needs an accountable owner and confirmation that the new handoff works.

Study tip: An actionable lesson identifies a change, an owner, and a way to verify the improvement.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: A general observation lacks ownership and verification, so the same uncertainty can persist in the next incident despite being documented.

B: Removing evidence hides the cause of the delay and prevents the organization from measuring or validating an effective process improvement.

C: Less evidence would hinder future analysis and does not resolve uncertainty over who is responsible for revoking compromised tokens.

D: Clear ownership, documented action, and a tested workflow directly address the handoff failure and provide evidence that the response process now works.

## SEC-Q231

An incident coordinator reads a fictional breach scenario to IT, legal, and business leaders. Participants discuss decisions and handoffs without sending test traffic or changing production systems. What type of exercise is this?

- A. A tabletop exercise
- B. An active penetration test
- C. A live production failover
- D. A forensic acquisition of an actual compromised server

Answer: A

A tabletop exercise is a discussion-based way to test understanding of response roles, escalation, and decision making. It can expose gaps without technical disruption, but it does not demonstrate that tools or failover mechanisms actually work. Technical simulations and operational tests can complement the discussion where those capabilities also require validation.

Study tip: Discussion tests coordination; executing actions tests operational capability.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: A tabletop exercise uses discussion of a scenario to examine roles, decisions, and procedures without requiring the team to execute technical actions.

B: Penetration testing performs authorized technical assessment of attack paths, whereas participants here are discussing response decisions rather than executing test activity.

C: A live failover changes which system delivers service; the scenario explicitly involves discussion without changes to production systems.

D: Forensic acquisition collects real system evidence, while this exercise uses a fictional scenario and performs no collection from an affected server.

## SEC-Q232

No alert has fired, but intelligence suggests attackers may use a legitimate remote-management utility after stealing credentials. Analysts proactively search historical process and authentication data for unusual use of that utility. Which activity are they performing?

- A. A routine vulnerability scan limited to missing software patches
- B. A completed incident eradication process
- C. An automated alert triage that begins only after a matching rule fires
- D. Threat hunting

Answer: D

Threat hunting begins with a question or hypothesis and looks for evidence that routine detections may have missed. Searching for unusual remote-tool use across process and identity data fits that model. Findings require contextual validation because legitimate administration can resemble attacker behavior, and the absence of an alert is not proof of absence of compromise.

Study tip: Hunting proactively tests a hypothesis; it does not assume the hypothesis is already proven.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Patch scanning identifies known weaknesses in installed software, whereas this task proactively searches historical behavior for signs of attacker use of valid credentials.

B: Eradication removes confirmed attacker presence, whereas the analysts are still searching for evidence and have not established a specific compromise to eliminate.

C: The analysts are proactively searching without an existing alert, which distinguishes hypothesis-driven hunting from processing an alert already generated by a detection rule.

D: Threat hunting proactively searches for evidence of adversary behavior using a hypothesis, including activity that existing automated detections have not surfaced.

## SEC-Q233

Legal counsel issues a preservation notice covering specific mailbox records relevant to an investigation. Their normal deletion date is tomorrow. What should the response team do with those records?

- A. Delete only the messages that appear unfavorable to the organization
- B. Apply normal deletion because automated retention jobs cannot be interrupted
- C. Suspend applicable deletion and preserve the scoped records with documented access controls
- D. Publish all mailbox content to every employee so a copy will survive

Answer: C

A legal hold pauses ordinary disposition for the specified information. The team should preserve relevant records, prevent automated deletion, and document controlled handling according to the notice and organizational process. Scope and release decisions should follow authorized direction; the existence of a normal retention schedule does not justify deleting held material.

Study tip: A preservation requirement can suspend normal deletion for the records it covers.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Selective deletion undermines preservation and evidence integrity; the hold applies to relevant scoped records regardless of whether their content is favorable.

B: An automated schedule does not override a valid preservation requirement; the team must prevent deletion of records within the hold's specified scope.

C: A legal hold requires preserving the identified material rather than applying routine deletion, with controlled handling that supports the investigation's evidence requirements.

D: Broad distribution creates unnecessary disclosure and loses control over sensitive evidence; preservation should use authorized, scoped storage and access.

## SEC-Q234

An examiner has acquired a forensic disk image, and another authorized analyst will receive a working copy. The team must support both integrity verification and a documented handling history. Which TWO practices BEST meet these distinct requirements? (Select TWO.)

- A. Calculate and record cryptographic hashes for the acquired image and verify copied evidence
- B. Use an editable filename as the only proof that the image has not changed
- C. Record who transferred and received the evidence, when, and for what purpose
- D. Discard transfer records once the destination analyst confirms the file opens
- E. Analyze the sole original image directly and overwrite it with investigation notes

Answer: A|C

Integrity verification and chain of custody answer different questions. Hashes help establish whether contents remain consistent, while custody records document who handled evidence and why. Both depend on a trustworthy, documented process. Preserve the acquired original and work from controlled copies so later examination can be compared against the original acquisition.

Study tip: A hash supports content integrity; chain of custody documents handling and control.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/61/r3/final

A: Hashes support comparison of evidence contents across acquisition and copying, helping detect alteration or corruption when the recorded values and process are trustworthy.

B: A filename can remain identical while contents change, so it does not provide a meaningful integrity check for forensic evidence.

C: Custody records establish the documented handling history and accountability for transfers, complementing technical integrity checks with information about evidence control.

D: Successful access does not preserve the handling history, and deleting transfer records removes accountability needed to explain who controlled the evidence.

E: Overwriting the original changes evidence and undermines preservation; analysis should use controlled working copies while retaining the acquired evidence appropriately.

## SEC-Q235

A firewall log shows action=allow, src=192.0.2.44, dst=198.51.100.80, dport=443, bytes_out=8400000. No application content is logged. Which conclusion is BEST supported by this record alone?

- A. The destination authenticated the user with multifactor authentication
- B. The source workstation is free of malware because the traffic used port 443
- C. A specific payroll spreadsheet was conclusively stolen from the source host
- D. The firewall permitted a connection and observed outbound data on that recorded flow

Answer: D

The record supports a network-level conclusion: traffic was allowed and a volume of outbound data was observed. It does not identify the file, user intent, or authentication details. Endpoint and application evidence can add that context, while HTTPS usage alone does not establish that a connection is trustworthy.

Study tip: State only what a log source actually observes; a permitted connection does not prove legitimate content.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/41/r1/final

A: A permitted network flow and destination port do not reveal the application's authentication method or whether any user completed an MFA challenge.

B: Port 443 is commonly used for HTTPS but is also usable by malicious software; an allowed port does not establish endpoint integrity.

C: The log lacks file content and application context, so it cannot by itself identify a particular document or prove unauthorized disclosure.

D: The action and byte counter support permitted traffic and observed volume for the flow, but provide no direct proof of the application's content or legitimacy.

## SEC-Q236

An investigator must determine which authenticated user downloaded invoice INV-731 and whether the application allowed the download. Which source would MOST directly answer both questions?

- A. A switch counter showing total bytes on the server's network port
- B. A DNS query log showing that the invoice site's hostname resolved
- C. A vulnerability scan listing the web server's supported TLS versions
- D. An application audit record containing user identity, invoice identifier, action, and result

Answer: D

Application audit logs can expose business-level details that infrastructure logs lack, such as a user identity and a particular invoice identifier. The investigator should check the event's meaning and whether the result represents authorization, download initiation, or completion. Supporting response and endpoint evidence may be needed for claims beyond what that event records.

Study tip: For actions on business objects, look for application-level identity, object, action, and result fields.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: An aggregate switch counter does not identify application users or individual invoice objects, and it does not record the application's access decision.

B: Name resolution can precede access but does not identify the requested invoice, the authenticated application user, or the download result.

C: A TLS configuration finding describes exposure and configuration, not which user requested a specific invoice or whether that request was allowed.

D: A detailed application audit event can connect the authenticated user to the specific invoice action and the application's recorded authorization or completion result.

## SEC-Q237

Endpoint telemetry records: parent=wordprocessor.exe; child=scriptengine.exe; user=analyst1; then scriptengine.exe connects to 198.51.100.66. The user had just opened an unexpected attachment. What is the BEST next investigative use of this data?

- A. Conclude every scriptengine.exe process on every host is malicious
- B. Correlate the process command line, attachment origin, and network activity to assess the execution chain
- C. Use the process name alone to determine the exact attacker identity
- D. Treat the external connection as harmless because the user was authenticated

Answer: B

Process ancestry links the document application to a scripting process, and timing connects that process to a network destination. Together with the unexpected attachment, this is a meaningful lead. Investigators should examine command lines, provenance, and related events before deciding what executed and how broad the incident may be.

Study tip: Correlate parent-child behavior and timing; a process name by itself is weak evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://attack.mitre.org/tactics/enterprise/|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A legitimate scripting utility can have benign uses, so the suspicious context does not justify classifying all instances across the environment as malicious.

B: The linked process and network events provide an investigative lead that can be evaluated against command details, attachment provenance, and expected application behavior.

C: A process name is neither unique to an attacker nor sufficient attribution evidence; identity claims require substantially more corroboration.

D: A valid user session can execute malicious attachment content, so authentication does not resolve the concern raised by this process ancestry.

## SEC-Q238

A technician needs to verify whether a local administrator account was created on a server and which account initiated the change. Which source is MOST directly relevant?

- A. The server's operating-system security audit log for account-management events
- B. The endpoint's scheduled software inventory report
- C. The perimeter firewall's allow and deny connection log
- D. The domain controller log for changes to directory accounts only

Answer: A

The operating system's security audit trail is the direct source for local account-management actions and initiating principals, provided the appropriate auditing was enabled and records retained. Directory logs are useful for directory accounts, but a local account change requires the server's relevant security telemetry rather than unrelated network or storage summaries.

Study tip: Match the log source to where the identity change actually occurred.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Account-management audit events can record creation actions and the initiating security principal when the relevant operating-system auditing is enabled.

B: Software inventory describes installed applications and versions, but it does not normally record who initiated a specific local administrator-account creation event.

C: Firewall connection decisions can show communication but generally do not record local account creation or identify the operating-system principal that initiated it.

D: Directory-account records cover a different identity store; creating a local account on this server requires the server's relevant account-management audit evidence.

## SEC-Q239

A packet capture contains a TLS session, including encrypted application records, but the investigator has no usable session keys or decrypted endpoint capture. Which question can the capture answer MOST directly?

- A. What exact password the user submitted inside the encrypted application data
- B. Which visible network endpoints exchanged packets and when those packets were observed
- C. Whether the encrypted document's business classification was accurately applied
- D. Which internal database rows the server returned after decrypting the request

Answer: B

Encryption limits what a packet capture can reveal about application content. Visible headers and timestamps still support analysis of endpoints, timing, and traffic patterns, but exact plaintext requires appropriate decryption capability or evidence from another source. TLS version and capture details can further affect which handshake metadata is visible.

Study tip: Packet capture does not automatically mean plaintext visibility when encryption is in use.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: Without usable decryption material or plaintext evidence, the encrypted TLS records do not directly reveal the application's submitted password.

B: Packet headers and timestamps provide endpoint and timing metadata even when TLS protects application content from direct inspection in the available capture.

C: Business classification requires document or policy context unavailable from the encrypted payload and visible network headers alone.

D: A network capture of encrypted application records does not expose the server's internal database operations or the plaintext returned rows.

## SEC-Q240

Three reliable logs record events on the same date: VPN login at 20:10 UTC; application export at 16:12 UTC-04:00; endpoint process start at 20:11 UTC. Clock skew has been ruled out. Which event sequence is correct?

- A. Endpoint process start, application export, VPN login
- B. VPN login, application export, endpoint process start
- C. VPN login, endpoint process start, application export
- D. Application export, VPN login, endpoint process start

Answer: C

Normalize timestamps to a common basis before constructing a timeline. A time recorded as 16:12 at UTC-04:00 corresponds to 20:12 UTC. With clock skew excluded, the login occurs first, followed by the process and then the export. Preserve original timestamps and offsets alongside normalized values so the analysis remains traceable.

Study tip: Normalize timezone offsets before sorting events; preserve the originals for traceability.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: The login is explicitly recorded at 20:10 UTC, before both the 20:11 process start and the export normalized to 20:12 UTC.

B: The export normalizes to 20:12 UTC rather than 16:12 UTC, so it follows the endpoint event recorded one minute earlier.

C: The export at 16:12 with a minus-four-hour offset is 20:12 UTC, placing it after the 20:10 login and 20:11 process start.

D: Comparing displayed hour numbers without applying the UTC offset incorrectly places the export first; its normalized time is 20:12 UTC.

## SEC-Q241

An executive approves an organization-wide document stating that employees must protect company information and use company systems only for authorized purposes. It establishes management expectations without specifying individual settings or task steps. What type of document is this?

- A. Guideline
- B. Standard
- C. Policy
- D. Procedure

Answer: C

Policies communicate what management requires and the scope of those requirements. Standards make those requirements specific and measurable, while procedures explain execution. The stated document sets broad mandatory expectations for information protection and system use, so it is a policy.

Study tip: Identify both authority and level of detail when classifying governance documents.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: A guideline offers recommended practices and usually permits discretion. The scenario explicitly describes mandatory expectations approved by organizational management.

B: A standard specifies mandatory, measurable requirements, such as approved protocols or configuration values. This document instead establishes broader management expectations.

C: A policy establishes management direction and mandatory organizational expectations. Detailed requirements and implementation steps are normally supplied by supporting documents.

D: A procedure describes how to perform a task through ordered instructions. The executive document deliberately omits individual task steps.

## SEC-Q242

A company policy requires protection of sensitive network traffic. Security engineers publish a mandatory list of approved TLS versions and cipher configurations for every production service. Which supporting document BEST fits this list?

- A. Incident response policy
- B. Encryption standard
- C. Cryptography guideline
- D. Certificate renewal procedure

Answer: B

The key distinction is that the list contains enforceable technical requirements. A policy provides the protection goal, and an encryption standard defines acceptable implementations. A procedure could subsequently explain how to apply those settings on a particular platform.

Study tip: Mandatory measurable settings point to a standard.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html

A: An incident response policy establishes expectations for handling incidents. It does not primarily define the approved cryptographic configuration of production services.

B: An encryption standard translates a broad protection policy into mandatory technical requirements that administrators can configure and auditors can verify.

C: A guideline recommends approaches and allows discretion. The approved configuration list is mandatory for every production service, making it a standard.

D: A certificate renewal procedure provides task instructions for replacing certificates. The scenario specifies configuration requirements rather than an ordered renewal workflow.

## SEC-Q243

Managers report that departing employees sometimes retain VPN access because different technicians interpret the offboarding policy differently. Which document would MOST directly make execution consistent?

- A. An optional guide describing several account-management approaches
- B. A vendor contract defining network equipment support hours
- C. An executive statement that former employees should lose access
- D. A step-by-step offboarding procedure with assigned tasks and verification

Answer: D

The policy already states the desired outcome, but technicians need a reproducible implementation. An offboarding procedure can sequence account disabling, token revocation, device recovery, and evidence collection. Assigned responsibilities and verification prevent individual interpretation from leaving access behind.

Study tip: When the goal is clear but execution varies, look for a procedure.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Optional guidance leaves discretion over essential offboarding steps. The reported problem requires a defined, consistently executed workflow with verification.

B: Equipment support terms do not specify employee offboarding actions. They would not resolve inconsistent account disabling or VPN access removal.

C: This restates the existing policy goal without resolving inconsistent execution. Technicians still need ordered tasks, responsible roles, and completion checks.

D: A procedure turns the existing policy into repeatable actions, identifies responsibility, and provides checks that access revocation actually occurred.

## SEC-Q244

A security team publishes recommended ways to arrange monitors in a shared workspace. Employees may use another arrangement if it provides equivalent privacy, and the document does not impose a required configuration. How should the document be classified?

- A. Standard
- B. Policy
- C. Procedure
- D. Guideline

Answer: D

A guideline helps people make sound choices while allowing appropriate alternatives. The scenario emphasizes discretion and equivalent outcomes, which separates the document from a mandatory standard. A related policy might require protecting displayed information, with this guideline suggesting practical ways to comply.

Study tip: Recommendations with permitted discretion indicate a guideline.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: A standard defines mandatory requirements used for consistent enforcement. This document allows discretionary alternatives and explicitly avoids imposing a required configuration.

B: A policy communicates authoritative organizational requirements and direction. These optional arrangement recommendations support privacy goals without establishing a binding organizational requirement.

C: A procedure supplies ordered instructions for completing a task. The document gives flexible recommendations rather than a required sequence of actions.

D: Guidelines provide recommended practices with room for judgment. Employees may choose an equivalent privacy arrangement without violating a mandatory configuration requirement.

## SEC-Q245

A finance director determines which departments may access payroll reports. A database administrator implements the approved permissions and maintains backups. Which role does the finance director perform for these reports?

- A. Data subject
- B. Data custodian
- C. Data owner
- D. External auditor

Answer: C

Ownership is a governance responsibility: deciding appropriate use and protection based on business needs. Custodians carry out the corresponding technical work. The director's access decisions identify the owner role, while the administrator's permission changes and backups identify custodial responsibilities.

Study tip: Owners decide protection requirements; custodians implement and maintain them.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A data subject is the individual described by personal information. That status does not confer organizational authority to approve access to payroll reports.

B: The custodian implements and maintains protective controls under the owner's direction. In this scenario, the database administrator performs that operational role.

C: The data owner is accountable for business decisions about classification and authorized access. The director makes those decisions for payroll reports.

D: An auditor evaluates evidence against defined criteria. The director is making business access decisions, not independently examining whether controls meet requirements.

## SEC-Q246

A parent company permits each subsidiary's security committee to choose local security standards and approve exceptions within its delegated authority. The parent board receives consolidated reports but does not approve every subsidiary decision. Which governance structure is MOST evident?

- A. Centralized governance
- B. Decentralized governance
- C. Technical configuration management
- D. Outsourced governance

Answer: B

Governance can distribute decision authority while retaining enterprise reporting and strategic oversight. In this case, local committees make substantive choices within delegated limits. That is decentralized governance, even though a parent board remains responsible for consolidated oversight.

Study tip: Classify governance by where decisions are authorized, not where reports are collected.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: Centralized governance concentrates decision authority in a common governing body. Here, subsidiary committees independently make standards and exception decisions within delegated limits.

B: Decision authority is distributed to subsidiaries. Consolidated reporting can still support enterprise oversight without requiring every security decision to be centralized.

C: Configuration management tracks and controls system settings. The question concerns where organizational decision authority resides, rather than how individual configurations are maintained.

D: No outside organization has been assigned governance authority. The subsidiary committees remain internal organizational bodies with delegated responsibilities and reporting obligations.

## SEC-Q247

An organization uses a centrally approved access standard. A business unit asks to bypass a required control to meet a deadline, but its manager has no authority to grant exceptions. What is the security lead's BEST response?

- A. Ask the system administrator to decide whether the business benefit is sufficient
- B. Route a documented risk-based exception request to the authorized decision maker
- C. Remove the requirement from the central standard for all business units
- D. Treat the business unit manager's deadline as sufficient approval

Answer: B

The lead should make the proposed deviation reviewable: document its scope, justification, risk, safeguards, and intended duration. The authorized decision maker can then approve or reject the exception. A deadline alone does not transfer governance authority to a requester or administrator.

Study tip: Technical capability to make a change is different from authority to accept its risk.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/30/r1/final

A: An administrator can assess implementation and technical consequences, but cannot assume business risk-acceptance authority that the governance structure assigns elsewhere.

B: The designated authority must evaluate the deviation, business justification, residual risk, and proposed safeguards. Documented exceptions preserve governance accountability without assuming approval.

C: An individual exception request does not justify an organization-wide standard change. Such a revision would require broader analysis and authorized approval.

D: Urgency does not expand the manager's delegated authority. Proceeding on that basis would bypass the organization's defined exception and risk-acceptance process.

## SEC-Q248

A company acquires a business in another country and begins processing a new category of customer information. Its security policies were reviewed six months ago. What is the BEST governance action?

- A. Wait until the next annual review because the policies are still current
- B. Update the policy approval date while retaining its existing contents
- C. Trigger a policy review based on the changed business and external requirements
- D. Apply the acquired company's policies to every existing business unit immediately

Answer: C

Policy review should be both periodic and triggered by significant changes. The acquisition changes organizational context and external considerations, so the company should assess applicability, identify gaps, obtain authorized revisions, and communicate affected requirements. A recent review does not remove that need.

Study tip: Major changes can trigger review before a calendar deadline.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: The previous review date does not establish suitability for changed operations. New jurisdictions and data categories can require action before the next scheduled review.

B: Changing a date does not evaluate whether the policy fits new obligations and operations. A substantive review must examine the changed circumstances.

C: A material change can invalidate policy assumptions before a scheduled review. The organization should assess new obligations, responsibilities, and required control updates.

D: Automatic enterprise adoption ignores differences in scope, requirements, and risk. Governance should evaluate the combined organization before approving appropriate revisions.

## SEC-Q249

A retailer wants a policy addressing how stores will continue essential sales and customer support during a prolonged outage. It must cover alternate work locations, staffing, communications, and manual processes. Which policy has the MOST appropriate scope?

- A. Business continuity policy
- B. Acceptable use policy
- C. Disaster recovery policy
- D. Software development lifecycle policy

Answer: A

Business continuity planning starts with essential functions and how to sustain them during disruption. Technology recovery is one supporting concern, but stores also need people, facilities, communications, and workable alternatives. The breadth of the requested policy makes business continuity the best fit.

Study tip: Continuing business functions is broader than restoring IT systems.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: Business continuity addresses maintaining essential business functions across people, facilities, communications, and technology disruptions. The requested scope extends across store operations.

B: An acceptable use policy defines permitted use of organizational resources. It does not establish alternate staffing, facilities, communications, or manual operating arrangements.

C: Disaster recovery emphasizes restoring disrupted technology and related capabilities. It supports continuity but does not by itself cover the full business-operation scope described.

D: An SDLC policy governs how software is planned, developed, tested, and maintained. It does not principally organize store operations during prolonged disruption.

## SEC-Q250

A company is formalizing responsibilities. Its board provides strategic oversight, a cross-functional security committee coordinates implementation priorities, data owners decide business access requirements, and custodians operate approved controls. Which assignments are appropriate? (Select TWO.)

- A. Have custodians implement the access restrictions approved by data owners
- B. Have the board review security risk against organizational strategy
- C. Have the security committee approve every decision reserved exclusively to the board
- D. Have custodians independently redefine which business groups need payroll access
- E. Have the board personally perform each scheduled database backup

Answer: A|B

Effective governance distinguishes oversight, coordination, ownership, and operation. The board reviews strategic risk, while custodians execute controls based on authorized requirements. Committees and administrators can contribute expertise, but their participation does not automatically expand their authority into decisions assigned to another role.

Study tip: Match each action to the role's stated authority and accountability.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Implementing approved restrictions is operational control work. It preserves the distinction between business authorization by owners and technical execution by custodians.

B: Strategic review fits the board's stated oversight role. It connects security risk decisions to organizational objectives rather than daily control administration.

C: Coordination responsibilities do not override explicitly reserved authority. The committee can prepare recommendations and implementation plans, but must respect the stated delegation.

D: The company assigns business access decisions to data owners. Custodians should implement those decisions rather than independently broaden access requirements.

E: Backup execution is a custodial operation. Assigning routine administration to strategic oversight does not match the organization's defined division of responsibilities.

## SEC-Q251

A risk model assigns a server environment an asset value of $600,000. A modeled incident would cause a loss equal to 20% of that value. What is the single loss expectancy (SLE)?

- A. $30,000 per incident
- B. $120,000 per incident
- C. $3,000,000 per incident
- D. $480,000 per incident

Answer: B

Single loss expectancy estimates the monetary loss from one occurrence of a specified event. The exposure factor is 20%, or 0.20, so SLE = $600,000 × 0.20 = $120,000 per incident. No annual frequency is needed until calculating annualized loss expectancy.

Study tip: SLE uses the fraction lost in one event, not the fraction remaining.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Dividing asset value by 20 does not convert the exposure factor correctly. Twenty percent must be represented as 0.20 in multiplication.

B: SLE equals asset value multiplied by exposure factor: $600,000 times 0.20 equals $120,000 for one modeled incident.

C: Dividing by the exposure fraction produces an unrelated value. The model calls for multiplying asset value by the fraction lost.

D: This is the modeled value remaining after a 20% loss. SLE represents the value lost, not the portion that remains.

## SEC-Q252

A planning model estimates that a particular outage occurs once every five years on average. Which annualized rate of occurrence (ARO) should be used?

- A. 5 occurrences per year
- B. 0.5 occurrences per year
- C. 0.2 occurrences per year
- D. 20 occurrences per year

Answer: C

ARO expresses the expected number of occurrences during a year. Converting the five-year interval gives 1 occurrence ÷ 5 years = 0.2 occurrences per year. This expected rate does not mean incidents arrive on a guaranteed five-year schedule.

Study tip: Convert the recurrence interval to occurrences per year before using ALE.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Five is the average number of years between occurrences. Using it as an annual frequency reverses the relationship and overstates event frequency.

B: A rate of 0.5 corresponds to one occurrence every two years on average. It does not match the stated five-year interval.

C: An average of one occurrence over five years produces a rate of 1 divided by 5, or 0.2 occurrences per year.

D: The fraction 0.2 must not be treated as the number 20. ARO is an expected occurrence rate with explicit time units.

## SEC-Q253

A storage system is valued at $250,000. The risk model uses an exposure factor of 40% for a damaging event and an ARO of 0.25 occurrences per year. What is the annualized loss expectancy (ALE)?

- A. $62,500 per year
- B. $25,000 per year
- C. $100,000 per year
- D. $400,000 per year

Answer: B

First calculate SLE: $250,000 × 0.40 = $100,000 per occurrence. Then multiply by ARO: $100,000 × 0.25 occurrences per year = $25,000 per year. ALE is an expected planning value, so actual losses in a particular year can differ substantially.

Study tip: Calculate SLE first, then multiply by the annual occurrence rate.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: This multiplies total asset value by ARO but ignores the exposure factor. Each modeled event loses only 40% of the asset value.

B: The SLE is $250,000 times 0.40, or $100,000 per event. Multiplying by 0.25 occurrences per year produces $25,000 annually.

C: This value is the single loss expectancy before applying event frequency. ALE must also account for the stated annualized rate of occurrence.

D: This divides SLE by ARO, reversing the frequency adjustment. A rate below one occurrence per year reduces annualized expected loss.

## SEC-Q254

A control is expected to reduce annualized loss expectancy from $60,000 per year to $15,000 per year. Its total annual cost is $18,000. Considering only these modeled losses and costs, what is the expected NET annual financial benefit of implementing the control?

- A. $45,000 per year
- B. $27,000 per year
- C. $3,000 per year
- D. $42,000 per year

Answer: B

The gross expected reduction is $60,000 − $15,000 = $45,000 per year. After the $18,000 annual control cost, net expected benefit is $27,000 per year. This calculation uses the model's assumptions and excludes other benefits, obligations, and uncertainty that could influence the actual decision.

Study tip: Net annual benefit = ALE before − ALE after − annual control cost.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: This is the gross reduction in expected losses. The question asks for net benefit, which must also subtract the control's annual cost.

B: The control reduces modeled annual loss by $45,000. Subtracting its $18,000 annual cost leaves an expected net benefit of $27,000.

C: Comparing residual ALE with control cost does not measure the improvement from the original condition. Net benefit must include the avoided expected loss.

D: Subtracting the control cost from the original ALE ignores the $15,000 residual expected loss that remains after implementation.

## SEC-Q255

A small organization lacks reliable financial loss data. Its workshop rates each risk's likelihood as low, medium, or high and its impact as minor, serious, or severe, then uses a matrix to prioritize discussion. What type of analysis is this?

- A. Single loss expectancy calculation
- B. Quantitative risk analysis
- C. Annualized rate of occurrence calculation
- D. Qualitative risk analysis

Answer: D

Qualitative analysis helps prioritize risks when precise data is unavailable or when a relative comparison is sufficient. The labels and matrix express judgments about likelihood and impact. Assigning category codes would not, by itself, make those judgments equivalent to calibrated monetary loss estimates.

Study tip: A numbered category can still be qualitative; ask what the number actually measures.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: SLE estimates the loss from one occurrence, commonly using asset value and exposure factor. The workshop has not calculated that amount.

B: Quantitative analysis uses numerical estimates of relevant quantities such as likelihood and loss. Descriptive category labels do not constitute monetary risk measurement.

C: ARO estimates event frequency per year. Categorizing likelihood as low, medium, or high does not provide an annual occurrence rate.

D: The analysis uses descriptive categories and relative judgments rather than monetary loss estimates. A matrix can organize those qualitative assessments for prioritization.

## SEC-Q256

A risk register describes an unpatched legacy application and records a remediation deadline, but no person is accountable for the business decision or tracking its treatment. Which addition MOST directly closes this governance gap?

- A. A larger inventory of installed application files
- B. An additional vulnerability severity score
- C. A designated risk owner
- D. A copy of the application's software license

Answer: C

A useful risk register supports decisions and follow-through rather than simply listing problems. The risk owner is accountable for coordinating risk treatment and appropriate escalation. Technical teams may implement remediation, but their involvement should not leave the underlying business risk without ownership.

Study tip: Risk ownership is accountability for the risk, not merely a technician assigned a ticket.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Additional asset detail may support technical analysis, but it does not establish responsibility for risk decisions or remediation follow-through.

B: A severity score helps describe technical seriousness but does not assign accountability. The missing element concerns who manages the business risk.

C: A risk owner is accountable for managing the identified risk and coordinating decisions and treatment. Assigning ownership closes the stated accountability gap.

D: The license records usage rights and terms. It does not identify an accountable owner for the organization's security risk and treatment.

## SEC-Q257

A board states that the company is willing to accept moderate cybersecurity risk to enter a new market. Management then requires escalation if a pilot exceeds $50,000 in modeled annual loss. Which interpretation is BEST?

- A. Both statements constitute complete risk avoidance
- B. The board expresses risk appetite; the escalation limit operationalizes risk tolerance
- C. The board expresses risk tolerance; the dollar limit expresses risk appetite
- D. Both statements calculate annualized rate of occurrence

Answer: B

Risk appetite describes the types and amount of risk an organization is broadly willing to accept while pursuing objectives. Risk tolerance translates that intent into specific limits or acceptable variation. The board's strategic posture and management's measurable escalation limit illustrate that relationship.

Study tip: Appetite gives broad direction; tolerance makes acceptable boundaries operational.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: The company explicitly plans to proceed with a risk-bearing pilot. Avoidance would remove the activity or exposure rather than establish acceptable boundaries.

B: Appetite describes broad willingness to pursue value with risk. A specific limit translates that direction into a practical boundary for operational decisions.

C: This reverses the relationship. Appetite is the broad strategic willingness, while tolerance provides more specific acceptable boundaries for its implementation.

D: Neither statement provides an event frequency. They describe organizational willingness and an escalation boundary rather than the number of occurrences expected annually.

## SEC-Q258

A company purchases a cyber insurance policy covering some incident response expenses. It continues operating the affected services and keeps preventive controls in place. Which risk treatment is MOST directly represented by the insurance purchase?

- A. Risk avoidance
- B. Risk transfer
- C. Risk elimination
- D. Technical risk mitigation

Answer: B

Risk transfer reallocates specified consequences through an arrangement such as insurance or a contract. It does not remove the underlying threat, make technical controls unnecessary, or transfer every form of accountability. Coverage scope and retained exposure must still be understood and managed.

Study tip: Insurance transfers specified financial exposure; it does not make incidents impossible.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Avoidance removes the activity or exposure creating the risk. The company continues operating the services, so the insurance purchase is not avoidance.

B: Insurance contractually shifts specified financial consequences to another party under coverage terms. The organization still retains uncovered losses and operational responsibilities.

C: Purchasing insurance does not prevent incidents or eliminate every consequence. Coverage terms, exclusions, deductibles, and reputational impacts can leave substantial residual exposure.

D: Preventive controls can reduce likelihood or impact, but the insurance purchase itself primarily redistributes financial consequences rather than changing technical exploitability.

## SEC-Q259

A company concludes that a proposed service would create unacceptable exposure. It cancels the launch and does not collect the sensitive data the service would require. Which treatment BEST describes this decision?

- A. Risk avoidance
- B. Risk transfer
- C. Risk mitigation
- D. Risk acceptance

Answer: A

Avoidance means changing plans so the specific risk-generating activity does not occur. Here, canceling the service also avoids the planned collection of sensitive data. The decision addresses that service's proposed exposure; it does not imply that the organization has eliminated unrelated cybersecurity risks.

Study tip: Abandoning the risk-generating activity indicates avoidance.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: The organization chooses not to undertake the activity that creates the specified risk. Canceling the service removes that particular proposed exposure.

B: Transfer would allocate specified consequences to another party through an arrangement such as insurance. No such allocation is described in this scenario.

C: Mitigation would reduce the likelihood or impact while retaining the activity. The company has chosen not to launch the risk-generating service.

D: Acceptance would involve knowingly retaining the identified exposure. The company instead cancels the activity that would have created the risk.

## SEC-Q260

A legacy system cannot meet a new control requirement until its replacement arrives in 60 days. Analysis shows that temporary compensating controls reduce exposure to within the organization's approved limits. What is the BEST way to handle the remaining risk?

- A. Mark the risk fully remediated because replacement equipment has been ordered
- B. Delete the finding once the temporary controls are enabled
- C. Allow the technician implementing the controls to silently accept the risk
- D. Obtain documented, time-limited acceptance from the authorized risk owner

Answer: D

The remaining risk should be accepted through the organization's established authority and documented exception process. Record the scope, compensating controls, responsible owner, expiration, and replacement plan. An approved temporary exception preserves visibility; it should not be confused with permanent remediation.

Study tip: Accepted residual risk still needs an owner and a review point.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: An order does not resolve the current exposure. The register should distinguish planned remediation from the risk that remains during the next 60 days.

B: Temporary mitigation does not erase the underlying exception. Tracking the residual risk and replacement commitment remains necessary until the approved condition is resolved.

C: Implementing safeguards does not automatically grant risk-acceptance authority. Silent acceptance also omits accountability, a review date, and evidence of the decision.

D: Documented acceptance records the remaining exposure, responsible authority, compensating controls, and review or expiration date. It makes the temporary decision accountable and reviewable.

## SEC-Q261

Management wants an early warning that exposure from unsupported systems is increasing. Which measure is the BEST key risk indicator for this concern?

- A. Number of patch-deployment jobs completed each month
- B. Percentage of production systems running unsupported software
- C. Percentage of employees acknowledging the acceptable use policy
- D. Mean time to restore service after unrelated network outages

Answer: B

A key risk indicator should be meaningfully connected to a risk and useful for monitoring changes or crossing thresholds. The percentage of systems with unsupported software directly represents the stated exposure. The organization can assign thresholds, responsible owners, and escalation actions to that measure.

Study tip: Choose an indicator of exposure, not merely a count of unrelated security activity.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Job counts measure activity but can include repeated or unsuccessful work. They do not directly quantify the remaining production population running unsupported software.

B: This measure tracks the exposure management is concerned about. A rising percentage can trigger investigation or action before a related incident occurs.

C: Acknowledgement measures a workforce compliance activity. It does not indicate the proportion of production systems exposed through unsupported software.

D: Restoration time measures recovery performance for those outages. It does not directly track how much of the production environment uses unsupported software.

## SEC-Q262

A business impact analysis states that an order service must be restored within four hours of an outage and that no more than 15 minutes of committed transactions may be lost. Which mappings are correct? (Select TWO.)

- A. Mean time between failures: four hours
- B. Recovery time objective: four hours
- C. Recovery point objective: four hours
- D. Recovery point objective: 15 minutes
- E. Mean time to repair: 15 minutes

Answer: B|D

RTO and RPO answer different business questions. RTO specifies how quickly the service needs to return, while RPO defines acceptable loss of recent data. The values are requirements established through business impact analysis; they are not measurements of how frequently systems fail or how long repairs historically take.

Study tip: RTO is time to restore; RPO is how much recent data may be lost.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final

A: MTBF describes the average operating interval between failures. The four-hour value is a restoration requirement after an outage has begun.

B: RTO defines the target restoration interval after disruption. The four-hour requirement specifies how soon the order service must be restored.

C: The four-hour requirement concerns restoration time, not how far back recovered data may be. It therefore maps to RTO.

D: RPO expresses the acceptable data-loss interval relative to disruption. The transaction requirement limits loss to the most recent 15 minutes.

E: MTTR is an observed or estimated average repair duration. The 15-minute value is a data-loss objective, not an average repair measurement.

## SEC-Q263

For a repairable service, a report records 10,000 hours of actual operating time, five failures, and 10 total hours spent repairing those five failures. Using operating time divided by failures for MTBF and repair time divided by failures for MTTR, what are the metrics?

- A. MTBF: 2 hours; MTTR: 2,000 hours
- B. MTBF: 2,000 hours; MTTR: 2 hours
- C. MTBF: 2,002 hours; MTTR: 2 hours
- D. MTBF: 10,000 hours; MTTR: 10 hours

Answer: B

The question supplies the calculation conventions to avoid ambiguity about included time. MTBF = 10,000 ÷ 5 = 2,000 operating hours between failures. MTTR = 10 ÷ 5 = 2 repair hours per failure. These are historical averages and do not guarantee the timing of future failures or repairs.

Study tip: Keep operating time and repair time separate, and follow the stated measurement convention.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: This reverses the metrics. Operating time between failures determines MTBF, while time spent repairing failures determines MTTR under the stated formulas.

B: The stated formulas give 10,000 operating hours divided by five failures and 10 repair hours divided by five failures, respectively.

C: This adds repair downtime to the operating-time numerator. The question explicitly defines MTBF using actual operating time, which excludes the reported repair hours.

D: These are total operating and repair times. Each total must be divided by the five failures to obtain the requested averages.

## SEC-Q264

A company wants risk assessments to reflect frequent cloud changes between quarterly meetings. Asset and configuration feeds are already available. Which actions BEST support this goal? (Select TWO.)

- A. Reevaluate affected risk scenarios when monitored assets or exposures materially change
- B. Freeze all risk ratings until the next quarterly meeting
- C. Notify accountable risk owners when defined exposure thresholds are crossed
- D. Close each risk permanently after its first automated configuration check passes
- E. Replace business-impact estimates with vulnerability severity scores alone

Answer: A|C

Continuous assessment uses appropriate monitoring and change information to keep risk decisions current. It does not require reevaluating every risk every second. Material changes should update affected scenarios, and meaningful thresholds should prompt accountable owners to review treatment before the next routine meeting.

Study tip: Continuous assessment connects changing evidence to risk decisions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/30/r1/final|https://csrc.nist.gov/pubs/ir/8286/a/r1/final

A: Using change signals to revisit relevant likelihood and impact estimates keeps risk assessment connected to the evolving environment between scheduled meetings.

B: Frozen ratings would preserve the gap the company wants to close. Material changes could increase exposure without influencing timely risk decisions.

C: Threshold-based escalation connects monitoring to timely decisions. Risk owners can evaluate treatment or acceptance rather than allowing changed exposure to remain unnoticed.

D: A passing check reflects a limited condition at a point in time. Future changes and other risk factors still require monitoring and reassessment.

E: Technical severity is one input, but business risk also depends on exposure, likelihood, and consequences. Removing impact analysis weakens the assessment.

## SEC-Q265

A business unit wants to upload customer records to a new SaaS service. Procurement has confirmed pricing, but nobody has evaluated the provider's security practices or data handling. What should happen BEFORE approving the service for these records?

- A. Perform risk-based vendor due diligence and review supporting evidence
- B. Use the lowest price as the primary indicator of acceptable security risk
- C. Wait for an incident before requesting information about provider controls
- D. Approve the upload because the provider offers encrypted web access

Answer: A

Vendor selection should include a risk-based examination of the proposed service and the information it will handle. Questionnaires, relevant independent reports, contractual terms, and follow-up evidence can support the decision. The depth should match the potential exposure, rather than treating a price quote or TLS connection as sufficient assurance.

Study tip: Evaluate the vendor for the intended use before entrusting data or access.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Due diligence evaluates whether the provider can meet relevant security and data-handling requirements before the organization commits sensitive information to the relationship.

B: Price does not establish protection of customer records. Selection must also consider the provider's controls, contractual commitments, and evidence relevant to the intended use.

C: Reactive investigation cannot replace pre-engagement due diligence. The organization needs enough evidence to make an informed decision before exposing customer records.

D: Transport encryption addresses only one concern. It does not establish appropriate access control, retention, incident handling, subcontractor practices, or other required protections.

## SEC-Q266

A customer wants a contractual mechanism allowing it to examine a provider's relevant control evidence under agreed conditions. Which provision MOST directly supports this requirement?

- A. Statement of work
- B. Service credit schedule
- C. Right-to-audit clause
- D. Non-disclosure agreement

Answer: C

The customer needs an explicit contractual right, including conditions for requesting and reviewing relevant evidence. A right-to-audit clause can establish that mechanism. Confidentiality terms may govern evidence handling, but an NDA alone does not require the provider to make audit evidence available.

Study tip: Confidentiality obligations and rights to inspect evidence are separate contract functions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An SOW defines project-specific tasks, deliverables, and responsibilities. Audit rights need explicit contractual coverage rather than being assumed from a project description.

B: A service credit schedule defines financial remedies for specified service failures. It does not by itself grant access to security control evidence.

C: A right-to-audit clause provides an agreed mechanism for examining relevant controls or evidence. Its scope and procedures should be defined in the contract.

D: An NDA protects confidential information exchanged between parties. It can support an audit arrangement but does not itself establish the required audit rights.

## SEC-Q267

A hosted service contract promises a defined monthly availability level and a maximum response time for critical support tickets. Which agreement component MOST directly describes these measurable commitments?

- A. Non-disclosure agreement
- B. Memorandum of understanding
- C. Service-level agreement
- D. Master service agreement

Answer: C

An SLA turns service expectations into measurable commitments. The parties need to define what is measured, how it is measured, and applicable exclusions or remedies. A broader contract can contain or reference an SLA, but the availability and response targets are service-level terms.

Study tip: Availability and response-time commitments are characteristic SLA content.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An NDA addresses confidentiality of shared information. It does not principally define operational availability targets or critical-ticket response commitments.

B: An MOU commonly records a shared understanding or intended cooperation. Specific measurable service-performance commitments are most directly described by an SLA.

C: An SLA specifies measurable service commitments, such as availability and response times, with agreed measurement methods and consequences where applicable.

D: An MSA establishes overarching relationship terms and may incorporate an SLA. The named component focused on measurable service levels is the SLA.

## SEC-Q268

A consulting firm and customer already have a master service agreement covering general commercial and security terms. They now need to define the deliverables, milestones, acceptance criteria, and price for one specific assessment. Which document is MOST appropriate?

- A. Non-disclosure agreement
- B. Replacement master service agreement
- C. Memorandum of understanding
- D. Statement of work

Answer: D

The MSA supplies reusable terms for the vendor relationship. An SOW then defines what will be done for a particular engagement and how completion will be judged. Keeping project-specific details in an SOW allows multiple engagements to operate under consistent overarching terms.

Study tip: MSA covers the relationship; SOW covers the specific work.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An NDA governs confidentiality. It would not adequately define assessment deliverables, completion milestones, acceptance criteria, and project pricing.

B: The existing MSA already covers general relationship terms. A project-specific SOW is the better fit for the requested assessment details.

C: An MOU records a shared understanding or intended relationship. The requested detailed project commitments are most directly established in an SOW.

D: An SOW specifies the particular project's scope, deliverables, milestones, and acceptance conditions while operating under the broader master agreement.

## SEC-Q269

A manufacturer must share an unreleased product design with a security assessor. Which agreement MOST directly establishes the assessor's confidentiality obligations for the information?

- A. Non-disclosure agreement
- B. Statement of work
- C. Security questionnaire
- D. Service-level agreement

Answer: A

An NDA defines how shared confidential information may be used and disclosed. It is relevant before providing unreleased designs to an assessor. It does not substitute for deciding what information is necessary to share or for maintaining appropriate access and handling controls.

Study tip: An NDA governs confidentiality; other documents govern work scope and performance.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: An NDA establishes confidentiality obligations and permitted handling or disclosure of information shared between parties, including sensitive unreleased product designs.

B: An SOW defines project-specific work and deliverables. Although it can reference confidentiality terms, an NDA most directly establishes the confidentiality obligations requested here.

C: A questionnaire gathers information about the assessor's practices. Answers can inform due diligence, but the questionnaire does not itself establish confidentiality commitments.

D: An SLA defines measurable service performance, such as availability or support response. It is not the principal agreement for protecting disclosed design information.

## SEC-Q270

A critical SaaS provider relies on a subcontractor for identity verification. The subcontractor will receive customer data, but it was absent from the original vendor review. What is the BEST next step?

- A. Assume the initial provider review automatically covers every future subcontractor
- B. Assess the subcontractor dependency and the provider's controls over that relationship
- C. Evaluate only the subcontractor's public website uptime
- D. Treat the subcontractor as unrelated because it has no direct customer contract

Answer: B

Third-party risk can extend through the provider's own supply chain. The company should understand what the subcontractor receives, what it does, and how the provider governs its performance and security. Relevant changes may require an updated risk decision and contractual safeguards before the new processing begins.

Study tip: Indirect suppliers can create direct consequences for your data and services.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A prior review cannot establish the suitability of an undisclosed new dependency. Changes in data recipients and control responsibilities require evaluation.

B: The new dependency changes data exposure and service risk. Reviewing oversight, data handling, and relevant contractual protections addresses the actual supply-chain change.

C: Uptime is a narrow service indicator. It does not address the subcontractor's handling of customer information or the provider's oversight responsibilities.

D: Indirect suppliers can affect confidentiality, integrity, and availability through the primary provider. Lack of a direct contract does not remove that exposure.

## SEC-Q271

A procurement committee member learns that a bidder is owned by a close family member. The employee is currently responsible for scoring that bidder's security proposal. What is the BEST response?

- A. Keep scoring the proposal without disclosure if the employee intends to be fair
- B. Ask the bidder to write the employee's evaluation to avoid personal influence
- C. Disclose the relationship and follow the organization's conflict-management process
- D. Disqualify the bidder immediately without consulting the procurement rules

Answer: C

A conflict of interest can affect decision quality and confidence in the selection process even without proven misconduct. The employee should disclose the relationship and follow established rules. An independent evaluator or recusal may be appropriate, but the response should follow the organization's authorized process.

Study tip: Disclose conflicts so the organization can apply impartial decision controls.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: Personal confidence in impartiality does not remove the conflict or its appearance. The organization needs disclosure to apply its established safeguards.

B: Allowing the bidder to evaluate itself undermines independent selection. It does not address the employee's conflict or provide an impartial assessment.

C: Disclosure allows the organization to manage the conflict, including reassignment or recusal where appropriate, while preserving a documented and impartial evaluation.

D: The scenario establishes a conflict requiring management, not automatic disqualification. The authorized process should determine appropriate safeguards or consequences.

## SEC-Q272

A provider supplies an independent assurance report, but its scope covers a different service and its review period ended before a major platform migration. What should the customer conclude?

- A. Independent authorship proves that the current service satisfies every customer requirement
- B. The report is useful context but insufficient evidence for the proposed service as currently operated
- C. The report proves the proposed service is compromised
- D. The report removes the need to review the provider's security contract

Answer: B

Review assurance evidence for relevance as well as credibility. The examined service, control scope, period, exceptions, and subsequent changes determine what conclusions are justified. Here, the customer should request current evidence for the proposed service and assess the migration's effects before relying on the report.

Study tip: An assurance report supports conclusions only within its actual scope and conditions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Independence does not expand the report's scope or review period. Controls for the proposed service and changed environment still require relevant evidence.

B: Assurance is limited by scope, period, and tested conditions. A different service and later migration leave important questions about current controls unanswered.

C: Insufficient assurance is not evidence of an actual compromise. The customer should request relevant information rather than infer an unsupported incident.

D: Technical assurance and contractual obligations serve different purposes. A report does not establish all required responsibilities, notifications, audit rights, or remedies.

## SEC-Q273

A vendor passed due diligence last year. It now repeatedly misses agreed remediation deadlines for significant control gaps. What is the BEST ongoing vendor-management action?

- A. Continue relying on the original review until the next contract renewal
- B. Escalate the missed commitments, reassess exposure, and track a corrective action plan
- C. Replace every vendor finding with the original approved risk score
- D. Accept verbal assurances without recording new target dates or responsibility

Answer: B

Vendor risk management continues after selection. Missed commitments can change both exposure and confidence in the provider's controls. The customer should evaluate severity, use established escalation or contractual mechanisms, and track concrete corrective actions. Further safeguards or a different provider may be considered if the risk remains unacceptable.

Study tip: A passed onboarding review does not replace ongoing vendor oversight.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

A: A historical approval does not address deteriorating performance. The missed security commitments are current evidence that may require action before renewal.

B: Ongoing monitoring should connect missed commitments to risk decisions. Escalation and a tracked plan establish accountable actions and allow the relationship to be reconsidered.

C: Overwriting new evidence with an old rating conceals changes in exposure. The risk assessment should reflect the vendor's current performance.

D: Untracked promises do not establish an accountable corrective plan. The organization needs evidence, responsible parties, deadlines, and escalation for continued nonperformance.

## SEC-Q274

A vendor will penetration-test a production application. The contract authorizes a test, but operating constraints have not been finalized. Which items should be established in the rules of engagement before testing begins? (Select TWO.)

- A. Permission to include any connected customer system discovered during testing
- B. An instruction to keep testing if a stated stop condition is reached
- C. A guarantee that every possible vulnerability will be discovered
- D. Emergency contacts, stop conditions, and an escalation process
- E. Authorized targets, permitted techniques, and test windows

Answer: D|E

Authorization must be made operationally specific. Rules of engagement identify targets, methods, timing, communication channels, and conditions requiring a pause or escalation. These details let the team test purposefully while respecting scope and production constraints. Discovering a dependency does not extend authorization to that dependency.

Study tip: Testing permission needs specific scope and operational boundaries.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Discovering a connected system does not authorize testing it. Additional targets require appropriate explicit authorization and a corresponding scope update.

B: Ignoring an agreed stop condition defeats the operational boundaries. The tester should follow the authorized pause and escalation process when that condition occurs.

C: Testing cannot guarantee discovery of all weaknesses. Rules of engagement should establish authorized conduct and constraints rather than an unattainable completeness promise.

D: Production testing needs an agreed way to pause and coordinate when unexpected impacts occur. Contacts and stop conditions support timely operational decisions.

E: Explicit scope and operating constraints define what the tester may do and when. They help align the engagement with business and technical requirements.

## SEC-Q275

A booking company decides why customer records will be processed and the essential means of processing. A hosting company stores those records solely under the booking company's documented instructions and has no separate purpose for that processing. Which role mapping is correct for this activity?

- A. Booking company: processor; hosting company: controller
- B. Booking company: controller; hosting company: processor
- C. Booking company: data subject; hosting company: controller
- D. Booking company: custodian only; hosting company: data subject

Answer: B

Privacy roles depend on the actual processing activity and decision-making responsibilities. The booking company is the controller because it determines why and the essential means by which the information is processed. The host acts as processor for this instructed activity; a company could have a different role for other processing.

Study tip: Classify privacy roles by decisions and purposes, not by who owns the servers.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/controllers-and-processors/controllers-and-processors/what-are-controllers-and-processors/

A: This reverses the stated responsibilities. Operating the infrastructure does not make the host the controller when it follows the booking company's processing instructions.

B: The controller determines purposes and essential means. The processor performs the described processing on the controller's behalf under its instructions.

C: The company is determining the processing, not being the individual described in these records. Hosting under instructions does not establish independent controller purposes.

D: The booking company makes purpose decisions, and the host is an organization providing processing services. The customers are the individuals described by the records.

## SEC-Q276

A travel agency stores a record containing Maria's name, contact information, and itinerary. In privacy terminology, which role does Maria have in relation to the personal information about her?

- A. Data subject
- B. Data controller
- C. Data processor
- D. Data custodian

Answer: A

Data subject identifies the person the personal information is about. It is distinct from controller, processor, owner, and custodian roles used to describe organizational decisions or responsibilities. A person's privacy rights do not make that person the administrator of the organization's database.

Study tip: Ask whose personal information is being processed.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/controllers-and-processors/controllers-and-processors/what-are-controllers-and-processors/

A: A data subject is the identifiable individual to whom personal information relates. Maria is the person described by the travel record.

B: A controller determines processing purposes and means. Maria's status as the person described does not make her the agency's controller.

C: A processor handles personal information on a controller's behalf. Merely being described in a record does not make Maria a processing service provider.

D: A custodian operates or maintains protective controls and data-handling systems. The question assigns Maria no responsibility for managing the agency's records.

## SEC-Q277

A company cannot explain where former customers' personal information remains or why some copies are retained. Which action would BEST support an effective retention and deletion program?

- A. Map data categories and locations to purposes, owners, and approved retention requirements
- B. Allow each application administrator to retain copies based on personal preference
- C. Treat encryption as a substitute for tracking retained personal information
- D. Set the same retention period for every record without reviewing obligations

Answer: A

Retention management needs visibility into data, its purposes, its locations, and applicable requirements. An inventory with accountable owners enables appropriate schedules and handling of copies across systems. Security controls such as encryption remain useful, but they do not determine whether keeping particular personal information is justified.

Study tip: An effective deletion process starts with knowing what data exists and why.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/dealing-requests-individuals_en

A: An inventory tied to purpose and retention requirements identifies what exists, why it is held, and who can implement appropriate retention or disposal decisions.

B: Uncoordinated preferences do not establish approved purposes or requirements. They make retention inconsistent and can leave undocumented copies outside lifecycle controls.

C: Encryption protects data but does not explain where it exists or why it is retained. Retention obligations still require inventory and lifecycle decisions.

D: Different data categories can have different business and legal requirements. A uniform period chosen without analysis may cause both excessive retention and premature deletion.

## SEC-Q278

An EU retailer receives a verified erasure request. Counsel confirms that specified invoice records must be retained under an applicable legal obligation, but separate obsolete marketing-profile data has no continuing lawful purpose. What is the BEST response?

- A. Retain all customer information indefinitely because some invoices must be kept
- B. Retain only the required invoice data for the justified period and erase eligible profile data
- C. Erase the invoices immediately because every erasure request overrides retention duties
- D. Move the marketing data to an unindexed folder and treat the request as completed

Answer: B

The legal-retention exception applies to the records needed to meet the confirmed obligation. It is not blanket permission to retain everything about the customer. The retailer should erase eligible data, limit retained information and access to justified needs, and explain the relevant outcome through its established request process.

Study tip: Apply a retention exception only to the information and period it actually covers.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/dealing-requests-individuals_en

A: An exception for specified invoice records does not authorize unlimited retention of unrelated information. Scope, purpose, and retention period remain relevant.

B: The confirmed legal requirement supports limited invoice retention. It does not justify retaining unrelated marketing information that is otherwise eligible for erasure.

C: The scenario establishes an applicable legal obligation to retain specified records. Erasure rights have relevant exceptions and do not automatically override that requirement.

D: Changing a location or search visibility does not erase personal information. Eligible data must be handled through the appropriate erasure process.

## SEC-Q279

A company expands into a new region while keeping its cloud servers in its existing country. Its leaders ask whether unchanged server location means the same privacy rules still cover every customer interaction. What is the BEST response?

- A. Review applicable requirements using the business activities, individuals, and data flows involved
- B. Assume the cloud provider becomes solely responsible for every privacy decision
- C. Copy a competitor's privacy notice and treat the expansion review as complete
- D. Assume only the physical server location determines all applicable privacy obligations

Answer: A

A change in operating region can alter privacy obligations even if the infrastructure stays put. The organization should involve its privacy and legal functions, map relevant processing, and determine applicable requirements. The scenario cannot be resolved from server geography or provider involvement alone.

Study tip: Map the processing context before deciding which privacy requirements apply.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final|https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/controllers-and-processors/controllers-and-processors/what-are-controllers-and-processors/

A: Privacy applicability can depend on more than server location. A review of the new activities and data flows identifies relevant obligations and any needed changes.

B: Using a provider does not automatically transfer the company's processing decisions or responsibilities. The parties' actual roles and applicable obligations must be evaluated.

C: A notice cannot establish that the company's actual processing complies with applicable requirements. Another business may have different activities, data flows, and obligations.

D: Server location is relevant but not universally decisive. The organization's establishment, activities, affected individuals, and cross-border processing can also matter.

## SEC-Q280

A manager must attest that recovery tests were completed for all 20 critical applications. Records support 18 applications; the other two have no verified results. What is the BEST action before making that attestation?

- A. Assume that a scheduled recovery test is evidence that it was completed
- B. Ask an administrator to generate historical results from the planned test dates
- C. Resolve the missing verification or accurately qualify the statement through the approved process
- D. Sign the unqualified statement because 90% of the applications have evidence

Answer: C

Attestation is a formal assertion and should match the available evidence. The manager cannot truthfully claim all tests were completed when two remain unverified. The appropriate response is to resolve those gaps or, if the process permits, clearly limit the statement rather than imply unsupported completeness.

Study tip: Match the scope of an attestation to the scope of verified evidence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: A schedule establishes intent, not execution or results. The missing applications need evidence appropriate to the claim being made.

B: Inventing historical results would create false evidence. The organization must verify what occurred or transparently address the gap through its approved process.

C: An attestation must reflect supported facts. Missing verification should be resolved, or the statement's scope and exceptions should be accurately represented where qualification is allowed.

D: A claim covering all 20 applications is not supported by evidence for only 18. A high completion percentage does not establish universal completion.

## SEC-Q281

An automated compliance system reports that several servers violate an approved configuration requirement. The service owner says an exception might apply, but no exception is linked to the records. What should the compliance team do NEXT?

- A. Treat the alerts as proof that the organization has suffered a data breach
- B. Delete the alerts because an owner mentioned that an exception might exist
- C. Declare every server compliant because automated tools can produce false positives
- D. Validate the results and any approved exception, then track the appropriate corrective action

Answer: D

Automation can identify potential deviations efficiently, but the organization must interpret the evidence and apply valid exceptions accurately. The team should confirm the configuration, determine whether an authorized exception covers it, and preserve an auditable resolution. A compliance finding should not be confused with proof of an incident.

Study tip: An automated finding needs validation and an accountable resolution.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: Configuration noncompliance can increase risk but does not itself prove a breach. Incident conclusions require additional evidence of actual compromise or exposure.

B: An unsupported suggestion does not establish an approved exception. Deleting the alerts would remove evidence without resolving the compliance status.

C: The possibility of false positives calls for validation, not blanket dismissal. The reported condition and any exception need evidence-based review.

D: The team needs to determine whether the control is noncompliant or covered by a valid exception. Evidence and accountable follow-through support a defensible result.

## SEC-Q282

A supplier agreement permits a customer to suspend data sharing if the supplier fails to maintain specified security controls. The supplier fails those requirements and loses access to the customer's data feed. What consequence is MOST directly illustrated?

- A. Professional license revocation
- B. Automatic regulatory fine
- C. Reputational damage
- D. Contractual impact

Answer: D

Noncompliance can affect contracts, reputation, licenses, or regulatory exposure depending on the requirements involved. Here, the stated consequence is specifically grounded in a supplier agreement: the customer exercises a contractual right to suspend data sharing. Additional consequences should not be assumed without supporting facts.

Study tip: Identify who imposes the consequence and which requirement gives them that authority.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/cswp/29/the-nist-cybersecurity-framework-csf-20/final

A: No licensing body or licensing requirement is identified. The customer's suspension of a data feed is an action under the contract.

B: The scenario describes enforcement of a customer agreement, not a regulator imposing a penalty. A contractual failure does not itself establish an automatic fine.

C: Reputational harm could accompany a security failure, but the stated action is suspension under a contract. No change in public trust is established.

D: The consequence follows an agreed contract condition. Loss of the customer data feed illustrates how security noncompliance can affect contractual business relationships.

## SEC-Q283

A board wants independent assurance that access reviews were performed according to the company's defined quarterly control requirements. Which engagement MOST directly addresses this objective?

- A. A penetration test seeking an exploitable path into the identity platform
- B. An independent audit examining review records against the stated criteria
- C. A tabletop discussion about a future identity-provider outage
- D. A network discovery exercise listing reachable identity servers

Answer: B

The objective determines the assessment method. The board asks whether a defined process operated according to requirements, so an independent audit of relevant evidence is the best fit. Technical testing could supplement assurance, but a successful or unsuccessful attack does not answer the quarterly-review question.

Study tip: Choose the engagement that produces evidence for the actual assurance question.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: A penetration test can demonstrate attack paths, but it does not directly establish whether required quarterly review activities were completed and documented.

B: An audit evaluates evidence against defined requirements. Independent examination of review records directly addresses whether the quarterly access-review control operated as required.

C: A tabletop tests or develops planned responses through discussion. It does not independently examine historical evidence of the access-review control's operation.

D: Discovery identifies exposed systems and services. It does not evaluate evidence that management performed the required quarterly access reviews.

## SEC-Q284

A department evaluates its own controls using a checklist before the organization's formal audit. Its staff gather evidence, identify gaps, and plan corrections. What activity is this?

- A. External penetration test
- B. Regulatory examination
- C. Internal self-assessment
- D. Independent third-party audit

Answer: C

Self-assessment is an internal review of the organization's or department's own controls and practices. It can identify missing evidence and remediation needs before an audit. Its results may be valuable, but they should not be presented as an independent third-party opinion.

Study tip: Who performs the review matters when classifying independence.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final

A: A penetration test evaluates exploitable weaknesses through authorized testing. The department is examining its own controls and evidence using a checklist.

B: A regulatory examination is performed under a regulator's authority. Nothing in the scenario assigns that authority to the department's internal checklist review.

C: The department is evaluating its own controls to identify gaps. This can improve readiness, but it is distinct from independent assurance.

D: An independent third-party audit is conducted by an external, appropriately independent party. The described review is performed by the department's own staff.

## SEC-Q285

Before an authorized penetration test, assessors receive source code, network diagrams, configuration details, and test accounts to support an in-depth examination. Which testing approach does this BEST describe?

- A. Unknown-environment testing
- B. Known-environment testing
- C. Partially known-environment testing
- D. Passive reconnaissance only

Answer: B

Known-environment testing gives assessors substantial internal knowledge so they can investigate efficiently and deeply. Unknown-environment testing withholds such knowledge, while partially known testing supplies a limited subset. These labels describe what assessors know, separately from whether the engagement is internal, external, or collaborative.

Study tip: Environment labels describe assessor knowledge, not where the tester sits.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Unknown-environment testing begins without substantial internal information. Source code, diagrams, configurations, and accounts provide the knowledge this approach would ordinarily lack.

B: The assessors have extensive internal information that supports a detailed examination. This is the defining feature of a known-environment testing approach.

C: Partially known testing provides limited internal information. The extensive set of source, architecture, configuration, and account information supports a known-environment classification.

D: The described information-sharing model does not restrict testing to passive research. It characterizes assessor knowledge before an authorized penetration test.

## SEC-Q286

An assessor receives an ordinary user account and a short description of an application's purpose, but no source code, architecture diagrams, or administrator access. The engagement models an authenticated user with limited internal knowledge. Which approach is MOST appropriate?

- A. Unknown-environment testing
- B. Known-environment testing
- C. Partially known-environment testing
- D. Compliance attestation

Answer: C

The engagement provides enough internal access to model an authenticated user but withholds extensive design and implementation details. That makes it partially known. The intended starting knowledge and access should be explicit, so reviewers understand what perspective and attack paths the test can examine.

Study tip: A supplied low-privilege account and limited context commonly indicate partially known testing.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: The assessor has a supplied account and internal context. That makes the engagement more informed than an unknown-environment approach described as starting without them.

B: A known-environment engagement typically provides extensive relevant internal information. The scenario deliberately limits knowledge and access to model an ordinary authenticated user.

C: The assessor has limited internal knowledge and a user-level starting point. This fits a partially known approach rather than full disclosure or no disclosure.

D: Attestation is an assertion about defined facts or requirements. The scenario describes an authorized technical testing model based on limited assessor knowledge.

## SEC-Q287

An assessor's reconnaissance phase must gather information without probing the target's infrastructure. Which action BEST satisfies that constraint?

- A. Connect to the target's services to collect software banners
- B. Scan the target's public IP addresses for open TCP ports
- C. Send crafted requests to the target application to identify hidden directories
- D. Review the target's entries in public third-party certificate-transparency records

Answer: D

Passive reconnaissance relies on information already available without directly probing the target under the question's stated constraint. Third-party certificate records can reveal names associated with the organization. Port scans, banner connections, and application enumeration actively interact with the target and require the corresponding authorization.

Study tip: Distinguish third-party information gathering from direct target interaction.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Banner collection through direct service connections interacts with target systems. It is active reconnaissance under the no-probing constraint described here.

B: Port scanning sends packets to the target to observe responses. That is active probing and violates the stated constraint for this phase.

C: Directory enumeration sends requests to target infrastructure to discover behavior or resources. That is active information gathering, not third-party research.

D: Reviewing records maintained by a third party gathers information without sending a probe to the target's infrastructure, matching the stated reconnaissance constraint.

## SEC-Q288

A physical security assessment is authorized for Building A only. During the visit, a helpful employee offers to guide the assessor through restricted areas of Building B. What should the assessor do?

- A. Enter Building B and seek written approval after documenting any findings
- B. Assess Building B because any employee invitation provides sufficient test authorization
- C. Include every building on the same campus because they share an owner
- D. Decline testing Building B and request a scope decision from the authorized coordinator

Answer: D

Physical assessments need the same clear authorization boundaries as technical testing. The employee's offer changes the opportunity, not the approved scope. The assessor should avoid testing Building B until the authorized coordinator determines whether and how the engagement can be expanded.

Study tip: Convenient access does not change the scope of an assessment.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: Retroactive approval cannot substitute for obtaining the required authorization before testing. The assessor should resolve the scope question before proceeding.

B: The scenario limits authorization to Building A. A helpful employee may lack authority to approve testing of another building's restricted areas.

C: Common ownership does not expand an engagement's defined scope. Different facilities can have different operating constraints, occupants, and approval requirements.

D: An employee's invitation does not expand the written assessment authorization. The assessor should respect the current boundary and seek a decision through the agreed channel.

## SEC-Q289

During an exercise, an offensive team performs agreed attack simulations while defenders observe telemetry. The teams then share findings, adjust detections, and rerun selected simulations to verify improvement. Which approach is MOST evident?

- A. An offensive-only test without defender coordination
- B. An audit of documented control approvals
- C. Integrated offensive and defensive assessment
- D. A defensive-only tabletop without attack execution

Answer: C

An integrated exercise connects offensive actions with defensive observations so the teams can improve controls and verify changes. The collaboration is the defining characteristic. The amount of system knowledge given to testers is a separate dimension and is not specified by the term integrated.

Study tip: Collaboration and retesting distinguish integrated exercises from an isolated attack simulation.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: The defenders are explicitly participating and exchanging results. Their detection changes and collaborative retesting distinguish this exercise from an isolated offensive engagement.

B: A documentary audit examines records against defined criteria. The scenario instead uses coordinated attack simulations and defensive retesting to improve detection.

C: The teams deliberately collaborate to connect simulated attacks, observed telemetry, detection changes, and retesting. The exercise integrates offensive and defensive work.

D: A tabletop centers on discussion of a hypothetical scenario. This exercise includes actual agreed simulations performed by an offensive team and subsequent retesting.

## SEC-Q290

An audit tests the requirement that each production deployment have an approved change ticket and a recorded rollback plan. A separate penetration test demonstrates that a low-privilege user can alter another customer's address. Which conclusions are supported? (Select TWO.)

- A. The demonstrated cross-customer change supports an authorization weakness within the tested scope
- B. Deployment records can be checked against the required approval and rollback evidence
- C. The penetration test can replace examination of change tickets for the process audit
- D. A valid change-approval record proves the deployment contains no authorization weaknesses
- E. The demonstrated authorization weakness proves every deployment bypassed change approval

Answer: A|B

The two engagements produce different evidence. The audit evaluates deployment records against documented change-control requirements. The penetration test demonstrates a specific authorization failure in the tested application. A compliant process can still produce vulnerable software, and an exploitable defect does not prove that approval procedures were bypassed.

Study tip: Process-compliance evidence and demonstrated exploitability answer different questions.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/53/a/r5/final|https://csrc.nist.gov/pubs/sp/800/115/final

A: The penetration test provides evidence that the tested access boundary can be crossed. Its demonstrated result supports a specific technical finding.

B: The audit has explicit criteria that can be evaluated using relevant deployment records. Its conclusion concerns process compliance supported by that evidence.

C: Testing an application authorization boundary does not verify required deployment approvals or rollback records. The audit still needs evidence relevant to its criteria.

D: Approval records can demonstrate process compliance but do not establish that the deployed code lacks vulnerabilities. The technical test addresses a different question.

E: An exploitable weakness can exist even when change approvals were obtained. The test does not establish the history of approvals for other deployments.

## SEC-Q291

An employee receives an unexpected message asking them to open a document and reauthenticate. The employee has not clicked anything, and the company provides a Report Phishing button that preserves the message for analysis. What should the employee do?

- A. Reply to the sender to ask whether the message is legitimate
- B. Delete the message without reporting because no credentials were entered
- C. Use the Report Phishing button and avoid interacting with the message
- D. Open the document on a work computer to determine whether it looks authentic

Answer: C

The employee should use the established reporting mechanism before interacting with unexpected content. That gives analysts the original message context and can help identify related messages. Reporting does not require the employee to prove maliciousness or test the document themselves.

Study tip: Report suspicion through the approved channel; employees do not need to investigate attachments.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Replying relies on the potentially hostile communication channel and may confirm an active recipient. The company already provides a safer reporting route.

B: Deletion alone removes an opportunity for security analysis and protection of other recipients. The approved reporting function is available even when no interaction occurred.

C: The approved reporting tool preserves useful evidence and alerts the security team. Avoiding the document and sign-in request prevents unnecessary exposure.

D: Opening unexpected content can expose the endpoint or prompt credential theft. Visual authenticity is not sufficient verification and is unnecessary before reporting.

## SEC-Q292

An accounts-payable employee receives an urgent voice call that sounds like the CFO and asks for a supplier's bank details to be changed immediately. The caller discourages following the normal approval process. What is the BEST response?

- A. Approve the change if the caller correctly states the CFO's name and job title
- B. Treat a familiar-sounding voice as sufficient authorization for the change
- C. Verify through a trusted independent channel and follow the payment-change approval process
- D. Use the callback number supplied during the same call as the sole verification

Answer: C

The employee should verify the request through a trusted route and preserve the normal approval process. The requested bank change is financially consequential, and the pressure to bypass controls is a warning sign. A recognizable voice or accurate organizational information is insufficient by itself.

Study tip: Verify consequential requests through a contact route the requester did not supply.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Names and titles are often discoverable and do not authenticate a caller. They cannot replace the required approval and verification process.

B: Voice familiarity can be misleading, including through impersonation or generated audio. The payment-change process provides stronger, independently verifiable authorization.

C: An independent channel and established approval process reduce reliance on the caller's claimed identity. Urgency and pressure to bypass controls warrant verification.

D: A number supplied by the requester may lead back to the attacker. Verification should use a trusted independently obtained contact method.

## SEC-Q293

An employee entered their password into a page opened from an email and then noticed the site address was unfamiliar. What guidance should the awareness program tell the employee to follow?

- A. Close the browser and assume the password was not transmitted
- B. Promptly report through a known support channel and follow the account-recovery process
- C. Change the password using another link in the same email without reporting
- D. Wait for an account-lockout notification before contacting support

Answer: B

Awareness guidance should make immediate reporting easy after a suspected mistake. Responders can assess credential exposure and coordinate password or authenticator recovery, session revocation, and investigation as appropriate. The employee should use a known trusted channel rather than follow further instructions from the suspicious message.

Study tip: After possible credential exposure, report promptly through a trusted route.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://csrc.nist.gov/pubs/sp/800/61/r3/final|https://pages.nist.gov/800-63-4/sp800-63b.html

A: Closing a page after submission does not retract credentials already sent. The employee should treat the disclosure as potentially real and initiate the approved response.

B: Reporting enables coordinated credential changes, session review, and other appropriate response steps. A known channel avoids returning to the potentially fraudulent page.

C: The additional link may also be attacker-controlled. A private password change alone may leave the security team unaware of exposed sessions or related activity.

D: The absence of a lockout does not establish that the account is safe. Prompt reporting gives responders a better opportunity to limit misuse.

## SEC-Q294

A field technician finds a USB flash drive labeled 'Store schedules' near a shared workstation. Company guidance requires unknown media to be handled by the security team. What is the BEST action?

- A. Open only the document files because the label suggests an operational purpose
- B. Insert it into the shared workstation after disabling AutoRun
- C. Keep the drive disconnected and deliver it through the approved reporting process
- D. Connect it to a personal laptop so production equipment is unaffected

Answer: C

Unknown removable media should be handled according to the organization's policy without connecting it to ordinary equipment. A plausible label is not evidence of trustworthiness. Disabling a particular execution feature or using a personal machine does not establish that the device is safe to inspect.

Study tip: An appealing label is a reason to verify provenance, not to trust a USB device.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: A label does not establish provenance or safety, and document files can be malicious. The technician should follow the designated handling process.

B: Disabling AutoRun does not address every malicious-device behavior or dangerous file. The drive should remain disconnected under the stated handling policy.

C: Following the unknown-media process avoids exposing a workstation and allows authorized personnel to decide whether and how the device should be examined.

D: A personal device can still be compromised or expose information. Moving the risk outside production does not satisfy the approved unknown-media process.

## SEC-Q295

An employee working in a public café uses an approved VPN but is about to discuss customer details on a loud video call while the laptop screen faces nearby customers. Which guidance BEST addresses the immediate gap?

- A. Move to a private workspace and protect both displayed and spoken information
- B. Enable full-disk encryption and continue the call in the same location
- C. Increase password length before beginning the customer discussion
- D. Switch VPN protocols while keeping the same seating and call volume

Answer: A

Remote-work awareness must include the surrounding physical environment as well as network protection. The VPN does not prevent shoulder surfing or overheard conversations. The employee should choose a suitable private setting and apply the organization's guidance for screens, discussions, and sensitive information.

Study tip: Network encryption does not protect information that others can see or hear.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: The visible screen and audible conversation expose information locally. A private setting and appropriate display handling address the specific physical privacy risks.

B: Disk encryption protects stored data in relevant device states. It does not conceal an unlocked display or prevent others from overhearing the call.

C: A stronger password does not stop observation of an active screen or conversation. The immediate issue concerns physical and situational privacy.

D: VPN configuration affects network protection, not whether nearby people can see the screen or hear customer details. The local exposure would remain.

## SEC-Q296

A technician wants to post a photo of a successful network upgrade on a public professional profile. The image includes an employee badge, internal hostnames, and a whiteboard of upcoming maintenance dates. What is the BEST action?

- A. Remove sensitive operational details and obtain any required approval before posting
- B. Post the original image because the profile is intended for professional contacts
- C. Post the image after checking that no password is visible
- D. Assume the details are harmless because the network upgrade is already complete

Answer: A

Operational security considers what apparently ordinary information can reveal when combined. Badges, internal system names, and schedules may support impersonation or more convincing pretexts. Public sharing should be reviewed for those details and follow the organization's approval requirements before publication.

Study tip: Look for useful context an attacker could combine, not only obvious secrets.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: The image reveals information useful for impersonation or targeting. Reviewing and removing sensitive details supports operational security while following the organization's publication process.

B: A public professional audience does not limit the image to trusted recipients. The exposed details remain available for unintended use.

C: Operational security includes more than passwords. Badges, internal names, and schedules can provide useful context for social engineering or targeted activity.

D: Completed work can still reveal current identities, internal structure, or future maintenance information. Completion does not remove the disclosure risk.

## SEC-Q297

An employee observes a colleague downloading an unusually large set of customer files unrelated to their apparent current work. The employee does not know whether there is an approved business reason. What is the BEST response?

- A. Report the observed facts through the designated channel without assuming intent
- B. Publicly accuse the colleague of stealing data to discourage further downloads
- C. Access the colleague's personal accounts to search for evidence of wrongdoing
- D. Ignore the activity unless the employee can prove that a crime occurred

Answer: A

Awareness training should encourage reporting unusual or risky behavior based on facts. Legitimate work, mistakes, and malicious activity can look similar without context. Authorized personnel can assess access, business purpose, and evidence; the observer should not independently investigate private accounts or make unsupported accusations.

Study tip: Report the anomaly; let authorized investigators determine context and intent.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: An objective report allows authorized personnel to assess the activity in context. Anomaly recognition does not require the observer to establish malicious intent.

B: An unusual action is not proof of misconduct. Public accusations can cause harm and interfere with a fair, authorized investigation.

C: Personal investigation can violate authorization and privacy boundaries. The employee should report work-related observations so designated personnel can investigate appropriately.

D: Reporting channels exist to evaluate concerns before intent is established. Requiring proof of a crime would discourage useful early reporting of suspicious behavior.

## SEC-Q298

A learning program gives developers secure-coding exercises, help-desk staff identity-verification scenarios, and executives risk-decision briefings, alongside basic training for everyone. Which approach does this demonstrate?

- A. Incident-only training
- B. Uniform technical training
- C. A purely technical vulnerability assessment
- D. Role-based security training

Answer: D

Role-based training connects security learning to the work people perform. Developers, support personnel, and executives face different decisions and benefit from relevant practice. Shared baseline awareness still matters, and initial learning should be reinforced with recurring updates as responsibilities, procedures, or threats change.

Study tip: Tailor practice to the security decisions each role is expected to make.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Incident-only training is triggered solely by events. The scenario describes a planned learning design based on roles, not only past incidents.

B: Uniform training gives everyone the same content. This program deliberately varies its exercises and briefings according to each group's responsibilities.

C: A vulnerability assessment examines weaknesses in systems or processes. These activities develop workforce knowledge and behavior through role-specific learning.

D: The program tailors learning to responsibilities and decisions different groups actually perform, while retaining common baseline awareness for the entire workforce.

## SEC-Q299

After training, a phishing simulation's click rate falls from 12% to 3%. The second campaign used much easier warning signs and reached a different mix of employees. What is the BEST interpretation?

- A. The result is encouraging, but comparable campaigns and behavior measures are needed to assess improvement
- B. The result proves the second employee group is more trustworthy than the first
- C. The lower rate proves that the training alone caused a 75% reduction in susceptibility
- D. The company should discontinue reporting drills because the click rate is now below 5%

Answer: A

The click rate declined by nine percentage points, a 75% relative decrease, but campaign and audience changes prevent a clean conclusion about training effectiveness. Compare similar conditions and assess useful behaviors such as reporting accuracy and time to report. Metrics should guide improvement, not unsupported claims or employee labels.

Study tip: Separate observed improvement from proof of causation; control for campaign difficulty and audience.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final

A: Difficulty and audience changed, so click-rate differences cannot be attributed solely to training. Comparable measures and reporting behavior provide a stronger evaluation.

B: Simulation outcomes are influenced by context and design. A changed click rate does not justify broad judgments about employee trustworthiness.

C: The relative drop is 75%, but the changed difficulty and audience confound attribution. The calculation alone does not establish the training's causal effect.

D: No justified stopping threshold is provided. Recognition, reporting, and response behavior still need evaluation, particularly when the campaign conditions changed.

## SEC-Q300

A company is updating employee guidance after incidents involving password reuse and unexpected MFA approval prompts. Which recommendations BEST address these behaviors? (Select TWO.)

- A. Deny unexpected MFA prompts and report them through the approved channel
- B. Approve repeated MFA prompts until the notifications stop
- C. Use the approved password manager to maintain unique passwords for different services
- D. Reuse the corporate password only on services that display an HTTPS connection
- E. Share a password-manager vault's master password with a coworker for convenience

Answer: A|C

Password reuse allows a compromise at one service to affect another, so unique passwords and an approved manager reduce that exposure. Unexpected MFA prompts require deliberate denial and reporting. MFA still depends on correct use; approving an attacker's request can defeat the intended protection.

Study tip: Unique passwords limit reuse attacks; unexpected MFA requests should be denied and reported.

Sources: https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6|https://csrc.nist.gov/pubs/sp/800/50/r1/final|https://pages.nist.gov/800-63-4/sp800-63b.html

A: Unexpected prompts may signal an unauthorized sign-in attempt. Denial and reporting help avoid approving an attacker while enabling security review.

B: Approving an unsolicited prompt can authorize an attacker's sign-in. Repeated prompts call for denial and reporting rather than consent under pressure.

C: Unique passwords limit the effect of one service's credential exposure on other accounts. An approved manager supports generating and handling those passwords.

D: HTTPS protects transport to that service but does not prevent its compromise or misuse. Password reuse still enables one exposed credential to affect other accounts.

E: Sharing the vault's main secret expands access beyond the intended owner. The organization should use approved sharing or delegation features when business access is needed.
