# History Bowl import guide

## Package contract

Add a separate subject named **CompTIA Security+ (SY0-701)**. The package contains 300 quiz items and 25 multi-part PBQs. Existing History Bowl records provide the CSV layout; the actual earlier CSV bytes were checked to verify its 15-column header and order. The new quiz CSV preserves those fields, then appends Security+ metadata.

The package is data and instructions. It has not been deployed to or tested inside the live study site. A site that only supports one answer per question needs `multiple_select` support, and PBQs need the task renderer described below.

## Main quiz CSV

File: `security_plus_quiz.csv`

Encoding is UTF-8 without a BOM, comma separated, with double-quoted fields, doubled embedded quotes and CRLF record separators. Use an RFC 4180-compatible CSV parser. Embedded line breaks inside quoted fields belong to the question; do not split the file on lines or commas yourself.

The first 15 columns exactly match the earlier History Bowl header:

```text
question_id,source_page,question,option_a,option_b,option_c,option_d,option_e,option_f,correct_option,correct_answer,accepted_variants,question_type,asset_id,notes
```

These 18 fields follow them:

```text
item_id,exam_code,domain_id,domain_name,objective_id,topic,difficulty,select_count,explanation,rationale_a,rationale_b,rationale_c,rationale_d,rationale_e,rationale_f,exam_tip,source_ids,source_urls
```

| Field | Meaning and handling |
| --- | --- |
| question_id | Integer 1–300, retained for the original importer |
| source_page | Blank: these are original questions, not questions transcribed from a source page |
| question | Full question stem; render as text, retaining meaningful newlines |
| option_a–option_f | Answer choices; omit empty choices from the UI |
| correct_option | Uppercase choice letter, or a pipe-delimited set such as `B\|E` |
| correct_answer | Human-readable answer text; multiple correct texts use ` || `; display only, not the scoring authority |
| accepted_variants | Blank because quiz scoring uses option identities, not free-text variants |
| question_type | `multiple_choice` for 270 questions; `multiple_select` for 30 |
| asset_id | Blank; no images or external media are needed |
| notes | Blank; no required prompt information is hidden in notes |
| item_id | Stable, namespaced identifier `SEC-Q001`–`SEC-Q300`; use it for progress and deduplication |
| exam_code | `SY0-701` |
| domain_id / domain_name | Main exam domain, numbered 1–5 |
| objective_id | Primary objective, e.g. `4.3`; preserve as a string |
| topic | Specific concept label for filters and review |
| difficulty | `foundational`, `intermediate`, or `advanced`; editorial labels |
| select_count | Number of required selections: 1, 2, or 3 |
| explanation | Main explanation, revealed after submitting |
| rationale_a–rationale_f | Explanation attached to each original answer choice |
| exam_tip | Short reasoning reminder, revealed with feedback |
| source_ids / source_urls | Pipe-delimited primary reference IDs and corresponding URLs; resolve IDs in `SOURCES.md` |

### Answer handling

For single-answer questions, show radio buttons and require one answer. For multi-select questions, show checkboxes, display the required selection count from `select_count`, and require that many selections before submission. The question itself also states the count.

Award one practice point only when the selected set exactly equals `correct_option`. An omitted correct answer or an extra answer makes that quiz item incorrect. You may show per-choice feedback afterward without awarding partial quiz credit.

Use stable option identities when shuffling. Move the answer text and its rationale together. Do not shuffle text and continue comparing against the old visible position. Do not use `correct_answer` text as the scoring key.

Example normalization after a proper CSV parser has produced a row object:

```javascript
function normalizeQuizRow(row) {
  const expected = row.correct_option.split('|').filter(Boolean);
  const choices = ['A', 'B', 'C', 'D', 'E', 'F']
    .map(id => ({
      id,
      text: row[`option_${id.toLowerCase()}`] ?? '',
      rationale: row[`rationale_${id.toLowerCase()}`] ?? ''
    }))
    .filter(choice => choice.text.trim() !== '');

  const choiceIds = new Set(choices.map(choice => choice.id));
  const selectCount = Number(row.select_count);
  if (!expected.length || expected.length !== selectCount ||
      new Set(expected).size !== expected.length ||
      expected.some(id => !choiceIds.has(id))) {
    throw new Error(`Invalid answer key: ${row.item_id}`);
  }

  return {
    id: row.item_id,
    legacyId: Number(row.question_id),
    subjectId: 'security-plus-sy0-701',
    type: row.question_type,
    prompt: row.question,
    choices,
    correctIds: expected,
    selectCount,
    objectiveId: row.objective_id,
    domainId: Number(row.domain_id),
    difficulty: row.difficulty,
    explanation: row.explanation,
    examTip: row.exam_tip
  };
}

function exactSetCorrect(selected, expected) {
  return Array.isArray(selected) &&
    selected.length === expected.length &&
    new Set(selected).size === selected.length &&
    selected.every(id => expected.includes(id));
}
```

Render log strings and code-like answer text literally. For PBQ Markdown, disable raw HTML or sanitize it, while preserving tables, lists and fenced code blocks. Do not display answer keys, rationales or reasoning tips before the learner submits an attempt.

## PBQ data model

`security_plus_pbqs.json` is the authoritative machine-readable PBQ file. The top-level object contains `schema_version`, `exam_code`, `authored_on`, `original_practice`, `scoring_note`, and a `pbqs` array of 25 cases. The CSV PBQ index is for navigation and metadata; it is not a replacement for the full JSON.

Each case contains:

- `id`, `title`, `exam_code`, `primary_domain`, `objective_ids`, `difficulty`, and `source_ids`.
- `time_minutes` and `max_points`, which are practice settings.
- `scenario_md` and `exhibits`, where each exhibit has `id`, `title`, and `content_md`.
- `tasks`, each with `id`, `prompt`, `response_type`, `options`, and `max_points`; an optional `group` label can guide the layout.
- `answer_key`, with one entry per task: `task_id`, `correct_response`, `explanation`, and `scoring`.

Task IDs are unique within a PBQ. Use the pair `(pbq.id, task.id)` as the stored response key. Option IDs are stable semantic keys, not display positions. Keep them internal: display simple letter labels or numbers beside option text. The standalone PBQ Markdown uses letters that restart at A for each task, with matching letters in its answer key. When the site shuffles choices, regenerate display labels and continue storing and grading the original option IDs. Do not infer the right answer from option order.

### Rendering and grading

| response_type | Suggested control | Expected response | scoring.method |
| --- | --- | --- | --- |
| single_select | Dropdown, radio group, or one matching slot | One option ID string | exact |
| multi_select | Checkbox group or multiple matching slots | Unordered array of option IDs | set_exact |
| ordering | Reorderable list with keyboard move buttons | Ordered array of all option IDs | ordered_exact |
| number | Numeric field, with units in the prompt | Finite number | numeric |

The 200 tasks comprise 180 selection/configuration fields, 4 multi-select fields, 12 numeric fields and 4 ordering fields. Matching exercises and configuration grids are represented as several independent selection tasks. Your agent can arrange related tasks in a table or drag-and-drop layout without changing their IDs or grading. A PBQ must retain its full scenario and exhibits; flattening it into a single quiz question loses the exercise. No free-text grading or external lab environment is required.

Each correct task earns its `max_points`; an incorrect or unanswered task earns zero. Thus, a PBQ supports partial credit across its tasks. Within an individual multi-select or ordering task, exact completion is required. Sum tasks for the PBQ score. The key's `scoring.points` equals the task's `max_points`, and the case's `max_points` is their sum.

Reference grading logic:

```javascript
function gradeTask(task, key, response) {
  let correct = false;
  const expected = key.correct_response;
  const sameList = (a, b) => Array.isArray(a) && Array.isArray(b) &&
    a.length === b.length && a.every((value, index) => value === b[index]);

  switch (key.scoring.method) {
    case 'exact':
      correct = typeof response === 'string' && response === expected;
      break;
    case 'set_exact':
      correct = exactSetCorrect(response, expected);
      break;
    case 'ordered_exact':
      correct = sameList(response, expected);
      break;
    case 'numeric': {
      // Empty input must not silently become zero. The input UI supplies
      // an unformatted number; display the requested units separately.
      const present = typeof response === 'number' ||
        (typeof response === 'string' && response.trim() !== '');
      const value = present ? Number(response) : NaN;
      correct = Number.isFinite(value) &&
        Math.abs(value - expected) <= (key.scoring.tolerance ?? 0);
      break;
    }
    default:
      throw new Error(`Unsupported scoring method: ${key.scoring.method}`);
  }
  return { correct, points: correct ? task.max_points : 0,
    possible: task.max_points, explanation: key.explanation };
}
```

Keep quiz percentage and PBQ task points visible separately. A combined practice percentage may also be useful, but it must be labeled as practice scoring. Do not convert it to CompTIA's scaled score or claim it predicts a pass.

## Optional practice configurations

`practice_sets.json` supplies three nonoverlapping practice exams. Each contains 85 quiz IDs and 5 PBQ IDs with a 90-minute suggested limit. The reserve contains 45 quiz items and 10 PBQs, unused in those three configurations. No new questions are introduced by these lists; all IDs resolve to the main bank.

The quiz IDs in each set use approximate domain weighting. The choice of five PBQs is a practice design choice, not a prediction of the real exam. Let the learner choose untimed objective drills, review of missed items, or a timed practice set.

## Site-agent handoff

> Add this package as a separate CompTIA Security+ SY0-701 subject in the existing study site. Import all 300 quiz rows, using the original 15-column History Bowl layout plus the documented metadata. Preserve namespaced item IDs for saved progress. Add exact-set checkbox scoring for the 30 multiple-select items, hide blank choices, and keep rationales attached to option IDs when shuffling. Render all 25 PBQs from their full JSON scenarios, exhibits, tasks and answer keys, using radio/dropdown, checkbox, ordering and numeric controls as specified. Make the exercises usable by keyboard and on a small screen. Reveal explanations after submission. Provide filters for domain, objective and difficulty, review of missed questions, and the supplied optional practice sets. Validate counts, saved progress, grading and reset behavior before marking the import complete.

## Import acceptance checks

- Exactly 300 unique quiz items appear: 270 single-answer and 30 multi-select, with the stated 36/66/54/84/60 domain totals.
- Exactly 25 PBQs appear, with every exhibit and task intact. Every key resolves to a task and every expected option exists.
- Choice shuffling preserves scores and rationales. No blank option button is displayed. Required selection counts are enforced.
- A correct multi-select set scores correctly regardless of order. Missing, duplicate, extra, or incorrect selections do not earn quiz credit.
- A numeric zero is accepted when correct; an unanswered numeric field earns zero points. Ordering comparisons preserve order.
- Refresh/resume stores responses and progress by subject plus stable item/task IDs. A new attempt resets its responses without changing the bank.
- Candidate views hide answers until submission. Tables and code-like logs render literally and remain readable.
- Practice-set IDs resolve, the three sets do not overlap, and reserve items remain available for fresh review.
