# Security+ SY0-701 study bank

**300 original quiz questions and 25 original performance-based practice scenarios.** Prepared October 3, 2026 for study and import into the History Bowl quiz site.

## Start here

1. Import `security_plus_quiz.csv` for the quiz bank.
2. Give your site agent `IMPORT_GUIDE.md` and `security_plus_pbqs.json` to add the PBQ exercises and select-multiple support.
3. Use `PBQ_QUESTIONS.md` for standalone practice. Open `PBQ_ANSWER_KEY.md` after attempting the tasks.
4. Use `QUIZ_REVIEW.md` for complete explanations and `OBJECTIVE_COVERAGE.md` to target weak objectives.

## Included files

| File | Contents |
| --- | --- |
| security_plus_quiz.csv | All 300 questions, options, correct answers, objective/difficulty tags, explanations and a rationale for every choice |
| security_plus_pbqs.json | All 25 PBQs with exhibits, tasks, stable option IDs, answer keys and machine-readable scoring |
| security_plus_pbq_index.csv | 25-row PBQ index linking each case to its question, solution and JSON |
| PBQ_QUESTIONS.md | Candidate-facing scenarios and exhibits, with no answer key |
| PBQ_ANSWER_KEY.md | Worked solutions and task-level scoring |
| QUIZ_REVIEW.md | Full quiz bank with answer-by-answer explanations |
| OBJECTIVE_COVERAGE.md | All 28 objective mappings and domain allocations |
| IMPORT_GUIDE.md | Exact CSV schema, answer handling, PBQ data model and site-agent handoff |
| STUDY_GUIDE.md | Suggested study workflow, common distinctions and PBQ approach |
| SOURCES.md | Official exam blueprint and primary technical references |
| practice_sets.json | Three nonoverlapping 85-question + 5-PBQ practice configurations, plus fresh reserve items |
| PACK_MANIFEST.json | File sizes, hashes and validation totals |

## Quiz mix

- 270 questions have four choices and one best answer.
- 30 questions have five or six choices and explicitly require two or three answers.
- Every item has a unique `SEC-Q###` identifier and maps to one main exam objective.
- All choices have explanations, including the distractors.
- Choice positions are varied; the 270 single-answer items use A/B/C/D 68/68/67/67 times.

| Domain | Name | Exam weight | Questions | Single-answer | Multi-select |
| --- | --- | ---: | ---: | ---: | ---: |
| 1 | General Security Concepts | 12% | 36 | 32 | 4 |
| 2 | Threats, Vulnerabilities, and Mitigations | 22% | 66 | 59 | 7 |
| 3 | Security Architecture | 18% | 54 | 49 | 5 |
| 4 | Security Operations | 28% | 84 | 76 | 8 |
| 5 | Security Program Management and Oversight | 20% | 60 | 54 | 6 |
| Total | | 100% | 300 | 270 | 30 |

The weights come from [CompTIA’s SY0-701 objectives](https://comptiacdn.azureedge.net/webcontent/docs/default-source/exam-objectives/comptia-security-sy0-701-exam-objectives-(6-0).pdf?sfvrsn=204179cc_6). The 25 PBQs are separate additional practice.

## History Bowl compatibility

The leading CSV fields preserve the earlier History Bowl question layout, including option_a through option_f, correct_option, correct_answer, accepted_variants, question_type and asset_id. Security+ metadata is appended. Unused choices are blank. Your agent should register this as a separate subject and use the namespaced item_id for progress tracking.

The existing site importer was not executed against this new bank. If it currently supports only a single correct choice, it needs checkbox handling for multiple_select and a task renderer for PBQs. The exact rules and acceptance checks are in IMPORT_GUIDE.md.

## Scope and scoring

This bank targets **SY0-701** and uses the official objectives as its syllabus. It contains original practice questions, not CompTIA exam items or recalled test content. It is not endorsed by CompTIA. Difficulty tags, task points, recommended times and the practice-set composition are author-designed study aids. Practice percentages are not CompTIA scaled scores or a guarantee of a passing result.
