# Security+ Study source bank - v1.0.0

Original, unofficial SY0-701 practice material for community review and supplementary study. Questions and answer keys may contain errors. Check uncertain points against trusted documentation, licensed training, and an instructor. Scores do not predict an exam result.

The repository installer loads the bank automatically. This archive contains authored interactive prompts and keys in JSONL, knowledge questions in CSV, PBQ scenarios in JSON, fixed exam manifests, technical references, an offline builder, and structural validators. CLI and firewall exercises are non-executing simulations.

For authoring, edit the relevant CSV/JSON/JSONL source and use the repository's scripts/rebuild-content.py to keep bundled formats in sync. The archive's tools/build_package.py rebuilds derived files when extracted. Run tools/validate_package.py for structural and grading-consistency checks; those checks are not factual certification.
