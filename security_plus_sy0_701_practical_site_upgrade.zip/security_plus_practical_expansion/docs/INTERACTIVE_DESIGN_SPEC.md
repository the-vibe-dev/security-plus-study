# Security+ Practice — Interaction & Visual Design Specification

## Design direction

Preserve the History Bowl site's existing brand/navigation patterns, but give the Security+ study area a bright, calm, capable interface. No giant hero banners or neon cyberpunk UI; study content comes first. Proposed tokens (adapt to site's theme): off-white `#F8FAFC`, surface `#FFFFFF`, ink `#14253D`, muted ink `#4B647C`, primary blue `#2563EB`, teal focus `#0D9488`, borders `#DCE5EF`, error `#B91C1C`. Meet WCAG AA contrast; tokens are examples, not a mandate to overwrite global CSS. Respect light/dark and reduced-motion settings.

Desktop layout: 260–300px sidebar only if existing navigation already supports one, generous central question width ~950px, sticky compact timer/progress bar, narrow task navigator. Mobile: collapsed navigator, stacked choices/table card scroll, full-width submit/next controls. Avoid nested scrolling traps on code, logs or drag/drop areas. Mobile controls must be usable by touch and keyboard without relying on precise drag gestures.

## Security+ routes and content navigation

- `/security-plus` — **Exam Readiness** dashboard: Continue studying, practice exams grid (01–10), weaknesses by domain, resume attempts, practice-by-skill tiles.
- `/security-plus/exams` — exactly ten exam cards, each status Not Started/In Progress/Completed, 90 items, 90-minute clock and count of reviewed/wrong items (if completed). No visible "Set 1" or "Set 2" anywhere.
- `/security-plus/exams/:examId` — PBQ-first practice exam, sticky compact timer, flagged navigator, progress, question types mixed in the exam, one Save & Next button, Submit Exam confirmation.
- `/security-plus/practice` — filter by domain/objective/type/difficulty, choose count/mode, study focused questions from **entire** knowledge+practical bank rather than a different page for each file.
- `/security-plus/labs` — PBQ Labs gallery grouped by firewall, terminal, topology, logs, IAM, forensics, etc.
- `/security-plus/acronyms`, `/ports`, `/cli`, `/firewall` — dedicated fast drills, all backed by the same canonical question engine and attempts store.
- `/security-plus/review` — wrong/flagged/unattempted questions across ALL types, with partial-credit details and solution explanations after practice submission.
- `/security-plus/history` — historic attempts including archived old set attempts; retain data without Set 1/2 labels.

If existing paths differ, adapt them. Preserve 6th-grade History Bowl and existing URL traffic.

## Question chrome (consistent across every type)

Top compact row: `Practice Exam 04` • `Question 13 / 90` • `Objective 4.4` • `08:41 remaining` • Flag toggle. Below: case stem, evidence panel(s), primary interaction panel, compact bottom actions (`Back`, `Save & Next`, `Mark for review`). In learning mode, answer feedback is a collapsible after-attempt section with rationale; in timed mode all feedback remains hidden until final submission. Provide `Skip` for difficult PBQs and allow later return.

## Required first-class renderers (not disguised MCQ)

### Simulated CLI (`simulated_cli`)

- Terminal panel with prompt, monospaced output and a **sandbox indicator**: "Practice simulator — no real commands executed."
- Student enters a single command. A restricted, typed command parser matches the fixture. Only then show the matching canned result and interpretation-choice field. Incorrect commands give non-answer-revealing feedback in practice mode; log attempt safely.
- Support Linux tools, Nmap, DNS, TLS and Windows PowerShell examples without running any command or allowing arbitrary tokens to reach `exec`, `eval`, shell or network. No remote host connection is ever made.
- The answer grading key checks both the command and what the output supports (not unjustified conclusions).

### Firewall rule builder (`firewall_rules`)

- Editable grid: rule order, action Allow/Deny, protocol TCP/UDP, source CIDR, destination CIDR, destination port, remove/reorder rule; default `Deny` is visible but not editable in these items.
- A secondary "Test Traffic" panel can let the learner enter a source/destination/port/protocol and receive *simulated* allow/deny according to **their submitted rules**, without telling which rules satisfy the hidden grading tests.
- Auto-save each row; detect invalid CIDR, ports 1–65535, overlapping shadowed rules, overly broad source scope and invalid protocol combinations. Explain the effect of first-match ordering and stateful responses.
- Server grader tests required reachability, prohibited neighboring clients/services/destinations and exact scope for full credit. Avoid grading purely by string comparison of the rule table.

### Matching (`matching`)

- Two-column pairs with draggable rows, or explicit per-row comboboxes for keyboard/touch accessibility. Each target can be used once for `one_to_one: true`.
- Preserve stable IDs even if right choices shuffle. Show partial credit by correctly paired item after submission.

### Ordering (`ordering`) and timeline (`timeline`)

- Reorder cards with pointer drag or accessible move-up/move-down buttons; timeline cards display timestamps, timezone offsets and source where provided.
- Do not pre-sort the cards with the hidden correct order. Highlight dependencies and wrong order only in after-exam review.

### Network diagram (`topology`)

- SVG canvas based on supplied `slots` and `elements`, with zoom and pan on desktop plus keyboard-accessible per-slot dropdown. Node labels use neutral positions A/B/C and functional hints. Provide screen-reader accessible equivalent list describing nodes and connections.
- Never treat a correct topology as a static image or show the answer through hard-coded CSS placement.

### Packet and log viewer (`single_select`/`multi_select` + `stimulus`)

- Immutable evidence table, copy of anonymized synthetic source lines, row numbers, searchable display, highlight/select multiple records where `candidate_ids` are present. For readability, color only important tokens (TCP flags, IPs, events), and label why a flag is significant only after grading.

### Numeric, text and acronym drills (`numeric`, `text_entry`)

- Numeric entry with unit label (USD, minutes, hours) and optional non-answer-revealing formula sheet in learning mode. Reject NaN/infinity, accept properly formatted numbers, honor exact tolerance.
- Acronym free recall typed input with optional hint on explicit user request in nonexam mode. Lowercase/casing and punctuation should not penalize semantically identical expansions.

## Practices and analytics

- Practice by category must generate mixed questions from the canonical bank: 20-question CLI tools; 20-question acronym/ports review; configurable matching/order drills; 10 PBQ labs.
- No question type is excluded from wrong-answer review, bookmarks, spaced repetition, topic mastery statistics or exam feedback.
- Show separate metrics: knowledge accuracy; interactive practice points; full PBQ points; objective/domain strengths; time by item type; 7-/30-day trends. **No unsupported CompTIA 750-equivalent score.**
- Existing user attempt progress must be preserved under archived attempts. New exam progress keys use `examId` + `manifestVersion` + `attemptId`; never use display labels as database keys.

## Empty/error/accessibility states

- Loading: skeleton content, not an empty exam screen; offline/disconnect: persisted local unsent state with reconciliation and duplicate submission safeguards; missing item: fail safely with error and do not silently substitute another.
- Keyboard-only completion possible for every UI type. Do not rely on color alone; ARIA announcements for moved matches or rules; contrast AA; scalable text; reduced-motion compatibility.
- Responsive at 360, 768, 1024 and 1440px; long logs and the rule grid use one controlled horizontal scroll region without clipping action buttons.
- Render `prompt`, `stimulus`, command output and Markdown with safe escaping/sanitization to prevent script execution; no unsanitized HTML injection.
