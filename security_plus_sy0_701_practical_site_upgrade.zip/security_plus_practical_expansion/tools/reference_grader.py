#!/usr/bin/env python3
"""Offline reference scorer for Security+ practical expansion.
This is reference only: run all authoritative grading SERVER-SIDE in production.
User-provided commands are never executed or passed to a shell.
"""
from __future__ import annotations
import ipaddress, re, math

def _norm(v):
    s=str(v).casefold().replace('&',' and ').replace('–','-').replace('—','-')
    return ' '.join(re.findall(r'[a-z0-9]+',s))

# Kept equivalent to the text-only lexer in command-match.mjs. No execution.
def command_tokens(value,shell='bash'):
    if not isinstance(value,str) or len(value)>200:return None
    windows=shell in ('powershell','cmd');tokens=[];word='';quote='';started=False;index=0
    while index<len(value):
        char=value[index]
        if char=='\\' and not windows and quote!="'":
            index+=1
            if index>=len(value):return None
            word+=value[index];started=True
        elif quote:
            if char==quote:quote=''
            else:word+=char
        elif char in ('"',"'"):quote=char;started=True
        elif char.isspace():
            if started:tokens.append(word);word='';started=False
        else:word+=char;started=True
        index+=1
    if quote:return None
    if started:tokens.append(word)
    return [token.lower() if windows and (i==0 or __import__('re').match(r'^-[a-z]',token,__import__('re').I)) else token for i,token in enumerate(tokens)]

def _valid_unique_order(response, expected):
    return isinstance(response,list) and len(response)==len(expected) and set(response)==set(expected)

def _firewall_decision(rules,flow):
    try:
        for rule in sorted(rules,key=lambda x:int(x.get('priority',100))):
            proto=str(rule.get('protocol',rule.get('proto',''))).lower()
            if proto!=flow['proto']: continue
            src=str(rule.get('source_cidr',rule.get('src','')))
            dst=str(rule.get('destination_cidr',rule.get('dst','')))
            if ipaddress.ip_address(flow['src']) not in ipaddress.ip_network(src,strict=False):continue
            if ipaddress.ip_address(flow['dst']) not in ipaddress.ip_network(dst,strict=False):continue
            if int(rule.get('destination_port',rule.get('port',-1)))!=flow['port']:continue
            return str(rule.get('action','deny')).lower()=='allow'
        return False
    except (ValueError,TypeError,KeyError):
        return False

def grade(item,key,response):
    """Return earned, available, correct, feedback; response comes from UI, not original item."""
    kind=item['interaction']['type']; points=key['points']; expected=key['answer']
    if kind=='single_select':
        earned=points if str(response)==str(expected) else 0
    elif kind=='multi_select':
        wanted=set(expected)
        received=set(response) if isinstance(response,(list,tuple,set)) else set()
        earned=points if received==wanted and len(received)==len(wanted) else 0
    elif kind=='text_entry':
        earned=points if any(_norm(response)==_norm(e) for e in expected) else 0
    elif kind=='numeric':
        try:
            n=float(str(response).replace(',','').replace('$','').strip())
            earned=points if math.isfinite(n) and abs(n-float(expected))<=float(item['interaction']['tolerance_abs']) else 0
        except (TypeError,ValueError):earned=0
    elif kind in ('matching','topology'):
        if not isinstance(response,dict): response={}
        earned=round(points*sum(response.get(k)==v for k,v in expected.items())/len(expected),2)
    elif kind in ('ordering','timeline'):
        if not _valid_unique_order(response,expected):earned=0
        else:earned=max(round(points*sum(a==b for a,b in zip(response,order))/len(order),2) for order in key.get('valid_orders',[expected]))
    elif kind=='simulated_cli':
        if not isinstance(response,dict):response={}
        good_cmd=any(command_tokens(response.get('command',''),item['interaction'].get('shell','bash'))==command_tokens(c,item['interaction'].get('shell','bash')) for c in expected['accepted_commands'])
        good_read=str(response.get('interpretation',''))==expected['interpretation']
        earned=round(points*((0.5 if good_cmd else 0)+(0.5 if good_read else 0)),2)
    elif kind=='firewall_rules':
        if not isinstance(response,list) or len(response)>item['interaction'].get('max_user_rules',5):
            earned=0
        else:
            positives=expected['allow_flows']; negatives=expected['deny_flows']
            correct_count=sum(_firewall_decision(response,f) for f in positives)+sum(not _firewall_decision(response,f) for f in negatives)
            earned=round(points*correct_count/(len(positives)+len(negatives)),2)
            # Full credit requires minimal exact-scope permit(s), not merely passing a handful of probes.
            def exact_rule(r,ref):
                try:
                    return (str(r.get('action','')).lower()=='allow' and
                      str(r.get('protocol',r.get('proto',''))).lower()==ref['proto'] and
                      ipaddress.ip_network(r.get('source_cidr',r.get('src')),strict=False)==ipaddress.ip_network(ref['src'],strict=False) and
                      ipaddress.ip_network(r.get('destination_cidr',r.get('dst')),strict=False)==ipaddress.ip_network(ref['dst'],strict=False) and
                      int(r.get('destination_port',r.get('port')))==ref['port'])
                except (TypeError,ValueError):return False
            desired=expected['solution_rules']
            if len(response)!=len(desired) or not all(any(exact_rule(r,d) for r in response) for d in desired):
                earned=min(earned,round(points*0.8,2))
    else:raise ValueError(f'Unsupported interaction type: {kind}')
    return {'earned':earned,'possible':points,'correct':earned==points,'feedback':key['explanation']}

if __name__=='__main__':
 import json,sys
 q,k,response=(json.loads(x) for x in sys.stdin.read().splitlines()[:3])
 print(json.dumps(grade(q,k,response)))
