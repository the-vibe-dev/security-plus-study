#!/usr/bin/env python3
from __future__ import annotations
import csv,json,collections,sys,math,re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from reference_grader import grade
ROOT=Path(__file__).resolve().parents[1]
def readj(path):return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]
Q=readj(ROOT/'bank'/'interactive_public.jsonl');A=readj(ROOT/'answer_keys'/'interactive_private.jsonl')
KNOW=readj(ROOT/'bank'/'knowledge_public.jsonl');KA=readj(ROOT/'answer_keys'/'knowledge_private.jsonl')
KI={x['id']:x for x in A}; QC={x['id']:x for x in Q}; KNOW_KEYS={x['id']:x for x in KA}
assert len(Q)==len(KI)==639
assert len(KNOW)==len(KA)==857
assert len(set(QC))==len(Q) and len(set(x['id'] for x in KNOW))==len(KNOW)
assert set(QC).isdisjoint(x['id'] for x in KNOW)
assert all('answer' not in x and 'correct_option' not in x and 'correct_answer' not in x for x in Q+KNOW)
pass_ok=collections.Counter(); fail_pos=[]; fail_neg=[]
for item in Q:
 k=KI[item['id']];t=item['interaction']['type'];expected=k['answer']
 if t=='simulated_cli':reply={'command':expected['accepted_commands'][0],'interpretation':expected['interpretation']}
 elif t=='firewall_rules':reply=[{'priority':j+1,'action':r['action'],'protocol':r['proto'],'source_cidr':r['src'],'destination_cidr':r['dst'],'destination_port':r['port']} for j,r in enumerate(expected['solution_rules'])]
 elif t=='text_entry':reply=expected[0]
 else:reply=expected
 result=grade(item,k,reply)
 if not result['correct']:fail_pos.append((item['id'],t,reply,result))
 wrong=grade(item,k,None)
 if wrong['correct']:fail_neg.append((item['id'],t,'None mistakenly got full credit'))
 pass_ok[t]+=1
 assert item['points']==k['points']
 assert item['domain_id'] in range(1,6)
 assert item['objective_id'].split('.')[0]==str(item['domain_id']),(item['id'],item['objective_id'],item['domain_id'])
 if t in ('single_select','multi_select'):
  opts=item['interaction'].get('options',[])
  if opts:assert len(opts)==len(set(map(str,opts))),item['id']
 if t=='matching':
  assert len(set(expected.values()))==len(expected)
  assert {x['id'] for x in item['interaction']['left']}==set(expected)
  assert set(expected.values())<={x['id'] for x in item['interaction']['right']}
 if t in ('ordering','timeline'):
  data=item['interaction'].get('cards',item['interaction'].get('events',[]))
  assert set(expected)=={x['id'] for x in data},item['id']
 if t=='firewall_rules':
  assert item['interaction']['default_policy']=='deny'
  assert all(p['src'] not in ['0.0.0.0/0','::/0'] for p in expected['solution_rules'])
 if t=='numeric':assert math.isfinite(float(expected))

assert not fail_pos,fail_pos[:5]
assert not fail_neg,fail_neg[:5]
for q in KNOW:
 k=KNOW_KEYS[q['id']]
 opts=q['interaction']['options']
 assert len(opts) in (4,5,6),q['id']
 labels={o['id'] for o in opts};strings={o['text'] for o in opts}
 assert len(labels)==len(opts) and len(strings)==len(opts),q['id']
 ans=k['answer']
 if isinstance(ans,list):assert 1<len(ans)<=len(opts) and set(ans)<=labels
 else:assert ans in labels,q['id']
 assert k['explanation'].strip(),q['id']

EXAMS=[json.loads((ROOT/'exams'/f'exam_{n:02d}.json').read_text()) for n in range(1,11)]
usage=collections.Counter();exrows=[]
for idx,e in enumerate(EXAMS,1):
 slots=e['items']; assert len(slots)==90
 roles=collections.Counter(slot['role'] for slot in slots)
 assert roles=={'knowledge':70,'short_interactive':15,'pbq':5},(idx,roles)
 domains=collections.Counter((next(q for q in KNOW if q['id']==slot['id']) if slot['role']=='knowledge' else QC[slot['id']])['domain_id'] for slot in slots)
 assert dict(domains)=={int(k):v for k,v in e['blueprint']['domain_target_counts'].items()},(idx,domains)
 practical=[QC[slot['id']] for slot in slots if slot['role']!='knowledge']
 topics=collections.Counter(p['topic'] for p in practical)
 for must in ['cli_tools','acronym_recall','firewall_setup','matching','in_order','ports_protocols','network_diagram','packet_analysis','risk_recovery_math','email_security','wireless_security','vuln_triage','identity_config']:
  assert topics[must]>0,(idx,must,dict(topics))
 for slot in slots:
  usage[slot['id']]+=1
  if slot['role']=='knowledge':assert slot['id'] in KNOW_KEYS
  else:assert slot['id'] in KI
 exrows.append({'exam':idx,'knowledge':roles['knowledge'],'interactive':roles['short_interactive'],'pbq':roles['pbq'],'domain_counts':dict(domains),'topics':dict(topics)})
assert len(usage)==900 and max(usage.values())==1

# A few explicit negative firewall test cases: off-subnet allow and over-broad permit lose points.
fw=next(q for q in Q if q['interaction']['type']=='firewall_rules');fk=KI[fw['id']]
broad={'priority':1,'action':'allow','protocol':fk['answer']['solution_rules'][0]['proto'],'source_cidr':'0.0.0.0/0','destination_cidr':'0.0.0.0/0','destination_port':fk['answer']['solution_rules'][0]['port']}
assert not grade(fw,fk,[broad])['correct']
assert not grade(fw,fk,[])['correct']

report={
 'status':'PASS','date':'2026-11-07','new_interactive_tested':len(Q),'new_interactive_correct_answers_full_score':len(Q),
 'new_interactive_empty_answers_not_full_score':len(Q),'knowledge_items_validated':len(KNOW),
 'grader_types_tested':dict(pass_ok),'exams_validated':len(EXAMS),'exam_items':sum(len(e['items']) for e in EXAMS),
 'distinct_exam_items':len(usage),'cross_exam_duplicates':0,'every_exam_has_all_13_required_topic_checks':True,
 'exam_breakdown':exrows,'negative_firewall_test':'PASS'
}
(ROOT/'VALIDATION_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='exam_breakdown'},indent=2))
